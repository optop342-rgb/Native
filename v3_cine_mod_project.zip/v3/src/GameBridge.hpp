// GameBridge.hpp - the ONLY place that talks to Minecraft's own code.
//
// STATUS: the command executor is not plugged in yet. Everything in the editor works without it,
// but the real game camera only follows the editor once GameBridge.cpp can run slash commands.
#pragma once
#include "CameraLink.hpp"
#include "Core.hpp"

namespace cm::game {

CameraLink& link();   // builds /camera /hud /fov_set /fade commands, sends them via the executor
void onEnter();       // cinematic mode switched ON
void onExit();        // cinematic mode switched OFF

}  // namespace cm::game
