#include "GameBridge.hpp"

#include <android/log.h>

// ---------------------------------------------------------------------------
// TODO - the ONE missing piece: a function that runs a slash command string inside the game
// (what happens when the player types /gamemode or /camera in chat, or what Script API's
// player.runCommand() calls). Once its signature is known:
//
//   1. resolve it:   uintptr_t addr = pl::memory::resolveSignature("AA BB ?? ...", "libminecraftpe.so");
//   2. write a small wrapper that builds the arguments the game expects from a std::string,
//   3. plug it in:   link().setExecutor([](const std::string& cmd) { return runGameCommand(cmd); });
//
// Until then link().connected() is false and no command is sent (the editor shows "NOT connected").
//
// Commands this mod will send (same ones the HeroCine add-on uses with runCommand):
//   hud @s hide all / hud @s reset all
//   camera @s set minecraft:free ease <t> linear pos <x y z> rot <pitch yaw>
//   camera @s fov_set <fov> <t> linear / camera @s fov_clear 0.15 linear
//   camera @s fade time <in> 0 <out>
//   camera @s clear
// ---------------------------------------------------------------------------

namespace cm::game {

CameraLink& link() {
  static CameraLink l;
  return l;
}

void onEnter() {
  __android_log_print(ANDROID_LOG_INFO, "CinematicMod", "cinematic mode ON (game link %s)",
                      link().connected() ? "connected" : "NOT connected - editor only");
  link().enter();
}

void onExit() {
  __android_log_print(ANDROID_LOG_INFO, "CinematicMod", "cinematic mode OFF");
  link().exit();
}

}  // namespace cm::game
