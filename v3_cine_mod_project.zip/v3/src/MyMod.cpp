// MyMod.cpp - LeviLauncher (Preloader SDK, `pl::` API) native mod entry point.
//
//   Mod Menu  ->  module "V3 Cine Mod" (toggle)
//   toggle ON ->  ImGui editor appears, the game is shown inside the preview box
//   [X]       ->  closes the editor and switches the module off again
#include <EGL/egl.h>
#include <dlfcn.h>

#include <filesystem>
#include <string>
#include <string_view>
#include <thread>

#include <pl/Input.hpp>
#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>
#include <pl/memory/Hook.hpp>

#include "Core.hpp"
#include "GameBridge.hpp"
#include "GlHost.hpp"

namespace {

constexpr const char* kModuleId = "cinematic_mod.mode";

// ---- eglSwapBuffers detour: draw our UI right before the frame is presented ----
using SwapFn = EGLBoolean (*)(EGLDisplay, EGLSurface);
SwapFn g_origSwap = nullptr;

EGLBoolean swapDetour(EGLDisplay display, EGLSurface surface) {
  cm::GlHost::instance().onSwap(display, surface);
  return g_origSwap ? g_origSwap(display, surface) : EGL_FALSE;
}

// Input callbacks cannot be unregistered, so they only forward to the (static) host.
bool g_inputRegistered = false;

}  // namespace

class CinematicMod {
 public:
  static CinematicMod& instance() {
    static CinematicMod i;
    return i;
  }

  CinematicMod() : mSelf(*ll::mod::NativeMod::current()) {}

  [[nodiscard]] ll::mod::NativeMod& getSelf() const { return mSelf; }

  bool load() {
    auto& self = getSelf();
    std::error_code ec;
    std::filesystem::create_directories(self.getDataDir(), ec);
    mLibFile = self.getDataDir() / "presets.txt";
    if (cm::loadLibrary(mLibFile, mLib)) self.getLogger().info("loaded presets from {}", mLibFile.string());
    return true;
  }

  bool enable() {
    auto& self = getSelf();
    auto& host = cm::GlHost::instance();

    cm::GlHost::Callbacks cb;
    cb.onSave = [this] { saveLibrary(); };
    cb.onClose = [] {
      // Called on the render thread: switch off now, and update the Mod Menu from another thread.
      cm::GlHost::instance().setActive(false);
      cm::game::onExit();
      std::thread([] { pl::modmenu::setModuleEnabled(kModuleId, false); }).detach();
    };
    cb.onCamera = [](const cm::Pose& p, float dt) { cm::game::link().update(p, dt); };
    cb.onFade = [](float seconds) { cm::game::link().fade(seconds); };
    cb.onSetRelative = [](bool rel) { cm::game::link().setRelative(rel); };
    cb.startPose = [] {
      // Relative mode: the player's position is the origin, camera starts at eye height.
      // (Once the player's real pose can be read, return it here instead.)
      cm::Pose p;
      p.x = 0.f; p.y = 1.62f; p.z = 0.f; p.pitch = 0.f; p.yaw = 0.f; p.fov = 70.f;
      return p;
    };
    cb.decorate = [](cm::EditorHost& h) {
      const auto& l = cm::game::link();
      h.linkConnected = l.connected();
      h.cmdSent = l.sent();
      h.cmdFailed = l.failed();
      h.linkRelative = l.relative();
    };
    cb.onKeyboard = [](bool show) {
      std::thread([show] {
        if (show) pl::input::showKeyboard();
        else pl::input::hideKeyboard();
      }).detach();
    };
    host.configure(&mLib, std::move(cb));
    host.clearShutdown();

    if (!g_inputRegistered) {
      g_inputRegistered = true;
      pl::input::registerTouchCallback([](const pl::input::TouchEvent& e) {
        return cm::GlHost::instance().onTouch(e.action, e.pointerId, e.x, e.y);
      });
      pl::input::registerKeyCallback([](const pl::input::KeyEvent& e) {
        return cm::GlHost::instance().onKey(e.keyCode, e.unicodeChar, e.isKeyDown);
      });
      pl::input::registerTextInputCallback(
          [](const pl::input::TextInputEvent& e) { return cm::GlHost::instance().onText(e.text); });
    }

    // Hook eglSwapBuffers (resolved from libEGL).
    void* target = dlsym(RTLD_DEFAULT, "eglSwapBuffers");
    if (!target) {
      self.getLogger().error("eglSwapBuffers not found");
      return false;
    }
    mSwapHook = pl::memory::HookHandle(target, reinterpret_cast<pl::memory::FuncPtr>(&swapDetour),
                                       reinterpret_cast<pl::memory::FuncPtr*>(&g_origSwap));
    if (!mSwapHook.installed()) {
      self.getLogger().error("failed to hook eglSwapBuffers");
      return false;
    }

    const bool ok =
        pl::modmenu::ModuleBuilder(kModuleId, "V3 Cine Mod")
            .modId(self.getId())
            .description("V3 Cine Mod: cinematic editor (segments, transitions, key points).")
            .defaultEnabled(false)
            .onToggle([](std::string_view, bool enabled) {
              cm::GlHost::instance().setActive(enabled);
              if (enabled) {
                cm::game::onEnter();
                // close the Mod Menu so the editor is visible right away
                std::thread([] { pl::modmenu::requestCloseMenu(); }).detach();
              } else {
                cm::game::onExit();
              }
            })
            .registerModule();
    if (!ok) self.getLogger().warn("Mod Menu module registration failed");
    self.getLogger().info("Cinematic mod enabled");
    return true;
  }

  bool disable() {
    auto& host = cm::GlHost::instance();
    host.setActive(false);
    cm::game::onExit();
    pl::modmenu::unregisterModule(kModuleId);
    saveLibrary();
    // ImGui / GL objects must be destroyed on the render thread: the (still installed) hook does it.
    host.requestShutdown();
    host.waitShutdown(300);
    mSwapHook.reset();
    return true;
  }

  bool unload() { return true; }

 private:
  void saveLibrary() {
    if (!cm::saveLibrary(mLibFile, mLib)) getSelf().getLogger().warn("could not save presets");
  }

  ll::mod::NativeMod& mSelf;
  cm::Library mLib;
  std::filesystem::path mLibFile;
  pl::memory::HookHandle mSwapHook;
};

PL_REGISTER_MOD(CinematicMod, CinematicMod::instance())
