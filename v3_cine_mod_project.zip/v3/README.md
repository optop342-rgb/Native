# V3 Cine Mod - LeviLauncher native mod (Android, arm64-v8a)

Mod Menu me **V3 Cine Mod** toggle -> game poori screen par dikhta hai. Teen chhote buttons se panels khulte hain:
`Editor` (top-left), `Tools` (top-right), `Timeline` (bottom). `X` = band.

## Kya naya hai (V3)
- **Panels video-editor jaise:** divider (grip dots wali line) ko kheench kar Editor / Tools / Timeline ka size badlo.
  Panel ke andar khaali jagah par drag karo to scroll hota hai. Sab band ho to game full screen.
- **XYZ coordinates hata diye.**
- **Segments (mcaddon jaisa):** N keys = N-1 segments (key1->key2, key2->key3 ...). Timeline par har segment ek rangeen strip
  (white / green / blue). Strip ka end-diamond kheench kar segment ka time badlo. Strip tap karo -> Tools me Duration + Ease type (32 ease, mcaddon wali list).
- **Transitions:** do segments ke beech `+` -> Instant / Hold (camera key par ruka rahe) / Fade (black dip), seconds ke saath (max 2s, mcaddon jaisa).
- **Key Points (pins):** `+ Pin` -> timeline par pin lagta hai, label likh sakte ho (jaise "yaha firework add karna"), kheench kar move.
- **Camera engine:** keys/segments/ease/transition se pose banta hai, `CameraLink` use `/camera`, `/hud`, `fov_set`, `fade` commands me badalta hai
  (wahi commands jo mcaddon runCommand se chalata hai).

## Build
1. Android NDK, `ANDROID_NDK_HOME` set karo. 2. `./build.sh` -> `dist/cinematic_mod/` + `dist/cinematic_mod.levipack`
   (internet chahiye; offline: `PRELOADER_SDK_DIR=/path/to/preloader-android ./build.sh`). PC nahi hai to GitHub Actions (`.github/workflows/build.yml`).
3. Folder ka naam `cinematic_mod` hi rakha hai, to ye purane version ko **replace** karta hai (do versions saath na rakho: dono eglSwapBuffers hook karenge).
4. PC par UI test: `make -C tests run`

## Sach: kya chalta hai, kya nahi
- **Phone par chalta dikha (V2 screenshots):** editor, game preview, touch, timeline. **V3 ka naya UI phone par abhi test nahi hua** (PC test 100+ checks pass, ASan clean).
- **Game camera abhi nahi hilega.** Wajah: game ke andar slash command chalane wala function abhi connect nahi hai.
  `src/GameBridge.cpp` me TODO hai. Tools me "GAME LINK: NOT connected" dikhta hai. Is wajah se player ek jagah rehta hai (humne touch game se le liye)
  aur joystick sirf editor ka camera badalta hai. `docs/CODEX_PROMPT.txt` Codex ko do, output mujhe do.
- Relative mode: abhi player ki position pata nahi, isliye camera commands `~x ~y ~z` (player ke relative) jate hain. Keys isi wajah se player ki khadi jagah ke relative hain.
- `/camera ... pos ... rot ...`, `fade`, `fov_set` ke syntax Bedrock docs / mcaddon se liye hain, **game me verify nahi hue**.
- Night vision / Full bright abhi sirf preview ka post-process hai.
- Tools me baaki mcaddon options (Lock On, Shake, Wall collision, Drift, Preset Shots, More POV) abhi nahi - camera chalne ke baad.

## Files
`src/Core.*` data+engine | `src/CameraLink.*` command builder | `src/Editor.*` UI | `src/TouchRouter.*` multi-touch |
`src/GlHost.*` EGL/GLES + ImGui | `src/GameBridge.*` game hook (TODO) | `src/MyMod.cpp` entry | presets: `<mod data dir>/presets.txt` (purani format-1 files auto convert)
