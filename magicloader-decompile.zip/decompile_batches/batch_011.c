// Batch 11/11
// Functions: 670


// ========================================
// Function: memmove
// Address: 005abf40
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memmove(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = (void *)(*(code *)PTR_memmove_005c6758)();
  return pvVar1;
}



// ========================================
// Function: __open_2
// Address: 005abf50
// ========================================

void __open_2(void)

{
  (*(code *)PTR___open_2_005c6760)();
  return;
}



// ========================================
// Function: load_active
// Address: 005abf60
// ========================================

void __thiscall pack_bridge::load_active(pack_bridge *this,int param_1,char *param_2,char *param_3)

{
  (*(code *)PTR_load_active_005c6768)(this,param_1);
  return;
}



// ========================================
// Function: load_all
// Address: 005abf70
// ========================================

void __thiscall pack_bridge::load_all(pack_bridge *this,int param_1,char *param_2)

{
  (*(code *)PTR_load_all_005c6770)(this,param_1);
  return;
}



// ========================================
// Function: read_from_module_dir
// Address: 005abf80
// ========================================

void native_mods::read_from_module_dir(int param_1)

{
  (*(code *)PTR_read_from_module_dir_005c6778)(param_1);
  return;
}



// ========================================
// Function: find_java
// Address: 005abf90
// ========================================

void __thiscall
pack_bridge::find_java(pack_bridge *this,int param_1,basic_string *param_2,char *param_3)

{
  (*(code *)PTR_find_java_005c6780)(this,param_1);
  return;
}



// ========================================
// Function: register_java
// Address: 005abfa0
// ========================================

void pack_bridge::register_java(int param_1,basic_string *param_2,char *param_3,vector *param_4)

{
  (*(code *)PTR_register_java_005c6788)(param_1);
  return;
}



// ========================================
// Function: install
// Address: 005abfb0
// ========================================

void pack_bridge::install(Pack *param_1,Pack *param_2,vector *param_3)

{
  (*(code *)PTR_install_005c6790)();
  return;
}



// ========================================
// Function: load_all
// Address: 005abfc0
// ========================================

void native_mods::load_all(magic_mod_api *param_1)

{
  (*(code *)PTR_load_all_005c6798)();
  return;
}



// ========================================
// Function: close
// Address: 005abfd0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int close(int __fd)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_close_005c67a0)(__fd);
  return iVar1;
}



// ========================================
// Function: pthread_create
// Address: 005abfe0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_create(pthread_t *__newthread,pthread_attr_t *__attr,__start_routine *__start_routine,
                  void *__arg)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_create_005c67a8)((int)__newthread);
  return iVar1;
}



// ========================================
// Function: pthread_detach
// Address: 005abff0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_detach(pthread_t __th)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_detach_005c67b0)((int)__th);
  return iVar1;
}



// ========================================
// Function: __openat_2
// Address: 005ac000
// ========================================

void __openat_2(void)

{
  (*(code *)PTR___openat_2_005c67b8)();
  return;
}



// ========================================
// Function: __errno
// Address: 005ac010
// ========================================

void __errno(void)

{
  (*(code *)PTR___errno_005c67c0)();
  return;
}



// ========================================
// Function: strerror
// Address: 005ac020
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strerror(int __errnum)

{
  char *pcVar1;
  
  pcVar1 = (char *)(*(code *)PTR_strerror_005c67c8)(__errnum);
  return pcVar1;
}



// ========================================
// Function: read
// Address: 005ac030
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

ssize_t read(int __fd,void *__buf,size_t __nbytes)

{
  ssize_t sVar1;
  
  sVar1 = (*(code *)PTR_read_005c67d0)(__fd);
  return sVar1;
}



// ========================================
// Function: fdopendir
// Address: 005ac040
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

DIR * fdopendir(int __fd)

{
  DIR *pDVar1;
  
  pDVar1 = (DIR *)(*(code *)PTR_fdopendir_005c67d8)(__fd);
  return pDVar1;
}



// ========================================
// Function: readdir
// Address: 005ac050
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

dirent * readdir(DIR *__dirp)

{
  dirent *pdVar1;
  
  pdVar1 = (dirent *)(*(code *)PTR_readdir_005c67e0)();
  return pdVar1;
}



// ========================================
// Function: fstatat
// Address: 005ac060
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fstatat(int __fd,char *__file,stat *__buf,int __flag)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_fstatat_005c67e8)(__fd,__file,__buf,__flag);
  return iVar1;
}



// ========================================
// Function: __emplace_back_slow_path<std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>const&,std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>>
// Address: 005ac070
// ========================================

pair * __thiscall
std::__ndk1::
vector<std::__ndk1::pair<std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>,std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>>,std::__ndk1::allocator<std::__ndk1::pair<std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>,std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>>>>
::
__emplace_back_slow_path<std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>const&,std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>>
          (vector<std::__ndk1::pair<std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>,std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>>,std::__ndk1::allocator<std::__ndk1::pair<std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>,std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>>>>
           *this,basic_string *param_1,basic_string *param_2)

{
  pair *ppVar1;
  
  ppVar1 = (pair *)(*(code *)
                     PTR___emplace_back_slow_path<std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>const&,std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>>_005c67f0
                   )();
  return ppVar1;
}



// ========================================
// Function: closedir
// Address: 005ac080
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int closedir(DIR *__dirp)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_closedir_005c67f8)((int)__dirp);
  return iVar1;
}



// ========================================
// Function: strcasecmp
// Address: 005ac090
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strcasecmp(char *__s1,char *__s2)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_strcasecmp_005c6800)((int)__s1);
  return iVar1;
}



// ========================================
// Function: memcpy
// Address: 005ac0a0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memcpy(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = (void *)(*(code *)PTR_memcpy_005c6808)();
  return pvVar1;
}



// ========================================
// Function: __push_back_slow_path<pack_bridge::Pack>
// Address: 005ac0b0
// ========================================

Pack * __thiscall
std::__ndk1::vector<pack_bridge::Pack,std::__ndk1::allocator<pack_bridge::Pack>>::
__push_back_slow_path<pack_bridge::Pack>
          (vector<pack_bridge::Pack,std::__ndk1::allocator<pack_bridge::Pack>> *this,Pack *param_1)

{
  Pack *pPVar1;
  
  pPVar1 = (Pack *)(*(code *)PTR___push_back_slow_path<pack_bridge::Pack>_005c6810)();
  return pPVar1;
}



// ========================================
// Function: __push_back_slow_path<pack_bridge::JavaPack>
// Address: 005ac0c0
// ========================================

JavaPack * __thiscall
std::__ndk1::vector<pack_bridge::JavaPack,std::__ndk1::allocator<pack_bridge::JavaPack>>::
__push_back_slow_path<pack_bridge::JavaPack>
          (vector<pack_bridge::JavaPack,std::__ndk1::allocator<pack_bridge::JavaPack>> *this,
          JavaPack *param_1)

{
  JavaPack *pJVar1;
  
  pJVar1 = (JavaPack *)(*(code *)PTR___push_back_slow_path<pack_bridge::JavaPack>_005c6818)();
  return pJVar1;
}



// ========================================
// Function: mkdirat
// Address: 005ac0d0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mkdirat(int __fd,char *__path,__mode_t __mode)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_mkdirat_005c6820)(__fd,__path,__mode);
  return iVar1;
}



// ========================================
// Function: __emplace_back_slow_path<char_const(&)[256]>
// Address: 005ac0e0
// ========================================

basic_string * __thiscall
std::__ndk1::
vector<std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>,std::__ndk1::allocator<std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>>>
::__emplace_back_slow_path<char_const(&)[256]>
          (vector<std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>,std::__ndk1::allocator<std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>>>
           *this,char *param_1)

{
  basic_string *pbVar1;
  
  pbVar1 = (basic_string *)(*(code *)PTR___emplace_back_slow_path<char_const(&)[256]>_005c6828)();
  return pbVar1;
}



// ========================================
// Function: strcmp
// Address: 005ac0f0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strcmp(char *__s1,char *__s2)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_strcmp_005c6830)((int)__s1);
  return iVar1;
}



// ========================================
// Function: __introsort<std::__ndk1::_ClassicAlgPolicy,std::__ndk1::__less<void,void>&,std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>*,false>
// Address: 005ac100
// ========================================

void std::__ndk1::
     __introsort<std::__ndk1::_ClassicAlgPolicy,std::__ndk1::__less<void,void>&,std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>*,false>
               (void)

{
  (*(code *)
    PTR___introsort<std::__ndk1::_ClassicAlgPolicy,std::__ndk1::__less<void,void>&,std::__ndk1::basic_string<char,std::__ndk1::char_traits<char>,std::__ndk1::allocator<char>>*,false>_005c6838
  )();
  return;
}



// ========================================
// Function: dirfd
// Address: 005ac110
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int dirfd(DIR *__dirp)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_dirfd_005c6840)((int)__dirp);
  return iVar1;
}



// ========================================
// Function: fstat
// Address: 005ac120
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fstat(int __fd,stat *__buf)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_fstat_005c6848)(__fd);
  return iVar1;
}



// ========================================
// Function: __read_chk
// Address: 005ac130
// ========================================

void __read_chk(void)

{
  (*(code *)PTR___read_chk_005c6850)();
  return;
}



// ========================================
// Function: syscall
// Address: 005ac140
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long syscall(long __sysno,...)

{
  long lVar1;
  
  lVar1 = (*(code *)PTR_syscall_005c6858)();
  return lVar1;
}



// ========================================
// Function: __write_chk
// Address: 005ac150
// ========================================

void __write_chk(void)

{
  (*(code *)PTR___write_chk_005c6860)();
  return;
}



// ========================================
// Function: android_dlopen_ext
// Address: 005ac160
// ========================================

void android_dlopen_ext(void)

{
  (*(code *)PTR_android_dlopen_ext_005c6868)();
  return;
}



// ========================================
// Function: dlsym
// Address: 005ac170
// ========================================

void dlsym(void)

{
  (*(code *)PTR_dlsym_005c6870)();
  return;
}



// ========================================
// Function: dlerror
// Address: 005ac180
// ========================================

void dlerror(void)

{
  (*(code *)PTR_dlerror_005c6878)();
  return;
}



// ========================================
// Function: memset
// Address: 005ac190
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memset(void *__s,int __c,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = (void *)(*(code *)PTR_memset_005c6880)(__s,__c);
  return pvVar1;
}



// ========================================
// Function: memcmp
// Address: 005ac1a0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int memcmp(void *__s1,void *__s2,size_t __n)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_memcmp_005c6888)((int)__s1);
  return iVar1;
}



// ========================================
// Function: dlopen
// Address: 005ac1b0
// ========================================

void dlopen(void)

{
  (*(code *)PTR_dlopen_005c6890)();
  return;
}



// ========================================
// Function: usleep
// Address: 005ac1c0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int usleep(__useconds_t __useconds)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_usleep_005c6898)(__useconds);
  return iVar1;
}



// ========================================
// Function: eglQuerySurface
// Address: 005ac1d0
// ========================================

void eglQuerySurface(void)

{
  (*(code *)PTR_eglQuerySurface_005c68a0)();
  return;
}



// ========================================
// Function: __system_property_get
// Address: 005ac1e0
// ========================================

void __system_property_get(void)

{
  (*(code *)PTR___system_property_get_005c68a8)();
  return;
}



// ========================================
// Function: fopen
// Address: 005ac1f0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

FILE * fopen(char *__filename,char *__modes)

{
  FILE *pFVar1;
  
  pFVar1 = (FILE *)(*(code *)PTR_fopen_005c68b0)();
  return pFVar1;
}



// ========================================
// Function: fgets
// Address: 005ac200
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * fgets(char *__s,int __n,FILE *__stream)

{
  char *pcVar1;
  
  pcVar1 = (char *)(*(code *)PTR_fgets_005c68b8)(__s,__n);
  return pcVar1;
}



// ========================================
// Function: strstr
// Address: 005ac210
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strstr(char *__haystack,char *__needle)

{
  char *pcVar1;
  
  pcVar1 = (char *)(*(code *)PTR_strstr_005c68c0)();
  return pcVar1;
}



// ========================================
// Function: fclose
// Address: 005ac220
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fclose(FILE *__stream)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_fclose_005c68c8)((int)__stream);
  return iVar1;
}



// ========================================
// Function: sscanf
// Address: 005ac230
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sscanf(char *__s,char *__format,...)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_sscanf_005c68d0)((int)__s);
  return iVar1;
}



// ========================================
// Function: sysconf
// Address: 005ac240
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long sysconf(int __name)

{
  long lVar1;
  
  lVar1 = (*(code *)PTR_sysconf_005c68d8)(__name);
  return lVar1;
}



// ========================================
// Function: mprotect
// Address: 005ac250
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mprotect(void *__addr,size_t __len,int __prot)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_mprotect_005c68e0)((int)__addr,__len,__prot);
  return iVar1;
}



// ========================================
// Function: eglDestroyContext
// Address: 005ac260
// ========================================

void eglDestroyContext(void)

{
  (*(code *)PTR_eglDestroyContext_005c68e8)();
  return;
}



// ========================================
// Function: eglMakeCurrent
// Address: 005ac270
// ========================================

void eglMakeCurrent(void)

{
  (*(code *)PTR_eglMakeCurrent_005c68f0)();
  return;
}



// ========================================
// Function: eglGetCurrentContext
// Address: 005ac280
// ========================================

void eglGetCurrentContext(void)

{
  (*(code *)PTR_eglGetCurrentContext_005c68f8)();
  return;
}



// ========================================
// Function: fdopen
// Address: 005ac290
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

FILE * fdopen(int __fd,char *__modes)

{
  FILE *pFVar1;
  
  pFVar1 = (FILE *)(*(code *)PTR_fdopen_005c6900)(__fd);
  return pFVar1;
}



// ========================================
// Function: mmap
// Address: 005ac2a0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * mmap(void *__addr,size_t __len,int __prot,int __flags,int __fd,__off_t __offset)

{
  void *pvVar1;
  
  pvVar1 = (void *)(*(code *)PTR_mmap_005c6908)(__addr,__len,__prot,__flags,__fd);
  return pvVar1;
}



// ========================================
// Function: pwrite
// Address: 005ac2b0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

ssize_t pwrite(int __fd,void *__buf,size_t __n,__off_t __offset)

{
  ssize_t sVar1;
  
  sVar1 = (*(code *)PTR_pwrite_005c6910)(__fd);
  return sVar1;
}



// ========================================
// Function: getpagesize
// Address: 005ac2c0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int getpagesize(void)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_getpagesize_005c6918)();
  return iVar1;
}



// ========================================
// Function: munmap
// Address: 005ac2d0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int munmap(void *__addr,size_t __len)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_munmap_005c6920)((int)__addr);
  return iVar1;
}



// ========================================
// Function: process_vm_readv
// Address: 005ac2e0
// ========================================

void process_vm_readv(void)

{
  (*(code *)PTR_process_vm_readv_005c6928)();
  return;
}



// ========================================
// Function: __vsnprintf_chk
// Address: 005ac2f0
// ========================================

void __vsnprintf_chk(void)

{
  (*(code *)PTR___vsnprintf_chk_005c6930)();
  return;
}



// ========================================
// Function: glGetError
// Address: 005ac300
// ========================================

void glGetError(void)

{
  (*(code *)PTR_glGetError_005c6938)();
  return;
}



// ========================================
// Function: glIsTexture
// Address: 005ac310
// ========================================

void glIsTexture(void)

{
  (*(code *)PTR_glIsTexture_005c6940)();
  return;
}



// ========================================
// Function: glGetIntegerv
// Address: 005ac320
// ========================================

void glGetIntegerv(void)

{
  (*(code *)PTR_glGetIntegerv_005c6948)();
  return;
}



// ========================================
// Function: glBindTexture
// Address: 005ac330
// ========================================

void glBindTexture(void)

{
  (*(code *)PTR_glBindTexture_005c6950)();
  return;
}



// ========================================
// Function: glGetTexLevelParameteriv
// Address: 005ac340
// ========================================

void glGetTexLevelParameteriv(void)

{
  (*(code *)PTR_glGetTexLevelParameteriv_005c6958)();
  return;
}



// ========================================
// Function: glIsEnabled
// Address: 005ac350
// ========================================

void glIsEnabled(void)

{
  (*(code *)PTR_glIsEnabled_005c6960)();
  return;
}



// ========================================
// Function: glGetFloatv
// Address: 005ac360
// ========================================

void glGetFloatv(void)

{
  (*(code *)PTR_glGetFloatv_005c6968)();
  return;
}



// ========================================
// Function: glGetUniformiv
// Address: 005ac370
// ========================================

void glGetUniformiv(void)

{
  (*(code *)PTR_glGetUniformiv_005c6970)();
  return;
}



// ========================================
// Function: glActiveTexture
// Address: 005ac380
// ========================================

void glActiveTexture(void)

{
  (*(code *)PTR_glActiveTexture_005c6978)();
  return;
}



// ========================================
// Function: glIsProgram
// Address: 005ac390
// ========================================

void glIsProgram(void)

{
  (*(code *)PTR_glIsProgram_005c6980)();
  return;
}



// ========================================
// Function: glGetProgramiv
// Address: 005ac3a0
// ========================================

void glGetProgramiv(void)

{
  (*(code *)PTR_glGetProgramiv_005c6988)();
  return;
}



// ========================================
// Function: glGetActiveUniform
// Address: 005ac3b0
// ========================================

void glGetActiveUniform(void)

{
  (*(code *)PTR_glGetActiveUniform_005c6990)();
  return;
}



// ========================================
// Function: __strchr_chk
// Address: 005ac3c0
// ========================================

void __strchr_chk(void)

{
  (*(code *)PTR___strchr_chk_005c6998)();
  return;
}



// ========================================
// Function: glGetUniformLocation
// Address: 005ac3d0
// ========================================

void glGetUniformLocation(void)

{
  (*(code *)PTR_glGetUniformLocation_005c69a0)();
  return;
}



// ========================================
// Function: glGetActiveAttrib
// Address: 005ac3e0
// ========================================

void glGetActiveAttrib(void)

{
  (*(code *)PTR_glGetActiveAttrib_005c69a8)();
  return;
}



// ========================================
// Function: glGetAttribLocation
// Address: 005ac3f0
// ========================================

void glGetAttribLocation(void)

{
  (*(code *)PTR_glGetAttribLocation_005c69b0)();
  return;
}



// ========================================
// Function: glDeleteTextures
// Address: 005ac400
// ========================================

void glDeleteTextures(void)

{
  (*(code *)PTR_glDeleteTextures_005c69b8)();
  return;
}



// ========================================
// Function: glGenFramebuffers
// Address: 005ac410
// ========================================

void glGenFramebuffers(void)

{
  (*(code *)PTR_glGenFramebuffers_005c69c0)();
  return;
}



// ========================================
// Function: glGenTextures
// Address: 005ac420
// ========================================

void glGenTextures(void)

{
  (*(code *)PTR_glGenTextures_005c69c8)();
  return;
}



// ========================================
// Function: glTexImage2D
// Address: 005ac430
// ========================================

void glTexImage2D(void)

{
  (*(code *)PTR_glTexImage2D_005c69d0)();
  return;
}



// ========================================
// Function: glTexParameteri
// Address: 005ac440
// ========================================

void glTexParameteri(void)

{
  (*(code *)PTR_glTexParameteri_005c69d8)();
  return;
}



// ========================================
// Function: glFramebufferTexture2D
// Address: 005ac450
// ========================================

void glFramebufferTexture2D(void)

{
  (*(code *)PTR_glFramebufferTexture2D_005c69e0)();
  return;
}



// ========================================
// Function: glCheckFramebufferStatus
// Address: 005ac460
// ========================================

void glCheckFramebufferStatus(void)

{
  (*(code *)PTR_glCheckFramebufferStatus_005c69e8)();
  return;
}



// ========================================
// Function: glDisable
// Address: 005ac470
// ========================================

void glDisable(void)

{
  (*(code *)PTR_glDisable_005c69f0)();
  return;
}



// ========================================
// Function: glFinish
// Address: 005ac480
// ========================================

void glFinish(void)

{
  (*(code *)PTR_glFinish_005c69f8)();
  return;
}



// ========================================
// Function: __strcpy_chk
// Address: 005ac490
// ========================================

void __strcpy_chk(void)

{
  (*(code *)PTR___strcpy_chk_005c6a00)();
  return;
}



// ========================================
// Function: strtoul
// Address: 005ac4a0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

ulong strtoul(char *__nptr,char **__endptr,int __base)

{
  ulong uVar1;
  
  uVar1 = (*(code *)PTR_strtoul_005c6a08)(__nptr,__endptr,__base);
  return uVar1;
}



// ========================================
// Function: eglChooseConfig
// Address: 005ac4b0
// ========================================

void eglChooseConfig(void)

{
  (*(code *)PTR_eglChooseConfig_005c6a10)();
  return;
}



// ========================================
// Function: eglGetConfigAttrib
// Address: 005ac4c0
// ========================================

void eglGetConfigAttrib(void)

{
  (*(code *)PTR_eglGetConfigAttrib_005c6a18)();
  return;
}



// ========================================
// Function: glBindFramebuffer
// Address: 005ac4d0
// ========================================

void glBindFramebuffer(void)

{
  (*(code *)PTR_glBindFramebuffer_005c6a20)();
  return;
}



// ========================================
// Function: glBlitFramebuffer
// Address: 005ac4e0
// ========================================

void glBlitFramebuffer(void)

{
  (*(code *)PTR_glBlitFramebuffer_005c6a28)();
  return;
}



// ========================================
// Function: glDrawBuffers
// Address: 005ac4f0
// ========================================

void glDrawBuffers(void)

{
  (*(code *)PTR_glDrawBuffers_005c6a30)();
  return;
}



// ========================================
// Function: glViewport
// Address: 005ac500
// ========================================

void glViewport(void)

{
  (*(code *)PTR_glViewport_005c6a38)();
  return;
}



// ========================================
// Function: glColorMask
// Address: 005ac510
// ========================================

void glColorMask(void)

{
  (*(code *)PTR_glColorMask_005c6a40)();
  return;
}



// ========================================
// Function: glReadPixels
// Address: 005ac520
// ========================================

void glReadPixels(void)

{
  (*(code *)PTR_glReadPixels_005c6a48)();
  return;
}



// ========================================
// Function: glGetVertexAttribiv
// Address: 005ac530
// ========================================

void glGetVertexAttribiv(void)

{
  (*(code *)PTR_glGetVertexAttribiv_005c6a50)();
  return;
}



// ========================================
// Function: glGetVertexAttribPointerv
// Address: 005ac540
// ========================================

void glGetVertexAttribPointerv(void)

{
  (*(code *)PTR_glGetVertexAttribPointerv_005c6a58)();
  return;
}



// ========================================
// Function: glGetAttachedShaders
// Address: 005ac550
// ========================================

void glGetAttachedShaders(void)

{
  (*(code *)PTR_glGetAttachedShaders_005c6a60)();
  return;
}



// ========================================
// Function: glGetShaderiv
// Address: 005ac560
// ========================================

void glGetShaderiv(void)

{
  (*(code *)PTR_glGetShaderiv_005c6a68)();
  return;
}



// ========================================
// Function: glGetShaderSource
// Address: 005ac570
// ========================================

void glGetShaderSource(void)

{
  (*(code *)PTR_glGetShaderSource_005c6a70)();
  return;
}



// ========================================
// Function: glGetBooleanv
// Address: 005ac580
// ========================================

void glGetBooleanv(void)

{
  (*(code *)PTR_glGetBooleanv_005c6a78)();
  return;
}



// ========================================
// Function: fmodf
// Address: 005ac590
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float fmodf(float __x,float __y)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_fmodf_005c6a80)();
  return fVar1;
}



// ========================================
// Function: glTexStorage2D
// Address: 005ac5a0
// ========================================

void glTexStorage2D(void)

{
  (*(code *)PTR_glTexStorage2D_005c6a88)();
  return;
}



// ========================================
// Function: glEnable
// Address: 005ac5b0
// ========================================

void glEnable(void)

{
  (*(code *)PTR_glEnable_005c6a90)();
  return;
}



// ========================================
// Function: glDepthFunc
// Address: 005ac5c0
// ========================================

void glDepthFunc(void)

{
  (*(code *)PTR_glDepthFunc_005c6a98)();
  return;
}



// ========================================
// Function: glDepthMask
// Address: 005ac5d0
// ========================================

void glDepthMask(void)

{
  (*(code *)PTR_glDepthMask_005c6aa0)();
  return;
}



// ========================================
// Function: glPolygonOffset
// Address: 005ac5e0
// ========================================

void glPolygonOffset(void)

{
  (*(code *)PTR_glPolygonOffset_005c6aa8)();
  return;
}



// ========================================
// Function: glClear
// Address: 005ac5f0
// ========================================

void glClear(void)

{
  (*(code *)PTR_glClear_005c6ab0)();
  return;
}



// ========================================
// Function: glUniformMatrix4fv
// Address: 005ac600
// ========================================

void glUniformMatrix4fv(void)

{
  (*(code *)PTR_glUniformMatrix4fv_005c6ab8)();
  return;
}



// ========================================
// Function: glBindVertexArray
// Address: 005ac610
// ========================================

void glBindVertexArray(void)

{
  (*(code *)PTR_glBindVertexArray_005c6ac0)();
  return;
}



// ========================================
// Function: glUniform1i
// Address: 005ac620
// ========================================

void glUniform1i(void)

{
  (*(code *)PTR_glUniform1i_005c6ac8)();
  return;
}



// ========================================
// Function: glBindSampler
// Address: 005ac630
// ========================================

void glBindSampler(void)

{
  (*(code *)PTR_glBindSampler_005c6ad0)();
  return;
}



// ========================================
// Function: glUniform1f
// Address: 005ac640
// ========================================

void glUniform1f(void)

{
  (*(code *)PTR_glUniform1f_005c6ad8)();
  return;
}



// ========================================
// Function: glBindBuffer
// Address: 005ac650
// ========================================

void glBindBuffer(void)

{
  (*(code *)PTR_glBindBuffer_005c6ae0)();
  return;
}



// ========================================
// Function: glGenVertexArrays
// Address: 005ac660
// ========================================

void glGenVertexArrays(void)

{
  (*(code *)PTR_glGenVertexArrays_005c6ae8)();
  return;
}



// ========================================
// Function: glGenSamplers
// Address: 005ac670
// ========================================

void glGenSamplers(void)

{
  (*(code *)PTR_glGenSamplers_005c6af0)();
  return;
}



// ========================================
// Function: glSamplerParameteri
// Address: 005ac680
// ========================================

void glSamplerParameteri(void)

{
  (*(code *)PTR_glSamplerParameteri_005c6af8)();
  return;
}



// ========================================
// Function: glReadBuffer
// Address: 005ac690
// ========================================

void glReadBuffer(void)

{
  (*(code *)PTR_glReadBuffer_005c6b00)();
  return;
}



// ========================================
// Function: sincosf
// Address: 005ac6a0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void sincosf(float __x,float *__sinx,float *__cosx)

{
  (*(code *)PTR_sincosf_005c6b08)();
  return;
}



// ========================================
// Function: atan2f
// Address: 005ac6b0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float atan2f(float __y,float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_atan2f_005c6b10)();
  return fVar1;
}



// ========================================
// Function: vsnprintf
// Address: 005ac6c0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vsnprintf(char *__s,size_t __maxlen,char *__format,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_vsnprintf_005c6b18)((int)__s);
  return iVar1;
}



// ========================================
// Function: glGetString
// Address: 005ac6d0
// ========================================

void glGetString(void)

{
  (*(code *)PTR_glGetString_005c6b20)();
  return;
}



// ========================================
// Function: eglGetProcAddress
// Address: 005ac6e0
// ========================================

void eglGetProcAddress(void)

{
  (*(code *)PTR_eglGetProcAddress_005c6b28)();
  return;
}



// ========================================
// Function: glUniform2f
// Address: 005ac6f0
// ========================================

void glUniform2f(void)

{
  (*(code *)PTR_glUniform2f_005c6b30)();
  return;
}



// ========================================
// Function: glDrawArrays
// Address: 005ac700
// ========================================

void glDrawArrays(void)

{
  (*(code *)PTR_glDrawArrays_005c6b38)();
  return;
}



// ========================================
// Function: exp2f
// Address: 005ac710
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float exp2f(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_exp2f_005c6b40)();
  return fVar1;
}



// ========================================
// Function: glDeleteFramebuffers
// Address: 005ac720
// ========================================

void glDeleteFramebuffers(void)

{
  (*(code *)PTR_glDeleteFramebuffers_005c6b48)();
  return;
}



// ========================================
// Function: glScissor
// Address: 005ac730
// ========================================

void glScissor(void)

{
  (*(code *)PTR_glScissor_005c6b50)();
  return;
}



// ========================================
// Function: glUniform4f
// Address: 005ac740
// ========================================

void glUniform4f(void)

{
  (*(code *)PTR_glUniform4f_005c6b58)();
  return;
}



// ========================================
// Function: pthread_setspecific
// Address: 005ac750
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setspecific(pthread_key_t __key,void *__pointer)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_setspecific_005c6b60)(__key);
  return iVar1;
}



// ========================================
// Function: atoi
// Address: 005ac760
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int atoi(char *__nptr)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_atoi_005c6b68)((int)__nptr);
  return iVar1;
}



// ========================================
// Function: glClearBufferfv
// Address: 005ac770
// ========================================

void glClearBufferfv(void)

{
  (*(code *)PTR_glClearBufferfv_005c6b70)();
  return;
}



// ========================================
// Function: glUniform3fv
// Address: 005ac780
// ========================================

void glUniform3fv(void)

{
  (*(code *)PTR_glUniform3fv_005c6b78)();
  return;
}



// ========================================
// Function: glDeleteBuffers
// Address: 005ac790
// ========================================

void glDeleteBuffers(void)

{
  (*(code *)PTR_glDeleteBuffers_005c6b80)();
  return;
}



// ========================================
// Function: glDeleteSync
// Address: 005ac7a0
// ========================================

void glDeleteSync(void)

{
  (*(code *)PTR_glDeleteSync_005c6b88)();
  return;
}



// ========================================
// Function: glGenBuffers
// Address: 005ac7b0
// ========================================

void glGenBuffers(void)

{
  (*(code *)PTR_glGenBuffers_005c6b90)();
  return;
}



// ========================================
// Function: glBufferData
// Address: 005ac7c0
// ========================================

void glBufferData(void)

{
  (*(code *)PTR_glBufferData_005c6b98)();
  return;
}



// ========================================
// Function: glFenceSync
// Address: 005ac7d0
// ========================================

void glFenceSync(void)

{
  (*(code *)PTR_glFenceSync_005c6ba0)();
  return;
}



// ========================================
// Function: glClientWaitSync
// Address: 005ac7e0
// ========================================

void glClientWaitSync(void)

{
  (*(code *)PTR_glClientWaitSync_005c6ba8)();
  return;
}



// ========================================
// Function: glMapBufferRange
// Address: 005ac7f0
// ========================================

void glMapBufferRange(void)

{
  (*(code *)PTR_glMapBufferRange_005c6bb0)();
  return;
}



// ========================================
// Function: glUnmapBuffer
// Address: 005ac800
// ========================================

void glUnmapBuffer(void)

{
  (*(code *)PTR_glUnmapBuffer_005c6bb8)();
  return;
}



// ========================================
// Function: glPixelStorei
// Address: 005ac810
// ========================================

void glPixelStorei(void)

{
  (*(code *)PTR_glPixelStorei_005c6bc0)();
  return;
}



// ========================================
// Function: glFlush
// Address: 005ac820
// ========================================

void glFlush(void)

{
  (*(code *)PTR_glFlush_005c6bc8)();
  return;
}



// ========================================
// Function: glUniform4fv
// Address: 005ac830
// ========================================

void glUniform4fv(void)

{
  (*(code *)PTR_glUniform4fv_005c6bd0)();
  return;
}



// ========================================
// Function: log2f
// Address: 005ac840
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float log2f(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_log2f_005c6bd8)();
  return fVar1;
}



// ========================================
// Function: glEnableVertexAttribArray
// Address: 005ac850
// ========================================

void glEnableVertexAttribArray(void)

{
  (*(code *)PTR_glEnableVertexAttribArray_005c6be0)();
  return;
}



// ========================================
// Function: glVertexAttribPointer
// Address: 005ac860
// ========================================

void glVertexAttribPointer(void)

{
  (*(code *)PTR_glVertexAttribPointer_005c6be8)();
  return;
}



// ========================================
// Function: glDisableVertexAttribArray
// Address: 005ac870
// ========================================

void glDisableVertexAttribArray(void)

{
  (*(code *)PTR_glDisableVertexAttribArray_005c6bf0)();
  return;
}



// ========================================
// Function: glVertexAttrib4f
// Address: 005ac880
// ========================================

void glVertexAttrib4f(void)

{
  (*(code *)PTR_glVertexAttrib4f_005c6bf8)();
  return;
}



// ========================================
// Function: glDrawElements
// Address: 005ac890
// ========================================

void glDrawElements(void)

{
  (*(code *)PTR_glDrawElements_005c6c00)();
  return;
}



// ========================================
// Function: glDeleteVertexArrays
// Address: 005ac8a0
// ========================================

void glDeleteVertexArrays(void)

{
  (*(code *)PTR_glDeleteVertexArrays_005c6c08)();
  return;
}



// ========================================
// Function: memchr
// Address: 005ac8b0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memchr(void *__s,int __c,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = (void *)(*(code *)PTR_memchr_005c6c10)(__s,__c);
  return pvVar1;
}



// ========================================
// Function: glClearColor
// Address: 005ac8c0
// ========================================

void glClearColor(void)

{
  (*(code *)PTR_glClearColor_005c6c18)();
  return;
}



// ========================================
// Function: glTexImage3D
// Address: 005ac8d0
// ========================================

void glTexImage3D(void)

{
  (*(code *)PTR_glTexImage3D_005c6c20)();
  return;
}



// ========================================
// Function: atof
// Address: 005ac8e0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double atof(char *__nptr)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_atof_005c6c28)();
  return dVar1;
}



// ========================================
// Function: strtof
// Address: 005ac8f0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float strtof(char *__nptr,char **__endptr)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_strtof_005c6c30)();
  return fVar1;
}



// ========================================
// Function: glUseProgram
// Address: 005ac900
// ========================================

void glUseProgram(void)

{
  (*(code *)PTR_glUseProgram_005c6c38)();
  return;
}



// ========================================
// Function: glUniform2fv
// Address: 005ac910
// ========================================

void glUniform2fv(void)

{
  (*(code *)PTR_glUniform2fv_005c6c40)();
  return;
}



// ========================================
// Function: remove
// Address: 005ac920
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int remove(char *__filename)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_remove_005c6c48)((int)__filename);
  return iVar1;
}



// ========================================
// Function: fputs
// Address: 005ac930
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fputs(char *__s,FILE *__stream)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_fputs_005c6c50)((int)__s);
  return iVar1;
}



// ========================================
// Function: access
// Address: 005ac940
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int access(char *__name,int __type)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_access_005c6c58)((int)__name,__type);
  return iVar1;
}



// ========================================
// Function: eglGetCurrentDisplay
// Address: 005ac950
// ========================================

void eglGetCurrentDisplay(void)

{
  (*(code *)PTR_eglGetCurrentDisplay_005c6c60)();
  return;
}



// ========================================
// Function: eglQueryContext
// Address: 005ac960
// ========================================

void eglQueryContext(void)

{
  (*(code *)PTR_eglQueryContext_005c6c68)();
  return;
}



// ========================================
// Function: eglCreateContext
// Address: 005ac970
// ========================================

void eglCreateContext(void)

{
  (*(code *)PTR_eglCreateContext_005c6c70)();
  return;
}



// ========================================
// Function: eglInitialize
// Address: 005ac980
// ========================================

void eglInitialize(void)

{
  (*(code *)PTR_eglInitialize_005c6c78)();
  return;
}



// ========================================
// Function: eglCreatePbufferSurface
// Address: 005ac990
// ========================================

void eglCreatePbufferSurface(void)

{
  (*(code *)PTR_eglCreatePbufferSurface_005c6c80)();
  return;
}



// ========================================
// Function: eglGetError
// Address: 005ac9a0
// ========================================

void eglGetError(void)

{
  (*(code *)PTR_eglGetError_005c6c88)();
  return;
}



// ========================================
// Function: pthread_attr_init
// Address: 005ac9b0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_attr_init(pthread_attr_t *__attr)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_attr_init_005c6c90)((int)__attr);
  return iVar1;
}



// ========================================
// Function: pthread_attr_setstacksize
// Address: 005ac9c0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_attr_setstacksize(pthread_attr_t *__attr,size_t __stacksize)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_attr_setstacksize_005c6c98)((int)__attr);
  return iVar1;
}



// ========================================
// Function: pthread_attr_setdetachstate
// Address: 005ac9d0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_attr_setdetachstate(pthread_attr_t *__attr,int __detachstate)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_attr_setdetachstate_005c6ca0)((int)__attr,__detachstate);
  return iVar1;
}



// ========================================
// Function: pthread_attr_destroy
// Address: 005ac9e0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_attr_destroy(pthread_attr_t *__attr)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_attr_destroy_005c6ca8)((int)__attr);
  return iVar1;
}



// ========================================
// Function: eglDestroySurface
// Address: 005ac9f0
// ========================================

void eglDestroySurface(void)

{
  (*(code *)PTR_eglDestroySurface_005c6cb0)();
  return;
}



// ========================================
// Function: eglTerminate
// Address: 005aca00
// ========================================

void eglTerminate(void)

{
  (*(code *)PTR_eglTerminate_005c6cb8)();
  return;
}



// ========================================
// Function: pthread_self
// Address: 005aca10
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

pthread_t pthread_self(void)

{
  pthread_t pVar1;
  
  pVar1 = (*(code *)PTR_pthread_self_005c6cc0)();
  return pVar1;
}



// ========================================
// Function: pthread_setname_np
// Address: 005aca20
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setname_np(pthread_t __target_thread,char *__name)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_setname_np_005c6cc8)((int)__target_thread);
  return iVar1;
}



// ========================================
// Function: gettid
// Address: 005aca30
// ========================================

void gettid(void)

{
  (*(code *)PTR_gettid_005c6cd0)();
  return;
}



// ========================================
// Function: setpriority
// Address: 005aca40
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int setpriority(__priority_which_t __which,id_t __who,int __prio)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_setpriority_005c6cd8)(__which,__who,__prio);
  return iVar1;
}



// ========================================
// Function: eglReleaseThread
// Address: 005aca50
// ========================================

void eglReleaseThread(void)

{
  (*(code *)PTR_eglReleaseThread_005c6ce0)();
  return;
}



// ========================================
// Function: glGetIntegeri_v
// Address: 005aca60
// ========================================

void glGetIntegeri_v(void)

{
  (*(code *)PTR_glGetIntegeri_v_005c6ce8)();
  return;
}



// ========================================
// Function: glGetInteger64i_v
// Address: 005aca70
// ========================================

void glGetInteger64i_v(void)

{
  (*(code *)PTR_glGetInteger64i_v_005c6cf0)();
  return;
}



// ========================================
// Function: glBindBufferRange
// Address: 005aca80
// ========================================

void glBindBufferRange(void)

{
  (*(code *)PTR_glBindBufferRange_005c6cf8)();
  return;
}



// ========================================
// Function: glBindBufferBase
// Address: 005aca90
// ========================================

void glBindBufferBase(void)

{
  (*(code *)PTR_glBindBufferBase_005c6d00)();
  return;
}



// ========================================
// Function: glBlendEquationSeparate
// Address: 005acaa0
// ========================================

void glBlendEquationSeparate(void)

{
  (*(code *)PTR_glBlendEquationSeparate_005c6d08)();
  return;
}



// ========================================
// Function: glDepthRangef
// Address: 005acab0
// ========================================

void glDepthRangef(void)

{
  (*(code *)PTR_glDepthRangef_005c6d10)();
  return;
}



// ========================================
// Function: glBindImageTexture
// Address: 005acac0
// ========================================

void glBindImageTexture(void)

{
  (*(code *)PTR_glBindImageTexture_005c6d18)();
  return;
}



// ========================================
// Function: glGetTexParameteriv
// Address: 005acad0
// ========================================

void glGetTexParameteriv(void)

{
  (*(code *)PTR_glGetTexParameteriv_005c6d20)();
  return;
}



// ========================================
// Function: strncmp
// Address: 005acae0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strncmp(char *__s1,char *__s2,size_t __n)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_strncmp_005c6d28)((int)__s1);
  return iVar1;
}



// ========================================
// Function: glCopyTexSubImage2D
// Address: 005acaf0
// ========================================

void glCopyTexSubImage2D(void)

{
  (*(code *)PTR_glCopyTexSubImage2D_005c6d30)();
  return;
}



// ========================================
// Function: glDeleteProgram
// Address: 005acb00
// ========================================

void glDeleteProgram(void)

{
  (*(code *)PTR_glDeleteProgram_005c6d38)();
  return;
}



// ========================================
// Function: glCreateProgram
// Address: 005acb10
// ========================================

void glCreateProgram(void)

{
  (*(code *)PTR_glCreateProgram_005c6d40)();
  return;
}



// ========================================
// Function: glAttachShader
// Address: 005acb20
// ========================================

void glAttachShader(void)

{
  (*(code *)PTR_glAttachShader_005c6d48)();
  return;
}



// ========================================
// Function: glLinkProgram
// Address: 005acb30
// ========================================

void glLinkProgram(void)

{
  (*(code *)PTR_glLinkProgram_005c6d50)();
  return;
}



// ========================================
// Function: glDeleteShader
// Address: 005acb40
// ========================================

void glDeleteShader(void)

{
  (*(code *)PTR_glDeleteShader_005c6d58)();
  return;
}



// ========================================
// Function: glGetProgramInfoLog
// Address: 005acb50
// ========================================

void glGetProgramInfoLog(void)

{
  (*(code *)PTR_glGetProgramInfoLog_005c6d60)();
  return;
}



// ========================================
// Function: glCreateShader
// Address: 005acb60
// ========================================

void glCreateShader(void)

{
  (*(code *)PTR_glCreateShader_005c6d68)();
  return;
}



// ========================================
// Function: glShaderSource
// Address: 005acb70
// ========================================

void glShaderSource(void)

{
  (*(code *)PTR_glShaderSource_005c6d70)();
  return;
}



// ========================================
// Function: glCompileShader
// Address: 005acb80
// ========================================

void glCompileShader(void)

{
  (*(code *)PTR_glCompileShader_005c6d78)();
  return;
}



// ========================================
// Function: glGetShaderInfoLog
// Address: 005acb90
// ========================================

void glGetShaderInfoLog(void)

{
  (*(code *)PTR_glGetShaderInfoLog_005c6d80)();
  return;
}



// ========================================
// Function: glUniform3f
// Address: 005acba0
// ========================================

void glUniform3f(void)

{
  (*(code *)PTR_glUniform3f_005c6d88)();
  return;
}



// ========================================
// Function: glBlendFuncSeparate
// Address: 005acbb0
// ========================================

void glBlendFuncSeparate(void)

{
  (*(code *)PTR_glBlendFuncSeparate_005c6d90)();
  return;
}



// ========================================
// Function: glFrontFace
// Address: 005acbc0
// ========================================

void glFrontFace(void)

{
  (*(code *)PTR_glFrontFace_005c6d98)();
  return;
}



// ========================================
// Function: glGetStringi
// Address: 005acbd0
// ========================================

void glGetStringi(void)

{
  (*(code *)PTR_glGetStringi_005c6da0)();
  return;
}



// ========================================
// Function: glDispatchCompute
// Address: 005acbe0
// ========================================

void glDispatchCompute(void)

{
  (*(code *)PTR_glDispatchCompute_005c6da8)();
  return;
}



// ========================================
// Function: glUniform2i
// Address: 005acbf0
// ========================================

void glUniform2i(void)

{
  (*(code *)PTR_glUniform2i_005c6db0)();
  return;
}



// ========================================
// Function: glBufferSubData
// Address: 005acc00
// ========================================

void glBufferSubData(void)

{
  (*(code *)PTR_glBufferSubData_005c6db8)();
  return;
}



// ========================================
// Function: glMemoryBarrier
// Address: 005acc10
// ========================================

void glMemoryBarrier(void)

{
  (*(code *)PTR_glMemoryBarrier_005c6dc0)();
  return;
}



// ========================================
// Function: glCopyBufferSubData
// Address: 005acc20
// ========================================

void glCopyBufferSubData(void)

{
  (*(code *)PTR_glCopyBufferSubData_005c6dc8)();
  return;
}



// ========================================
// Function: dl_iterate_phdr
// Address: 005acc30
// ========================================

void dl_iterate_phdr(void)

{
  (*(code *)PTR_dl_iterate_phdr_005c6dd0)();
  return;
}



// ========================================
// Function: fread
// Address: 005acc40
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t fread(void *__ptr,size_t __size,size_t __n,FILE *__stream)

{
  size_t sVar1;
  
  sVar1 = (*(code *)PTR_fread_005c6dd8)();
  return sVar1;
}



// ========================================
// Function: fseek
// Address: 005acc50
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fseek(FILE *__stream,long __off,int __whence)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_fseek_005c6de0)((int)__stream,__off,__whence);
  return iVar1;
}



// ========================================
// Function: ftell
// Address: 005acc60
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long ftell(FILE *__stream)

{
  long lVar1;
  
  lVar1 = (*(code *)PTR_ftell_005c6de8)();
  return lVar1;
}



// ========================================
// Function: glProgramBinary
// Address: 005acc70
// ========================================

void glProgramBinary(void)

{
  (*(code *)PTR_glProgramBinary_005c6df0)();
  return;
}



// ========================================
// Function: glProgramParameteri
// Address: 005acc80
// ========================================

void glProgramParameteri(void)

{
  (*(code *)PTR_glProgramParameteri_005c6df8)();
  return;
}



// ========================================
// Function: glGetProgramBinary
// Address: 005acc90
// ========================================

void glGetProgramBinary(void)

{
  (*(code *)PTR_glGetProgramBinary_005c6e00)();
  return;
}



// ========================================
// Function: glProgramUniform1i
// Address: 005acca0
// ========================================

void glProgramUniform1i(void)

{
  (*(code *)PTR_glProgramUniform1i_005c6e08)();
  return;
}



// ========================================
// Function: fwrite
// Address: 005accb0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t fwrite(void *__ptr,size_t __size,size_t __n,FILE *__s)

{
  size_t sVar1;
  
  sVar1 = (*(code *)PTR_fwrite_005c6e10)();
  return sVar1;
}



// ========================================
// Function: rename
// Address: 005accc0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int rename(char *__old,char *__new)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_rename_005c6e18)((int)__old);
  return iVar1;
}



// ========================================
// Function: glVertexAttribFormat
// Address: 005accd0
// ========================================

void glVertexAttribFormat(void)

{
  (*(code *)PTR_glVertexAttribFormat_005c6e20)();
  return;
}



// ========================================
// Function: glVertexAttribBinding
// Address: 005acce0
// ========================================

void glVertexAttribBinding(void)

{
  (*(code *)PTR_glVertexAttribBinding_005c6e28)();
  return;
}



// ========================================
// Function: glVertexAttribIFormat
// Address: 005accf0
// ========================================

void glVertexAttribIFormat(void)

{
  (*(code *)PTR_glVertexAttribIFormat_005c6e30)();
  return;
}



// ========================================
// Function: wmemchr
// Address: 005acd00
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

wchar_t * wmemchr(wchar_t *__s,wchar_t __c,size_t __n)

{
  wchar_t *pwVar1;
  
  pwVar1 = (wchar_t *)(*(code *)PTR_wmemchr_005c6e38)(__s,__c);
  return pwVar1;
}



// ========================================
// Function: glTexSubImage2D
// Address: 005acd10
// ========================================

void glTexSubImage2D(void)

{
  (*(code *)PTR_glTexSubImage2D_005c6e40)();
  return;
}



// ========================================
// Function: glTexStorage3D
// Address: 005acd20
// ========================================

void glTexStorage3D(void)

{
  (*(code *)PTR_glTexStorage3D_005c6e48)();
  return;
}



// ========================================
// Function: glTexSubImage3D
// Address: 005acd30
// ========================================

void glTexSubImage3D(void)

{
  (*(code *)PTR_glTexSubImage3D_005c6e50)();
  return;
}



// ========================================
// Function: glBlendEquation
// Address: 005acd40
// ========================================

void glBlendEquation(void)

{
  (*(code *)PTR_glBlendEquation_005c6e58)();
  return;
}



// ========================================
// Function: glCopyImageSubData
// Address: 005acd50
// ========================================

void glCopyImageSubData(void)

{
  (*(code *)PTR_glCopyImageSubData_005c6e60)();
  return;
}



// ========================================
// Function: glDisablei
// Address: 005acd60
// ========================================

void glDisablei(void)

{
  (*(code *)PTR_glDisablei_005c6e68)();
  return;
}



// ========================================
// Function: glGenerateMipmap
// Address: 005acd70
// ========================================

void glGenerateMipmap(void)

{
  (*(code *)PTR_glGenerateMipmap_005c6e70)();
  return;
}



// ========================================
// Function: glDeleteSamplers
// Address: 005acd80
// ========================================

void glDeleteSamplers(void)

{
  (*(code *)PTR_glDeleteSamplers_005c6e78)();
  return;
}



// ========================================
// Function: glClearBufferuiv
// Address: 005acd90
// ========================================

void glClearBufferuiv(void)

{
  (*(code *)PTR_glClearBufferuiv_005c6e80)();
  return;
}



// ========================================
// Function: glClearBufferiv
// Address: 005acda0
// ========================================

void glClearBufferiv(void)

{
  (*(code *)PTR_glClearBufferiv_005c6e88)();
  return;
}



// ========================================
// Function: glEnablei
// Address: 005acdb0
// ========================================

void glEnablei(void)

{
  (*(code *)PTR_glEnablei_005c6e90)();
  return;
}



// ========================================
// Function: glBlendFuncSeparatei
// Address: 005acdc0
// ========================================

void glBlendFuncSeparatei(void)

{
  (*(code *)PTR_glBlendFuncSeparatei_005c6e98)();
  return;
}



// ========================================
// Function: glInvalidateFramebuffer
// Address: 005acdd0
// ========================================

void glInvalidateFramebuffer(void)

{
  (*(code *)PTR_glInvalidateFramebuffer_005c6ea0)();
  return;
}



// ========================================
// Function: glTexBuffer
// Address: 005acde0
// ========================================

void glTexBuffer(void)

{
  (*(code *)PTR_glTexBuffer_005c6ea8)();
  return;
}



// ========================================
// Function: glBindVertexBuffer
// Address: 005acdf0
// ========================================

void glBindVertexBuffer(void)

{
  (*(code *)PTR_glBindVertexBuffer_005c6eb0)();
  return;
}



// ========================================
// Function: free
// Address: 005ace00
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  (*(code *)PTR_free_005c6eb8)();
  return;
}



// ========================================
// Function: strtod
// Address: 005ace10
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double strtod(char *__nptr,char **__endptr)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_strtod_005c6ec0)();
  return dVar1;
}



// ========================================
// Function: __strlen_chk
// Address: 005ace20
// ========================================

void __strlen_chk(void)

{
  (*(code *)PTR___strlen_chk_005c6ec8)();
  return;
}



// ========================================
// Function: printf
// Address: 005ace30
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int printf(char *__format,...)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_printf_005c6ed0)((int)__format);
  return iVar1;
}



// ========================================
// Function: puts
// Address: 005ace40
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int puts(char *__s)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_puts_005c6ed8)((int)__s);
  return iVar1;
}



// ========================================
// Function: fputc
// Address: 005ace50
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fputc(int __c,FILE *__stream)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_fputc_005c6ee0)(__c);
  return iVar1;
}



// ========================================
// Function: frexp
// Address: 005ace60
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double frexp(double __x,int *__exponent)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_frexp_005c6ee8)();
  return dVar1;
}



// ========================================
// Function: log2
// Address: 005ace70
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double log2(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_log2_005c6ef0)();
  return dVar1;
}



// ========================================
// Function: sinh
// Address: 005ace80
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double sinh(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_sinh_005c6ef8)();
  return dVar1;
}



// ========================================
// Function: asinh
// Address: 005ace90
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double asinh(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_asinh_005c6f00)();
  return dVar1;
}



// ========================================
// Function: acos
// Address: 005acea0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double acos(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_acos_005c6f08)();
  return dVar1;
}



// ========================================
// Function: atan
// Address: 005aceb0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double atan(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_atan_005c6f10)();
  return dVar1;
}



// ========================================
// Function: asin
// Address: 005acec0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double asin(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_asin_005c6f18)();
  return dVar1;
}



// ========================================
// Function: sin
// Address: 005aced0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double sin(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_sin_005c6f20)();
  return dVar1;
}



// ========================================
// Function: cosh
// Address: 005acee0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double cosh(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_cosh_005c6f28)();
  return dVar1;
}



// ========================================
// Function: acosh
// Address: 005acef0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double acosh(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_acosh_005c6f30)();
  return dVar1;
}



// ========================================
// Function: exp2
// Address: 005acf00
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double exp2(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_exp2_005c6f38)();
  return dVar1;
}



// ========================================
// Function: exp
// Address: 005acf10
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double exp(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_exp_005c6f40)();
  return dVar1;
}



// ========================================
// Function: atanh
// Address: 005acf20
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double atanh(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_atanh_005c6f48)();
  return dVar1;
}



// ========================================
// Function: tan
// Address: 005acf30
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double tan(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_tan_005c6f50)();
  return dVar1;
}



// ========================================
// Function: tanh
// Address: 005acf40
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double tanh(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_tanh_005c6f58)();
  return dVar1;
}



// ========================================
// Function: log
// Address: 005acf50
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double log(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_log_005c6f60)();
  return dVar1;
}



// ========================================
// Function: cos
// Address: 005acf60
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double cos(double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_cos_005c6f68)();
  return dVar1;
}



// ========================================
// Function: pow
// Address: 005acf70
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double pow(double __x,double __y)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_pow_005c6f70)();
  return dVar1;
}



// ========================================
// Function: atan2
// Address: 005acf80
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double atan2(double __y,double __x)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_atan2_005c6f78)();
  return dVar1;
}



// ========================================
// Function: malloc
// Address: 005acf90
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * malloc(size_t __size)

{
  void *pvVar1;
  
  pvVar1 = (void *)(*(code *)PTR_malloc_005c6f80)();
  return pvVar1;
}



// ========================================
// Function: fprintf
// Address: 005acfa0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fprintf(FILE *__stream,char *__format,...)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_fprintf_005c6f88)((int)__stream);
  return iVar1;
}



// ========================================
// Function: nl_langinfo
// Address: 005acfb0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * nl_langinfo(nl_item __item)

{
  char *pcVar1;
  
  pcVar1 = (char *)(*(code *)PTR_nl_langinfo_005c6f90)(__item);
  return pcVar1;
}



// ========================================
// Function: __strcat_chk
// Address: 005acfc0
// ========================================

void __strcat_chk(void)

{
  (*(code *)PTR___strcat_chk_005c6f98)();
  return;
}



// ========================================
// Function: __vsprintf_chk
// Address: 005acfd0
// ========================================

void __vsprintf_chk(void)

{
  (*(code *)PTR___vsprintf_chk_005c6fa0)();
  return;
}



// ========================================
// Function: sincos
// Address: 005acfe0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void sincos(double __x,double *__sinx,double *__cosx)

{
  (*(code *)PTR_sincos_005c6fa8)();
  return;
}



// ========================================
// Function: fmod
// Address: 005acff0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double fmod(double __x,double __y)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_fmod_005c6fb0)();
  return dVar1;
}



// ========================================
// Function: expf
// Address: 005ad000
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float expf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_expf_005c6fb8)();
  return fVar1;
}



// ========================================
// Function: sinf
// Address: 005ad010
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float sinf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_sinf_005c6fc0)();
  return fVar1;
}



// ========================================
// Function: cosf
// Address: 005ad020
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float cosf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_cosf_005c6fc8)();
  return fVar1;
}



// ========================================
// Function: tanf
// Address: 005ad030
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float tanf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_tanf_005c6fd0)();
  return fVar1;
}



// ========================================
// Function: asinf
// Address: 005ad040
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float asinf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_asinf_005c6fd8)();
  return fVar1;
}



// ========================================
// Function: acosf
// Address: 005ad050
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float acosf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_acosf_005c6fe0)();
  return fVar1;
}



// ========================================
// Function: atanf
// Address: 005ad060
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float atanf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_atanf_005c6fe8)();
  return fVar1;
}



// ========================================
// Function: powf
// Address: 005ad070
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float powf(float __x,float __y)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_powf_005c6ff0)();
  return fVar1;
}



// ========================================
// Function: logf
// Address: 005ad080
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float logf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_logf_005c6ff8)();
  return fVar1;
}



// ========================================
// Function: log10f
// Address: 005ad090
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float log10f(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_log10f_005c7000)();
  return fVar1;
}



// ========================================
// Function: rand
// Address: 005ad0a0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int rand(void)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_rand_005c7008)();
  return iVar1;
}



// ========================================
// Function: __pread_chk
// Address: 005ad0b0
// ========================================

void __pread_chk(void)

{
  (*(code *)PTR___pread_chk_005c7010)();
  return;
}



// ========================================
// Function: strchr
// Address: 005ad0c0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strchr(char *__s,int __c)

{
  char *pcVar1;
  
  pcVar1 = (char *)(*(code *)PTR_strchr_005c7018)(__s,__c);
  return pcVar1;
}



// ========================================
// Function: __memcpy_chk
// Address: 005ad0d0
// ========================================

void __memcpy_chk(void)

{
  (*(code *)PTR___memcpy_chk_005c7020)();
  return;
}



// ========================================
// Function: realloc
// Address: 005ad0e0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * realloc(void *__ptr,size_t __size)

{
  void *pvVar1;
  
  pvVar1 = (void *)(*(code *)PTR_realloc_005c7028)();
  return pvVar1;
}



// ========================================
// Function: pthread_join
// Address: 005ad0f0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_join(pthread_t __th,void **__thread_return)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_join_005c7030)((int)__th);
  return iVar1;
}



// ========================================
// Function: pthread_mutex_lock
// Address: 005ad100
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_lock(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_mutex_lock_005c7038)((int)__mutex);
  return iVar1;
}



// ========================================
// Function: pthread_cond_wait
// Address: 005ad110
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_wait(pthread_cond_t *__cond,pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_cond_wait_005c7040)((int)__cond);
  return iVar1;
}



// ========================================
// Function: pthread_mutex_unlock
// Address: 005ad120
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_unlock(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_mutex_unlock_005c7048)((int)__mutex);
  return iVar1;
}



// ========================================
// Function: pthread_cond_broadcast
// Address: 005ad130
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_broadcast(pthread_cond_t *__cond)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_cond_broadcast_005c7050)((int)__cond);
  return iVar1;
}



// ========================================
// Function: clock_gettime
// Address: 005ad140
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int clock_gettime(clockid_t __clock_id,timespec *__tp)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_clock_gettime_005c7058)(__clock_id);
  return iVar1;
}



// ========================================
// Function: wcslen
// Address: 005ad150
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t wcslen(wchar_t *__s)

{
  size_t sVar1;
  
  sVar1 = (*(code *)PTR_wcslen_005c7060)();
  return sVar1;
}



// ========================================
// Function: snprintf
// Address: 005ad160
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int snprintf(char *__s,size_t __maxlen,char *__format,...)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_snprintf_005c7068)((int)__s);
  return iVar1;
}



// ========================================
// Function: strerror_r
// Address: 005ad170
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strerror_r(int __errnum,char *__buf,size_t __buflen)

{
  char *pcVar1;
  
  pcVar1 = (char *)(*(code *)PTR_strerror_r_005c7070)(__errnum);
  return pcVar1;
}



// ========================================
// Function: abort
// Address: 005ad180
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void abort(void)

{
  (*(code *)PTR_abort_005c7078)();
  return;
}



// ========================================
// Function: vfprintf
// Address: 005ad190
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vfprintf(FILE *__s,char *__format,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_vfprintf_005c7080)((int)__s);
  return iVar1;
}



// ========================================
// Function: vasprintf
// Address: 005ad1a0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vasprintf(char **__ptr,char *__f,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_vasprintf_005c7088)((int)__ptr);
  return iVar1;
}



// ========================================
// Function: android_set_abort_message
// Address: 005ad1b0
// ========================================

void android_set_abort_message(void)

{
  (*(code *)PTR_android_set_abort_message_005c7090)();
  return;
}



// ========================================
// Function: openlog
// Address: 005ad1c0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void openlog(char *__ident,int __option,int __facility)

{
  (*(code *)PTR_openlog_005c7098)(__ident,__option,__facility);
  return;
}



// ========================================
// Function: syslog
// Address: 005ad1d0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void syslog(int __pri,char *__fmt,...)

{
  (*(code *)PTR_syslog_005c70a0)(__pri);
  return;
}



// ========================================
// Function: closelog
// Address: 005ad1e0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void closelog(void)

{
  (*(code *)PTR_closelog_005c70a8)();
  return;
}



// ========================================
// Function: pthread_mutex_destroy
// Address: 005ad1f0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_destroy(pthread_mutex_t *__mutex)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_mutex_destroy_005c70b0)((int)__mutex);
  return iVar1;
}



// ========================================
// Function: pthread_getspecific
// Address: 005ad200
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * pthread_getspecific(pthread_key_t __key)

{
  void *pvVar1;
  
  pvVar1 = (void *)(*(code *)PTR_pthread_getspecific_005c70b8)(__key);
  return pvVar1;
}



// ========================================
// Function: pthread_key_create
// Address: 005ad210
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_create(pthread_key_t *__key,__destr_function *__destr_function)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_key_create_005c70c0)((int)__key);
  return iVar1;
}



// ========================================
// Function: fseeko
// Address: 005ad220
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fseeko(FILE *__stream,__off_t __off,int __whence)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_fseeko_005c70c8)((int)__stream,__off,__whence);
  return iVar1;
}



// ========================================
// Function: ftello
// Address: 005ad230
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

__off_t ftello(FILE *__stream)

{
  __off_t _Var1;
  
  _Var1 = (*(code *)PTR_ftello_005c70d0)();
  return _Var1;
}



// ========================================
// Function: fflush
// Address: 005ad240
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fflush(FILE *__stream)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_fflush_005c70d8)((int)__stream);
  return iVar1;
}



// ========================================
// Function: newlocale
// Address: 005ad250
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

__locale_t newlocale(int __category_mask,char *__locale,__locale_t __base)

{
  __locale_t p_Var1;
  
  p_Var1 = (__locale_t)(*(code *)PTR_newlocale_005c70e0)(__category_mask);
  return p_Var1;
}



// ========================================
// Function: uselocale
// Address: 005ad260
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

__locale_t uselocale(__locale_t __dataset)

{
  __locale_t p_Var1;
  
  p_Var1 = (__locale_t)(*(code *)PTR_uselocale_005c70e8)();
  return p_Var1;
}



// ========================================
// Function: vsscanf
// Address: 005ad270
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vsscanf(char *__s,char *__format,__gnuc_va_list __arg)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_vsscanf_005c70f0)((int)__s);
  return iVar1;
}



// ========================================
// Function: strftime_l
// Address: 005ad280
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t strftime_l(char *__s,size_t __maxsize,char *__format,tm *__tp,__locale_t __loc)

{
  size_t sVar1;
  
  sVar1 = (*(code *)PTR_strftime_l_005c70f8)();
  return sVar1;
}



// ========================================
// Function: mbsrtowcs
// Address: 005ad290
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t mbsrtowcs(wchar_t *__dst,char **__src,size_t __len,mbstate_t *__ps)

{
  size_t sVar1;
  
  sVar1 = (*(code *)PTR_mbsrtowcs_005c7100)();
  return sVar1;
}



// ========================================
// Function: freelocale
// Address: 005ad2a0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void freelocale(__locale_t __dataset)

{
  (*(code *)PTR_freelocale_005c7108)();
  return;
}



// ========================================
// Function: iswlower_l
// Address: 005ad2b0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int iswlower_l(wint_t __wc,__locale_t __locale)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_iswlower_l_005c7110)(__wc);
  return iVar1;
}



// ========================================
// Function: wcsnrtombs
// Address: 005ad2c0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t wcsnrtombs(char *__dst,wchar_t **__src,size_t __nwc,size_t __len,mbstate_t *__ps)

{
  size_t sVar1;
  
  sVar1 = (*(code *)PTR_wcsnrtombs_005c7118)();
  return sVar1;
}



// ========================================
// Function: wcrtomb
// Address: 005ad2d0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t wcrtomb(char *__s,wchar_t __wc,mbstate_t *__ps)

{
  size_t sVar1;
  
  sVar1 = (*(code *)PTR_wcrtomb_005c7120)(__s,__wc);
  return sVar1;
}



// ========================================
// Function: mbsnrtowcs
// Address: 005ad2e0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t mbsnrtowcs(wchar_t *__dst,char **__src,size_t __nmc,size_t __len,mbstate_t *__ps)

{
  size_t sVar1;
  
  sVar1 = (*(code *)PTR_mbsnrtowcs_005c7128)();
  return sVar1;
}



// ========================================
// Function: mbrtowc
// Address: 005ad2f0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t mbrtowc(wchar_t *__pwc,char *__s,size_t __n,mbstate_t *__p)

{
  size_t sVar1;
  
  sVar1 = (*(code *)PTR_mbrtowc_005c7130)();
  return sVar1;
}



// ========================================
// Function: mbtowc
// Address: 005ad300
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mbtowc(wchar_t *__pwc,char *__s,size_t __n)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_mbtowc_005c7138)((int)__pwc);
  return iVar1;
}



// ========================================
// Function: __ctype_get_mb_cur_max
// Address: 005ad310
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t __ctype_get_mb_cur_max(void)

{
  size_t sVar1;
  
  sVar1 = (*(code *)PTR___ctype_get_mb_cur_max_005c7140)();
  return sVar1;
}



// ========================================
// Function: mbrlen
// Address: 005ad320
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t mbrlen(char *__s,size_t __n,mbstate_t *__ps)

{
  size_t sVar1;
  
  sVar1 = (*(code *)PTR_mbrlen_005c7148)();
  return sVar1;
}



// ========================================
// Function: strtoll_l
// Address: 005ad330
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

longlong strtoll_l(char *__nptr,char **__endptr,int __base,__locale_t __loc)

{
  longlong lVar1;
  
  lVar1 = (*(code *)PTR_strtoll_l_005c7150)(__nptr,__endptr,__base);
  return lVar1;
}



// ========================================
// Function: strtoull_l
// Address: 005ad340
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

ulonglong strtoull_l(char *__nptr,char **__endptr,int __base,__locale_t __loc)

{
  ulonglong uVar1;
  
  uVar1 = (*(code *)PTR_strtoull_l_005c7158)(__nptr,__endptr,__base);
  return uVar1;
}



// ========================================
// Function: strtold_l
// Address: 005ad350
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double strtold_l(char *__nptr,char **__endptr,__locale_t __loc)

{
  double dVar1;
  
  dVar1 = (double)(*(code *)PTR_strtold_l_005c7160)();
  return dVar1;
}



// ========================================
// Function: opendir
// Address: 005ad360
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

DIR * opendir(char *__name)

{
  DIR *pDVar1;
  
  pDVar1 = (DIR *)(*(code *)PTR_opendir_005c7168)();
  return pDVar1;
}



// ========================================
// Function: lstat
// Address: 005ad370
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int lstat(char *__file,stat *__buf)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_lstat_005c7170)((int)__file);
  return iVar1;
}



// ========================================
// Function: stat
// Address: 005ad380
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int stat(char *__file,stat *__buf)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_stat_005c7178)((int)__file);
  return iVar1;
}



// ========================================
// Function: mkdir
// Address: 005ad390
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mkdir(char *__path,__mode_t __mode)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_mkdir_005c7180)((int)__path,__mode);
  return iVar1;
}



// ========================================
// Function: pathconf
// Address: 005ad3a0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long pathconf(char *__path,int __name)

{
  long lVar1;
  
  lVar1 = (*(code *)PTR_pathconf_005c7188)(__path,__name);
  return lVar1;
}



// ========================================
// Function: getcwd
// Address: 005ad3b0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * getcwd(char *__buf,size_t __size)

{
  char *pcVar1;
  
  pcVar1 = (char *)(*(code *)PTR_getcwd_005c7190)();
  return pcVar1;
}



// ========================================
// Function: posix_memalign
// Address: 005ad3c0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int posix_memalign(void **__memptr,size_t __alignment,size_t __size)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_posix_memalign_005c7198)((int)__memptr);
  return iVar1;
}



// ========================================
// Function: __assert2
// Address: 005ad3d0
// ========================================

void __assert2(void)

{
  (*(code *)PTR___assert2_005c71a0)();
  return;
}



// ========================================
// Function: __cxa_thread_atexit_impl
// Address: 005ad3e0
// ========================================

void __cxa_thread_atexit_impl(void)

{
  (*(code *)PTR___cxa_thread_atexit_impl_005c71a8)();
  return;
}



// ========================================
// Function: pthread_once
// Address: 005ad3f0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_once(pthread_once_t *__once_control,__init_routine *__init_routine)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_once_005c71b0)((int)__once_control);
  return iVar1;
}



// ========================================
// Function: pthread_key_delete
// Address: 005ad400
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_delete(pthread_key_t __key)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_key_delete_005c71b8)(__key);
  return iVar1;
}



// ========================================
// Function: getauxval
// Address: 005ad410
// ========================================

void getauxval(void)

{
  (*(code *)PTR_getauxval_005c71c0)();
  return;
}



// ========================================
// Function: pthread_rwlock_wrlock
// Address: 005ad420
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_wrlock(pthread_rwlock_t *__rwlock)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_rwlock_wrlock_005c71c8)((int)__rwlock);
  return iVar1;
}



// ========================================
// Function: pthread_rwlock_unlock
// Address: 005ad430
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_unlock(pthread_rwlock_t *__rwlock)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_rwlock_unlock_005c71d0)((int)__rwlock);
  return iVar1;
}



// ========================================
// Function: pthread_rwlock_rdlock
// Address: 005ad440
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_rdlock(pthread_rwlock_t *__rwlock)

{
  int iVar1;
  
  iVar1 = (*(code *)PTR_pthread_rwlock_rdlock_005c71d8)((int)__rwlock);
  return iVar1;
}



// ========================================
// Function: __cxa_finalize
// Address: 00993000
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __cxa_finalize(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __cxa_atexit
// Address: 00993008
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __cxa_atexit(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __register_atfork
// Address: 00993010
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __register_atfork(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: getpid
// Address: 00993018
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

__pid_t getpid(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: getuid
// Address: 00993020
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

__uid_t getuid(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __android_log_print
// Address: 00993028
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __android_log_print(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __stack_chk_fail
// Address: 00993030
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __stack_chk_fail(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strlen
// Address: 00993038
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t strlen(char *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: memmove
// Address: 00993040
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memmove(void *__dest,void *__src,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __open_2
// Address: 00993048
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __open_2(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: close
// Address: 00993050
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int close(int __fd)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_create
// Address: 00993058
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_create(pthread_t *__newthread,pthread_attr_t *__attr,__start_routine *__start_routine,
                  void *__arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_detach
// Address: 00993060
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_detach(pthread_t __th)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __openat_2
// Address: 00993068
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __openat_2(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __errno
// Address: 00993070
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __errno(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strerror
// Address: 00993078
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strerror(int __errnum)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: read
// Address: 00993080
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

ssize_t read(int __fd,void *__buf,size_t __nbytes)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fdopendir
// Address: 00993088
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

DIR * fdopendir(int __fd)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: readdir
// Address: 00993090
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

dirent * readdir(DIR *__dirp)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fstatat
// Address: 00993098
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fstatat(int __fd,char *__file,stat *__buf,int __flag)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: closedir
// Address: 009930a0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int closedir(DIR *__dirp)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strcasecmp
// Address: 009930a8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strcasecmp(char *__s1,char *__s2)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: memcpy
// Address: 009930b0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memcpy(void *__dest,void *__src,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: mkdirat
// Address: 009930b8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mkdirat(int __fd,char *__path,__mode_t __mode)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strcmp
// Address: 009930c0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strcmp(char *__s1,char *__s2)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: dirfd
// Address: 009930c8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int dirfd(DIR *__dirp)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fstat
// Address: 009930d0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fstat(int __fd,stat *__buf)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __read_chk
// Address: 009930d8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __read_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: syscall
// Address: 009930e0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long syscall(long __sysno,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __write_chk
// Address: 009930e8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __write_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: android_dlopen_ext
// Address: 009930f0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void android_dlopen_ext(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: dlsym
// Address: 009930f8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void dlsym(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: dlerror
// Address: 00993100
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void dlerror(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: memset
// Address: 00993108
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memset(void *__s,int __c,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: memcmp
// Address: 00993110
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int memcmp(void *__s1,void *__s2,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: dlopen
// Address: 00993118
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void dlopen(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: usleep
// Address: 00993120
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int usleep(__useconds_t __useconds)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglQuerySurface
// Address: 00993128
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglQuerySurface(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __system_property_get
// Address: 00993130
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __system_property_get(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fopen
// Address: 00993138
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

FILE * fopen(char *__filename,char *__modes)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fgets
// Address: 00993140
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * fgets(char *__s,int __n,FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strstr
// Address: 00993148
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strstr(char *__haystack,char *__needle)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fclose
// Address: 00993150
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fclose(FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: sscanf
// Address: 00993158
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int sscanf(char *__s,char *__format,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: sysconf
// Address: 00993160
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long sysconf(int __name)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: mprotect
// Address: 00993168
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mprotect(void *__addr,size_t __len,int __prot)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglDestroyContext
// Address: 00993170
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglDestroyContext(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglMakeCurrent
// Address: 00993178
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglMakeCurrent(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglGetCurrentContext
// Address: 00993180
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglGetCurrentContext(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fdopen
// Address: 00993188
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

FILE * fdopen(int __fd,char *__modes)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: mmap
// Address: 00993190
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * mmap(void *__addr,size_t __len,int __prot,int __flags,int __fd,__off_t __offset)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pwrite
// Address: 00993198
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

ssize_t pwrite(int __fd,void *__buf,size_t __n,__off_t __offset)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: getpagesize
// Address: 009931a0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int getpagesize(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: munmap
// Address: 009931a8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int munmap(void *__addr,size_t __len)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: process_vm_readv
// Address: 009931b0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void process_vm_readv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __vsnprintf_chk
// Address: 009931b8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __vsnprintf_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetError
// Address: 009931c0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetError(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glIsTexture
// Address: 009931c8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glIsTexture(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetIntegerv
// Address: 009931d0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetIntegerv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBindTexture
// Address: 009931d8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBindTexture(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetTexLevelParameteriv
// Address: 009931e0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetTexLevelParameteriv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glIsEnabled
// Address: 009931e8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glIsEnabled(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetFloatv
// Address: 009931f0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetFloatv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetUniformiv
// Address: 009931f8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetUniformiv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glActiveTexture
// Address: 00993200
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glActiveTexture(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glIsProgram
// Address: 00993208
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glIsProgram(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetProgramiv
// Address: 00993210
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetProgramiv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetActiveUniform
// Address: 00993218
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetActiveUniform(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __strchr_chk
// Address: 00993220
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __strchr_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetUniformLocation
// Address: 00993228
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetUniformLocation(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetActiveAttrib
// Address: 00993230
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetActiveAttrib(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetAttribLocation
// Address: 00993238
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetAttribLocation(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDeleteTextures
// Address: 00993240
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDeleteTextures(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGenFramebuffers
// Address: 00993248
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGenFramebuffers(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGenTextures
// Address: 00993250
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGenTextures(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glTexImage2D
// Address: 00993258
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glTexImage2D(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glTexParameteri
// Address: 00993260
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glTexParameteri(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glFramebufferTexture2D
// Address: 00993268
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glFramebufferTexture2D(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glCheckFramebufferStatus
// Address: 00993270
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glCheckFramebufferStatus(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDisable
// Address: 00993278
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDisable(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glFinish
// Address: 00993280
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glFinish(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __strcpy_chk
// Address: 00993288
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __strcpy_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strtoul
// Address: 00993290
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

ulong strtoul(char *__nptr,char **__endptr,int __base)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglChooseConfig
// Address: 00993298
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglChooseConfig(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglGetConfigAttrib
// Address: 009932a0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglGetConfigAttrib(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBindFramebuffer
// Address: 009932a8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBindFramebuffer(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBlitFramebuffer
// Address: 009932b0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBlitFramebuffer(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDrawBuffers
// Address: 009932b8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDrawBuffers(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glViewport
// Address: 009932c0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glViewport(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glColorMask
// Address: 009932c8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glColorMask(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glReadPixels
// Address: 009932d0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glReadPixels(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetVertexAttribiv
// Address: 009932d8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetVertexAttribiv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetVertexAttribPointerv
// Address: 009932e0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetVertexAttribPointerv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetAttachedShaders
// Address: 009932e8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetAttachedShaders(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetShaderiv
// Address: 009932f0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetShaderiv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetShaderSource
// Address: 009932f8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetShaderSource(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetBooleanv
// Address: 00993300
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetBooleanv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fmodf
// Address: 00993308
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float fmodf(float __x,float __y)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glTexStorage2D
// Address: 00993310
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glTexStorage2D(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glEnable
// Address: 00993318
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glEnable(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDepthFunc
// Address: 00993320
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDepthFunc(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDepthMask
// Address: 00993328
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDepthMask(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glPolygonOffset
// Address: 00993330
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glPolygonOffset(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glClear
// Address: 00993338
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glClear(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glUniformMatrix4fv
// Address: 00993340
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glUniformMatrix4fv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBindVertexArray
// Address: 00993348
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBindVertexArray(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glUniform1i
// Address: 00993350
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glUniform1i(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBindSampler
// Address: 00993358
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBindSampler(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glUniform1f
// Address: 00993360
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glUniform1f(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBindBuffer
// Address: 00993368
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBindBuffer(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGenVertexArrays
// Address: 00993370
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGenVertexArrays(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGenSamplers
// Address: 00993378
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGenSamplers(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glSamplerParameteri
// Address: 00993380
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glSamplerParameteri(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glReadBuffer
// Address: 00993388
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glReadBuffer(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: sincosf
// Address: 00993390
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void sincosf(float __x,float *__sinx,float *__cosx)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: atan2f
// Address: 00993398
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float atan2f(float __y,float __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: vsnprintf
// Address: 009933a0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vsnprintf(char *__s,size_t __maxlen,char *__format,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetString
// Address: 009933a8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetString(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglGetProcAddress
// Address: 009933b0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglGetProcAddress(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glUniform2f
// Address: 009933b8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glUniform2f(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDrawArrays
// Address: 009933c0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDrawArrays(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: exp2f
// Address: 009933c8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float exp2f(float __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDeleteFramebuffers
// Address: 009933d0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDeleteFramebuffers(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glScissor
// Address: 009933d8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glScissor(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glUniform4f
// Address: 009933e0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glUniform4f(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_setspecific
// Address: 009933e8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setspecific(pthread_key_t __key,void *__pointer)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: atoi
// Address: 009933f0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int atoi(char *__nptr)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glClearBufferfv
// Address: 009933f8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glClearBufferfv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glUniform3fv
// Address: 00993400
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glUniform3fv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDeleteBuffers
// Address: 00993408
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDeleteBuffers(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDeleteSync
// Address: 00993410
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDeleteSync(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGenBuffers
// Address: 00993418
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGenBuffers(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBufferData
// Address: 00993420
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBufferData(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glFenceSync
// Address: 00993428
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glFenceSync(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glClientWaitSync
// Address: 00993430
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glClientWaitSync(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glMapBufferRange
// Address: 00993438
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glMapBufferRange(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glUnmapBuffer
// Address: 00993440
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glUnmapBuffer(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glPixelStorei
// Address: 00993448
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glPixelStorei(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glFlush
// Address: 00993450
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glFlush(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glUniform4fv
// Address: 00993458
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glUniform4fv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: log2f
// Address: 00993460
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float log2f(float __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glEnableVertexAttribArray
// Address: 00993468
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glEnableVertexAttribArray(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glVertexAttribPointer
// Address: 00993470
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glVertexAttribPointer(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDisableVertexAttribArray
// Address: 00993478
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDisableVertexAttribArray(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glVertexAttrib4f
// Address: 00993480
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glVertexAttrib4f(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDrawElements
// Address: 00993488
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDrawElements(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDeleteVertexArrays
// Address: 00993490
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDeleteVertexArrays(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: memchr
// Address: 00993498
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * memchr(void *__s,int __c,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glClearColor
// Address: 009934a0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glClearColor(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glTexImage3D
// Address: 009934a8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glTexImage3D(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: atof
// Address: 009934b0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double atof(char *__nptr)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strtof
// Address: 009934b8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float strtof(char *__nptr,char **__endptr)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glUseProgram
// Address: 009934c0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glUseProgram(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glUniform2fv
// Address: 009934c8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glUniform2fv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: remove
// Address: 009934d0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int remove(char *__filename)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fputs
// Address: 009934d8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fputs(char *__s,FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: access
// Address: 009934e0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int access(char *__name,int __type)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglGetCurrentDisplay
// Address: 009934e8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglGetCurrentDisplay(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglQueryContext
// Address: 009934f0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglQueryContext(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglCreateContext
// Address: 009934f8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglCreateContext(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglInitialize
// Address: 00993500
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglInitialize(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglCreatePbufferSurface
// Address: 00993508
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglCreatePbufferSurface(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglGetError
// Address: 00993510
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglGetError(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_attr_init
// Address: 00993518
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_attr_init(pthread_attr_t *__attr)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_attr_setstacksize
// Address: 00993520
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_attr_setstacksize(pthread_attr_t *__attr,size_t __stacksize)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_attr_setdetachstate
// Address: 00993528
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_attr_setdetachstate(pthread_attr_t *__attr,int __detachstate)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_attr_destroy
// Address: 00993530
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_attr_destroy(pthread_attr_t *__attr)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglDestroySurface
// Address: 00993538
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglDestroySurface(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglTerminate
// Address: 00993540
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglTerminate(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_self
// Address: 00993548
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

pthread_t pthread_self(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_setname_np
// Address: 00993550
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_setname_np(pthread_t __target_thread,char *__name)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: gettid
// Address: 00993558
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void gettid(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: setpriority
// Address: 00993560
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int setpriority(__priority_which_t __which,id_t __who,int __prio)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: eglReleaseThread
// Address: 00993568
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void eglReleaseThread(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetIntegeri_v
// Address: 00993570
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetIntegeri_v(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetInteger64i_v
// Address: 00993578
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetInteger64i_v(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBindBufferRange
// Address: 00993580
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBindBufferRange(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBindBufferBase
// Address: 00993588
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBindBufferBase(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBlendEquationSeparate
// Address: 00993590
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBlendEquationSeparate(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDepthRangef
// Address: 00993598
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDepthRangef(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBindImageTexture
// Address: 009935a0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBindImageTexture(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetTexParameteriv
// Address: 009935a8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetTexParameteriv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strncmp
// Address: 009935b0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int strncmp(char *__s1,char *__s2,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glCopyTexSubImage2D
// Address: 009935b8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glCopyTexSubImage2D(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDeleteProgram
// Address: 009935c0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDeleteProgram(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glCreateProgram
// Address: 009935c8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glCreateProgram(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glAttachShader
// Address: 009935d0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glAttachShader(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glLinkProgram
// Address: 009935d8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glLinkProgram(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDeleteShader
// Address: 009935e0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDeleteShader(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetProgramInfoLog
// Address: 009935e8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetProgramInfoLog(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glCreateShader
// Address: 009935f0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glCreateShader(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glShaderSource
// Address: 009935f8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glShaderSource(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glCompileShader
// Address: 00993600
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glCompileShader(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetShaderInfoLog
// Address: 00993608
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetShaderInfoLog(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glUniform3f
// Address: 00993610
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glUniform3f(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBlendFuncSeparate
// Address: 00993618
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBlendFuncSeparate(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glFrontFace
// Address: 00993620
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glFrontFace(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetStringi
// Address: 00993628
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetStringi(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDispatchCompute
// Address: 00993630
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDispatchCompute(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glUniform2i
// Address: 00993638
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glUniform2i(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBufferSubData
// Address: 00993640
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBufferSubData(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glMemoryBarrier
// Address: 00993648
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glMemoryBarrier(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glCopyBufferSubData
// Address: 00993650
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glCopyBufferSubData(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: dl_iterate_phdr
// Address: 00993658
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void dl_iterate_phdr(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fread
// Address: 00993660
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t fread(void *__ptr,size_t __size,size_t __n,FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fseek
// Address: 00993668
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fseek(FILE *__stream,long __off,int __whence)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: ftell
// Address: 00993670
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long ftell(FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glProgramBinary
// Address: 00993678
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glProgramBinary(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glProgramParameteri
// Address: 00993680
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glProgramParameteri(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGetProgramBinary
// Address: 00993688
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGetProgramBinary(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glProgramUniform1i
// Address: 00993690
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glProgramUniform1i(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fwrite
// Address: 00993698
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t fwrite(void *__ptr,size_t __size,size_t __n,FILE *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: rename
// Address: 009936a0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int rename(char *__old,char *__new)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glVertexAttribFormat
// Address: 009936a8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glVertexAttribFormat(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glVertexAttribBinding
// Address: 009936b0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glVertexAttribBinding(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glVertexAttribIFormat
// Address: 009936b8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glVertexAttribIFormat(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: wmemchr
// Address: 009936c0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

wchar_t * wmemchr(wchar_t *__s,wchar_t __c,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glTexSubImage2D
// Address: 009936c8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glTexSubImage2D(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glTexStorage3D
// Address: 009936d0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glTexStorage3D(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glTexSubImage3D
// Address: 009936d8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glTexSubImage3D(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBlendEquation
// Address: 009936e0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBlendEquation(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glCopyImageSubData
// Address: 009936e8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glCopyImageSubData(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDisablei
// Address: 009936f0
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDisablei(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glGenerateMipmap
// Address: 009936f8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glGenerateMipmap(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glDeleteSamplers
// Address: 00993700
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glDeleteSamplers(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glClearBufferuiv
// Address: 00993708
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glClearBufferuiv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glClearBufferiv
// Address: 00993710
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glClearBufferiv(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glEnablei
// Address: 00993718
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glEnablei(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBlendFuncSeparatei
// Address: 00993720
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBlendFuncSeparatei(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glInvalidateFramebuffer
// Address: 00993728
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glInvalidateFramebuffer(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glTexBuffer
// Address: 00993730
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glTexBuffer(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: glBindVertexBuffer
// Address: 00993738
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void glBindVertexBuffer(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: free
// Address: 00993740
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strtod
// Address: 00993748
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double strtod(char *__nptr,char **__endptr)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __strlen_chk
// Address: 00993750
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __strlen_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: printf
// Address: 00993758
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int printf(char *__format,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: puts
// Address: 00993760
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int puts(char *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fputc
// Address: 00993770
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fputc(int __c,FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: frexp
// Address: 00993778
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double frexp(double __x,int *__exponent)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: log2
// Address: 00993780
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double log2(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: sinh
// Address: 00993788
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double sinh(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: asinh
// Address: 00993790
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double asinh(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: acos
// Address: 00993798
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double acos(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: atan
// Address: 009937a0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double atan(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: asin
// Address: 009937a8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double asin(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: sin
// Address: 009937b0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double sin(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: cosh
// Address: 009937b8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double cosh(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: acosh
// Address: 009937c0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double acosh(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: exp2
// Address: 009937c8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double exp2(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: exp
// Address: 009937d0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double exp(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: atanh
// Address: 009937d8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double atanh(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: tan
// Address: 009937e0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double tan(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: tanh
// Address: 009937e8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double tanh(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: log
// Address: 009937f0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double log(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: cos
// Address: 009937f8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double cos(double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pow
// Address: 00993800
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double pow(double __x,double __y)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: atan2
// Address: 00993808
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double atan2(double __y,double __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: malloc
// Address: 00993818
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * malloc(size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fprintf
// Address: 00993820
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fprintf(FILE *__stream,char *__format,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: nl_langinfo
// Address: 00993828
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * nl_langinfo(nl_item __item)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __strcat_chk
// Address: 00993830
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __strcat_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __vsprintf_chk
// Address: 00993838
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __vsprintf_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: sincos
// Address: 00993840
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void sincos(double __x,double *__sinx,double *__cosx)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fmod
// Address: 00993848
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double fmod(double __x,double __y)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: expf
// Address: 00993850
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float expf(float __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: sinf
// Address: 00993858
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float sinf(float __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: cosf
// Address: 00993860
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float cosf(float __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: tanf
// Address: 00993868
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float tanf(float __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: asinf
// Address: 00993870
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float asinf(float __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: acosf
// Address: 00993878
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float acosf(float __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: atanf
// Address: 00993880
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float atanf(float __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: powf
// Address: 00993888
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float powf(float __x,float __y)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: logf
// Address: 00993890
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float logf(float __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: log10f
// Address: 00993898
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float log10f(float __x)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: rand
// Address: 009938a0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int rand(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __pread_chk
// Address: 009938a8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __pread_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strchr
// Address: 009938b0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strchr(char *__s,int __c)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __memcpy_chk
// Address: 009938b8
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __memcpy_chk(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: realloc
// Address: 009938c0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * realloc(void *__ptr,size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_join
// Address: 009938c8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_join(pthread_t __th,void **__thread_return)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_mutex_lock
// Address: 009938d0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_lock(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_cond_wait
// Address: 009938d8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_wait(pthread_cond_t *__cond,pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_mutex_unlock
// Address: 009938e0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_unlock(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_cond_broadcast
// Address: 009938e8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_cond_broadcast(pthread_cond_t *__cond)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: clock_gettime
// Address: 009938f0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int clock_gettime(clockid_t __clock_id,timespec *__tp)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: wcslen
// Address: 009938f8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t wcslen(wchar_t *__s)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: snprintf
// Address: 00993900
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int snprintf(char *__s,size_t __maxlen,char *__format,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strerror_r
// Address: 00993908
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * strerror_r(int __errnum,char *__buf,size_t __buflen)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: abort
// Address: 00993910
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void abort(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: vfprintf
// Address: 00993920
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vfprintf(FILE *__s,char *__format,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: vasprintf
// Address: 00993928
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vasprintf(char **__ptr,char *__f,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: android_set_abort_message
// Address: 00993930
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void android_set_abort_message(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: openlog
// Address: 00993938
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void openlog(char *__ident,int __option,int __facility)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: syslog
// Address: 00993940
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void syslog(int __pri,char *__fmt,...)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: closelog
// Address: 00993948
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void closelog(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_mutex_destroy
// Address: 00993950
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_mutex_destroy(pthread_mutex_t *__mutex)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_getspecific
// Address: 00993958
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void * pthread_getspecific(pthread_key_t __key)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_key_create
// Address: 00993960
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_create(pthread_key_t *__key,__destr_function *__destr_function)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fseeko
// Address: 00993968
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fseeko(FILE *__stream,__off_t __off,int __whence)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: ftello
// Address: 00993970
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

__off_t ftello(FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: fflush
// Address: 00993978
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int fflush(FILE *__stream)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: newlocale
// Address: 00993980
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

__locale_t newlocale(int __category_mask,char *__locale,__locale_t __base)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: uselocale
// Address: 00993988
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

__locale_t uselocale(__locale_t __dataset)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: vsscanf
// Address: 00993990
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int vsscanf(char *__s,char *__format,__gnuc_va_list __arg)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strftime_l
// Address: 00993998
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t strftime_l(char *__s,size_t __maxsize,char *__format,tm *__tp,__locale_t __loc)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: mbsrtowcs
// Address: 009939a0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t mbsrtowcs(wchar_t *__dst,char **__src,size_t __len,mbstate_t *__ps)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: freelocale
// Address: 009939a8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void freelocale(__locale_t __dataset)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: iswlower_l
// Address: 009939b0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int iswlower_l(wint_t __wc,__locale_t __locale)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: wcsnrtombs
// Address: 009939b8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t wcsnrtombs(char *__dst,wchar_t **__src,size_t __nwc,size_t __len,mbstate_t *__ps)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: wcrtomb
// Address: 009939c0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t wcrtomb(char *__s,wchar_t __wc,mbstate_t *__ps)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: mbsnrtowcs
// Address: 009939c8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t mbsnrtowcs(wchar_t *__dst,char **__src,size_t __nmc,size_t __len,mbstate_t *__ps)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: mbrtowc
// Address: 009939d0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t mbrtowc(wchar_t *__pwc,char *__s,size_t __n,mbstate_t *__p)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: mbtowc
// Address: 009939d8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mbtowc(wchar_t *__pwc,char *__s,size_t __n)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __ctype_get_mb_cur_max
// Address: 009939e0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t __ctype_get_mb_cur_max(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: mbrlen
// Address: 009939e8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

size_t mbrlen(char *__s,size_t __n,mbstate_t *__ps)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strtoll_l
// Address: 009939f0
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

longlong strtoll_l(char *__nptr,char **__endptr,int __base,__locale_t __loc)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strtoull_l
// Address: 009939f8
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

ulonglong strtoull_l(char *__nptr,char **__endptr,int __base,__locale_t __loc)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: strtold_l
// Address: 00993a00
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

double strtold_l(char *__nptr,char **__endptr,__locale_t __loc)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: opendir
// Address: 00993a08
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

DIR * opendir(char *__name)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: lstat
// Address: 00993a10
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int lstat(char *__file,stat *__buf)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: stat
// Address: 00993a18
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int stat(char *__file,stat *__buf)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: mkdir
// Address: 00993a20
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int mkdir(char *__path,__mode_t __mode)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pathconf
// Address: 00993a28
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

long pathconf(char *__path,int __name)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: getcwd
// Address: 00993a30
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

char * getcwd(char *__buf,size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: posix_memalign
// Address: 00993a38
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int posix_memalign(void **__memptr,size_t __alignment,size_t __size)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __assert2
// Address: 00993a40
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __assert2(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: __cxa_thread_atexit_impl
// Address: 00993a48
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void __cxa_thread_atexit_impl(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_once
// Address: 00993a50
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_once(pthread_once_t *__once_control,__init_routine *__init_routine)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_key_delete
// Address: 00993a58
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_key_delete(pthread_key_t __key)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: getauxval
// Address: 00993a60
// ========================================

/* WARNING: Control flow encountered bad instruction data */

void getauxval(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_rwlock_wrlock
// Address: 00993a68
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_wrlock(pthread_rwlock_t *__rwlock)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_rwlock_unlock
// Address: 00993a70
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_unlock(pthread_rwlock_t *__rwlock)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}



// ========================================
// Function: pthread_rwlock_rdlock
// Address: 00993a78
// ========================================

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Unknown calling convention -- yet parameter storage is locked */

int pthread_rwlock_rdlock(pthread_rwlock_t *__rwlock)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

