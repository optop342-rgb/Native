// Batch 8/11
// Functions: 700


// ========================================
// Function: FUN_00505948
// Address: 00505948
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00505948(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1158;
  undefined8 local_1150;
  undefined8 uStack_1148;
  undefined1 auStack_1140 [4096];
  undefined8 *local_140;
  long local_138;
  undefined8 uStack_130;
  undefined8 local_128 [24];
  long local_68;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_68 = *(long *)(lVar3 + 0x28);
  uStack_130 = _UNK_001a0d48;
  local_138 = _DAT_001a0d40;
  uStack_1148 = _UNK_001a1328;
  local_1150 = _DAT_001a1320;
  local_1158 = auStack_1140;
  local_140 = local_128;
                    /* try { // try from 005059c8 to 00505a4f has its CatchHandler @ 00505aec */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1158,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1158,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1158,param_4,uVar6);
  FUN_00505b14(&local_1158,param_5);
  uVar6 = __strlen_chk(param_6,0xffffffffffffffff);
  FUN_0044c958(&local_1158,param_6,uVar6);
  FUN_0044c6fc(param_1,&local_1158);
  if (local_138 != 0) {
    lVar8 = local_138 * 0x18;
    puVar7 = local_140;
    do {
      if ((undefined1 *)*puVar7 != auStack_1140) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1158 != auStack_1140) {
    free(local_1158);
  }
  local_138 = 0;
  uStack_1148 = uVar5;
  local_1150 = uVar4;
  local_1158 = auStack_1140;
  if (local_140 != local_128) {
    free(local_140);
  }
  if (*(long *)(lVar3 + 0x28) == local_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00505b14
// Address: 00505b14
// ========================================

undefined8 FUN_00505b14(undefined8 param_1,undefined4 *param_2)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  FUN_005628b4(local_50,*param_2);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 00505b68 to 00505b6f has its CatchHandler @ 00505ba8 */
  FUN_0044c958(param_1,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}



// ========================================
// Function: FUN_00505bd8
// Address: 00505bd8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00505bd8(undefined8 param_1,byte *param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  long lVar7;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
                    /* try { // try from 00505c78 to 00505cbf has its CatchHandler @ 00505d60 */
  local_1160 = auStack_1148;
  local_148 = local_130;
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  FUN_00505d8c(&local_1160,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11
               ,param_12);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar7 = local_140 * 0x18;
    puVar6 = local_148;
    do {
      if ((undefined1 *)*puVar6 != auStack_1148) {
        free((undefined1 *)*puVar6);
      }
      lVar7 = lVar7 + -0x18;
      puVar6 = puVar6 + 3;
    } while (lVar7 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00505d8c
// Address: 00505d8c
// ========================================

void FUN_00505d8c(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  FUN_00505e94(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_00505e94
// Address: 00505e94
// ========================================

void FUN_00505e94(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,undefined8 *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  __s = (char *)*param_5;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_00505f54
// Address: 00505f54
// ========================================

void FUN_00505f54(long param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 undefined8 *param_6,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1 + 0xc68,param_2,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1 + 0xc68,param_4,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  __s = (char *)*param_6;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1 + 0xc68,__s,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_0050608c
// Address: 0050608c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050608c(undefined8 param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined8 uVar7;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_70 = *(long *)(lVar1 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uVar7 = *param_2;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 0050610c to 0050614f has its CatchHandler @ 005061ec */
  uVar4 = __strlen_chk(uVar7,0xffffffffffffffff);
  FUN_0044c958(&local_1160,uVar7,uVar4);
  FUN_00506340(&local_1160,param_3,param_4,param_5,param_6,param_7);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar6 = local_140 * 0x18;
    puVar5 = local_148;
    do {
      if ((undefined1 *)*puVar5 != auStack_1148) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar3;
  local_1158 = uVar2;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar1 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00506214
// Address: 00506214
// ========================================

void FUN_00506214(long param_1,undefined8 *param_2,char *param_3,undefined8 *param_4,char *param_5,
                 undefined8 *param_6,char *param_7)

{
  size_t sVar1;
  char *pcVar2;
  
  pcVar2 = (char *)*param_2;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar1);
  pcVar2 = (char *)*param_4;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar1);
  pcVar2 = (char *)*param_6;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_00506340
// Address: 00506340
// ========================================

void FUN_00506340(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,
                 undefined8 *param_5,char *param_6)

{
  size_t sVar1;
  char *pcVar2;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar1);
  pcVar2 = (char *)*param_3;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar1);
  pcVar2 = (char *)*param_5;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar1);
  return;
}



// ========================================
// Function: FUN_005063fc
// Address: 005063fc
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005063fc(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 00506464 to 00506487 has its CatchHandler @ 0050651c */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00506544
// Address: 00506544
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00506544(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 005065ac to 005065cf has its CatchHandler @ 00506664 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050668c
// Address: 0050668c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050668c(undefined8 param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined8 uVar7;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_70 = *(long *)(lVar1 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uVar7 = *param_2;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 0050670c to 0050674f has its CatchHandler @ 005067ec */
  uVar4 = __strlen_chk(uVar7,0xffffffffffffffff);
  FUN_0044c958(&local_1160,uVar7,uVar4);
  FUN_00506940(&local_1160,param_3,param_4,param_5,param_6,param_7);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar6 = local_140 * 0x18;
    puVar5 = local_148;
    do {
      if ((undefined1 *)*puVar5 != auStack_1148) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar3;
  local_1158 = uVar2;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar1 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00506814
// Address: 00506814
// ========================================

void FUN_00506814(long param_1,undefined8 *param_2,char *param_3,undefined8 *param_4,char *param_5,
                 undefined8 *param_6,char *param_7)

{
  size_t sVar1;
  char *pcVar2;
  
  pcVar2 = (char *)*param_2;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar1);
  pcVar2 = (char *)*param_4;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar1);
  pcVar2 = (char *)*param_6;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_00506940
// Address: 00506940
// ========================================

void FUN_00506940(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,
                 undefined8 *param_5,char *param_6)

{
  size_t sVar1;
  char *pcVar2;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar1);
  pcVar2 = (char *)*param_3;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar1);
  pcVar2 = (char *)*param_5;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar1);
  return;
}



// ========================================
// Function: FUN_005069fc
// Address: 005069fc
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005069fc(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 00506a64 to 00506a87 has its CatchHandler @ 00506b1c */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00506b44
// Address: 00506b44
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00506b44(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 00506bac to 00506bcf has its CatchHandler @ 00506c64 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00506c8c
// Address: 00506c8c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00506c8c(undefined8 param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined8 uVar7;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_70 = *(long *)(lVar1 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uVar7 = *param_2;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 00506d0c to 00506d4f has its CatchHandler @ 00506dec */
  uVar4 = __strlen_chk(uVar7,0xffffffffffffffff);
  FUN_0044c958(&local_1160,uVar7,uVar4);
  FUN_00506f40(&local_1160,param_3,param_4,param_5,param_6,param_7);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar6 = local_140 * 0x18;
    puVar5 = local_148;
    do {
      if ((undefined1 *)*puVar5 != auStack_1148) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar3;
  local_1158 = uVar2;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar1 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00506e14
// Address: 00506e14
// ========================================

void FUN_00506e14(long param_1,undefined8 *param_2,char *param_3,undefined8 *param_4,char *param_5,
                 undefined8 *param_6,char *param_7)

{
  size_t sVar1;
  char *pcVar2;
  
  pcVar2 = (char *)*param_2;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar1);
  pcVar2 = (char *)*param_4;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar1);
  pcVar2 = (char *)*param_6;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_00506f40
// Address: 00506f40
// ========================================

void FUN_00506f40(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,
                 undefined8 *param_5,char *param_6)

{
  size_t sVar1;
  char *pcVar2;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar1);
  pcVar2 = (char *)*param_3;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar1);
  pcVar2 = (char *)*param_5;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar1);
  return;
}



// ========================================
// Function: FUN_00506ffc
// Address: 00506ffc
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00506ffc(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 00507064 to 00507087 has its CatchHandler @ 0050711c */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00507144
// Address: 00507144
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00507144(undefined8 param_1,undefined8 *param_2,undefined8 param_3)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined8 uVar7;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uVar7 = *param_2;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 005071b4 to 005071f7 has its CatchHandler @ 00507290 */
  uVar4 = __strlen_chk(uVar7,0xffffffffffffffff);
  FUN_0044c958(&local_1148,uVar7,uVar4);
  uVar4 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_3,uVar4);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar6 = local_128 * 0x18;
    puVar5 = local_130;
    do {
      if ((undefined1 *)*puVar5 != auStack_1130) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar3;
  local_1140 = uVar2;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005072b8
// Address: 005072b8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005072b8(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 00507320 to 00507343 has its CatchHandler @ 005073d8 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00507400
// Address: 00507400
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00507400(undefined8 param_1,undefined8 *param_2,undefined8 param_3)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined8 uVar7;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uVar7 = *param_2;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 00507470 to 005074b3 has its CatchHandler @ 0050754c */
  uVar4 = __strlen_chk(uVar7,0xffffffffffffffff);
  FUN_0044c958(&local_1148,uVar7,uVar4);
  uVar4 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_3,uVar4);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar6 = local_128 * 0x18;
    puVar5 = local_130;
    do {
      if ((undefined1 *)*puVar5 != auStack_1130) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar3;
  local_1140 = uVar2;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00507574
// Address: 00507574
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00507574(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 005075dc to 005075ff has its CatchHandler @ 00507694 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005076bc
// Address: 005076bc
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005076bc(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_70 = *(long *)(lVar1 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 0050774c to 005077a3 has its CatchHandler @ 00507848 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar4);
  FUN_00507874(&local_1160,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11
               ,param_12);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar6 = local_140 * 0x18;
    puVar5 = local_148;
    do {
      if ((undefined1 *)*puVar5 != auStack_1148) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  uStack_1150 = uVar3;
  local_1158 = uVar2;
  local_140 = 0;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar1 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00507874
// Address: 00507874
// ========================================

void FUN_00507874(undefined8 param_1,undefined8 param_2,char *param_3,undefined8 *param_4,
                 char *param_5,undefined8 *param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11)

{
  size_t sVar1;
  char *pcVar2;
  
  FUN_00507954();
  sVar1 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar1);
  pcVar2 = (char *)*param_4;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar1);
  pcVar2 = (char *)*param_6;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  FUN_00507a18(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_00507954
// Address: 00507954
// ========================================

undefined8 FUN_00507954(undefined8 param_1,undefined4 *param_2)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  FUN_005628b4(local_50,*param_2);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 005079a8 to 005079af has its CatchHandler @ 005079e8 */
  FUN_0044c958(param_1,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}



// ========================================
// Function: FUN_00507a18
// Address: 00507a18
// ========================================

void FUN_00507a18(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,
                 undefined8 *param_5,char *param_6)

{
  size_t sVar1;
  char *pcVar2;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar1);
  pcVar2 = (char *)*param_3;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar1);
  pcVar2 = (char *)*param_5;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar1);
  return;
}



// ========================================
// Function: FUN_00507ad4
// Address: 00507ad4
// ========================================

void FUN_00507ad4(long param_1,undefined8 *param_2,char *param_3,undefined8 *param_4,char *param_5,
                 undefined8 *param_6,char *param_7)

{
  size_t sVar1;
  char *pcVar2;
  
  pcVar2 = (char *)*param_2;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar1);
  pcVar2 = (char *)*param_4;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar1);
  pcVar2 = (char *)*param_6;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_00507c00
// Address: 00507c00
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00507c00(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12,
                 undefined8 param_13,undefined8 param_14)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_70 = *(long *)(lVar1 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 00507c8c to 00507d07 has its CatchHandler @ 00507da8 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar4);
  FUN_00507954(&local_1160,param_3);
  uVar4 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_4,uVar4);
  FUN_00507dd4(&local_1160,param_5,param_6,param_7,param_8,param_9,param_10,param_11,param_12,
               param_13,param_14);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar6 = local_140 * 0x18;
    puVar5 = local_148;
    do {
      if ((undefined1 *)*puVar5 != auStack_1148) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar3;
  local_1158 = uVar2;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar1 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00507dd4
// Address: 00507dd4
// ========================================

void FUN_00507dd4(undefined8 param_1,undefined8 *param_2,char *param_3,undefined8 *param_4,
                 char *param_5,undefined8 *param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11)

{
  size_t sVar1;
  char *pcVar2;
  
  pcVar2 = (char *)*param_2;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar1);
  pcVar2 = (char *)*param_4;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar1);
  pcVar2 = (char *)*param_6;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  FUN_00507ed4(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_00507ed4
// Address: 00507ed4
// ========================================

void FUN_00507ed4(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,
                 undefined8 *param_5,char *param_6)

{
  size_t sVar1;
  char *pcVar2;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar1);
  pcVar2 = (char *)*param_3;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar1);
  pcVar2 = (char *)*param_5;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar1);
  return;
}



// ========================================
// Function: FUN_00507f90
// Address: 00507f90
// ========================================

void FUN_00507f90(long param_1,undefined8 param_2,char *param_3,undefined8 *param_4,char *param_5,
                 undefined8 *param_6,char *param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11,undefined8 param_12,undefined8 param_13)

{
  size_t sVar1;
  char *pcVar2;
  
  FUN_00507954(param_1 + 0xc68);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar1);
  pcVar2 = (char *)*param_4;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar1);
  pcVar2 = (char *)*param_6;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_005080e4(param_1,param_8,param_9,param_10,param_11,param_12,param_13);
  return;
}



// ========================================
// Function: FUN_005080e4
// Address: 005080e4
// ========================================

void FUN_005080e4(long param_1,undefined8 *param_2,char *param_3,undefined8 *param_4,char *param_5,
                 undefined8 *param_6,char *param_7)

{
  size_t sVar1;
  char *pcVar2;
  
  pcVar2 = (char *)*param_2;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar1);
  pcVar2 = (char *)*param_4;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar1);
  pcVar2 = (char *)*param_6;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_00508210
// Address: 00508210
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00508210(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  long lVar5;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 00508298 to 005082b3 has its CatchHandler @ 00508348 */
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_00508370(&local_1138,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,
               param_11);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar5 = local_118 * 0x18;
    puVar4 = local_120;
    do {
      if ((undefined1 *)*puVar4 != auStack_1120) {
        free((undefined1 *)*puVar4);
      }
      lVar5 = lVar5 + -0x18;
      puVar4 = puVar4 + 3;
    } while (lVar5 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00508370
// Address: 00508370
// ========================================

void FUN_00508370(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,
                 undefined8 *param_5,char *param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11)

{
  size_t sVar1;
  char *pcVar2;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar1);
  pcVar2 = (char *)*param_3;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar1);
  pcVar2 = (char *)*param_5;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar1);
  FUN_00508470(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_00508470
// Address: 00508470
// ========================================

void FUN_00508470(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,
                 undefined8 *param_5,char *param_6)

{
  size_t sVar1;
  char *pcVar2;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar1);
  pcVar2 = (char *)*param_3;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar1);
  pcVar2 = (char *)*param_5;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar1);
  return;
}



// ========================================
// Function: FUN_0050852c
// Address: 0050852c
// ========================================

void FUN_0050852c(long param_1,char *param_2,char *param_3,undefined8 *param_4,char *param_5,
                 undefined8 *param_6,char *param_7)

{
  size_t sVar1;
  char *pcVar2;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1 + 0xc68,param_2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar1);
  pcVar2 = (char *)*param_4;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar1);
  pcVar2 = (char *)*param_6;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_00508658
// Address: 00508658
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00508658(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  long lVar1;
  undefined8 *puVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 005086d0 to 005086e3 has its CatchHandler @ 00508778 */
  uVar4 = _DAT_001a1320;
  uVar5 = _UNK_001a1328;
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_005087a0(&local_1138,param_2,param_3,param_4,param_5,param_6,param_8,param_9,_DAT_001a1320,
               _UNK_001a1328);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar3 = local_118 * 0x18;
    puVar2 = local_120;
    do {
      if ((undefined1 *)*puVar2 != auStack_1120) {
        free((undefined1 *)*puVar2);
      }
      lVar3 = lVar3 + -0x18;
      puVar2 = puVar2 + 3;
    } while (lVar3 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  local_1138 = auStack_1120;
  local_1130 = uVar4;
  uStack_1128 = uVar5;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005087a0
// Address: 005087a0
// ========================================

void FUN_005087a0(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,
                 undefined8 *param_5,char *param_6)

{
  size_t sVar1;
  char *pcVar2;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar1);
  pcVar2 = (char *)*param_3;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar1);
  pcVar2 = (char *)*param_5;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar1);
  return;
}



// ========================================
// Function: FUN_0050885c
// Address: 0050885c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050885c(undefined8 param_1,undefined8 param_2,undefined8 *param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12,
                 undefined8 param_13)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined8 uVar7;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_70 = *(long *)(lVar1 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 005088e8 to 0050895b has its CatchHandler @ 005089fc */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar4);
  uVar7 = *param_3;
  uVar4 = __strlen_chk(uVar7,0xffffffffffffffff);
  FUN_0044c958(&local_1160,uVar7,uVar4);
  FUN_00508b98(&local_1160,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,
               param_12,param_13);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar6 = local_140 * 0x18;
    puVar5 = local_148;
    do {
      if ((undefined1 *)*puVar5 != auStack_1148) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar3;
  local_1158 = uVar2;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar1 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00508a28
// Address: 00508a28
// ========================================

void FUN_00508a28(long param_1,char *param_2,undefined8 *param_3,char *param_4,undefined8 *param_5,
                 char *param_6,char *param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11,undefined8 param_12,undefined8 param_13)

{
  size_t sVar1;
  char *pcVar2;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1 + 0xc68,param_2,sVar1);
  pcVar2 = (char *)*param_3;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1 + 0xc68,param_4,sVar1);
  pcVar2 = (char *)*param_5;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_6);
  FUN_0044c958(param_1 + 0xc68,param_6,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_00508d54(param_1,param_8,param_9,param_10,param_11,param_12,param_13);
  return;
}



// ========================================
// Function: FUN_00508b98
// Address: 00508b98
// ========================================

void FUN_00508b98(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,char *param_5,
                 undefined8 *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  size_t sVar1;
  char *pcVar2;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar1);
  pcVar2 = (char *)*param_3;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar1);
  sVar1 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar1);
  pcVar2 = (char *)*param_6;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  FUN_00508c98(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_00508c98
// Address: 00508c98
// ========================================

void FUN_00508c98(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,
                 undefined8 *param_5,char *param_6)

{
  size_t sVar1;
  char *pcVar2;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar1);
  pcVar2 = (char *)*param_3;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar1);
  pcVar2 = (char *)*param_5;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar1);
  return;
}



// ========================================
// Function: FUN_00508d54
// Address: 00508d54
// ========================================

void FUN_00508d54(long param_1,undefined8 *param_2,char *param_3,undefined8 *param_4,char *param_5,
                 undefined8 *param_6,char *param_7)

{
  size_t sVar1;
  char *pcVar2;
  
  pcVar2 = (char *)*param_2;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar1);
  pcVar2 = (char *)*param_4;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar1);
  pcVar2 = (char *)*param_6;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1 + 0xc68,pcVar2,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar1 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_00508e80
// Address: 00508e80
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00508e80(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  long lVar1;
  undefined8 *puVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 00508ef8 to 00508f0b has its CatchHandler @ 00508fa0 */
  uVar4 = _DAT_001a1320;
  uVar5 = _UNK_001a1328;
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_00508fc8(&local_1138,param_2,param_3,param_4,param_5,param_6,param_8,param_9,_DAT_001a1320,
               _UNK_001a1328);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar3 = local_118 * 0x18;
    puVar2 = local_120;
    do {
      if ((undefined1 *)*puVar2 != auStack_1120) {
        free((undefined1 *)*puVar2);
      }
      lVar3 = lVar3 + -0x18;
      puVar2 = puVar2 + 3;
    } while (lVar3 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  local_1138 = auStack_1120;
  local_1130 = uVar4;
  uStack_1128 = uVar5;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00508fc8
// Address: 00508fc8
// ========================================

void FUN_00508fc8(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,
                 undefined8 *param_5,char *param_6)

{
  size_t sVar1;
  char *pcVar2;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar1);
  pcVar2 = (char *)*param_3;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar1);
  pcVar2 = (char *)*param_5;
  sVar1 = strlen(pcVar2);
  FUN_0044c958(param_1,pcVar2,sVar1);
  sVar1 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar1);
  return;
}



// ========================================
// Function: FUN_00509084
// Address: 00509084
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

long * FUN_00509084(long *param_1,uint *param_2,undefined8 param_3,undefined8 *param_4)

{
  uint uVar1;
  undefined4 uVar2;
  ulong uVar3;
  long lVar4;
  long *plVar5;
  undefined8 uVar6;
  long lVar7;
  long *plVar8;
  long lVar9;
  undefined8 *puVar10;
  long lVar11;
  ulong uVar12;
  long lVar13;
  long *plVar14;
  long *plVar15;
  long *plVar16;
  long *plVar17;
  long *plVar18;
  long *unaff_x26;
  undefined2 uVar19;
  float fVar20;
  
  lVar4 = tpidr_el0;
  lVar7 = *(long *)(lVar4 + 0x28);
  plVar18 = (long *)param_1[1];
  uVar1 = *param_2;
  plVar17 = (long *)(ulong)uVar1;
  if (plVar18 != (long *)0x0) {
    uVar6 = CONCAT17(POPCOUNT((char)((ulong)plVar18 >> 0x38)),
                     CONCAT16(POPCOUNT((char)((ulong)plVar18 >> 0x30)),
                              CONCAT15(POPCOUNT((char)((ulong)plVar18 >> 0x28)),
                                       CONCAT14(POPCOUNT((char)((ulong)plVar18 >> 0x20)),
                                                CONCAT13(POPCOUNT((char)((ulong)plVar18 >> 0x18)),
                                                         CONCAT12(POPCOUNT((char)((ulong)plVar18 >>
                                                                                 0x10)),
                                                                  CONCAT11(POPCOUNT((char)((ulong)
                                                  plVar18 >> 8)),POPCOUNT((char)plVar18))))))));
    uVar19 = NEON_uaddlv(uVar6,1);
    uVar12 = CONCAT62((int6)((ulong)uVar6 >> 0x10),uVar19) & 0xffffffff;
    if (uVar12 < 2) {
      unaff_x26 = (long *)(ulong)((int)plVar18 - 1U & uVar1);
    }
    else {
      unaff_x26 = plVar17;
      if (plVar18 <= plVar17) {
        uVar3 = 0;
        if (plVar18 != (long *)0x0) {
          uVar3 = (ulong)plVar17 / (ulong)plVar18;
        }
        unaff_x26 = (long *)((long)plVar17 - uVar3 * (long)plVar18);
      }
    }
    puVar10 = *(undefined8 **)(*param_1 + (long)unaff_x26 * 8);
    if ((puVar10 != (undefined8 *)0x0) && (plVar16 = (long *)*puVar10, plVar16 != (long *)0x0)) {
      do {
        plVar14 = (long *)plVar16[1];
        if (plVar14 == plVar17) {
          if (*(uint *)(plVar16 + 2) == uVar1) {
            uVar6 = 0;
            goto LAB_00509354;
          }
        }
        else {
          if (uVar12 < 2) {
            plVar14 = (long *)((ulong)plVar14 & (long)plVar18 - 1U);
          }
          else if (plVar18 <= plVar14) {
            uVar3 = 0;
            if (plVar18 != (long *)0x0) {
              uVar3 = (ulong)plVar14 / (ulong)plVar18;
            }
            plVar14 = (long *)((long)plVar14 - uVar3 * (long)plVar18);
          }
          if (plVar14 != unaff_x26) break;
        }
        plVar16 = (long *)*plVar16;
      } while (plVar16 != (long *)0x0);
    }
  }
  plVar14 = param_1 + 2;
  plVar16 = (long *)FUN_005a5d4c(0x50);
  lVar9 = _UNK_001a0d48;
  lVar13 = _DAT_001a0d40;
  lVar11 = param_1[3];
  uVar2 = *(undefined4 *)*param_4;
  *plVar16 = 0;
  plVar16[1] = (long)plVar17;
  plVar16[5] = lVar9;
  plVar16[4] = lVar13;
  fVar20 = *(float *)(param_1 + 4);
  *(undefined4 *)(plVar16 + 2) = uVar2;
  plVar16[3] = (long)(plVar16 + 6);
  plVar5 = plVar16;
  if ((plVar18 == (long *)0x0) || (fVar20 * (float)plVar18 < (float)(lVar11 + 1))) {
    if (plVar18 < (long *)0x3) {
      uVar12 = 1;
    }
    else {
      uVar12 = (ulong)(((ulong)plVar18 & (long)plVar18 - 1U) != 0);
    }
    plVar8 = (long *)(uVar12 | (long)plVar18 << 1);
    plVar15 = (long *)(long)((float)(lVar11 + 1) / fVar20);
    if (plVar8 <= plVar15) {
      plVar8 = plVar15;
    }
    if ((long)plVar8 - 1U == 0) {
      plVar8 = (long *)0x2;
    }
    else if (((ulong)plVar8 & (long)plVar8 - 1U) != 0) {
                    /* try { // try from 00509218 to 005092a3 has its CatchHandler @ 00509384 */
      plVar5 = (long *)FUN_0055fe2c(plVar8);
      plVar18 = (long *)param_1[1];
      plVar8 = plVar5;
    }
    if (plVar18 < plVar8) {
LAB_00509230:
      plVar5 = (long *)FUN_00509400(param_1,plVar8);
    }
    else if (plVar8 < plVar18) {
      plVar5 = (long *)(long)((float)(ulong)param_1[3] / *(float *)(param_1 + 4));
      if ((plVar18 < (long *)0x3) ||
         (uVar6 = CONCAT17(POPCOUNT((char)((ulong)plVar18 >> 0x38)),
                           CONCAT16(POPCOUNT((char)((ulong)plVar18 >> 0x30)),
                                    CONCAT15(POPCOUNT((char)((ulong)plVar18 >> 0x28)),
                                             CONCAT14(POPCOUNT((char)((ulong)plVar18 >> 0x20)),
                                                      CONCAT13(POPCOUNT((char)((ulong)plVar18 >>
                                                                              0x18)),
                                                               CONCAT12(POPCOUNT((char)((ulong)
                                                  plVar18 >> 0x10)),
                                                  CONCAT11(POPCOUNT((char)((ulong)plVar18 >> 8)),
                                                           POPCOUNT((char)plVar18)))))))),
         uVar19 = NEON_uaddlv(uVar6,1),
         1 < (CONCAT62((int6)((ulong)uVar6 >> 0x10),uVar19) & 0xffffffff))) {
        plVar5 = (long *)FUN_0055fe2c();
      }
      else if ((long *)0x1 < plVar5) {
        plVar5 = (long *)(1L << (-LZCOUNT((long)plVar5 + -1) & 0x3fU));
      }
      if (plVar8 <= plVar5) {
        plVar8 = plVar5;
      }
      if (plVar8 < plVar18) goto LAB_00509230;
    }
    plVar18 = (long *)param_1[1];
    if (((ulong)plVar18 & (long)plVar18 - 1U) == 0) {
      unaff_x26 = (long *)(ulong)((int)plVar18 - 1U & uVar1);
    }
    else {
      unaff_x26 = plVar17;
      if (plVar18 <= plVar17) {
        uVar12 = 0;
        if (plVar18 != (long *)0x0) {
          uVar12 = (ulong)plVar17 / (ulong)plVar18;
        }
        unaff_x26 = (long *)((long)plVar17 - uVar12 * (long)plVar18);
      }
    }
  }
  lVar13 = *param_1;
  plVar17 = *(long **)(lVar13 + (long)unaff_x26 * 8);
  if (plVar17 == (long *)0x0) {
    lVar9 = *plVar14;
    *plVar14 = (long)plVar16;
    *plVar16 = lVar9;
    *(long **)(lVar13 + (long)unaff_x26 * 8) = plVar14;
    if (*plVar16 == 0) goto LAB_00509344;
    plVar17 = *(long **)(*plVar16 + 8);
    if (((ulong)plVar18 & (long)plVar18 - 1U) == 0) {
      plVar17 = (long *)((ulong)plVar17 & (long)plVar18 - 1U);
    }
    else if (plVar18 <= plVar17) {
      uVar12 = 0;
      if (plVar18 != (long *)0x0) {
        uVar12 = (ulong)plVar17 / (ulong)plVar18;
      }
      plVar17 = (long *)((long)plVar17 - uVar12 * (long)plVar18);
    }
    plVar17 = (long *)(*param_1 + (long)plVar17 * 8);
  }
  else {
    *plVar16 = *plVar17;
  }
  *plVar17 = (long)plVar16;
LAB_00509344:
  uVar6 = 1;
  param_1[3] = param_1[3] + 1;
  param_1 = plVar5;
LAB_00509354:
  if (*(long *)(lVar4 + 0x28) == lVar7) {
    return plVar16;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(param_1,uVar6);
}



// ========================================
// Function: FUN_005093ac
// Address: 005093ac
// ========================================

void FUN_005093ac(undefined8 *param_1)

{
  void *__ptr;
  
  __ptr = (void *)*param_1;
  *param_1 = 0;
  if (__ptr != (void *)0x0) {
    if (*(char *)(param_1 + 2) != '\0') {
      *(undefined8 *)((long)__ptr + 0x20) = 0;
      if (*(void **)((long)__ptr + 0x18) != (void *)((long)__ptr + 0x30)) {
        free(*(void **)((long)__ptr + 0x18));
      }
    }
    free(__ptr);
    return;
  }
  return;
}



// ========================================
// Function: FUN_00509400
// Address: 00509400
// ========================================

void FUN_00509400(long *param_1,ulong param_2)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  ulong uVar4;
  long *plVar5;
  ulong uVar6;
  long *plVar7;
  ulong uVar8;
  undefined2 uVar9;
  undefined8 uVar10;
  
  if (param_2 == 0) {
    pvVar3 = (void *)*param_1;
    *param_1 = 0;
    if (pvVar3 != (void *)0x0) {
      free(pvVar3);
    }
    param_1[1] = 0;
  }
  else {
    if (param_2 >> 0x3d != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_0029fc3c();
    }
    lVar2 = FUN_005a5d4c(param_2 << 3);
    pvVar3 = (void *)*param_1;
    *param_1 = lVar2;
    if (pvVar3 != (void *)0x0) {
      free(pvVar3);
    }
    uVar4 = 0;
    param_1[1] = param_2;
    do {
      *(undefined8 *)(*param_1 + uVar4 * 8) = 0;
      uVar4 = uVar4 + 1;
    } while (param_2 != uVar4);
    plVar5 = (long *)param_1[2];
    if (plVar5 != (long *)0x0) {
      uVar4 = plVar5[1];
      uVar10 = CONCAT17(POPCOUNT((char)(param_2 >> 0x38)),
                        CONCAT16(POPCOUNT((char)(param_2 >> 0x30)),
                                 CONCAT15(POPCOUNT((char)(param_2 >> 0x28)),
                                          CONCAT14(POPCOUNT((char)(param_2 >> 0x20)),
                                                   CONCAT13(POPCOUNT((char)(param_2 >> 0x18)),
                                                            CONCAT12(POPCOUNT((char)(param_2 >> 0x10
                                                                                    )),
                                                                     CONCAT11(POPCOUNT((char)(
                                                  param_2 >> 8)),POPCOUNT((char)param_2))))))));
      uVar9 = NEON_uaddlv(uVar10,1);
      uVar6 = CONCAT62((int6)((ulong)uVar10 >> 0x10),uVar9) & 0xffffffff;
      if (uVar6 < 2) {
        uVar4 = uVar4 & param_2 - 1;
      }
      else if (param_2 <= uVar4) {
        uVar8 = 0;
        if (param_2 != 0) {
          uVar8 = uVar4 / param_2;
        }
        uVar4 = uVar4 - uVar8 * param_2;
      }
      *(long **)(*param_1 + uVar4 * 8) = param_1 + 2;
      plVar7 = (long *)*plVar5;
      if (plVar7 != (long *)0x0) {
        do {
          uVar8 = plVar7[1];
          if (uVar6 < 2) {
            uVar8 = uVar8 & param_2 - 1;
          }
          else if (param_2 <= uVar8) {
            uVar1 = 0;
            if (param_2 != 0) {
              uVar1 = uVar8 / param_2;
            }
            uVar8 = uVar8 - uVar1 * param_2;
          }
          if (uVar8 != uVar4) {
            if (*(long *)(*param_1 + uVar8 * 8) == 0) {
              *(long **)(*param_1 + uVar8 * 8) = plVar5;
              uVar4 = uVar8;
            }
            else {
              *plVar5 = *plVar7;
              *plVar7 = **(long **)(*param_1 + uVar8 * 8);
              **(undefined8 **)(*param_1 + uVar8 * 8) = plVar7;
              plVar7 = plVar5;
            }
          }
          plVar5 = plVar7;
          plVar7 = (long *)*plVar5;
        } while (plVar7 != (long *)0x0);
      }
    }
  }
  return;
}



// ========================================
// Function: FUN_0050955c
// Address: 0050955c
// ========================================

void FUN_0050955c(long param_1,undefined4 *param_2)

{
  long lVar1;
  long lVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined *puVar5;
  long *plVar6;
  void *pvVar7;
  long lVar8;
  ulong uVar9;
  void *pvVar10;
  
  lVar8 = *(long *)(param_1 + 0x10);
  if (lVar8 == 0) {
    uVar4 = *(int *)(param_1 + 0x80) << (ulong)(*(uint *)(param_1 + 0x30) & 0x1f);
    uVar9 = (ulong)uVar4;
    pvVar7 = malloc(uVar9 * 0x170);
    if (pvVar7 == (void *)0x0) {
      return;
    }
    FUN_00454404(param_1 + 8,uVar9);
    if (uVar4 != 0) {
      lVar8 = *(long *)(param_1 + 0x10);
      pvVar10 = pvVar7;
      do {
        FUN_00454404(param_1 + 8,lVar8 + 1);
        lVar8 = *(long *)(param_1 + 0x10);
        uVar9 = uVar9 - 1;
        *(void **)(*(long *)(param_1 + 8) + lVar8 * 8) = pvVar10;
        lVar8 = lVar8 + 1;
        pvVar10 = (void *)((long)pvVar10 + 0x170);
        *(long *)(param_1 + 0x10) = lVar8;
      } while (uVar9 != 0);
    }
    FUN_004544f4(param_1 + 0x28,*(long *)(param_1 + 0x30) + 1);
    lVar1 = *(long *)(param_1 + 8);
    lVar8 = *(long *)(param_1 + 0x10);
    lVar2 = *(long *)(param_1 + 0x30);
    *(void **)(*(long *)(param_1 + 0x28) + lVar2 * 8) = pvVar7;
    plVar6 = *(long **)(lVar1 + lVar8 * 8 + -8);
    *(long *)(param_1 + 0x30) = lVar2 + 1;
    if (lVar8 == 0) goto LAB_00509590;
  }
  else {
    plVar6 = *(long **)(*(long *)(param_1 + 8) + lVar8 * 8 + -8);
  }
  *(long *)(param_1 + 0x10) = lVar8 + -1;
LAB_00509590:
  puVar5 = PTR_DAT_005c61b0;
  uVar3 = *param_2;
  plVar6[6] = 0;
  plVar6[7] = 0;
  *(undefined4 *)(plVar6 + 1) = 0;
  *(undefined4 *)((long)plVar6 + 0xc) = uVar3;
  *(undefined4 *)(plVar6 + 8) = 1;
  *(undefined4 *)(plVar6 + 0xf) = 1;
  *(undefined4 *)(plVar6 + 0x16) = 1;
  *(undefined4 *)(plVar6 + 0x1d) = 1;
  *(undefined4 *)(plVar6 + 0x20) = 1;
  plVar6[0x22] = (long)(plVar6 + 0x25);
  plVar6[0x23] = 0;
  *plVar6 = (long)(puVar5 + 0x10);
  plVar6[3] = 0;
  plVar6[2] = 0;
  plVar6[5] = 0;
  plVar6[4] = 0;
  plVar6[0xd] = 0;
  plVar6[0xe] = 0;
  plVar6[10] = 0;
  plVar6[9] = 0;
  plVar6[0xc] = 0;
  plVar6[0xb] = 0;
  plVar6[0x14] = 0;
  plVar6[0x15] = 0;
  plVar6[0x11] = 0;
  plVar6[0x10] = 0;
  plVar6[0x13] = 0;
  plVar6[0x12] = 0;
  plVar6[0x1b] = 0;
  plVar6[0x1c] = 0;
  plVar6[0x18] = 0;
  plVar6[0x17] = 0;
  plVar6[0x1a] = 0;
  plVar6[0x19] = 0;
  plVar6[0x1e] = 0;
  plVar6[0x1f] = 0;
  *(undefined4 *)(plVar6 + 0x21) = 0;
  plVar6[0x24] = 8;
  *(undefined1 *)(plVar6 + 0x29) = 0;
  plVar6[0x2b] = 0;
  plVar6[0x2c] = 0;
  *(undefined4 *)(plVar6 + 0x2d) = 0;
  plVar6[0x2a] = 0;
  return;
}



// ========================================
// Function: FUN_005096c4
// Address: 005096c4
// ========================================

void FUN_005096c4(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_00509788
// Address: 00509788
// ========================================

void FUN_00509788(undefined8 param_1,undefined4 *param_2,char *param_3)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  FUN_00562e2c(local_50,*param_2);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 005097e0 to 005097e7 has its CatchHandler @ 00509834 */
  FUN_0044c958(param_1,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar4);
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_00509864
// Address: 00509864
// ========================================

void FUN_00509864(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  return;
}



// ========================================
// Function: FUN_00509928
// Address: 00509928
// ========================================

void FUN_00509928(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_005099ec
// Address: 005099ec
// ========================================

void FUN_005099ec(undefined8 param_1,char *param_2,char *param_3,char *param_4,undefined8 *param_5,
                 char *param_6)

{
  size_t sVar1;
  char *__s;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar1);
  sVar1 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar1);
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar1);
  __s = (char *)*param_5;
  sVar1 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar1);
  sVar1 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar1);
  return;
}



// ========================================
// Function: FUN_00509aa4
// Address: 00509aa4
// ========================================

void FUN_00509aa4(undefined8 param_1,char *param_2,char *param_3,char *param_4,undefined8 *param_5,
                 char *param_6)

{
  size_t sVar1;
  char *__s;
  
  sVar1 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar1);
  sVar1 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar1);
  sVar1 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar1);
  __s = (char *)*param_5;
  sVar1 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar1);
  sVar1 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar1);
  return;
}



// ========================================
// Function: FUN_00509b5c
// Address: 00509b5c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00509b5c(undefined8 param_1,byte *param_2,byte *param_3,byte *param_4,undefined8 param_5)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
                    /* try { // try from 00509be8 to 00509c57 has its CatchHandler @ 00509cf0 */
  local_1148 = auStack_1130;
  local_130 = local_118;
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_5,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_5,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_00509d18
// Address: 00509d18
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_00509d18(long param_1,byte *param_2,undefined4 *param_3,undefined1 *param_4)

{
  long lVar1;
  long lVar2;
  undefined4 uVar3;
  undefined1 uVar4;
  uint uVar5;
  long lVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  long lVar9;
  undefined8 *puVar10;
  ulong uVar11;
  undefined8 *puVar12;
  undefined8 local_70;
  undefined8 uStack_68;
  undefined8 local_60;
  long local_58;
  
  lVar6 = tpidr_el0;
  local_58 = *(long *)(lVar6 + 0x28);
  lVar9 = *(long *)(param_1 + 0x10);
  if (lVar9 == 0) {
    uVar5 = *(int *)(param_1 + 0x80) << (ulong)(*(uint *)(param_1 + 0x30) & 0x1f);
    uVar11 = (ulong)uVar5;
    puVar10 = (undefined8 *)malloc(uVar11 * 0x120);
    if (puVar10 == (undefined8 *)0x0) goto LAB_00509e08;
    FUN_004517fc(param_1 + 8,uVar11);
    if (uVar5 != 0) {
      lVar9 = *(long *)(param_1 + 0x10);
      puVar12 = puVar10;
      do {
        FUN_004517fc(param_1 + 8,lVar9 + 1);
        lVar9 = *(long *)(param_1 + 0x10);
        uVar11 = uVar11 - 1;
        *(undefined8 **)(*(long *)(param_1 + 8) + lVar9 * 8) = puVar12;
        lVar9 = lVar9 + 1;
        puVar12 = puVar12 + 0x24;
        *(long *)(param_1 + 0x10) = lVar9;
      } while (uVar11 != 0);
    }
    FUN_004518ec(param_1 + 0x28,*(long *)(param_1 + 0x30) + 1);
    lVar1 = *(long *)(param_1 + 8);
    lVar9 = *(long *)(param_1 + 0x10);
    lVar2 = *(long *)(param_1 + 0x30);
    *(undefined8 **)(*(long *)(param_1 + 0x28) + lVar2 * 8) = puVar10;
    puVar10 = *(undefined8 **)(lVar1 + lVar9 * 8 + -8);
    *(long *)(param_1 + 0x30) = lVar2 + 1;
    if (lVar9 != 0) goto LAB_00509d60;
  }
  else {
    puVar10 = *(undefined8 **)(*(long *)(param_1 + 8) + lVar9 * 8 + -8);
LAB_00509d60:
    *(long *)(param_1 + 0x10) = lVar9 + -1;
  }
  if ((*param_2 & 1) == 0) {
    uStack_68 = *(undefined8 *)(param_2 + 8);
    local_70 = *(undefined8 *)param_2;
    local_60 = *(undefined8 *)(param_2 + 0x10);
  }
  else {
    FUN_00251fc8(&local_70,*(undefined8 *)(param_2 + 0x10),*(undefined8 *)(param_2 + 8));
  }
  uVar3 = *param_3;
  uVar4 = *param_4;
  *(undefined4 *)((long)puVar10 + 0x31) = 0;
  *(undefined4 *)(puVar10 + 5) = uVar3;
  *(undefined4 *)((long)puVar10 + 0x2c) = 0;
  *puVar10 = &PTR_FUN_005bdbf0;
  puVar10[1] = 0;
  *(undefined1 *)(puVar10 + 6) = uVar4;
  *(undefined4 *)(puVar10 + 0x23) = 0;
  puVar10[4] = local_60;
  puVar10[7] = puVar10 + 10;
  puVar10[8] = 0;
  puVar10[9] = 8;
  puVar10[3] = uStack_68;
  puVar10[2] = local_70;
  uVar8 = _UNK_001a0d48;
  uVar7 = _DAT_001a0d40;
  puVar10[0xe] = puVar10 + 0x11;
  puVar10[0x15] = puVar10 + 0x18;
  puVar10[0x10] = uVar8;
  puVar10[0xf] = uVar7;
  puVar10[0x17] = uVar8;
  puVar10[0x16] = uVar7;
  puVar10[0x1c] = puVar10 + 0x1f;
  puVar10[0x1e] = uVar8;
  puVar10[0x1d] = uVar7;
LAB_00509e08:
  if (*(long *)(lVar6 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return puVar10;
}



// ========================================
// Function: FUN_00509ed8
// Address: 00509ed8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00509ed8(undefined8 param_1,byte *param_2,byte *param_3,undefined8 param_4)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
                    /* try { // try from 00509f60 to 00509faf has its CatchHandler @ 0050a048 */
  local_1148 = auStack_1130;
  local_130 = local_118;
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0050a070
// Address: 0050a070
// ========================================

void FUN_0050a070(undefined8 param_1,byte *param_2,char *param_3,undefined8 *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  __s = (char *)*param_4;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050a130
// Address: 0050a130
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050a130(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 0050a1b8 to 0050a217 has its CatchHandler @ 0050a2b8 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  FUN_0050a2e4(&local_1160,param_4,param_5,param_6,param_7,param_8);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar8 = local_140 * 0x18;
    puVar7 = local_148;
    do {
      if ((undefined1 *)*puVar7 != auStack_1148) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050a2e4
// Address: 0050a2e4
// ========================================

void FUN_0050a2e4(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050a3a8
// Address: 0050a3a8
// ========================================

void FUN_0050a3a8(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_0050a4d8
// Address: 0050a4d8
// ========================================

void FUN_0050a4d8(undefined8 param_1,byte *param_2,char *param_3,undefined8 *param_4,char *param_5,
                 byte *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  __s = (char *)*param_4;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  return;
}



// ========================================
// Function: FUN_0050a598
// Address: 0050a598
// ========================================

void FUN_0050a598(undefined8 param_1,byte *param_2,char *param_3,undefined8 *param_4,char *param_5,
                 byte *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  __s = (char *)*param_4;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  return;
}



// ========================================
// Function: FUN_0050a658
// Address: 0050a658
// ========================================

void FUN_0050a658(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050a71c
// Address: 0050a71c
// ========================================

void FUN_0050a71c(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050a7e0
// Address: 0050a7e0
// ========================================

void FUN_0050a7e0(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050a8a4
// Address: 0050a8a4
// ========================================

void FUN_0050a8a4(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050a968
// Address: 0050a968
// ========================================

void FUN_0050a968(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050aa2c
// Address: 0050aa2c
// ========================================

void FUN_0050aa2c(undefined8 param_1,undefined8 *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  __s = (char *)*param_2;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_0050a7e0(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_0050ab34
// Address: 0050ab34
// ========================================

void FUN_0050ab34(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  return;
}



// ========================================
// Function: FUN_0050abf8
// Address: 0050abf8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050abf8(undefined8 param_1,byte *param_2,undefined8 param_3,byte *param_4,
                 undefined8 param_5)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
                    /* try { // try from 0050ac84 to 0050acef has its CatchHandler @ 0050ad88 */
  local_1148 = auStack_1130;
  local_130 = local_118;
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_3,uVar6);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_5,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_5,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0050adb0
// Address: 0050adb0
// ========================================

void FUN_0050adb0(long param_1)

{
  undefined8 uVar1;
  
  if (*(long *)(param_1 + 8) == 0) {
    uVar1 = FUN_005a5e04(0x10);
                    /* try { // try from 0050adec to 0050adf7 has its CatchHandler @ 0050ae30 */
    FUN_0043b7a0(uVar1,"nullptr");
  }
  else {
    if (*(int *)(param_1 + 0x10) == 10) {
      return;
    }
    uVar1 = FUN_005a5e04(0x10);
                    /* try { // try from 0050ae08 to 0050ae13 has its CatchHandler @ 0050ae2c */
    FUN_0043b7a0(uVar1,"Bad cast");
  }
                    /* WARNING: Subroutine does not return */
  FUN_005a5f24(uVar1,PTR_PTR_005c6130,PTR_FUN_005c6360);
}



// ========================================
// Function: FUN_0050ae44
// Address: 0050ae44
// ========================================

void FUN_0050ae44(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050af08
// Address: 0050af08
// ========================================

void FUN_0050af08(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050afcc
// Address: 0050afcc
// ========================================

void FUN_0050afcc(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050b090
// Address: 0050b090
// ========================================

void FUN_0050b090(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050b154
// Address: 0050b154
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050b154(undefined8 param_1,byte *param_2,undefined8 param_3,byte *param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
                    /* try { // try from 0050b1f4 to 0050b25f has its CatchHandler @ 0050b300 */
  local_1160 = auStack_1148;
  local_148 = local_130;
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_3,uVar6);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  FUN_0050b32c(&local_1160,param_5,param_6,param_7,param_8,param_9);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar8 = local_140 * 0x18;
    puVar7 = local_148;
    do {
      if ((undefined1 *)*puVar7 != auStack_1148) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) != local_70) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0050b32c
// Address: 0050b32c
// ========================================

void FUN_0050b32c(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050b3f0
// Address: 0050b3f0
// ========================================

void FUN_0050b3f0(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_0050b520
// Address: 0050b520
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050b520(undefined8 param_1,byte *param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  long lVar7;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
                    /* try { // try from 0050b5c0 to 0050b607 has its CatchHandler @ 0050b6a8 */
  local_1160 = auStack_1148;
  local_148 = local_130;
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  FUN_0050b6d4(&local_1160,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11
               ,param_12);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar7 = local_140 * 0x18;
    puVar6 = local_148;
    do {
      if ((undefined1 *)*puVar6 != auStack_1148) {
        free((undefined1 *)*puVar6);
      }
      lVar7 = lVar7 + -0x18;
      puVar6 = puVar6 + 3;
    } while (lVar7 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050b6d4
// Address: 0050b6d4
// ========================================

void FUN_0050b6d4(undefined8 param_1,char *param_2,byte *param_3,char *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_0050b7dc(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_0050b7dc
// Address: 0050b7dc
// ========================================

void FUN_0050b7dc(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050b8a0
// Address: 0050b8a0
// ========================================

void FUN_0050b8a0(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_0050b9d0
// Address: 0050b9d0
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050b9d0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  long lVar5;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 0050ba58 to 0050ba73 has its CatchHandler @ 0050bb08 */
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_0050bb30(&local_1138,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,
               param_11);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar5 = local_118 * 0x18;
    puVar4 = local_120;
    do {
      if ((undefined1 *)*puVar4 != auStack_1120) {
        free((undefined1 *)*puVar4);
      }
      lVar5 = lVar5 + -0x18;
      puVar4 = puVar4 + 3;
    } while (lVar5 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050bb30
// Address: 0050bb30
// ========================================

void FUN_0050bb30(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_0050b32c(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_0050bc30
// Address: 0050bc30
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050bc30(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  long lVar5;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 0050bcb8 to 0050bcd3 has its CatchHandler @ 0050bd68 */
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_0050bd90(&local_1138,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,
               param_11);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar5 = local_118 * 0x18;
    puVar4 = local_120;
    do {
      if ((undefined1 *)*puVar4 != auStack_1120) {
        free((undefined1 *)*puVar4);
      }
      lVar5 = lVar5 + -0x18;
      puVar4 = puVar4 + 3;
    } while (lVar5 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050bd90
// Address: 0050bd90
// ========================================

void FUN_0050bd90(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_0050be90(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_0050be90
// Address: 0050be90
// ========================================

void FUN_0050be90(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050bf54
// Address: 0050bf54
// ========================================

void FUN_0050bf54(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_0050c084
// Address: 0050c084
// ========================================

void FUN_0050c084(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050c148
// Address: 0050c148
// ========================================

void FUN_0050c148(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050c20c
// Address: 0050c20c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050c20c(undefined8 param_1,byte *param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  long lVar7;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
                    /* try { // try from 0050c2ac to 0050c2f3 has its CatchHandler @ 0050c394 */
  local_1160 = auStack_1148;
  local_148 = local_130;
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  FUN_0050c3c0(&local_1160,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11
               ,param_12);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar7 = local_140 * 0x18;
    puVar6 = local_148;
    do {
      if ((undefined1 *)*puVar6 != auStack_1148) {
        free((undefined1 *)*puVar6);
      }
      lVar7 = lVar7 + -0x18;
      puVar6 = puVar6 + 3;
    } while (lVar7 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050c3c0
// Address: 0050c3c0
// ========================================

void FUN_0050c3c0(undefined8 param_1,char *param_2,byte *param_3,char *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_0050b7dc(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_0050c4c8
// Address: 0050c4c8
// ========================================

void FUN_0050c4c8(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050c58c
// Address: 0050c58c
// ========================================

void FUN_0050c58c(long param_1,char *param_2,undefined4 *param_3)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  sVar4 = strlen(param_2);
  FUN_0044c958(param_1 + 0xc68,param_2,sVar4);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_00562e2c(local_50,*param_3);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 0050c608 to 0050c60f has its CatchHandler @ 0050c650 */
  FUN_0044c958(param_1 + 0xc68,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0050c680
// Address: 0050c680
// ========================================

void FUN_0050c680(undefined8 param_1,char *param_2,byte *param_3,char *param_4,undefined8 *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  __s = (char *)*param_5;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050c740
// Address: 0050c740
// ========================================

void FUN_0050c740(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,byte *param_5,
                 char *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  __s = (char *)*param_3;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  FUN_0050c844(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_0050c844
// Address: 0050c844
// ========================================

void FUN_0050c844(undefined8 param_1,undefined8 *param_2,char *param_3,byte *param_4,char *param_5,
                 undefined8 *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *pcVar4;
  
  pcVar4 = (char *)*param_2;
  sVar3 = strlen(pcVar4);
  FUN_0044c958(param_1,pcVar4,sVar3);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  pcVar4 = (char *)*param_6;
  sVar3 = strlen(pcVar4);
  FUN_0044c958(param_1,pcVar4,sVar3);
  return;
}



// ========================================
// Function: FUN_0050c904
// Address: 0050c904
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050c904(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 0050c974 to 0050c9a3 has its CatchHandler @ 0050ca3c */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar4);
  FUN_0044c898(&local_1148,param_3);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar6 = local_128 * 0x18;
    puVar5 = local_130;
    do {
      if ((undefined1 *)*puVar5 != auStack_1130) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar3;
  local_1140 = uVar2;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050ca64
// Address: 0050ca64
// ========================================

void FUN_0050ca64(long param_1,char *param_2,undefined4 *param_3)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  sVar4 = strlen(param_2);
  FUN_0044c958(param_1 + 0xc68,param_2,sVar4);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_00562e2c(local_50,*param_3);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 0050cae0 to 0050cae7 has its CatchHandler @ 0050cb28 */
  FUN_0044c958(param_1 + 0xc68,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0050cb58
// Address: 0050cb58
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050cb58(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 0050cbc8 to 0050cbf7 has its CatchHandler @ 0050cc90 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar4);
  FUN_0044c898(&local_1148,param_3);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar6 = local_128 * 0x18;
    puVar5 = local_130;
    do {
      if ((undefined1 *)*puVar5 != auStack_1130) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar3;
  local_1140 = uVar2;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050ccb8
// Address: 0050ccb8
// ========================================

void FUN_0050ccb8(long param_1,char *param_2,undefined4 *param_3)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  sVar4 = strlen(param_2);
  FUN_0044c958(param_1 + 0xc68,param_2,sVar4);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_00562e2c(local_50,*param_3);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 0050cd34 to 0050cd3b has its CatchHandler @ 0050cd7c */
  FUN_0044c958(param_1 + 0xc68,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0050cdac
// Address: 0050cdac
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050cdac(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 0050ce1c to 0050ce4b has its CatchHandler @ 0050cee4 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar4);
  FUN_0044c898(&local_1148,param_3);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar6 = local_128 * 0x18;
    puVar5 = local_130;
    do {
      if ((undefined1 *)*puVar5 != auStack_1130) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar3;
  local_1140 = uVar2;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050cf0c
// Address: 0050cf0c
// ========================================

void FUN_0050cf0c(long param_1,char *param_2,undefined4 *param_3)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  sVar4 = strlen(param_2);
  FUN_0044c958(param_1 + 0xc68,param_2,sVar4);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_00562e2c(local_50,*param_3);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 0050cf88 to 0050cf8f has its CatchHandler @ 0050cfd0 */
  FUN_0044c958(param_1 + 0xc68,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0050d000
// Address: 0050d000
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050d000(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 0050d070 to 0050d09f has its CatchHandler @ 0050d138 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar4);
  FUN_0044c898(&local_1148,param_3);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar6 = local_128 * 0x18;
    puVar5 = local_130;
    do {
      if ((undefined1 *)*puVar5 != auStack_1130) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar3;
  local_1140 = uVar2;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050d160
// Address: 0050d160
// ========================================

void FUN_0050d160(long param_1,char *param_2,undefined4 *param_3)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  sVar4 = strlen(param_2);
  FUN_0044c958(param_1 + 0xc68,param_2,sVar4);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_00562e2c(local_50,*param_3);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 0050d1dc to 0050d1e3 has its CatchHandler @ 0050d224 */
  FUN_0044c958(param_1 + 0xc68,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0050d254
// Address: 0050d254
// ========================================

void FUN_0050d254(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050d318
// Address: 0050d318
// ========================================

void FUN_0050d318(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050d3dc
// Address: 0050d3dc
// ========================================

void FUN_0050d3dc(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050d4a0
// Address: 0050d4a0
// ========================================

long * FUN_0050d4a0(long *param_1,uint *param_2,undefined8 param_3,undefined8 *param_4)

{
  uint uVar1;
  undefined4 uVar2;
  ulong uVar3;
  long lVar4;
  long *plVar5;
  long *plVar6;
  undefined4 *puVar7;
  ulong uVar8;
  ulong uVar9;
  long lVar10;
  ulong uVar11;
  ulong uVar12;
  ulong unaff_x24;
  undefined2 uVar13;
  undefined8 uVar14;
  float fVar15;
  
  uVar12 = param_1[1];
  uVar1 = *param_2;
  uVar11 = (ulong)uVar1;
  if (uVar12 != 0) {
    uVar14 = CONCAT17(POPCOUNT((char)(uVar12 >> 0x38)),
                      CONCAT16(POPCOUNT((char)(uVar12 >> 0x30)),
                               CONCAT15(POPCOUNT((char)(uVar12 >> 0x28)),
                                        CONCAT14(POPCOUNT((char)(uVar12 >> 0x20)),
                                                 CONCAT13(POPCOUNT((char)(uVar12 >> 0x18)),
                                                          CONCAT12(POPCOUNT((char)(uVar12 >> 0x10)),
                                                                   CONCAT11(POPCOUNT((char)(uVar12 
                                                  >> 8)),POPCOUNT((char)uVar12))))))));
    uVar13 = NEON_uaddlv(uVar14,1);
    uVar8 = CONCAT62((int6)((ulong)uVar14 >> 0x10),uVar13) & 0xffffffff;
    if (uVar8 < 2) {
      unaff_x24 = (ulong)((int)uVar12 - 1U & uVar1);
    }
    else {
      unaff_x24 = uVar11;
      if (uVar12 <= uVar11) {
        uVar9 = 0;
        if (uVar12 != 0) {
          uVar9 = uVar11 / uVar12;
        }
        unaff_x24 = uVar11 - uVar9 * uVar12;
      }
    }
    plVar6 = *(long **)(*param_1 + unaff_x24 * 8);
    if ((plVar6 != (long *)0x0) && (plVar6 = (long *)*plVar6, plVar6 != (long *)0x0)) {
      do {
        uVar9 = plVar6[1];
        if (uVar9 == uVar11) {
          if (*(uint *)(plVar6 + 2) == uVar1) {
            return plVar6;
          }
        }
        else {
          if (uVar8 < 2) {
            uVar9 = uVar9 & uVar12 - 1;
          }
          else if (uVar12 <= uVar9) {
            uVar3 = 0;
            if (uVar12 != 0) {
              uVar3 = uVar9 / uVar12;
            }
            uVar9 = uVar9 - uVar3 * uVar12;
          }
          if (uVar9 != unaff_x24) break;
        }
        plVar6 = (long *)*plVar6;
      } while (plVar6 != (long *)0x0);
    }
  }
  plVar6 = (long *)FUN_005a5d4c(0x18);
  lVar4 = param_1[3];
  puVar7 = (undefined4 *)*param_4;
  fVar15 = *(float *)(param_1 + 4);
  *plVar6 = 0;
  plVar6[1] = uVar11;
  uVar2 = *puVar7;
  *(undefined1 *)((long)plVar6 + 0x14) = 0;
  *(undefined4 *)(plVar6 + 2) = uVar2;
  if ((uVar12 == 0) || (fVar15 * (float)uVar12 < (float)(lVar4 + 1))) {
    if (uVar12 < 3) {
      uVar8 = 1;
    }
    else {
      uVar8 = (ulong)((uVar12 & uVar12 - 1) != 0);
    }
    uVar8 = uVar8 | uVar12 << 1;
    uVar9 = (ulong)((float)(lVar4 + 1) / fVar15);
    if (uVar8 <= uVar9) {
      uVar8 = uVar9;
    }
    if (uVar8 - 1 == 0) {
      uVar8 = 2;
    }
    else if ((uVar8 & uVar8 - 1) != 0) {
                    /* try { // try from 0050d600 to 0050d68b has its CatchHandler @ 0050d758 */
      uVar8 = FUN_0055fe2c(uVar8);
      uVar12 = param_1[1];
    }
    if (uVar12 < uVar8) {
LAB_0050d618:
      FUN_004fb954(param_1,uVar8);
    }
    else if (uVar8 < uVar12) {
      uVar9 = (ulong)((float)(ulong)param_1[3] / *(float *)(param_1 + 4));
      if ((uVar12 < 3) ||
         (uVar14 = CONCAT17(POPCOUNT((char)(uVar12 >> 0x38)),
                            CONCAT16(POPCOUNT((char)(uVar12 >> 0x30)),
                                     CONCAT15(POPCOUNT((char)(uVar12 >> 0x28)),
                                              CONCAT14(POPCOUNT((char)(uVar12 >> 0x20)),
                                                       CONCAT13(POPCOUNT((char)(uVar12 >> 0x18)),
                                                                CONCAT12(POPCOUNT((char)(uVar12 >>
                                                                                        0x10)),
                                                                         CONCAT11(POPCOUNT((char)(
                                                  uVar12 >> 8)),POPCOUNT((char)uVar12)))))))),
         uVar13 = NEON_uaddlv(uVar14,1),
         1 < (CONCAT62((int6)((ulong)uVar14 >> 0x10),uVar13) & 0xffffffff))) {
        uVar9 = FUN_0055fe2c();
      }
      else if (1 < uVar9) {
        uVar9 = 1L << (-LZCOUNT(uVar9 - 1) & 0x3fU);
      }
      if (uVar8 <= uVar9) {
        uVar8 = uVar9;
      }
      if (uVar8 < uVar12) goto LAB_0050d618;
    }
    uVar12 = param_1[1];
    if ((uVar12 & uVar12 - 1) == 0) {
      unaff_x24 = (ulong)((int)uVar12 - 1U & uVar1);
    }
    else {
      unaff_x24 = uVar11;
      if (uVar12 <= uVar11) {
        uVar8 = 0;
        if (uVar12 != 0) {
          uVar8 = uVar11 / uVar12;
        }
        unaff_x24 = uVar11 - uVar8 * uVar12;
      }
    }
  }
  lVar4 = *param_1;
  plVar5 = *(long **)(lVar4 + unaff_x24 * 8);
  if (plVar5 == (long *)0x0) {
    plVar5 = param_1 + 2;
    lVar10 = *plVar5;
    *plVar5 = (long)plVar6;
    *plVar6 = lVar10;
    *(long **)(lVar4 + unaff_x24 * 8) = plVar5;
    if (*plVar6 == 0) goto LAB_0050d730;
    uVar11 = *(ulong *)(*plVar6 + 8);
    if ((uVar12 & uVar12 - 1) == 0) {
      uVar11 = uVar11 & uVar12 - 1;
    }
    else if (uVar12 <= uVar11) {
      uVar8 = 0;
      if (uVar12 != 0) {
        uVar8 = uVar11 / uVar12;
      }
      uVar11 = uVar11 - uVar8 * uVar12;
    }
    plVar5 = (long *)(*param_1 + uVar11 * 8);
  }
  else {
    *plVar6 = *plVar5;
  }
  *plVar5 = (long)plVar6;
LAB_0050d730:
  param_1[3] = param_1[3] + 1;
  return plVar6;
}



// ========================================
// Function: FUN_0050d76c
// Address: 0050d76c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050d76c(undefined8 param_1,byte *param_2,undefined8 param_3,byte *param_4,
                 undefined8 param_5)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
                    /* try { // try from 0050d7f8 to 0050d863 has its CatchHandler @ 0050d8fc */
  local_1148 = auStack_1130;
  local_130 = local_118;
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_3,uVar6);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_5,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_5,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0050d924
// Address: 0050d924
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050d924(undefined8 param_1,byte *param_2,undefined1 *param_3,undefined1 *param_4,
                 undefined8 param_5)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 local_115c [4];
  undefined1 *local_1158;
  undefined8 local_1150;
  undefined8 uStack_1148;
  undefined1 auStack_1140 [4096];
  undefined8 *local_140;
  long local_138;
  undefined8 uStack_130;
  undefined8 local_128 [24];
  long local_68;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_68 = *(long *)(lVar3 + 0x28);
  uStack_130 = _UNK_001a0d48;
  local_138 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1148 = _UNK_001a1328;
  local_1150 = _DAT_001a1320;
                    /* try { // try from 0050d9b0 to 0050da0f has its CatchHandler @ 0050daac */
  local_1158 = auStack_1140;
  local_140 = local_128;
  FUN_0044c958(&local_1158,pbVar2,uVar1);
  local_115c[0] = *param_3;
  FUN_0044c958(&local_1158,local_115c,1);
  local_115c[0] = *param_4;
  FUN_0044c958(&local_1158,local_115c,1);
  uVar6 = __strlen_chk(param_5,0xffffffffffffffff);
  FUN_0044c958(&local_1158,param_5,uVar6);
  FUN_0044c6fc(param_1,&local_1158);
  if (local_138 != 0) {
    lVar8 = local_138 * 0x18;
    puVar7 = local_140;
    do {
      if ((undefined1 *)*puVar7 != auStack_1140) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1158 != auStack_1140) {
    free(local_1158);
  }
  local_138 = 0;
  uStack_1148 = uVar5;
  local_1150 = uVar4;
  local_1158 = auStack_1140;
  if (local_140 != local_128) {
    free(local_140);
  }
  if (*(long *)(lVar3 + 0x28) == local_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050dad4
// Address: 0050dad4
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050dad4(undefined8 param_1,byte *param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  long lVar7;
  undefined1 *local_1158;
  undefined8 local_1150;
  undefined8 uStack_1148;
  undefined1 auStack_1140 [4096];
  undefined8 *local_140;
  long local_138;
  undefined8 uStack_130;
  undefined8 local_128 [24];
  long local_68;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_68 = *(long *)(lVar3 + 0x28);
  uStack_130 = _UNK_001a0d48;
  local_138 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1148 = _UNK_001a1328;
  local_1150 = _DAT_001a1320;
                    /* try { // try from 0050db6c to 0050db9b has its CatchHandler @ 0050dc38 */
  local_1158 = auStack_1140;
  local_140 = local_128;
  FUN_0044c958(&local_1158,pbVar2,uVar1);
  FUN_0050ddb8(&local_1158,param_3,param_4,param_5,param_6,param_7);
  FUN_0044c6fc(param_1,&local_1158);
  if (local_138 != 0) {
    lVar7 = local_138 * 0x18;
    puVar6 = local_140;
    do {
      if ((undefined1 *)*puVar6 != auStack_1140) {
        free((undefined1 *)*puVar6);
      }
      lVar7 = lVar7 + -0x18;
      puVar6 = puVar6 + 3;
    } while (lVar7 != 0);
  }
  if (local_1158 != auStack_1140) {
    free(local_1158);
  }
  local_138 = 0;
  uStack_1148 = uVar5;
  local_1150 = uVar4;
  local_1158 = auStack_1140;
  if (local_140 != local_128) {
    free(local_140);
  }
  if (*(long *)(lVar3 + 0x28) == local_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050dc60
// Address: 0050dc60
// ========================================

void FUN_0050dc60(long param_1,byte *param_2,char *param_3,undefined1 *param_4,char *param_5,
                 byte *param_6,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  size_t sVar4;
  undefined1 local_5c [4];
  long local_58;
  
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar4);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  local_5c[0] = *param_4;
  FUN_0044c958(param_1 + 0xc68,local_5c,1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar4 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar4);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar4 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar4);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  if (*(long *)(lVar3 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050ddb8
// Address: 0050ddb8
// ========================================

void FUN_0050ddb8(undefined8 param_1,char *param_2,undefined1 *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  size_t sVar4;
  undefined1 local_5c [4];
  long local_58;
  
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  sVar4 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar4);
  local_5c[0] = *param_3;
  FUN_0044c958(param_1,local_5c,1);
  sVar4 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar4);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar4 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar4);
  if (*(long *)(lVar3 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050dea8
// Address: 0050dea8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050dea8(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  long lVar1;
  undefined8 *puVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 0050df20 to 0050df33 has its CatchHandler @ 0050dfc8 */
  uVar4 = _DAT_001a1320;
  uVar5 = _UNK_001a1328;
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_0050dff0(&local_1138,param_2,param_3,param_4,param_5,param_6,param_8,param_9,_DAT_001a1320,
               _UNK_001a1328);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar3 = local_118 * 0x18;
    puVar2 = local_120;
    do {
      if ((undefined1 *)*puVar2 != auStack_1120) {
        free((undefined1 *)*puVar2);
      }
      lVar3 = lVar3 + -0x18;
      puVar2 = puVar2 + 3;
    } while (lVar3 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  local_1138 = auStack_1120;
  local_1130 = uVar4;
  uStack_1128 = uVar5;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050dff0
// Address: 0050dff0
// ========================================

void FUN_0050dff0(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050e0b4
// Address: 0050e0b4
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050e0b4(undefined8 param_1,byte *param_2,undefined8 param_3)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_48 = *(long *)(lVar3 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 0050e134 to 0050e163 has its CatchHandler @ 0050e1f8 */
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_0044c958(&local_1138,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_3,uVar6);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar8 = local_118 * 0x18;
    puVar7 = local_120;
    do {
      if ((undefined1 *)*puVar7 != auStack_1120) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar5;
  local_1130 = uVar4;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar3 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050e220
// Address: 0050e220
// ========================================

undefined8 FUN_0050e220(long param_1,undefined8 param_2)

{
  long lVar1;
  long lVar2;
  uint uVar3;
  void *pvVar4;
  long lVar5;
  undefined8 uVar6;
  ulong uVar7;
  void *pvVar8;
  
  lVar5 = *(long *)(param_1 + 0x10);
  if (lVar5 == 0) {
    uVar3 = *(int *)(param_1 + 0x80) << (ulong)(*(uint *)(param_1 + 0x30) & 0x1f);
    uVar7 = (ulong)uVar3;
    pvVar4 = malloc(uVar7 * 0x98);
    if (pvVar4 == (void *)0x0) {
      return 0;
    }
    FUN_0045bc40(param_1 + 8,uVar7);
    if (uVar3 != 0) {
      lVar5 = *(long *)(param_1 + 0x10);
      pvVar8 = pvVar4;
      do {
        FUN_0045bc40(param_1 + 8,lVar5 + 1);
        lVar5 = *(long *)(param_1 + 0x10);
        uVar7 = uVar7 - 1;
        *(void **)(*(long *)(param_1 + 8) + lVar5 * 8) = pvVar8;
        lVar5 = lVar5 + 1;
        pvVar8 = (void *)((long)pvVar8 + 0x98);
        *(long *)(param_1 + 0x10) = lVar5;
      } while (uVar7 != 0);
    }
    FUN_0050e484(param_1 + 0x28,*(long *)(param_1 + 0x30) + 1);
    lVar1 = *(long *)(param_1 + 8);
    lVar5 = *(long *)(param_1 + 0x10);
    lVar2 = *(long *)(param_1 + 0x30);
    *(void **)(*(long *)(param_1 + 0x28) + lVar2 * 8) = pvVar4;
    uVar6 = *(undefined8 *)(lVar1 + lVar5 * 8 + -8);
    *(long *)(param_1 + 0x30) = lVar2 + 1;
    if (lVar5 == 0) goto LAB_0050e254;
  }
  else {
    uVar6 = *(undefined8 *)(*(long *)(param_1 + 8) + lVar5 * 8 + -8);
  }
  *(long *)(param_1 + 0x10) = lVar5 + -1;
LAB_0050e254:
  FUN_0050e310(uVar6,param_2);
  return uVar6;
}



// ========================================
// Function: FUN_0050e310
// Address: 0050e310
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050e310(long *param_1,long *param_2)

{
  undefined *puVar1;
  undefined8 *puVar2;
  ulong uVar3;
  long lVar4;
  undefined4 *puVar5;
  long lVar6;
  undefined4 *puVar7;
  ulong uVar8;
  long lVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  ulong uVar12;
  long *plVar13;
  undefined8 uVar14;
  long lVar15;
  undefined8 uVar16;
  undefined8 uVar17;
  
  puVar1 = PTR_DAT_005c6270 + 0x10;
  *(int *)(param_1 + 1) = (int)param_2[1];
  *param_1 = (long)puVar1;
  *(undefined8 *)((long)param_1 + 0xc) = *(undefined8 *)((long)param_2 + 0xc);
  if ((*(byte *)(param_2 + 3) & 1) == 0) {
    lVar6 = param_2[4];
    lVar4 = param_2[3];
    param_1[5] = param_2[5];
    param_1[4] = lVar6;
    param_1[3] = lVar4;
  }
  else {
    FUN_00251fc8(param_1 + 3,param_2[5],param_2[4]);
  }
  if ((*(byte *)(param_2 + 6) & 1) == 0) {
    lVar6 = param_2[7];
    lVar4 = param_2[6];
    param_1[8] = param_2[8];
    param_1[7] = lVar6;
    param_1[6] = lVar4;
  }
  else {
                    /* try { // try from 0050e398 to 0050e39f has its CatchHandler @ 0050e468 */
    FUN_00251fc8(param_1 + 6,param_2[8],param_2[7]);
  }
  lVar6 = _UNK_001a0d48;
  lVar4 = _DAT_001a0d40;
  lVar15 = param_2[10];
  lVar9 = param_2[9];
  *(short *)(param_1 + 0xb) = (short)param_2[0xb];
  param_1[10] = lVar15;
  param_1[9] = lVar9;
  plVar13 = param_1 + 0xc;
  *plVar13 = (long)(param_1 + 0xf);
  param_1[0xe] = lVar6;
  param_1[0xd] = lVar4;
  if (param_1 == param_2) {
    return;
  }
  FUN_0044d9dc(plVar13,param_2[0xd]);
  uVar3 = param_2[0xd];
  if (uVar3 != 0) {
    lVar4 = *plVar13;
    lVar6 = param_2[0xc];
    uVar8 = 0;
    if ((7 < uVar3) && (0x1f < (ulong)(lVar4 - lVar6))) {
      uVar8 = uVar3 & 0xfffffffffffffff8;
      puVar10 = (undefined8 *)(lVar4 + 0x10);
      puVar11 = (undefined8 *)(lVar6 + 0x10);
      uVar12 = uVar8;
      do {
        puVar2 = puVar11 + -1;
        uVar14 = puVar11[-2];
        uVar17 = puVar11[1];
        uVar16 = *puVar11;
        uVar12 = uVar12 - 8;
        puVar11 = puVar11 + 4;
        puVar10[-1] = *puVar2;
        puVar10[-2] = uVar14;
        puVar10[1] = uVar17;
        *puVar10 = uVar16;
        puVar10 = puVar10 + 4;
      } while (uVar12 != 0);
      if (uVar3 == uVar8) goto LAB_0050e454;
    }
    lVar9 = uVar3 - uVar8;
    puVar5 = (undefined4 *)(lVar4 + uVar8 * 4);
    puVar7 = (undefined4 *)(lVar6 + uVar8 * 4);
    do {
      lVar9 = lVar9 + -1;
      *puVar5 = *puVar7;
      puVar5 = puVar5 + 1;
      puVar7 = puVar7 + 1;
    } while (lVar9 != 0);
  }
LAB_0050e454:
  param_1[0xd] = uVar3;
  return;
}



// ========================================
// Function: FUN_0050e484
// Address: 0050e484
// ========================================

void FUN_0050e484(long *param_1,ulong param_2)

{
  long *plVar1;
  void *__ptr;
  long *__ptr_00;
  ulong uVar2;
  ulong uVar3;
  long lVar4;
  long lVar5;
  long lVar6;
  ulong uVar7;
  
  if (param_2 >> 0x3d != 0) {
LAB_0050e4e0:
                    /* WARNING: Subroutine does not return */
    FUN_0058bdd0();
  }
  uVar2 = param_1[2];
  if (uVar2 < param_2) {
    if (uVar2 < 9) {
      uVar2 = 8;
    }
    do {
      uVar3 = uVar2;
      uVar2 = uVar3 << 1;
    } while (uVar3 < param_2);
    if (uVar3 < 9) {
      plVar1 = param_1 + 3;
    }
    else {
      plVar1 = (long *)malloc(uVar3 << 3);
      if (plVar1 == (long *)0x0) goto LAB_0050e4e0;
    }
    __ptr_00 = plVar1;
    if ((plVar1 != (long *)*param_1) &&
       (uVar2 = param_1[1], __ptr_00 = (long *)*param_1, uVar2 != 0)) {
      uVar7 = 0;
      do {
        lVar4 = uVar7 * 8;
        lVar6 = *(long *)(*param_1 + lVar4);
        *(undefined8 *)(*param_1 + lVar4) = 0;
        lVar5 = *param_1;
        plVar1[uVar7] = lVar6;
        __ptr = *(void **)(lVar5 + lVar4);
        *(undefined8 *)(lVar5 + lVar4) = 0;
        if (__ptr != (void *)0x0) {
          free(__ptr);
          uVar2 = param_1[1];
        }
        uVar7 = uVar7 + 1;
      } while (uVar7 < uVar2);
      __ptr_00 = (long *)*param_1;
    }
    if (__ptr_00 != param_1 + 3) {
      free(__ptr_00);
    }
    *param_1 = (long)plVar1;
    param_1[2] = uVar3;
  }
  return;
}



// ========================================
// Function: FUN_0050e578
// Address: 0050e578
// ========================================

void FUN_0050e578(long *param_1)

{
  undefined *puVar1;
  
  puVar1 = PTR_DAT_005c6270;
  param_1[0xd] = 0;
  *param_1 = (long)(puVar1 + 0x10);
  if ((long *)param_1[0xc] != param_1 + 0xf) {
    free((long *)param_1[0xc]);
  }
  if ((*(byte *)(param_1 + 6) & 1) != 0) {
    free((void *)param_1[8]);
  }
  if ((*(byte *)(param_1 + 3) & 1) == 0) {
    return;
  }
  free((void *)param_1[5]);
  return;
}



// ========================================
// Function: FUN_0050e5e4
// Address: 0050e5e4
// ========================================

void FUN_0050e5e4(long *param_1)

{
  undefined *puVar1;
  
  puVar1 = PTR_DAT_005c6270;
  param_1[0xd] = 0;
  *param_1 = (long)(puVar1 + 0x10);
  if ((long *)param_1[0xc] != param_1 + 0xf) {
    free((long *)param_1[0xc]);
  }
  if ((*(byte *)(param_1 + 6) & 1) != 0) {
    free((void *)param_1[8]);
  }
  if ((*(byte *)(param_1 + 3) & 1) != 0) {
    free((void *)param_1[5]);
  }
  free(param_1);
  return;
}



// ========================================
// Function: FUN_0050e64c
// Address: 0050e64c
// ========================================

void FUN_0050e64c(undefined8 param_1,undefined8 param_2)

{
  FUN_0050e220(param_2,param_1);
  return;
}



// ========================================
// Function: FUN_0050e65c
// Address: 0050e65c
// ========================================

void FUN_0050e65c(long param_1,long param_2)

{
  long lVar1;
  long lVar2;
  uint uVar3;
  undefined *puVar4;
  long *plVar5;
  void *pvVar6;
  long lVar7;
  undefined8 uVar8;
  ulong uVar9;
  void *pvVar10;
  
  lVar7 = *(long *)(param_1 + 0x10);
  if (lVar7 == 0) {
    uVar3 = *(int *)(param_1 + 0x80) << (ulong)(*(uint *)(param_1 + 0x30) & 0x1f);
    uVar9 = (ulong)uVar3;
    pvVar6 = malloc(uVar9 * 0x18);
    if (pvVar6 == (void *)0x0) {
      return;
    }
    FUN_0045b9d4(param_1 + 8,uVar9);
    if (uVar3 != 0) {
      lVar7 = *(long *)(param_1 + 0x10);
      pvVar10 = pvVar6;
      do {
        FUN_0045b9d4(param_1 + 8,lVar7 + 1);
        lVar7 = *(long *)(param_1 + 0x10);
        uVar9 = uVar9 - 1;
        *(void **)(*(long *)(param_1 + 8) + lVar7 * 8) = pvVar10;
        lVar7 = lVar7 + 1;
        pvVar10 = (void *)((long)pvVar10 + 0x18);
        *(long *)(param_1 + 0x10) = lVar7;
      } while (uVar9 != 0);
    }
    FUN_0050e768(param_1 + 0x28,*(long *)(param_1 + 0x30) + 1);
    lVar1 = *(long *)(param_1 + 8);
    lVar7 = *(long *)(param_1 + 0x10);
    lVar2 = *(long *)(param_1 + 0x30);
    *(void **)(*(long *)(param_1 + 0x28) + lVar2 * 8) = pvVar6;
    plVar5 = *(long **)(lVar1 + lVar7 * 8 + -8);
    *(long *)(param_1 + 0x30) = lVar2 + 1;
    if (lVar7 == 0) goto LAB_0050e690;
  }
  else {
    plVar5 = *(long **)(*(long *)(param_1 + 8) + lVar7 * 8 + -8);
  }
  *(long *)(param_1 + 0x10) = lVar7 + -1;
LAB_0050e690:
  puVar4 = PTR_DAT_005c6278;
  *(undefined4 *)(plVar5 + 1) = *(undefined4 *)(param_2 + 8);
  *plVar5 = (long)(puVar4 + 0x10);
  uVar8 = *(undefined8 *)(param_2 + 0xc);
  *(undefined4 *)((long)plVar5 + 0x14) = *(undefined4 *)(param_2 + 0x14);
  *(undefined8 *)((long)plVar5 + 0xc) = uVar8;
  return;
}



// ========================================
// Function: FUN_0050e768
// Address: 0050e768
// ========================================

void FUN_0050e768(long *param_1,ulong param_2)

{
  long *plVar1;
  void *__ptr;
  long *__ptr_00;
  ulong uVar2;
  ulong uVar3;
  long lVar4;
  long lVar5;
  long lVar6;
  ulong uVar7;
  
  if (param_2 >> 0x3d != 0) {
LAB_0050e7c4:
                    /* WARNING: Subroutine does not return */
    FUN_0058bdd0();
  }
  uVar2 = param_1[2];
  if (uVar2 < param_2) {
    if (uVar2 < 9) {
      uVar2 = 8;
    }
    do {
      uVar3 = uVar2;
      uVar2 = uVar3 << 1;
    } while (uVar3 < param_2);
    if (uVar3 < 9) {
      plVar1 = param_1 + 3;
    }
    else {
      plVar1 = (long *)malloc(uVar3 << 3);
      if (plVar1 == (long *)0x0) goto LAB_0050e7c4;
    }
    __ptr_00 = plVar1;
    if ((plVar1 != (long *)*param_1) &&
       (uVar2 = param_1[1], __ptr_00 = (long *)*param_1, uVar2 != 0)) {
      uVar7 = 0;
      do {
        lVar4 = uVar7 * 8;
        lVar6 = *(long *)(*param_1 + lVar4);
        *(undefined8 *)(*param_1 + lVar4) = 0;
        lVar5 = *param_1;
        plVar1[uVar7] = lVar6;
        __ptr = *(void **)(lVar5 + lVar4);
        *(undefined8 *)(lVar5 + lVar4) = 0;
        if (__ptr != (void *)0x0) {
          free(__ptr);
          uVar2 = param_1[1];
        }
        uVar7 = uVar7 + 1;
      } while (uVar7 < uVar2);
      __ptr_00 = (long *)*param_1;
    }
    if (__ptr_00 != param_1 + 3) {
      free(__ptr_00);
    }
    *param_1 = (long)plVar1;
    param_1[2] = uVar3;
  }
  return;
}



// ========================================
// Function: free
// Address: 0050e85c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_0050e860
// Address: 0050e860
// ========================================

void FUN_0050e860(undefined8 param_1,undefined8 param_2)

{
  FUN_0050e65c(param_2,param_1);
  return;
}



// ========================================
// Function: FUN_0050e870
// Address: 0050e870
// ========================================

void FUN_0050e870(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  return;
}



// ========================================
// Function: FUN_0050e934
// Address: 0050e934
// ========================================

void FUN_0050e934(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050e9f8
// Address: 0050e9f8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050e9f8(undefined8 param_1,byte *param_2,undefined8 param_3,byte *param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12,
                 undefined8 param_13,undefined8 param_14,undefined8 param_15)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
                    /* try { // try from 0050ea94 to 0050eb2b has its CatchHandler @ 0050ebc8 */
  local_1160 = auStack_1148;
  local_148 = local_130;
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_3,uVar6);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_5,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_5,uVar6);
  FUN_0050ebf0(&local_1160,param_6,param_7,param_8,param_9,param_10,param_11,param_12,param_13,
               param_14,param_15);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar8 = local_140 * 0x18;
    puVar7 = local_148;
    do {
      if ((undefined1 *)*puVar7 != auStack_1148) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) != local_70) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0050ebf0
// Address: 0050ebf0
// ========================================

void FUN_0050ebf0(undefined8 param_1,undefined8 *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  __s = (char *)*param_2;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_0050b7dc(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_0050ecf8
// Address: 0050ecf8
// ========================================

void FUN_0050ecf8(long param_1,byte *param_2,char *param_3,undefined8 *param_4,char *param_5,
                 byte *param_6,char *param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11,undefined8 param_12,undefined8 param_13)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  __s = (char *)*param_4;
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1 + 0xc68,__s,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_0050b8a0(param_1,param_8,param_9,param_10,param_11,param_12,param_13);
  return;
}



// ========================================
// Function: FUN_0050ee68
// Address: 0050ee68
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050ee68(undefined8 param_1,undefined8 *param_2,undefined8 param_3,byte *param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12,
                 undefined8 param_13,undefined8 param_14,undefined8 param_15)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined8 uVar9;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uVar9 = *param_2;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 0050eef4 to 0050ef9f has its CatchHandler @ 0050f040 */
  uVar6 = __strlen_chk(uVar9,0xffffffffffffffff);
  FUN_0044c958(&local_1160,uVar9,uVar6);
  uVar6 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_3,uVar6);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_5,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_5,uVar6);
  FUN_0050f06c(&local_1160,param_6,param_7,param_8,param_9,param_10,param_11,param_12,param_13,
               param_14,param_15);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar8 = local_140 * 0x18;
    puVar7 = local_148;
    do {
      if ((undefined1 *)*puVar7 != auStack_1148) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050f06c
// Address: 0050f06c
// ========================================

void FUN_0050f06c(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_0050b7dc(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_0050f16c
// Address: 0050f16c
// ========================================

void FUN_0050f16c(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7,undefined8 param_8,undefined8 param_9,undefined8 param_10,
                 undefined8 param_11,undefined8 param_12,undefined8 param_13)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_0050b8a0(param_1,param_8,param_9,param_10,param_11,param_12,param_13);
  return;
}



// ========================================
// Function: FUN_0050f2e0
// Address: 0050f2e0
// ========================================

void FUN_0050f2e0(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_0050f3e0(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_0050f3e0
// Address: 0050f3e0
// ========================================

void FUN_0050f3e0(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050f4a4
// Address: 0050f4a4
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050f4a4(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  long lVar1;
  undefined8 *puVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 0050f51c to 0050f52f has its CatchHandler @ 0050f5c4 */
  uVar4 = _DAT_001a1320;
  uVar5 = _UNK_001a1328;
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_0050f5ec(&local_1138,param_2,param_3,param_4,param_5,param_6,param_8,param_9,_DAT_001a1320,
               _UNK_001a1328);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar3 = local_118 * 0x18;
    puVar2 = local_120;
    do {
      if ((undefined1 *)*puVar2 != auStack_1120) {
        free((undefined1 *)*puVar2);
      }
      lVar3 = lVar3 + -0x18;
      puVar2 = puVar2 + 3;
    } while (lVar3 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  local_1138 = auStack_1120;
  local_1130 = uVar4;
  uStack_1128 = uVar5;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050f5ec
// Address: 0050f5ec
// ========================================

void FUN_0050f5ec(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050f6b0
// Address: 0050f6b0
// ========================================

void FUN_0050f6b0(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050f774
// Address: 0050f774
// ========================================

void FUN_0050f774(undefined8 param_1,char *param_2,byte *param_3,char *param_4,undefined8 *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  __s = (char *)*param_5;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050f834
// Address: 0050f834
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050f834(undefined8 param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined8 uVar7;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_70 = *(long *)(lVar1 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uVar7 = *param_2;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 0050f8b4 to 0050f8f7 has its CatchHandler @ 0050f994 */
  uVar4 = __strlen_chk(uVar7,0xffffffffffffffff);
  FUN_0044c958(&local_1160,uVar7,uVar4);
  FUN_0050faf0(&local_1160,param_3,param_4,param_5,param_6,param_7);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar6 = local_140 * 0x18;
    puVar5 = local_148;
    do {
      if ((undefined1 *)*puVar5 != auStack_1148) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar3;
  local_1158 = uVar2;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar1 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050f9bc
// Address: 0050f9bc
// ========================================

void FUN_0050f9bc(long param_1,undefined8 *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  __s = (char *)*param_2;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1 + 0xc68,__s,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_0050faf0
// Address: 0050faf0
// ========================================

void FUN_0050faf0(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0050fbb4
// Address: 0050fbb4
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050fbb4(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 0050fc1c to 0050fc3f has its CatchHandler @ 0050fcd4 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050fcfc
// Address: 0050fcfc
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050fcfc(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 0050fd70 to 0050fdcf has its CatchHandler @ 0050fe68 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0050fe90
// Address: 0050fe90
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050fe90(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 0050ff04 to 0050ff63 has its CatchHandler @ 0050fffc */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00510024
// Address: 00510024
// ========================================

void FUN_00510024(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_005100e8
// Address: 005100e8
// ========================================

void FUN_005100e8(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_005101ac
// Address: 005101ac
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005101ac(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  long lVar5;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 00510234 to 0051024f has its CatchHandler @ 005102e4 */
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_0051030c(&local_1138,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,
               param_11);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar5 = local_118 * 0x18;
    puVar4 = local_120;
    do {
      if ((undefined1 *)*puVar4 != auStack_1120) {
        free((undefined1 *)*puVar4);
      }
      lVar5 = lVar5 + -0x18;
      puVar4 = puVar4 + 3;
    } while (lVar5 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051030c
// Address: 0051030c
// ========================================

void FUN_0051030c(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_0050a2e4(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_0051040c
// Address: 0051040c
// ========================================

void FUN_0051040c(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_0051053c
// Address: 0051053c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051053c(undefined8 param_1,byte *param_2,undefined8 param_3,byte *param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
                    /* try { // try from 005105dc to 00510647 has its CatchHandler @ 005106e8 */
  local_1160 = auStack_1148;
  local_148 = local_130;
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_3,uVar6);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  FUN_00510714(&local_1160,param_5,param_6,param_7,param_8,param_9);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar8 = local_140 * 0x18;
    puVar7 = local_148;
    do {
      if ((undefined1 *)*puVar7 != auStack_1148) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) != local_70) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_00510714
// Address: 00510714
// ========================================

void FUN_00510714(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_005107d8
// Address: 005107d8
// ========================================

void FUN_005107d8(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_00510908
// Address: 00510908
// ========================================

void FUN_00510908(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_005109cc
// Address: 005109cc
// ========================================

void FUN_005109cc(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_00510a90
// Address: 00510a90
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_00510a90(long param_1,byte *param_2,undefined4 *param_3,undefined1 *param_4)

{
  long lVar1;
  long lVar2;
  undefined4 uVar3;
  undefined1 uVar4;
  uint uVar5;
  long lVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  long lVar9;
  undefined8 *puVar10;
  ulong uVar11;
  undefined8 *puVar12;
  undefined8 local_70;
  undefined8 uStack_68;
  undefined8 local_60;
  long local_58;
  
  lVar6 = tpidr_el0;
  local_58 = *(long *)(lVar6 + 0x28);
  lVar9 = *(long *)(param_1 + 0x10);
  if (lVar9 == 0) {
    uVar5 = *(int *)(param_1 + 0x80) << (ulong)(*(uint *)(param_1 + 0x30) & 0x1f);
    uVar11 = (ulong)uVar5;
    puVar10 = (undefined8 *)malloc(uVar11 * 0x120);
    if (puVar10 == (undefined8 *)0x0) goto LAB_00510b80;
    FUN_004517fc(param_1 + 8,uVar11);
    if (uVar5 != 0) {
      lVar9 = *(long *)(param_1 + 0x10);
      puVar12 = puVar10;
      do {
        FUN_004517fc(param_1 + 8,lVar9 + 1);
        lVar9 = *(long *)(param_1 + 0x10);
        uVar11 = uVar11 - 1;
        *(undefined8 **)(*(long *)(param_1 + 8) + lVar9 * 8) = puVar12;
        lVar9 = lVar9 + 1;
        puVar12 = puVar12 + 0x24;
        *(long *)(param_1 + 0x10) = lVar9;
      } while (uVar11 != 0);
    }
    FUN_004518ec(param_1 + 0x28,*(long *)(param_1 + 0x30) + 1);
    lVar1 = *(long *)(param_1 + 8);
    lVar9 = *(long *)(param_1 + 0x10);
    lVar2 = *(long *)(param_1 + 0x30);
    *(undefined8 **)(*(long *)(param_1 + 0x28) + lVar2 * 8) = puVar10;
    puVar10 = *(undefined8 **)(lVar1 + lVar9 * 8 + -8);
    *(long *)(param_1 + 0x30) = lVar2 + 1;
    if (lVar9 != 0) goto LAB_00510ad8;
  }
  else {
    puVar10 = *(undefined8 **)(*(long *)(param_1 + 8) + lVar9 * 8 + -8);
LAB_00510ad8:
    *(long *)(param_1 + 0x10) = lVar9 + -1;
  }
  if ((*param_2 & 1) == 0) {
    uStack_68 = *(undefined8 *)(param_2 + 8);
    local_70 = *(undefined8 *)param_2;
    local_60 = *(undefined8 *)(param_2 + 0x10);
  }
  else {
    FUN_00251fc8(&local_70,*(undefined8 *)(param_2 + 0x10),*(undefined8 *)(param_2 + 8));
  }
  uVar3 = *param_3;
  uVar4 = *param_4;
  *(undefined4 *)((long)puVar10 + 0x31) = 0;
  *(undefined4 *)(puVar10 + 5) = uVar3;
  *(undefined4 *)((long)puVar10 + 0x2c) = 0;
  *puVar10 = &PTR_FUN_005bdbf0;
  puVar10[1] = 0;
  *(undefined1 *)(puVar10 + 6) = uVar4;
  *(undefined4 *)(puVar10 + 0x23) = 0;
  puVar10[4] = local_60;
  puVar10[7] = puVar10 + 10;
  puVar10[8] = 0;
  puVar10[9] = 8;
  puVar10[3] = uStack_68;
  puVar10[2] = local_70;
  uVar8 = _UNK_001a0d48;
  uVar7 = _DAT_001a0d40;
  puVar10[0xe] = puVar10 + 0x11;
  puVar10[0x15] = puVar10 + 0x18;
  puVar10[0x10] = uVar8;
  puVar10[0xf] = uVar7;
  puVar10[0x17] = uVar8;
  puVar10[0x16] = uVar7;
  puVar10[0x1c] = puVar10 + 0x1f;
  puVar10[0x1e] = uVar8;
  puVar10[0x1d] = uVar7;
LAB_00510b80:
  if (*(long *)(lVar6 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return puVar10;
}



// ========================================
// Function: FUN_00510c50
// Address: 00510c50
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510c50(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4,
                 byte *param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 00510cdc to 00510d77 has its CatchHandler @ 00510e18 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_4,uVar6);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  FUN_0050a2e4(&local_1160,param_6,param_7,param_8,param_9,param_10);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar8 = local_140 * 0x18;
    puVar7 = local_148;
    do {
      if ((undefined1 *)*puVar7 != auStack_1148) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00510e44
// Address: 00510e44
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510e44(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 00510ecc to 00510f2b has its CatchHandler @ 00510fcc */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  FUN_00510714(&local_1160,param_4,param_5,param_6,param_7,param_8);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar8 = local_140 * 0x18;
    puVar7 = local_148;
    do {
      if ((undefined1 *)*puVar7 != auStack_1148) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00510ff8
// Address: 00510ff8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510ff8(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 00511060 to 00511083 has its CatchHandler @ 00511118 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00511140
// Address: 00511140
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511140(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 005111a8 to 005111cb has its CatchHandler @ 00511260 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00511288
// Address: 00511288
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511288(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 005112f0 to 00511313 has its CatchHandler @ 005113a8 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005113d0
// Address: 005113d0
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005113d0(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 00511440 to 0051146f has its CatchHandler @ 00511508 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar4);
  FUN_00511530(&local_1148,param_3);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar6 = local_128 * 0x18;
    puVar5 = local_130;
    do {
      if ((undefined1 *)*puVar5 != auStack_1130) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar3;
  local_1140 = uVar2;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00511530
// Address: 00511530
// ========================================

undefined8 FUN_00511530(undefined8 param_1,undefined2 *param_2)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  FUN_005628b4(local_50,*param_2);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 00511584 to 0051158b has its CatchHandler @ 005115c4 */
  FUN_0044c958(param_1,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return param_1;
}



// ========================================
// Function: FUN_005115f4
// Address: 005115f4
// ========================================

void FUN_005115f4(undefined8 param_1,char *param_2,byte *param_3,undefined8 *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  __s = (char *)*param_4;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_005116bc
// Address: 005116bc
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005116bc(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12,
                 undefined8 param_13,undefined8 param_14,undefined8 param_15,undefined8 param_16,
                 undefined8 param_17,undefined8 param_18,undefined8 param_19,undefined8 param_20,
                 undefined8 param_21,undefined8 param_22,undefined8 param_23,undefined8 param_24)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 00511748 to 005117ff has its CatchHandler @ 005118a0 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_4,uVar6);
  FUN_005118cc(&local_1160,param_5,param_6,param_7,param_8,param_9,param_10,param_11,param_12,
               param_13,param_14,param_15,param_16,param_17,param_18,param_19,param_20,param_21,
               param_22,param_23,param_24);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar8 = local_140 * 0x18;
    puVar7 = local_148;
    do {
      if ((undefined1 *)*puVar7 != auStack_1148) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005118cc
// Address: 005118cc
// ========================================

void FUN_005118cc(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11,undefined8 param_12,undefined8 param_13)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_00511a28(param_1,param_7,param_8,param_9,param_10,param_11,param_12,param_13);
  return;
}



// ========================================
// Function: FUN_00511a28
// Address: 00511a28
// ========================================

void FUN_00511a28(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11,undefined8 param_12,undefined8 param_13)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  FUN_00511b54(param_1,param_7,param_8,param_9,param_10,param_11,param_12,param_13);
  return;
}



// ========================================
// Function: FUN_00511b54
// Address: 00511b54
// ========================================

void FUN_00511b54(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_0050a2e4(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_00511c54
// Address: 00511c54
// ========================================

void FUN_00511c54(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7,undefined8 param_8,undefined8 param_9,undefined8 param_10,
                 undefined8 param_11,undefined8 param_12,undefined8 param_13,undefined8 param_14)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_00511e00(param_1,param_8,param_9,param_10,param_11,param_12,param_13,param_14);
  return;
}



// ========================================
// Function: FUN_00511e00
// Address: 00511e00
// ========================================

void FUN_00511e00(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7,undefined8 param_8,undefined8 param_9,undefined8 param_10,
                 undefined8 param_11,undefined8 param_12,undefined8 param_13)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_0050a3a8(param_1,param_8,param_9,param_10,param_11,param_12,param_13);
  return;
}



// ========================================
// Function: FUN_00511f74
// Address: 00511f74
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511f74(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12,
                 undefined8 param_13,undefined8 param_14,undefined8 param_15,undefined8 param_16,
                 undefined8 param_17,undefined8 param_18,undefined8 param_19,undefined8 param_20,
                 undefined8 param_21,undefined8 param_22,undefined8 param_23,undefined8 param_24)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_70 = *(long *)(lVar1 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 00512000 to 00512087 has its CatchHandler @ 00512128 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar4);
  FUN_00512154(&local_1160,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11
               ,param_12,param_13,param_14,param_15,param_16,param_17,param_18,param_19,param_20,
               param_21,param_22,param_23,param_24);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar6 = local_140 * 0x18;
    puVar5 = local_148;
    do {
      if ((undefined1 *)*puVar5 != auStack_1148) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar3;
  local_1158 = uVar2;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar1 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00512154
// Address: 00512154
// ========================================

void FUN_00512154(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11,undefined8 param_12,undefined8 param_13)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_005122d0(param_1,param_7,param_8,param_9,param_10,param_11,param_12,param_13);
  return;
}



// ========================================
// Function: FUN_005122d0
// Address: 005122d0
// ========================================

void FUN_005122d0(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11,undefined8 param_12,undefined8 param_13)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  FUN_0051240c(param_1,param_7,param_8,param_9,param_10,param_11,param_12,param_13);
  return;
}



// ========================================
// Function: FUN_0051240c
// Address: 0051240c
// ========================================

void FUN_0051240c(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11,undefined8 param_12,undefined8 param_13)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_00512518(param_1,param_7,param_8,param_9,param_10,param_11,param_12,param_13);
  return;
}



// ========================================
// Function: FUN_00512518
// Address: 00512518
// ========================================

void FUN_00512518(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6,undefined8 param_7,undefined8 param_8)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  FUN_005125fc(param_1,param_7,param_8);
  return;
}



// ========================================
// Function: FUN_005125fc
// Address: 005125fc
// ========================================

void FUN_005125fc(undefined8 param_1,undefined4 *param_2,char *param_3)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  FUN_00562e2c(local_50,*param_2);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 00512654 to 0051265b has its CatchHandler @ 005126a8 */
  FUN_0044c958(param_1,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar4);
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_005126d8
// Address: 005126d8
// ========================================

void FUN_005126d8(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7,undefined8 param_8,undefined8 param_9,undefined8 param_10,
                 undefined8 param_11,undefined8 param_12,undefined8 param_13,undefined8 param_14)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_0051289c(param_1,param_8,param_9,param_10,param_11,param_12,param_13,param_14);
  return;
}



// ========================================
// Function: FUN_0051289c
// Address: 0051289c
// ========================================

void FUN_0051289c(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7,undefined8 param_8,undefined8 param_9,undefined8 param_10,
                 undefined8 param_11,undefined8 param_12,undefined8 param_13,undefined8 param_14)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_00512a28(param_1,param_8,param_9,param_10,param_11,param_12,param_13,param_14);
  return;
}



// ========================================
// Function: FUN_00512a28
// Address: 00512a28
// ========================================

void FUN_00512a28(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7,undefined8 param_8,undefined8 param_9)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_00512b74(param_1,param_8,param_9);
  return;
}



// ========================================
// Function: FUN_00512b74
// Address: 00512b74
// ========================================

void FUN_00512b74(long param_1,undefined4 *param_2,char *param_3)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  FUN_00562e2c(local_50,*param_2);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 00512bcc to 00512bd3 has its CatchHandler @ 00512c38 */
  FUN_0044c958(param_1 + 0xc68,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar4);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_00512c68
// Address: 00512c68
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512c68(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  long lVar1;
  undefined8 *puVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 00512ce0 to 00512cf3 has its CatchHandler @ 00512d88 */
  uVar4 = _DAT_001a1320;
  uVar5 = _UNK_001a1328;
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_00512db0(&local_1138,param_2,param_3,param_4,param_5,param_6,param_8,param_9,_DAT_001a1320,
               _UNK_001a1328);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar3 = local_118 * 0x18;
    puVar2 = local_120;
    do {
      if ((undefined1 *)*puVar2 != auStack_1120) {
        free((undefined1 *)*puVar2);
      }
      lVar3 = lVar3 + -0x18;
      puVar2 = puVar2 + 3;
    } while (lVar3 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  local_1138 = auStack_1120;
  local_1130 = uVar4;
  uStack_1128 = uVar5;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00512db0
// Address: 00512db0
// ========================================

void FUN_00512db0(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_00512e74
// Address: 00512e74
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512e74(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1158;
  undefined8 local_1150;
  undefined8 uStack_1148;
  undefined1 auStack_1140 [4096];
  undefined8 *local_140;
  long local_138;
  undefined8 uStack_130;
  undefined8 local_128 [24];
  long local_68;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_68 = *(long *)(lVar3 + 0x28);
  uStack_130 = _UNK_001a0d48;
  local_138 = _DAT_001a0d40;
  uStack_1148 = _UNK_001a1328;
  local_1150 = _DAT_001a1320;
  local_1158 = auStack_1140;
  local_140 = local_128;
                    /* try { // try from 00512ef4 to 00512f63 has its CatchHandler @ 00513000 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1158,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1158,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1158,param_4,uVar6);
  FUN_005125fc(&local_1158,param_5,param_6);
  FUN_0044c6fc(param_1,&local_1158);
  if (local_138 != 0) {
    lVar8 = local_138 * 0x18;
    puVar7 = local_140;
    do {
      if ((undefined1 *)*puVar7 != auStack_1140) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1158 != auStack_1140) {
    free(local_1158);
  }
  local_138 = 0;
  uStack_1148 = uVar5;
  local_1150 = uVar4;
  local_1158 = auStack_1140;
  if (local_140 != local_128) {
    free(local_140);
  }
  if (*(long *)(lVar3 + 0x28) == local_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00513028
// Address: 00513028
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00513028(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12,
                 undefined8 param_13,undefined8 param_14,undefined8 param_15,undefined8 param_16,
                 undefined8 param_17,undefined8 param_18)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 005130b4 to 0051313b has its CatchHandler @ 005131dc */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  FUN_00511a28(&local_1160,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,
               param_12,param_13,param_14,param_15,param_16,param_17,param_18);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar8 = local_140 * 0x18;
    puVar7 = local_148;
    do {
      if ((undefined1 *)*puVar7 != auStack_1148) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00513208
// Address: 00513208
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00513208(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 0051327c to 005132db has its CatchHandler @ 00513374 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051339c
// Address: 0051339c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051339c(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  long lVar1;
  undefined8 *puVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 00513414 to 00513427 has its CatchHandler @ 005134bc */
  uVar4 = _DAT_001a1320;
  uVar5 = _UNK_001a1328;
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_005134e4(&local_1138,param_2,param_3,param_4,param_5,param_6,param_8,param_9,_DAT_001a1320,
               _UNK_001a1328);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar3 = local_118 * 0x18;
    puVar2 = local_120;
    do {
      if ((undefined1 *)*puVar2 != auStack_1120) {
        free((undefined1 *)*puVar2);
      }
      lVar3 = lVar3 + -0x18;
      puVar2 = puVar2 + 3;
    } while (lVar3 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  local_1138 = auStack_1120;
  local_1130 = uVar4;
  uStack_1128 = uVar5;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005134e4
// Address: 005134e4
// ========================================

void FUN_005134e4(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_005135a8
// Address: 005135a8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005135a8(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 0051361c to 0051367b has its CatchHandler @ 00513714 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051373c
// Address: 0051373c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051373c(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 005137c4 to 00513823 has its CatchHandler @ 005138c4 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  FUN_005138f0(&local_1160,param_4,param_5,param_6,param_7,param_8);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar8 = local_140 * 0x18;
    puVar7 = local_148;
    do {
      if ((undefined1 *)*puVar7 != auStack_1148) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005138f0
// Address: 005138f0
// ========================================

void FUN_005138f0(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_005139b4
// Address: 005139b4
// ========================================

void FUN_005139b4(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_00513ae4
// Address: 00513ae4
// ========================================

void FUN_00513ae4(undefined8 param_1,byte *param_2,char *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_00513ba0
// Address: 00513ba0
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00513ba0(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 00513c14 to 00513c73 has its CatchHandler @ 00513d0c */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00513d34
// Address: 00513d34
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00513d34(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 00513da8 to 00513e07 has its CatchHandler @ 00513ea0 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00513ec8
// Address: 00513ec8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00513ec8(long param_1,undefined8 *param_2,undefined4 *param_3,undefined1 *param_4)

{
  long lVar1;
  long lVar2;
  undefined4 uVar3;
  undefined1 uVar4;
  undefined1 uVar5;
  uint uVar6;
  long lVar7;
  undefined *puVar8;
  long *plVar9;
  void *pvVar10;
  long lVar11;
  long lVar12;
  ulong uVar13;
  void *pvVar14;
  undefined7 local_68;
  undefined1 uStack_61;
  
  lVar7 = tpidr_el0;
  lVar11 = *(long *)(lVar7 + 0x28);
  lVar12 = *(long *)(param_1 + 0x10);
  if (lVar12 == 0) {
    uVar6 = *(int *)(param_1 + 0x80) << (ulong)(*(uint *)(param_1 + 0x30) & 0x1f);
    uVar13 = (ulong)uVar6;
    pvVar10 = malloc(uVar13 * 0x120);
    if (pvVar10 == (void *)0x0) goto LAB_00513fa8;
    FUN_004517fc(param_1 + 8,uVar13);
    if (uVar6 != 0) {
      lVar12 = *(long *)(param_1 + 0x10);
      pvVar14 = pvVar10;
      do {
        FUN_004517fc(param_1 + 8,lVar12 + 1);
        lVar12 = *(long *)(param_1 + 0x10);
        uVar13 = uVar13 - 1;
        *(void **)(*(long *)(param_1 + 8) + lVar12 * 8) = pvVar14;
        lVar12 = lVar12 + 1;
        pvVar14 = (void *)((long)pvVar14 + 0x120);
        *(long *)(param_1 + 0x10) = lVar12;
      } while (uVar13 != 0);
    }
    FUN_004518ec(param_1 + 0x28,*(long *)(param_1 + 0x30) + 1);
    lVar1 = *(long *)(param_1 + 8);
    lVar12 = *(long *)(param_1 + 0x10);
    lVar2 = *(long *)(param_1 + 0x30);
    *(void **)(*(long *)(param_1 + 0x28) + lVar2 * 8) = pvVar10;
    plVar9 = *(long **)(lVar1 + lVar12 * 8 + -8);
    *(long *)(param_1 + 0x30) = lVar2 + 1;
    if (lVar12 != 0) goto LAB_00513f08;
  }
  else {
    plVar9 = *(long **)(*(long *)(param_1 + 8) + lVar12 * 8 + -8);
LAB_00513f08:
    *(long *)(param_1 + 0x10) = lVar12 + -1;
  }
  lVar12 = param_2[1];
  lVar1 = param_2[2];
  param_2[2] = 0;
  puVar8 = PTR_DAT_005c61a8;
  local_68 = (undefined7)*(undefined8 *)((long)param_2 + 1);
  uStack_61 = (undefined1)lVar12;
  uVar4 = *(undefined1 *)param_2;
  *param_2 = 0;
  param_2[1] = 0;
  uVar5 = *param_4;
  *plVar9 = (long)(puVar8 + 0x10);
  uVar3 = *param_3;
  plVar9[1] = 0;
  *(undefined1 *)(plVar9 + 2) = uVar4;
  *(undefined4 *)(plVar9 + 5) = uVar3;
  *(undefined4 *)((long)plVar9 + 0x2c) = 0;
  plVar9[7] = (long)(plVar9 + 10);
  plVar9[8] = 0;
  *(ulong *)((long)plVar9 + 0x11) = CONCAT17(uStack_61,local_68);
  plVar9[3] = lVar12;
  plVar9[4] = lVar1;
  plVar9[9] = 8;
  lVar1 = _UNK_001a0d48;
  lVar12 = _DAT_001a0d40;
  plVar9[0xe] = (long)(plVar9 + 0x11);
  plVar9[0x15] = (long)(plVar9 + 0x18);
  *(undefined1 *)(plVar9 + 6) = uVar5;
  *(undefined4 *)((long)plVar9 + 0x31) = 0;
  plVar9[0x10] = lVar1;
  plVar9[0xf] = lVar12;
  plVar9[0x17] = lVar1;
  plVar9[0x16] = lVar12;
  plVar9[0x1c] = (long)(plVar9 + 0x1f);
  plVar9[0x1e] = lVar1;
  plVar9[0x1d] = lVar12;
  *(undefined4 *)(plVar9 + 0x23) = 0;
LAB_00513fa8:
  if (*(long *)(lVar7 + 0x28) != lVar11) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_00514084
// Address: 00514084
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00514084(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 0051410c to 0051416b has its CatchHandler @ 0051420c */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  FUN_0050a2e4(&local_1160,param_4,param_5,param_6,param_7,param_8);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar8 = local_140 * 0x18;
    puVar7 = local_148;
    do {
      if ((undefined1 *)*puVar7 != auStack_1148) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00514238
// Address: 00514238
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00514238(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 005142c0 to 0051431f has its CatchHandler @ 005143c0 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  FUN_0050a2e4(&local_1160,param_4,param_5,param_6,param_7,param_8);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar8 = local_140 * 0x18;
    puVar7 = local_148;
    do {
      if ((undefined1 *)*puVar7 != auStack_1148) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005143ec
// Address: 005143ec
// ========================================

void FUN_005143ec(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11,undefined8 param_12,undefined8 param_13)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  FUN_00511b54(param_1,param_7,param_8,param_9,param_10,param_11,param_12,param_13);
  return;
}



// ========================================
// Function: FUN_00514518
// Address: 00514518
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00514518(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_70 = *(long *)(lVar1 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 005145a8 to 005145ff has its CatchHandler @ 005146a4 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar4);
  FUN_005146d0(&local_1160,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11
               ,param_12);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar6 = local_140 * 0x18;
    puVar5 = local_148;
    do {
      if ((undefined1 *)*puVar5 != auStack_1148) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  uStack_1150 = uVar3;
  local_1158 = uVar2;
  local_140 = 0;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar1 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005146d0
// Address: 005146d0
// ========================================

void FUN_005146d0(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_005147d0(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_005147d0
// Address: 005147d0
// ========================================

void FUN_005147d0(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_00514894
// Address: 00514894
// ========================================

void FUN_00514894(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_005149c4
// Address: 005149c4
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005149c4(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9,undefined8 param_10,undefined8 param_11,undefined8 param_12)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_70 = *(long *)(lVar1 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 00514a54 to 00514aab has its CatchHandler @ 00514b50 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar4);
  FUN_005146d0(&local_1160,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11
               ,param_12);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar6 = local_140 * 0x18;
    puVar5 = local_148;
    do {
      if ((undefined1 *)*puVar5 != auStack_1148) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  uStack_1150 = uVar3;
  local_1158 = uVar2;
  local_140 = 0;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar1 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00514b7c
// Address: 00514b7c
// ========================================

void FUN_00514b7c(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6,undefined8 param_7,undefined8 param_8)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  FUN_00509788(param_1,param_7,param_8);
  return;
}



// ========================================
// Function: FUN_00514c60
// Address: 00514c60
// ========================================

void FUN_00514c60(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  return;
}



// ========================================
// Function: FUN_00514d24
// Address: 00514d24
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00514d24(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 00514d94 to 00514dc3 has its CatchHandler @ 00514e5c */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar4);
  FUN_00511530(&local_1148,param_3);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar6 = local_128 * 0x18;
    puVar5 = local_130;
    do {
      if ((undefined1 *)*puVar5 != auStack_1130) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar3;
  local_1140 = uVar2;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00514e84
// Address: 00514e84
// ========================================

void FUN_00514e84(undefined8 param_1,undefined4 *param_2,byte *param_3,byte *param_4)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  void *pvVar4;
  byte local_60 [8];
  ulong local_58;
  void *local_50;
  long local_48;
  
  lVar3 = tpidr_el0;
  local_48 = *(long *)(lVar3 + 0x28);
  FUN_00562e2c(local_60,*param_2);
  uVar1 = (ulong)(local_60[0] >> 1);
  pvVar4 = (void *)((ulong)local_60 | 1);
  if ((local_60[0] & 1) != 0) {
    uVar1 = local_58;
    pvVar4 = local_50;
  }
                    /* try { // try from 00514ee4 to 00514eeb has its CatchHandler @ 00514f5c */
  FUN_0044c958(param_1,pvVar4,uVar1);
  if ((local_60[0] & 1) != 0) {
    free(local_50);
  }
  local_60[0] = *param_3;
  FUN_0044c958(param_1,local_60,1);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  if (*(long *)(lVar3 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00514f8c
// Address: 00514f8c
// ========================================

void FUN_00514f8c(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  __s = (char *)*param_3;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0051504c
// Address: 0051504c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051504c(undefined8 param_1,byte *param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  long lVar7;
  undefined1 *local_1158;
  undefined8 local_1150;
  undefined8 uStack_1148;
  undefined1 auStack_1140 [4096];
  undefined8 *local_140;
  long local_138;
  undefined8 uStack_130;
  undefined8 local_128 [24];
  long local_68;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_68 = *(long *)(lVar3 + 0x28);
  uStack_130 = _UNK_001a0d48;
  local_138 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1148 = _UNK_001a1328;
  local_1150 = _DAT_001a1320;
                    /* try { // try from 005150e4 to 00515113 has its CatchHandler @ 005151b0 */
  local_1158 = auStack_1140;
  local_140 = local_128;
  FUN_0044c958(&local_1158,pbVar2,uVar1);
  FUN_00515318(&local_1158,param_3,param_4,param_5,param_6,param_7);
  FUN_0044c6fc(param_1,&local_1158);
  if (local_138 != 0) {
    lVar7 = local_138 * 0x18;
    puVar6 = local_140;
    do {
      if ((undefined1 *)*puVar6 != auStack_1140) {
        free((undefined1 *)*puVar6);
      }
      lVar7 = lVar7 + -0x18;
      puVar6 = puVar6 + 3;
    } while (lVar7 != 0);
  }
  if (local_1158 != auStack_1140) {
    free(local_1158);
  }
  local_138 = 0;
  uStack_1148 = uVar5;
  local_1150 = uVar4;
  local_1158 = auStack_1140;
  if (local_140 != local_128) {
    free(local_140);
  }
  if (*(long *)(lVar3 + 0x28) == local_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005151d8
// Address: 005151d8
// ========================================

void FUN_005151d8(long param_1,byte *param_2,byte *param_3,byte *param_4,byte *param_5,byte *param_6
                 ,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_00515318
// Address: 00515318
// ========================================

void FUN_00515318(undefined8 param_1,byte *param_2,byte *param_3,byte *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_005153e4
// Address: 005153e4
// ========================================

void FUN_005153e4(undefined8 param_1,undefined8 *param_2,undefined8 *param_3,byte *param_4,
                 char *param_5,byte *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *pcVar4;
  
  pcVar4 = (char *)*param_2;
  sVar3 = strlen(pcVar4);
  FUN_0044c958(param_1,pcVar4,sVar3);
  pcVar4 = (char *)*param_3;
  sVar3 = strlen(pcVar4);
  FUN_0044c958(param_1,pcVar4,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  return;
}



// ========================================
// Function: FUN_005154ac
// Address: 005154ac
// ========================================

void FUN_005154ac(undefined8 param_1,undefined4 *param_2,char *param_3)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  FUN_00562e2c(local_50,*param_2);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 00515504 to 0051550b has its CatchHandler @ 00515558 */
  FUN_0044c958(param_1,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar4);
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_00515588
// Address: 00515588
// ========================================

void FUN_00515588(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0051564c
// Address: 0051564c
// ========================================

void FUN_0051564c(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_00515710
// Address: 00515710
// ========================================

void FUN_00515710(undefined8 param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
                 undefined8 param_10,undefined8 param_11)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  FUN_00515810(param_1,param_7,param_8,param_9,param_10,param_11);
  return;
}



// ========================================
// Function: FUN_00515810
// Address: 00515810
// ========================================

void FUN_00515810(undefined8 param_1,char *param_2,byte *param_3,char *param_4,undefined8 *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  __s = (char *)*param_5;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_005158d0
// Address: 005158d0
// ========================================

void FUN_005158d0(undefined8 param_1,undefined4 *param_2,char *param_3,undefined8 param_4)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_60 [8];
  ulong local_58;
  void *local_50;
  long local_48;
  
  lVar2 = tpidr_el0;
  local_48 = *(long *)(lVar2 + 0x28);
  FUN_00562e2c(local_60,*param_2);
  uVar1 = (ulong)(local_60[0] >> 1);
  pvVar3 = (void *)((ulong)local_60 | 1);
  if ((local_60[0] & 1) != 0) {
    uVar1 = local_58;
    pvVar3 = local_50;
  }
                    /* try { // try from 00515930 to 00515937 has its CatchHandler @ 00515994 */
  FUN_0044c958(param_1,pvVar3,uVar1);
  if ((local_60[0] & 1) != 0) {
    free(local_50);
  }
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar4);
  FUN_004f4f90(param_1,param_4);
  if (*(long *)(lVar2 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_005159c4
// Address: 005159c4
// ========================================

long * FUN_005159c4(long *param_1,byte *param_2)

{
  size_t sVar1;
  size_t sVar2;
  byte *pbVar3;
  byte bVar4;
  ulong uVar5;
  long lVar6;
  int iVar7;
  ulong uVar8;
  long *plVar9;
  ulong uVar10;
  ulong uVar11;
  ulong uVar12;
  ulong uVar13;
  undefined2 uVar14;
  undefined8 uVar15;
  undefined1 uStack_69;
  long local_68;
  
  lVar6 = tpidr_el0;
  local_68 = *(long *)(lVar6 + 0x28);
  uVar8 = *(ulong *)(param_2 + 8);
  pbVar3 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar3 = param_2 + 1;
    uVar8 = (ulong)(*param_2 >> 1);
  }
                    /* try { // try from 00515a10 to 00515a17 has its CatchHandler @ 00515b7c */
  uVar8 = FUN_002ef008(&uStack_69,pbVar3,uVar8);
  uVar11 = param_1[1];
  if (uVar11 != 0) {
    uVar15 = CONCAT17(POPCOUNT((char)(uVar11 >> 0x38)),
                      CONCAT16(POPCOUNT((char)(uVar11 >> 0x30)),
                               CONCAT15(POPCOUNT((char)(uVar11 >> 0x28)),
                                        CONCAT14(POPCOUNT((char)(uVar11 >> 0x20)),
                                                 CONCAT13(POPCOUNT((char)(uVar11 >> 0x18)),
                                                          CONCAT12(POPCOUNT((char)(uVar11 >> 0x10)),
                                                                   CONCAT11(POPCOUNT((char)(uVar11 
                                                  >> 8)),POPCOUNT((char)uVar11))))))));
    uVar14 = NEON_uaddlv(uVar15,1);
    uVar12 = CONCAT62((int6)((ulong)uVar15 >> 0x10),uVar14) & 0xffffffff;
    if (uVar12 < 2) {
      uVar13 = uVar11 - 1 & uVar8;
    }
    else {
      uVar13 = uVar8;
      if (uVar11 <= uVar8) {
        uVar13 = 0;
        if (uVar11 != 0) {
          uVar13 = uVar8 / uVar11;
        }
        uVar13 = uVar8 - uVar13 * uVar11;
      }
    }
    plVar9 = *(long **)(*param_1 + uVar13 * 8);
    if (plVar9 != (long *)0x0) {
      plVar9 = (long *)*plVar9;
      if (plVar9 != (long *)0x0) {
        pbVar3 = param_2 + 1;
        sVar1 = (ulong)(*param_2 >> 1);
        if ((*param_2 & 1) != 0) {
          pbVar3 = *(byte **)(param_2 + 0x10);
          sVar1 = *(size_t *)(param_2 + 8);
        }
        do {
          uVar10 = plVar9[1];
          if (uVar10 == uVar8) {
            bVar4 = *(byte *)(plVar9 + 2);
            sVar2 = (ulong)(bVar4 >> 1);
            if ((bVar4 & 1) != 0) {
              sVar2 = plVar9[3];
            }
            if (sVar2 == sVar1) {
              if ((bVar4 & 1) == 0) {
                if (bVar4 < 2) break;
                uVar10 = 0;
                while (*(byte *)((long)plVar9 + uVar10 + 0x11) == pbVar3[uVar10]) {
                  uVar10 = uVar10 + 1;
                  if (bVar4 >> 1 == uVar10) goto LAB_00515b44;
                }
              }
              else {
                iVar7 = memcmp((void *)plVar9[4],pbVar3,plVar9[3]);
                if (iVar7 == 0) break;
              }
            }
          }
          else {
            if (uVar12 < 2) {
              uVar10 = uVar10 & uVar11 - 1;
            }
            else if (uVar11 <= uVar10) {
              uVar5 = 0;
              if (uVar11 != 0) {
                uVar5 = uVar10 / uVar11;
              }
              uVar10 = uVar10 - uVar5 * uVar11;
            }
            if (uVar10 != uVar13) goto LAB_00515b40;
          }
          plVar9 = (long *)*plVar9;
        } while (plVar9 != (long *)0x0);
      }
      goto LAB_00515b44;
    }
  }
LAB_00515b40:
  plVar9 = (long *)0x0;
LAB_00515b44:
  if (*(long *)(lVar6 + 0x28) == local_68) {
    return plVar9;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00515b80
// Address: 00515b80
// ========================================

long * FUN_00515b80(long *param_1,byte *param_2,undefined8 param_3,undefined8 *param_4)

{
  size_t sVar1;
  size_t sVar2;
  byte *pbVar3;
  byte bVar4;
  long lVar5;
  uint uVar6;
  long *plVar7;
  undefined8 uVar8;
  undefined8 *puVar9;
  long *plVar10;
  long *plVar11;
  long lVar12;
  long lVar13;
  ulong uVar14;
  ulong uVar15;
  long *plVar16;
  long *plVar17;
  long *plVar18;
  long *unaff_x26;
  undefined2 uVar19;
  float fVar20;
  long *local_80;
  long *plStack_78;
  undefined1 local_70;
  long local_68;
  
  lVar5 = tpidr_el0;
  local_68 = *(long *)(lVar5 + 0x28);
  uVar15 = *(ulong *)(param_2 + 8);
  pbVar3 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar3 = param_2 + 1;
    uVar15 = (ulong)(*param_2 >> 1);
  }
                    /* try { // try from 00515bd0 to 00515bd7 has its CatchHandler @ 00515f5c */
  plVar7 = (long *)FUN_002ef008(&local_80,pbVar3,uVar15);
  plVar18 = (long *)param_1[1];
  if (plVar18 != (long *)0x0) {
    uVar8 = CONCAT17(POPCOUNT((char)((ulong)plVar18 >> 0x38)),
                     CONCAT16(POPCOUNT((char)((ulong)plVar18 >> 0x30)),
                              CONCAT15(POPCOUNT((char)((ulong)plVar18 >> 0x28)),
                                       CONCAT14(POPCOUNT((char)((ulong)plVar18 >> 0x20)),
                                                CONCAT13(POPCOUNT((char)((ulong)plVar18 >> 0x18)),
                                                         CONCAT12(POPCOUNT((char)((ulong)plVar18 >>
                                                                                 0x10)),
                                                                  CONCAT11(POPCOUNT((char)((ulong)
                                                  plVar18 >> 8)),POPCOUNT((char)plVar18))))))));
    uVar19 = NEON_uaddlv(uVar8,1);
    uVar15 = CONCAT62((int6)((ulong)uVar8 >> 0x10),uVar19) & 0xffffffff;
    if (uVar15 < 2) {
      unaff_x26 = (long *)((long)plVar18 - 1U & (ulong)plVar7);
    }
    else {
      unaff_x26 = plVar7;
      if (plVar18 <= plVar7) {
        uVar14 = 0;
        if (plVar18 != (long *)0x0) {
          uVar14 = (ulong)plVar7 / (ulong)plVar18;
        }
        unaff_x26 = (long *)((long)plVar7 - uVar14 * (long)plVar18);
      }
    }
    puVar9 = *(undefined8 **)(*param_1 + (long)unaff_x26 * 8);
    if ((puVar9 != (undefined8 *)0x0) && (plVar17 = (long *)*puVar9, plVar17 != (long *)0x0)) {
      plVar11 = plVar7;
      pbVar3 = param_2 + 1;
      sVar1 = (ulong)(*param_2 >> 1);
      if ((*param_2 & 1) != 0) {
        pbVar3 = *(byte **)(param_2 + 0x10);
        sVar1 = *(size_t *)(param_2 + 8);
      }
      do {
        plVar10 = (long *)plVar17[1];
        if (plVar10 == plVar7) {
          bVar4 = *(byte *)(plVar17 + 2);
          sVar2 = (ulong)(bVar4 >> 1);
          if ((bVar4 & 1) != 0) {
            sVar2 = plVar17[3];
          }
          if (sVar2 == sVar1) {
            if ((bVar4 & 1) == 0) {
              if (bVar4 < 2) {
LAB_00515cf8:
                uVar8 = 0;
                goto LAB_00515f00;
              }
              uVar14 = 0;
              while (*(byte *)((long)plVar17 + uVar14 + 0x11) == pbVar3[uVar14]) {
                uVar14 = uVar14 + 1;
                if (bVar4 >> 1 == uVar14) goto LAB_00515cf8;
              }
            }
            else {
              uVar6 = memcmp((void *)plVar17[4],pbVar3,plVar17[3]);
              plVar11 = (long *)(ulong)uVar6;
              if (uVar6 == 0) goto LAB_00515cf8;
            }
          }
        }
        else {
          if (uVar15 < 2) {
            plVar10 = (long *)((ulong)plVar10 & (long)plVar18 - 1U);
          }
          else if (plVar18 <= plVar10) {
            uVar14 = 0;
            if (plVar18 != (long *)0x0) {
              uVar14 = (ulong)plVar10 / (ulong)plVar18;
            }
            plVar10 = (long *)((long)plVar10 - uVar14 * (long)plVar18);
          }
          if (plVar10 != unaff_x26) break;
        }
        plVar17 = (long *)*plVar17;
      } while (plVar17 != (long *)0x0);
    }
  }
  plVar10 = param_1 + 2;
  plVar17 = (long *)FUN_005a5d4c(0x50);
  plVar11 = (long *)*param_4;
  *plVar17 = 0;
  plVar17[1] = (long)plVar7;
  lVar13 = plVar11[1];
  lVar12 = *plVar11;
  plVar17[4] = plVar11[2];
  plVar17[3] = lVar13;
  plVar17[2] = lVar12;
  plVar11[1] = 0;
  plVar11[2] = 0;
  *plVar11 = 0;
  lVar12 = param_1[3];
  plVar17[6] = 0;
  plVar17[5] = 0;
  plVar17[8] = 0;
  plVar17[7] = 0;
  fVar20 = *(float *)(param_1 + 4);
  *(undefined4 *)(plVar17 + 9) = 0x3f800000;
  local_70 = 1;
  plVar11 = plVar17;
  local_80 = plVar17;
  plStack_78 = plVar10;
  if ((plVar18 == (long *)0x0) || (fVar20 * (float)plVar18 < (float)(lVar12 + 1))) {
    if (plVar18 < (long *)0x3) {
      uVar15 = 1;
    }
    else {
      uVar15 = (ulong)(((ulong)plVar18 & (long)plVar18 - 1U) != 0);
    }
    plVar18 = (long *)(uVar15 | (long)plVar18 << 1);
    plVar16 = (long *)(long)((float)(lVar12 + 1) / fVar20);
    if (plVar18 <= plVar16) {
      plVar18 = plVar16;
    }
    if ((long)plVar18 - 1U == 0) {
      plVar18 = (long *)0x2;
    }
    else if (((ulong)plVar18 & (long)plVar18 - 1U) != 0) {
                    /* try { // try from 00515dc8 to 00515e4b has its CatchHandler @ 00515f34 */
      plVar11 = (long *)FUN_0055fe2c(plVar18);
      plVar18 = plVar11;
    }
    plVar16 = (long *)param_1[1];
    if (plVar16 < plVar18) {
LAB_00515de0:
      plVar11 = (long *)FUN_00515fd4(param_1,plVar18);
    }
    else if (plVar18 < plVar16) {
      plVar11 = (long *)(long)((float)(ulong)param_1[3] / *(float *)(param_1 + 4));
      if ((plVar16 < (long *)0x3) ||
         (uVar8 = CONCAT17(POPCOUNT((char)((ulong)plVar16 >> 0x38)),
                           CONCAT16(POPCOUNT((char)((ulong)plVar16 >> 0x30)),
                                    CONCAT15(POPCOUNT((char)((ulong)plVar16 >> 0x28)),
                                             CONCAT14(POPCOUNT((char)((ulong)plVar16 >> 0x20)),
                                                      CONCAT13(POPCOUNT((char)((ulong)plVar16 >>
                                                                              0x18)),
                                                               CONCAT12(POPCOUNT((char)((ulong)
                                                  plVar16 >> 0x10)),
                                                  CONCAT11(POPCOUNT((char)((ulong)plVar16 >> 8)),
                                                           POPCOUNT((char)plVar16)))))))),
         uVar19 = NEON_uaddlv(uVar8,1),
         1 < (CONCAT62((int6)((ulong)uVar8 >> 0x10),uVar19) & 0xffffffff))) {
        plVar11 = (long *)FUN_0055fe2c();
      }
      else if ((long *)0x1 < plVar11) {
        plVar11 = (long *)(1L << (-LZCOUNT((long)plVar11 + -1) & 0x3fU));
      }
      if (plVar18 <= plVar11) {
        plVar18 = plVar11;
      }
      if (plVar18 < plVar16) goto LAB_00515de0;
    }
    plVar18 = (long *)param_1[1];
    if (((ulong)plVar18 & (long)plVar18 - 1U) == 0) {
      unaff_x26 = (long *)((long)plVar18 - 1U & (ulong)plVar7);
    }
    else {
      unaff_x26 = plVar7;
      if (plVar18 <= plVar7) {
        uVar15 = 0;
        if (plVar18 != (long *)0x0) {
          uVar15 = (ulong)plVar7 / (ulong)plVar18;
        }
        unaff_x26 = (long *)((long)plVar7 - uVar15 * (long)plVar18);
      }
    }
  }
  lVar12 = *param_1;
  plVar7 = *(long **)(lVar12 + (long)unaff_x26 * 8);
  if (plVar7 == (long *)0x0) {
    lVar13 = *plVar10;
    *plVar10 = (long)plVar17;
    *plVar17 = lVar13;
    *(long **)(lVar12 + (long)unaff_x26 * 8) = plVar10;
    if (*plVar17 == 0) goto LAB_00515ef0;
    plVar7 = *(long **)(*plVar17 + 8);
    if (((ulong)plVar18 & (long)plVar18 - 1U) == 0) {
      plVar7 = (long *)((ulong)plVar7 & (long)plVar18 - 1U);
    }
    else if (plVar18 <= plVar7) {
      uVar15 = 0;
      if (plVar18 != (long *)0x0) {
        uVar15 = (ulong)plVar7 / (ulong)plVar18;
      }
      plVar7 = (long *)((long)plVar7 - uVar15 * (long)plVar18);
    }
    plVar7 = (long *)(*param_1 + (long)plVar7 * 8);
  }
  else {
    *plVar17 = *plVar7;
  }
  *plVar7 = (long)plVar17;
LAB_00515ef0:
  uVar8 = 1;
  param_1[3] = param_1[3] + 1;
LAB_00515f00:
  if (*(long *)(lVar5 + 0x28) != local_68) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(plVar11,uVar8);
  }
  return plVar17;
}



// ========================================
// Function: FUN_00515f60
// Address: 00515f60
// ========================================

void FUN_00515f60(undefined8 *param_1)

{
  undefined8 *__ptr;
  void *__ptr_00;
  void *pvVar1;
  
  __ptr_00 = (void *)*param_1;
  *param_1 = 0;
  if (__ptr_00 == (void *)0x0) {
    return;
  }
  if (*(char *)(param_1 + 2) != '\0') {
    __ptr = (undefined8 *)*(void **)((long)__ptr_00 + 0x38);
    while (__ptr != (undefined8 *)0x0) {
      pvVar1 = (void *)*__ptr;
      free(__ptr);
      __ptr = (undefined8 *)pvVar1;
    }
    pvVar1 = *(void **)((long)__ptr_00 + 0x28);
    *(undefined8 *)((long)__ptr_00 + 0x28) = 0;
    if (pvVar1 != (void *)0x0) {
      free(pvVar1);
    }
    if ((*(byte *)((long)__ptr_00 + 0x10) & 1) != 0) {
      free(*(void **)((long)__ptr_00 + 0x20));
    }
  }
  free(__ptr_00);
  return;
}



// ========================================
// Function: FUN_00515fd4
// Address: 00515fd4
// ========================================

void FUN_00515fd4(long *param_1,ulong param_2)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  ulong uVar4;
  long *plVar5;
  ulong uVar6;
  long *plVar7;
  ulong uVar8;
  undefined2 uVar9;
  undefined8 uVar10;
  
  if (param_2 == 0) {
    pvVar3 = (void *)*param_1;
    *param_1 = 0;
    if (pvVar3 != (void *)0x0) {
      free(pvVar3);
    }
    param_1[1] = 0;
  }
  else {
    if (param_2 >> 0x3d != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_0029fc3c();
    }
    lVar2 = FUN_005a5d4c(param_2 << 3);
    pvVar3 = (void *)*param_1;
    *param_1 = lVar2;
    if (pvVar3 != (void *)0x0) {
      free(pvVar3);
    }
    uVar4 = 0;
    param_1[1] = param_2;
    do {
      *(undefined8 *)(*param_1 + uVar4 * 8) = 0;
      uVar4 = uVar4 + 1;
    } while (param_2 != uVar4);
    plVar5 = (long *)param_1[2];
    if (plVar5 != (long *)0x0) {
      uVar4 = plVar5[1];
      uVar10 = CONCAT17(POPCOUNT((char)(param_2 >> 0x38)),
                        CONCAT16(POPCOUNT((char)(param_2 >> 0x30)),
                                 CONCAT15(POPCOUNT((char)(param_2 >> 0x28)),
                                          CONCAT14(POPCOUNT((char)(param_2 >> 0x20)),
                                                   CONCAT13(POPCOUNT((char)(param_2 >> 0x18)),
                                                            CONCAT12(POPCOUNT((char)(param_2 >> 0x10
                                                                                    )),
                                                                     CONCAT11(POPCOUNT((char)(
                                                  param_2 >> 8)),POPCOUNT((char)param_2))))))));
      uVar9 = NEON_uaddlv(uVar10,1);
      uVar6 = CONCAT62((int6)((ulong)uVar10 >> 0x10),uVar9) & 0xffffffff;
      if (uVar6 < 2) {
        uVar4 = uVar4 & param_2 - 1;
      }
      else if (param_2 <= uVar4) {
        uVar8 = 0;
        if (param_2 != 0) {
          uVar8 = uVar4 / param_2;
        }
        uVar4 = uVar4 - uVar8 * param_2;
      }
      *(long **)(*param_1 + uVar4 * 8) = param_1 + 2;
      plVar7 = (long *)*plVar5;
      if (plVar7 != (long *)0x0) {
        do {
          uVar8 = plVar7[1];
          if (uVar6 < 2) {
            uVar8 = uVar8 & param_2 - 1;
          }
          else if (param_2 <= uVar8) {
            uVar1 = 0;
            if (param_2 != 0) {
              uVar1 = uVar8 / param_2;
            }
            uVar8 = uVar8 - uVar1 * param_2;
          }
          if (uVar8 != uVar4) {
            if (*(long *)(*param_1 + uVar8 * 8) == 0) {
              *(long **)(*param_1 + uVar8 * 8) = plVar5;
              uVar4 = uVar8;
            }
            else {
              *plVar5 = *plVar7;
              *plVar7 = **(long **)(*param_1 + uVar8 * 8);
              **(undefined8 **)(*param_1 + uVar8 * 8) = plVar7;
              plVar7 = plVar5;
            }
          }
          plVar5 = plVar7;
          plVar7 = (long *)*plVar5;
        } while (plVar7 != (long *)0x0);
      }
    }
  }
  return;
}



// ========================================
// Function: FUN_00516130
// Address: 00516130
// ========================================

long * FUN_00516130(long *param_1,ulong *param_2,long *param_3)

{
  ulong uVar1;
  long lVar2;
  long *plVar3;
  long *plVar4;
  ulong uVar5;
  ulong uVar6;
  long lVar7;
  ulong uVar8;
  ulong uVar9;
  ulong unaff_x24;
  undefined2 uVar10;
  undefined8 uVar11;
  float fVar12;
  
  uVar8 = param_1[1];
  uVar9 = *param_2;
  if (uVar8 != 0) {
    uVar11 = CONCAT17(POPCOUNT((char)(uVar8 >> 0x38)),
                      CONCAT16(POPCOUNT((char)(uVar8 >> 0x30)),
                               CONCAT15(POPCOUNT((char)(uVar8 >> 0x28)),
                                        CONCAT14(POPCOUNT((char)(uVar8 >> 0x20)),
                                                 CONCAT13(POPCOUNT((char)(uVar8 >> 0x18)),
                                                          CONCAT12(POPCOUNT((char)(uVar8 >> 0x10)),
                                                                   CONCAT11(POPCOUNT((char)(uVar8 >>
                                                                                           8)),
                                                                            POPCOUNT((char)uVar8))))
                                                ))));
    uVar10 = NEON_uaddlv(uVar11,1);
    uVar5 = CONCAT62((int6)((ulong)uVar11 >> 0x10),uVar10) & 0xffffffff;
    if (uVar5 < 2) {
      unaff_x24 = uVar8 - 1 & uVar9;
    }
    else {
      unaff_x24 = uVar9;
      if (uVar8 <= uVar9) {
        uVar6 = 0;
        if (uVar8 != 0) {
          uVar6 = uVar9 / uVar8;
        }
        unaff_x24 = uVar9 - uVar6 * uVar8;
      }
    }
    plVar4 = *(long **)(*param_1 + unaff_x24 * 8);
    if ((plVar4 != (long *)0x0) && (plVar4 = (long *)*plVar4, plVar4 != (long *)0x0)) {
      do {
        uVar6 = plVar4[1];
        if (uVar6 == uVar9) {
          if (plVar4[2] == uVar9) {
            return plVar4;
          }
        }
        else {
          if (uVar5 < 2) {
            uVar6 = uVar6 & uVar8 - 1;
          }
          else if (uVar8 <= uVar6) {
            uVar1 = 0;
            if (uVar8 != 0) {
              uVar1 = uVar6 / uVar8;
            }
            uVar6 = uVar6 - uVar1 * uVar8;
          }
          if (uVar6 != unaff_x24) break;
        }
        plVar4 = (long *)*plVar4;
      } while (plVar4 != (long *)0x0);
    }
  }
  plVar4 = (long *)FUN_005a5d4c(0x18);
  lVar2 = param_1[3];
  fVar12 = *(float *)(param_1 + 4);
  *plVar4 = 0;
  plVar4[1] = uVar9;
  plVar4[2] = *param_3;
  if ((uVar8 == 0) || (fVar12 * (float)uVar8 < (float)(lVar2 + 1))) {
    if (uVar8 < 3) {
      uVar5 = 1;
    }
    else {
      uVar5 = (ulong)((uVar8 & uVar8 - 1) != 0);
    }
    uVar5 = uVar5 | uVar8 << 1;
    uVar6 = (ulong)((float)(lVar2 + 1) / fVar12);
    if (uVar5 <= uVar6) {
      uVar5 = uVar6;
    }
    if (uVar5 - 1 == 0) {
      uVar5 = 2;
    }
    else if ((uVar5 & uVar5 - 1) != 0) {
                    /* try { // try from 00516280 to 0051630b has its CatchHandler @ 005163dc */
      uVar5 = FUN_0055fe2c(uVar5);
      uVar8 = param_1[1];
    }
    if (uVar8 < uVar5) {
LAB_00516298:
      FUN_005163f0(param_1,uVar5);
    }
    else if (uVar5 < uVar8) {
      uVar6 = (ulong)((float)(ulong)param_1[3] / *(float *)(param_1 + 4));
      if ((uVar8 < 3) ||
         (uVar11 = CONCAT17(POPCOUNT((char)(uVar8 >> 0x38)),
                            CONCAT16(POPCOUNT((char)(uVar8 >> 0x30)),
                                     CONCAT15(POPCOUNT((char)(uVar8 >> 0x28)),
                                              CONCAT14(POPCOUNT((char)(uVar8 >> 0x20)),
                                                       CONCAT13(POPCOUNT((char)(uVar8 >> 0x18)),
                                                                CONCAT12(POPCOUNT((char)(uVar8 >> 
                                                  0x10)),CONCAT11(POPCOUNT((char)(uVar8 >> 8)),
                                                                  POPCOUNT((char)uVar8)))))))),
         uVar10 = NEON_uaddlv(uVar11,1),
         1 < (CONCAT62((int6)((ulong)uVar11 >> 0x10),uVar10) & 0xffffffff))) {
        uVar6 = FUN_0055fe2c();
      }
      else if (1 < uVar6) {
        uVar6 = 1L << (-LZCOUNT(uVar6 - 1) & 0x3fU);
      }
      if (uVar5 <= uVar6) {
        uVar5 = uVar6;
      }
      if (uVar5 < uVar8) goto LAB_00516298;
    }
    uVar8 = param_1[1];
    if ((uVar8 & uVar8 - 1) == 0) {
      unaff_x24 = uVar8 - 1 & uVar9;
    }
    else {
      unaff_x24 = uVar9;
      if (uVar8 <= uVar9) {
        uVar5 = 0;
        if (uVar8 != 0) {
          uVar5 = uVar9 / uVar8;
        }
        unaff_x24 = uVar9 - uVar5 * uVar8;
      }
    }
  }
  lVar2 = *param_1;
  plVar3 = *(long **)(lVar2 + unaff_x24 * 8);
  if (plVar3 == (long *)0x0) {
    plVar3 = param_1 + 2;
    lVar7 = *plVar3;
    *plVar3 = (long)plVar4;
    *plVar4 = lVar7;
    *(long **)(lVar2 + unaff_x24 * 8) = plVar3;
    if (*plVar4 == 0) goto LAB_005163b4;
    uVar9 = *(ulong *)(*plVar4 + 8);
    if ((uVar8 & uVar8 - 1) == 0) {
      uVar9 = uVar9 & uVar8 - 1;
    }
    else if (uVar8 <= uVar9) {
      uVar5 = 0;
      if (uVar8 != 0) {
        uVar5 = uVar9 / uVar8;
      }
      uVar9 = uVar9 - uVar5 * uVar8;
    }
    plVar3 = (long *)(*param_1 + uVar9 * 8);
  }
  else {
    *plVar4 = *plVar3;
  }
  *plVar3 = (long)plVar4;
LAB_005163b4:
  param_1[3] = param_1[3] + 1;
  return plVar4;
}



// ========================================
// Function: FUN_005163f0
// Address: 005163f0
// ========================================

void FUN_005163f0(long *param_1,ulong param_2)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  ulong uVar4;
  long *plVar5;
  ulong uVar6;
  long *plVar7;
  ulong uVar8;
  undefined2 uVar9;
  undefined8 uVar10;
  
  if (param_2 == 0) {
    pvVar3 = (void *)*param_1;
    *param_1 = 0;
    if (pvVar3 != (void *)0x0) {
      free(pvVar3);
    }
    param_1[1] = 0;
  }
  else {
    if (param_2 >> 0x3d != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_0029fc3c();
    }
    lVar2 = FUN_005a5d4c(param_2 << 3);
    pvVar3 = (void *)*param_1;
    *param_1 = lVar2;
    if (pvVar3 != (void *)0x0) {
      free(pvVar3);
    }
    uVar4 = 0;
    param_1[1] = param_2;
    do {
      *(undefined8 *)(*param_1 + uVar4 * 8) = 0;
      uVar4 = uVar4 + 1;
    } while (param_2 != uVar4);
    plVar5 = (long *)param_1[2];
    if (plVar5 != (long *)0x0) {
      uVar4 = plVar5[1];
      uVar10 = CONCAT17(POPCOUNT((char)(param_2 >> 0x38)),
                        CONCAT16(POPCOUNT((char)(param_2 >> 0x30)),
                                 CONCAT15(POPCOUNT((char)(param_2 >> 0x28)),
                                          CONCAT14(POPCOUNT((char)(param_2 >> 0x20)),
                                                   CONCAT13(POPCOUNT((char)(param_2 >> 0x18)),
                                                            CONCAT12(POPCOUNT((char)(param_2 >> 0x10
                                                                                    )),
                                                                     CONCAT11(POPCOUNT((char)(
                                                  param_2 >> 8)),POPCOUNT((char)param_2))))))));
      uVar9 = NEON_uaddlv(uVar10,1);
      uVar6 = CONCAT62((int6)((ulong)uVar10 >> 0x10),uVar9) & 0xffffffff;
      if (uVar6 < 2) {
        uVar4 = uVar4 & param_2 - 1;
      }
      else if (param_2 <= uVar4) {
        uVar8 = 0;
        if (param_2 != 0) {
          uVar8 = uVar4 / param_2;
        }
        uVar4 = uVar4 - uVar8 * param_2;
      }
      *(long **)(*param_1 + uVar4 * 8) = param_1 + 2;
      plVar7 = (long *)*plVar5;
      if (plVar7 != (long *)0x0) {
        do {
          uVar8 = plVar7[1];
          if (uVar6 < 2) {
            uVar8 = uVar8 & param_2 - 1;
          }
          else if (param_2 <= uVar8) {
            uVar1 = 0;
            if (param_2 != 0) {
              uVar1 = uVar8 / param_2;
            }
            uVar8 = uVar8 - uVar1 * param_2;
          }
          if (uVar8 != uVar4) {
            if (*(long *)(*param_1 + uVar8 * 8) == 0) {
              *(long **)(*param_1 + uVar8 * 8) = plVar5;
              uVar4 = uVar8;
            }
            else {
              *plVar5 = *plVar7;
              *plVar7 = **(long **)(*param_1 + uVar8 * 8);
              **(undefined8 **)(*param_1 + uVar8 * 8) = plVar7;
              plVar7 = plVar5;
            }
          }
          plVar5 = plVar7;
          plVar7 = (long *)*plVar5;
        } while (plVar7 != (long *)0x0);
      }
    }
  }
  return;
}



// ========================================
// Function: FUN_0051654c
// Address: 0051654c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051654c(undefined8 param_1,byte *param_2,undefined8 param_3,byte *param_4,
                 undefined8 param_5)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
                    /* try { // try from 005165d8 to 00516643 has its CatchHandler @ 005166dc */
  local_1148 = auStack_1130;
  local_130 = local_118;
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_3,uVar6);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_5,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_5,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_00516704
// Address: 00516704
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516704(undefined8 param_1,undefined8 param_2,undefined8 *param_3,undefined8 param_4)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined8 uVar7;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 00516778 to 005167d7 has its CatchHandler @ 00516870 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar4);
  uVar7 = *param_3;
  uVar4 = __strlen_chk(uVar7,0xffffffffffffffff);
  FUN_0044c958(&local_1148,uVar7,uVar4);
  uVar4 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar4);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar6 = local_128 * 0x18;
    puVar5 = local_130;
    do {
      if ((undefined1 *)*puVar5 != auStack_1130) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar3;
  local_1140 = uVar2;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00516898
// Address: 00516898
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516898(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 00516900 to 00516923 has its CatchHandler @ 005169b8 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005169e0
// Address: 005169e0
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005169e0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  long lVar1;
  undefined8 *puVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 00516a5c to 00516a6f has its CatchHandler @ 00516b04 */
  uVar4 = _DAT_001a1320;
  uVar5 = _UNK_001a1328;
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_00516c4c(&local_1138,param_2,param_3,param_4,param_5,param_6,param_7,param_9,_DAT_001a1320,
               _UNK_001a1328);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar3 = local_118 * 0x18;
    puVar2 = local_120;
    do {
      if ((undefined1 *)*puVar2 != auStack_1120) {
        free((undefined1 *)*puVar2);
      }
      lVar3 = lVar3 + -0x18;
      puVar2 = puVar2 + 3;
    } while (lVar3 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  local_1138 = auStack_1120;
  local_1130 = uVar4;
  uStack_1128 = uVar5;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00516b2c
// Address: 00516b2c
// ========================================

void FUN_00516b2c(long param_1,char *param_2,undefined8 param_3,char *param_4,char *param_5,
                 byte *param_6,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1 + 0xc68,param_2,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_0044eb74(param_1 + 0xc68,param_3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1 + 0xc68,param_4,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_00516c4c
// Address: 00516c4c
// ========================================

void FUN_00516c4c(undefined8 param_1,char *param_2,undefined8 param_3,char *param_4,char *param_5,
                 byte *param_6,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  FUN_0044eb74(param_1,param_3);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1,param_7,sVar3);
  return;
}



// ========================================
// Function: FUN_00516d20
// Address: 00516d20
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516d20(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 00516d88 to 00516dab has its CatchHandler @ 00516e40 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00516e68
// Address: 00516e68
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516e68(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 00516edc to 00516f27 has its CatchHandler @ 00516fc0 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar4);
  FUN_0044eab0(&local_1148,param_3);
  uVar4 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar4);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar6 = local_128 * 0x18;
    puVar5 = local_130;
    do {
      if ((undefined1 *)*puVar5 != auStack_1130) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar3;
  local_1140 = uVar2;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00516fe8
// Address: 00516fe8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516fe8(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_70 = *(long *)(lVar3 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 00517070 to 005170cf has its CatchHandler @ 00517170 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1160,pbVar2,uVar1);
  FUN_0050a7e0(&local_1160,param_4,param_5,param_6,param_7,param_8);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar8 = local_140 * 0x18;
    puVar7 = local_148;
    do {
      if ((undefined1 *)*puVar7 != auStack_1148) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar5;
  local_1158 = uVar4;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar3 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051719c
// Address: 0051719c
// ========================================

void FUN_0051719c(long param_1,byte *param_2,char *param_3,byte *param_4,char *param_5,byte *param_6
                 ,char *param_7)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar3 = strlen(param_7);
  FUN_0044c958(param_1 + 0xc68,param_7,sVar3);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  return;
}



// ========================================
// Function: FUN_005172cc
// Address: 005172cc
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005172cc(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  long lVar1;
  undefined8 *puVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 00517344 to 00517357 has its CatchHandler @ 005173ec */
  uVar4 = _DAT_001a1320;
  uVar5 = _UNK_001a1328;
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_00517414(&local_1138,param_2,param_3,param_4,param_5,param_6,param_8,param_9,_DAT_001a1320,
               _UNK_001a1328);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar3 = local_118 * 0x18;
    puVar2 = local_120;
    do {
      if ((undefined1 *)*puVar2 != auStack_1120) {
        free((undefined1 *)*puVar2);
      }
      lVar3 = lVar3 + -0x18;
      puVar2 = puVar2 + 3;
    } while (lVar3 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  local_1138 = auStack_1120;
  local_1130 = uVar4;
  uStack_1128 = uVar5;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00517414
// Address: 00517414
// ========================================

void FUN_00517414(undefined8 param_1,char *param_2,byte *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_005174d8
// Address: 005174d8
// ========================================

void FUN_005174d8(undefined8 *param_1,undefined8 *param_2,long param_3,uint param_4)

{
  long lVar1;
  ulong uVar2;
  uint uVar3;
  undefined4 *puVar4;
  bool bVar5;
  ulong uVar6;
  undefined8 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  ulong uVar10;
  uint *puVar11;
  uint *puVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  undefined4 *puVar15;
  undefined4 uVar16;
  ulong uVar17;
  uint *puVar18;
  undefined8 *puVar19;
  long lVar20;
  ulong uVar21;
  ulong uVar22;
  long lVar23;
  uint *puVar24;
  uint *puVar25;
  uint uVar26;
  undefined4 uVar27;
  uint *puVar28;
  uint *puVar29;
  uint *puVar30;
  undefined8 uVar31;
  
LAB_00517504:
  puVar28 = (uint *)((long)param_2 + -4);
  puVar29 = (uint *)((long)param_2 + -0xc);
  puVar30 = (uint *)((long)param_2 + -0x14);
  puVar13 = param_1;
LAB_00517514:
  do {
    param_1 = puVar13;
    uVar10 = (long)param_2 - (long)param_1 >> 3;
    if (uVar10 - 2 == 0 || (long)uVar10 < 2) {
      if (uVar10 < 2) {
        return;
      }
      if (uVar10 == 2) {
        if (*(uint *)((long)param_1 + 4) <= *(uint *)((long)param_2 + -4)) {
          return;
        }
        uVar27 = *(undefined4 *)param_1;
        *(undefined4 *)param_1 = *(undefined4 *)(param_2 + -1);
        *(undefined4 *)(param_2 + -1) = uVar27;
        uVar27 = *(undefined4 *)((long)param_1 + 4);
        *(undefined4 *)((long)param_1 + 4) = *(undefined4 *)((long)param_2 + -4);
        *(undefined4 *)((long)param_2 + -4) = uVar27;
        return;
      }
    }
    else {
      if (uVar10 == 3) {
        puVar29 = (uint *)((long)param_1 + 4);
        uVar9 = *puVar29;
        puVar28 = (uint *)((long)param_1 + 0xc);
        uVar26 = *puVar28;
        puVar30 = (uint *)((long)param_2 + -4);
        if (uVar26 < uVar9) {
          uVar27 = *(undefined4 *)param_1;
          if (*puVar30 < uVar26) {
            *(undefined4 *)param_1 = *(undefined4 *)(param_2 + -1);
          }
          else {
            uVar16 = *(undefined4 *)(param_1 + 1);
            *(undefined4 *)(param_1 + 1) = uVar27;
            *(uint *)((long)param_1 + 0xc) = uVar9;
            *(undefined4 *)param_1 = uVar16;
            *(uint *)((long)param_1 + 4) = uVar26;
            if (uVar9 <= *puVar30) {
              return;
            }
            *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + -1);
            puVar29 = puVar28;
          }
          *(undefined4 *)(param_2 + -1) = uVar27;
          puVar28 = puVar30;
        }
        else {
          if (uVar26 <= *puVar30) {
            return;
          }
          uVar27 = *(undefined4 *)(param_1 + 1);
          *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + -1);
          *(undefined4 *)(param_2 + -1) = uVar27;
          uVar27 = *(undefined4 *)((long)param_1 + 0xc);
          *(undefined4 *)((long)param_1 + 0xc) = *(undefined4 *)((long)param_2 + -4);
          *(undefined4 *)((long)param_2 + -4) = uVar27;
          if (*(uint *)((long)param_1 + 4) <= *(uint *)((long)param_1 + 0xc)) {
            return;
          }
          uVar27 = *(undefined4 *)param_1;
          *(undefined4 *)param_1 = *(undefined4 *)(param_1 + 1);
          *(undefined4 *)(param_1 + 1) = uVar27;
        }
        uVar9 = *puVar29;
        *puVar29 = *puVar28;
        *puVar28 = uVar9;
        return;
      }
      if (uVar10 == 4) {
        FUN_0051837c(param_1,param_1 + 1,param_1 + 2,param_2 + -1);
        return;
      }
      if (uVar10 == 5) {
        FUN_0051837c(param_1,param_1 + 1,param_1 + 2,param_1 + 3);
        if (*(uint *)((long)param_1 + 0x1c) <= *(uint *)((long)param_2 + -4)) {
          return;
        }
        uVar27 = *(undefined4 *)(param_1 + 3);
        *(undefined4 *)(param_1 + 3) = *(undefined4 *)(param_2 + -1);
        *(undefined4 *)(param_2 + -1) = uVar27;
        uVar27 = *(undefined4 *)((long)param_1 + 0x1c);
        *(undefined4 *)((long)param_1 + 0x1c) = *(undefined4 *)((long)param_2 + -4);
        *(undefined4 *)((long)param_2 + -4) = uVar27;
        uVar9 = *(uint *)((long)param_1 + 0x1c);
        uVar26 = *(uint *)((long)param_1 + 0x14);
        if (uVar26 <= uVar9) {
          return;
        }
        uVar3 = *(uint *)((long)param_1 + 0xc);
        uVar27 = *(undefined4 *)(param_1 + 2);
        uVar16 = *(undefined4 *)(param_1 + 3);
        *(undefined4 *)(param_1 + 2) = uVar16;
        *(uint *)((long)param_1 + 0x14) = uVar9;
        *(undefined4 *)(param_1 + 3) = uVar27;
        *(uint *)((long)param_1 + 0x1c) = uVar26;
        if (uVar3 <= uVar9) {
          return;
        }
        uVar26 = *(uint *)((long)param_1 + 4);
        uVar27 = *(undefined4 *)(param_1 + 1);
        *(undefined4 *)(param_1 + 1) = uVar16;
        *(uint *)((long)param_1 + 0xc) = uVar9;
        *(undefined4 *)(param_1 + 2) = uVar27;
        *(uint *)((long)param_1 + 0x14) = uVar3;
        if (uVar26 <= uVar9) {
          return;
        }
        uVar27 = *(undefined4 *)param_1;
        *(undefined4 *)param_1 = uVar16;
        *(uint *)((long)param_1 + 4) = uVar9;
        *(undefined4 *)(param_1 + 1) = uVar27;
        *(uint *)((long)param_1 + 0xc) = uVar26;
        return;
      }
    }
    if ((long)uVar10 < 0x18) {
      puVar13 = param_1 + 1;
      if ((param_4 & 1) == 0) {
        if (param_1 == param_2 || puVar13 == param_2) {
          return;
        }
        puVar8 = (undefined4 *)((long)param_1 + 0xc);
        do {
          puVar7 = puVar13;
          if (*(uint *)((long)param_1 + 0xc) < *(uint *)((long)param_1 + 4)) {
            uVar31 = *puVar7;
            puVar4 = puVar8;
            do {
              puVar15 = puVar4;
              uVar9 = (uint)((ulong)uVar31 >> 0x20);
              puVar15[-1] = puVar15[-3];
              *puVar15 = puVar15[-2];
              puVar4 = puVar15 + -2;
            } while (uVar9 < (uint)puVar15[-4]);
            puVar15[-3] = (int)uVar31;
            puVar15[-2] = uVar9;
          }
          puVar8 = puVar8 + 2;
          puVar13 = puVar7 + 1;
          param_1 = puVar7;
        } while (puVar7 + 1 != param_2);
        return;
      }
      if (param_1 == param_2 || puVar13 == param_2) {
        return;
      }
      lVar23 = 0;
      puVar7 = param_1;
      break;
    }
    if (param_3 == 0) {
      if (param_1 == param_2) {
        return;
      }
      uVar6 = uVar10 - 2 >> 1;
      uVar17 = uVar6;
      goto LAB_00517d60;
    }
    uVar17 = uVar10 >> 1;
    uVar9 = *puVar28;
    puVar13 = param_1 + uVar17;
    if (uVar10 < 0x81) {
      puVar11 = (uint *)((long)param_1 + 4);
      uVar3 = *puVar11;
      puVar12 = puVar11 + uVar17 * 2;
      uVar26 = *puVar12;
      if (uVar3 < uVar26) {
        uVar27 = *(undefined4 *)puVar13;
        if (uVar9 < uVar3) {
          *(undefined4 *)puVar13 = *(undefined4 *)(param_2 + -1);
        }
        else {
          uVar16 = *(undefined4 *)param_1;
          *puVar12 = uVar3;
          *(undefined4 *)puVar13 = uVar16;
          *(undefined4 *)param_1 = uVar27;
          *(uint *)((long)param_1 + 4) = uVar26;
          if (uVar26 <= *puVar28) goto joined_r0x00517778;
          *(undefined4 *)param_1 = *(undefined4 *)(param_2 + -1);
          puVar12 = puVar11;
        }
        *(undefined4 *)(param_2 + -1) = uVar27;
        puVar11 = puVar28;
LAB_00517764:
        uVar9 = *puVar12;
        *puVar12 = *puVar11;
        *puVar11 = uVar9;
      }
      else if (uVar9 < uVar3) {
        uVar27 = *(undefined4 *)param_1;
        *(undefined4 *)param_1 = *(undefined4 *)(param_2 + -1);
        *(undefined4 *)(param_2 + -1) = uVar27;
        uVar27 = *(undefined4 *)((long)param_1 + 4);
        *(undefined4 *)((long)param_1 + 4) = *(undefined4 *)((long)param_2 + -4);
        *(undefined4 *)((long)param_2 + -4) = uVar27;
        if (*(uint *)((long)param_1 + 4) < *puVar12) {
          uVar27 = *(undefined4 *)puVar13;
          *(undefined4 *)puVar13 = *(undefined4 *)param_1;
          *(undefined4 *)param_1 = uVar27;
          goto LAB_00517764;
        }
      }
    }
    else {
      puVar11 = (uint *)((long)param_1 + 4);
      uVar3 = *puVar11;
      puVar12 = puVar11 + uVar17 * 2;
      uVar26 = *puVar12;
      if (uVar26 < uVar3) {
        uVar27 = *(undefined4 *)param_1;
        if (uVar9 < uVar26) {
          *(undefined4 *)param_1 = *(undefined4 *)(param_2 + -1);
        }
        else {
          *(undefined4 *)param_1 = *(undefined4 *)puVar13;
          *(uint *)((long)param_1 + 4) = uVar26;
          *(undefined4 *)puVar13 = uVar27;
          *puVar12 = uVar3;
          if (uVar3 <= *puVar28) goto LAB_005176ac;
          *(undefined4 *)puVar13 = *(undefined4 *)(param_2 + -1);
          puVar11 = puVar12;
        }
        *(undefined4 *)(param_2 + -1) = uVar27;
        puVar18 = puVar28;
LAB_0051769c:
        uVar9 = *puVar11;
        *puVar11 = *puVar18;
        *puVar18 = uVar9;
      }
      else if (uVar9 < uVar26) {
        uVar27 = *(undefined4 *)puVar13;
        *(undefined4 *)puVar13 = *(undefined4 *)(param_2 + -1);
        *(undefined4 *)(param_2 + -1) = uVar27;
        uVar9 = *puVar12;
        *puVar12 = *(uint *)((long)param_2 + -4);
        *(uint *)((long)param_2 + -4) = uVar9;
        if (*puVar12 < *puVar11) {
          uVar27 = *(undefined4 *)param_1;
          *(undefined4 *)param_1 = *(undefined4 *)puVar13;
          *(undefined4 *)puVar13 = uVar27;
          puVar18 = puVar12;
          goto LAB_0051769c;
        }
      }
LAB_005176ac:
      puVar11 = (uint *)((long)puVar13 + -4);
      uVar9 = *puVar11;
      puVar7 = puVar13 + -1;
      puVar18 = (uint *)((long)param_1 + 0xc);
      uVar26 = *puVar18;
      if (uVar9 < uVar26) {
        uVar27 = *(undefined4 *)(param_1 + 1);
        if (*puVar29 < uVar9) {
          *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + -2);
        }
        else {
          *(undefined4 *)(param_1 + 1) = *(undefined4 *)puVar7;
          *(uint *)((long)param_1 + 0xc) = uVar9;
          *(undefined4 *)puVar7 = uVar27;
          *puVar11 = uVar26;
          if (uVar26 <= *puVar29) goto LAB_005177c0;
          *(undefined4 *)puVar7 = *(undefined4 *)(param_2 + -2);
          puVar18 = puVar11;
        }
        *(undefined4 *)(param_2 + -2) = uVar27;
        puVar25 = puVar29;
LAB_005177b0:
        uVar9 = *puVar18;
        *puVar18 = *puVar25;
        *puVar25 = uVar9;
      }
      else if (*puVar29 < uVar9) {
        uVar27 = *(undefined4 *)puVar7;
        *(undefined4 *)puVar7 = *(undefined4 *)(param_2 + -2);
        *(undefined4 *)(param_2 + -2) = uVar27;
        uVar9 = *puVar11;
        *puVar11 = *(uint *)((long)param_2 + -0xc);
        *(uint *)((long)param_2 + -0xc) = uVar9;
        if (*puVar11 < *puVar18) {
          uVar27 = *(undefined4 *)(param_1 + 1);
          *(undefined4 *)(param_1 + 1) = *(undefined4 *)puVar7;
          *(undefined4 *)puVar7 = uVar27;
          puVar25 = puVar11;
          goto LAB_005177b0;
        }
      }
LAB_005177c0:
      puVar18 = (uint *)((long)puVar13 + 0xc);
      uVar9 = *puVar18;
      puVar14 = puVar13 + 1;
      puVar25 = (uint *)((long)param_1 + 0x14);
      uVar26 = *puVar25;
      if (uVar9 < uVar26) {
        uVar27 = *(undefined4 *)(param_1 + 2);
        if (*puVar30 < uVar9) {
          *(undefined4 *)(param_1 + 2) = *(undefined4 *)(param_2 + -3);
        }
        else {
          *(undefined4 *)(param_1 + 2) = *(undefined4 *)puVar14;
          *(uint *)((long)param_1 + 0x14) = uVar9;
          *(undefined4 *)puVar14 = uVar27;
          *puVar18 = uVar26;
          uVar9 = uVar26;
          if (uVar26 <= *puVar30) goto LAB_00517890;
          *(undefined4 *)puVar14 = *(undefined4 *)(param_2 + -3);
          puVar25 = puVar18;
        }
        *(undefined4 *)(param_2 + -3) = uVar27;
        puVar24 = puVar30;
LAB_0051787c:
        uVar9 = *puVar25;
        *puVar25 = *puVar24;
        *puVar24 = uVar9;
        uVar9 = *puVar18;
      }
      else if (*puVar30 < uVar9) {
        uVar27 = *(undefined4 *)puVar14;
        *(undefined4 *)puVar14 = *(undefined4 *)(param_2 + -3);
        *(undefined4 *)(param_2 + -3) = uVar27;
        uVar9 = *puVar18;
        *puVar18 = *(uint *)((long)param_2 + -0x14);
        *(uint *)((long)param_2 + -0x14) = uVar9;
        uVar9 = *puVar18;
        if (uVar9 < *puVar25) {
          uVar27 = *(undefined4 *)(param_1 + 2);
          *(undefined4 *)(param_1 + 2) = *(undefined4 *)puVar14;
          *(undefined4 *)puVar14 = uVar27;
          puVar24 = puVar18;
          goto LAB_0051787c;
        }
      }
LAB_00517890:
      uVar26 = *puVar12;
      uVar3 = *puVar11;
      if (uVar26 < uVar3) {
        uVar27 = *(undefined4 *)puVar7;
        if (uVar9 < uVar26) {
          uVar16 = *(undefined4 *)puVar14;
          *(undefined4 *)puVar14 = uVar27;
          *(undefined4 *)puVar7 = uVar16;
        }
        else {
          uVar16 = *(undefined4 *)puVar13;
          *(undefined4 *)puVar13 = uVar27;
          *puVar11 = uVar26;
          *(undefined4 *)puVar7 = uVar16;
          *puVar12 = uVar3;
          uVar26 = uVar3;
          if (uVar3 <= uVar9) goto LAB_00517934;
          uVar16 = *(undefined4 *)puVar14;
          *(undefined4 *)puVar14 = uVar27;
          *(undefined4 *)puVar13 = uVar16;
          puVar11 = puVar12;
        }
LAB_00517924:
        *puVar11 = uVar9;
        *puVar18 = uVar3;
        uVar26 = *puVar12;
        uVar27 = *(undefined4 *)puVar13;
      }
      else {
        uVar27 = *(undefined4 *)puVar13;
        if (uVar9 < uVar26) {
          uVar27 = *(undefined4 *)puVar14;
          *(undefined4 *)puVar14 = *(undefined4 *)puVar13;
          *puVar12 = uVar9;
          *(undefined4 *)puVar13 = uVar27;
          *puVar18 = uVar26;
          uVar26 = uVar9;
          if (uVar9 < uVar3) {
            uVar16 = *(undefined4 *)puVar7;
            *(undefined4 *)puVar7 = uVar27;
            *(undefined4 *)puVar13 = uVar16;
            puVar18 = puVar12;
            goto LAB_00517924;
          }
        }
      }
LAB_00517934:
      uVar31 = *param_1;
      *(undefined4 *)param_1 = uVar27;
      *(uint *)((long)param_1 + 4) = uVar26;
      *puVar13 = uVar31;
    }
joined_r0x00517778:
    if (((param_4 & 1) != 0) || (*(uint *)((long)param_1 - 4) < *(uint *)((long)param_1 + 4))) {
      param_3 = param_3 + -1;
      uVar31 = *param_1;
      lVar23 = 0;
      do {
        lVar1 = lVar23 + 8;
        lVar20 = lVar23 + 0xc;
        uVar9 = (uint)((ulong)uVar31 >> 0x20);
        lVar23 = lVar1;
      } while (*(uint *)((long)param_1 + lVar20) < uVar9);
      puVar7 = (undefined8 *)((long)param_1 + lVar1);
      puVar14 = param_2;
      if (lVar1 == 8) {
        do {
          if (puVar14 <= puVar7) break;
          puVar12 = (uint *)((long)puVar14 + -4);
          puVar14 = puVar14 + -1;
        } while (uVar9 <= *puVar12);
      }
      else {
        do {
          puVar12 = (uint *)((long)puVar14 + -4);
          puVar14 = puVar14 + -1;
        } while (uVar9 <= *puVar12);
      }
      puVar19 = puVar14;
      puVar13 = puVar7;
      if (puVar7 < puVar14) {
        do {
          uVar27 = *(undefined4 *)puVar13;
          *(undefined4 *)puVar13 = *(undefined4 *)puVar19;
          *(undefined4 *)puVar19 = uVar27;
          uVar27 = *(undefined4 *)((long)puVar13 + 4);
          *(undefined4 *)((long)puVar13 + 4) = *(undefined4 *)((long)puVar19 + 4);
          *(undefined4 *)((long)puVar19 + 4) = uVar27;
          do {
            puVar12 = (uint *)((long)puVar13 + 0xc);
            puVar13 = puVar13 + 1;
          } while (*puVar12 < uVar9);
          do {
            puVar12 = (uint *)((long)puVar19 + -4);
            puVar19 = puVar19 + -1;
          } while (uVar9 <= *puVar12);
        } while (puVar13 < puVar19);
      }
      puVar19 = puVar13 + -1;
      if (puVar19 != param_1) {
        *(undefined4 *)param_1 = *(undefined4 *)(puVar13 + -1);
        *(undefined4 *)((long)param_1 + 4) = *(undefined4 *)((long)puVar13 - 4);
      }
      *(int *)(puVar13 + -1) = (int)uVar31;
      *(uint *)((long)puVar13 - 4) = uVar9;
      if (puVar14 <= puVar7) {
        uVar10 = FUN_00518040(param_1,puVar19);
        uVar17 = FUN_00518040(puVar13,param_2);
        if ((uVar17 & 1) != 0) goto LAB_00517b84;
        if ((uVar10 & 1) != 0) goto LAB_00517514;
      }
      FUN_005174d8(param_1,puVar19,param_3,param_4 & 1);
      param_4 = 0;
      goto LAB_00517514;
    }
    uVar31 = *param_1;
    uVar9 = (uint)((ulong)uVar31 >> 0x20);
    puVar13 = param_1;
    puVar7 = param_1;
    if (uVar9 < *(uint *)((long)param_2 + -4)) {
      do {
        puVar12 = (uint *)((long)puVar13 + 0xc);
        puVar13 = puVar13 + 1;
      } while (*puVar12 <= uVar9);
    }
    else {
      do {
        puVar13 = puVar7 + 1;
        if (param_2 <= puVar13) break;
        puVar12 = (uint *)((long)puVar7 + 0xc);
        puVar7 = puVar13;
      } while (*puVar12 <= uVar9);
    }
    puVar7 = param_2;
    if (puVar13 < param_2) {
      do {
        puVar12 = (uint *)((long)puVar7 + -4);
        puVar7 = puVar7 + -1;
      } while (uVar9 < *puVar12);
    }
    while (puVar13 < puVar7) {
      uVar27 = *(undefined4 *)puVar13;
      *(undefined4 *)puVar13 = *(undefined4 *)puVar7;
      *(undefined4 *)puVar7 = uVar27;
      uVar27 = *(undefined4 *)((long)puVar13 + 4);
      *(undefined4 *)((long)puVar13 + 4) = *(undefined4 *)((long)puVar7 + 4);
      *(undefined4 *)((long)puVar7 + 4) = uVar27;
      do {
        puVar12 = (uint *)((long)puVar13 + 0xc);
        puVar13 = puVar13 + 1;
      } while (*puVar12 <= uVar9);
      do {
        puVar12 = (uint *)((long)puVar7 + -4);
        puVar7 = puVar7 + -1;
      } while (uVar9 < *puVar12);
    }
    if (puVar13 + -1 != param_1) {
      *(undefined4 *)param_1 = *(undefined4 *)(puVar13 + -1);
      *(undefined4 *)((long)param_1 + 4) = *(undefined4 *)((long)puVar13 + -4);
    }
    param_4 = 0;
    *(int *)(puVar13 + -1) = (int)uVar31;
    *(uint *)((long)puVar13 + -4) = uVar9;
    param_3 = param_3 + -1;
  } while( true );
LAB_00517cf4:
  puVar14 = puVar13;
  if (*(uint *)((long)puVar7 + 0xc) < *(uint *)((long)puVar7 + 4)) {
    uVar27 = *(undefined4 *)puVar14;
    uVar9 = *(uint *)((long)puVar14 + 4);
    lVar1 = lVar23;
    do {
      lVar20 = lVar1;
      puVar8 = (undefined4 *)((long)param_1 + lVar20);
      puVar8[2] = *puVar8;
      puVar8[3] = puVar8[1];
      puVar13 = param_1;
      if (lVar20 == 0) goto LAB_00517ce0;
      lVar1 = lVar20 + -8;
    } while (uVar9 < (uint)puVar8[-1]);
    puVar13 = (undefined8 *)((long)param_1 + lVar20);
LAB_00517ce0:
    *(undefined4 *)puVar13 = uVar27;
    *(uint *)((long)puVar13 + 4) = uVar9;
  }
  lVar23 = lVar23 + 8;
  puVar13 = puVar14 + 1;
  puVar7 = puVar14;
  if (puVar14 + 1 == param_2) {
    return;
  }
  goto LAB_00517cf4;
LAB_00517d60:
  do {
    if ((long)uVar17 <= (long)uVar6) {
      uVar22 = (uVar17 & 0x1fffffffffffffff) << 1 | 1;
      uVar2 = (uVar17 & 0x1fffffffffffffff) * 2 + 2;
      puVar13 = param_1 + uVar22;
      uVar21 = uVar22;
      if ((long)uVar2 < (long)uVar10) {
        bVar5 = *(uint *)((long)puVar13 + 4) < *(uint *)((long)puVar13 + 0xc);
        uVar21 = uVar2;
        if (!bVar5) {
          uVar21 = uVar22;
        }
        puVar13 = puVar13 + bVar5;
      }
      puVar7 = param_1 + uVar17;
      if (*(uint *)((long)puVar7 + 4) <= *(uint *)((long)puVar13 + 4)) {
        uVar27 = *(undefined4 *)puVar7;
        uVar9 = *(uint *)((long)puVar7 + 4);
        do {
          puVar14 = puVar13;
          *(undefined4 *)puVar7 = *(undefined4 *)puVar14;
          *(undefined4 *)((long)puVar7 + 4) = *(undefined4 *)((long)puVar14 + 4);
          if ((long)uVar6 < (long)uVar21) break;
          uVar22 = uVar21 << 1 | 1;
          uVar2 = uVar21 * 2 + 2;
          puVar13 = param_1 + uVar22;
          uVar21 = uVar22;
          if ((long)uVar2 < (long)uVar10) {
            bVar5 = *(uint *)((long)puVar13 + 4) < *(uint *)((long)puVar13 + 0xc);
            uVar21 = uVar2;
            if (!bVar5) {
              uVar21 = uVar22;
            }
            puVar13 = puVar13 + bVar5;
          }
          puVar7 = puVar14;
        } while (uVar9 <= *(uint *)((long)puVar13 + 4));
        *(undefined4 *)puVar14 = uVar27;
        *(uint *)((long)puVar14 + 4) = uVar9;
      }
    }
    bVar5 = 0 < (long)uVar17;
    uVar17 = uVar17 - 1;
  } while (bVar5);
  do {
    uVar31 = *param_1;
    puVar13 = param_1;
    uVar17 = 0;
    do {
      uVar2 = uVar17 << 1 | 1;
      uVar6 = uVar17 * 2 + 2;
      puVar7 = puVar13 + uVar17 + 1;
      uVar22 = uVar2;
      if (((long)uVar6 < (long)uVar10) &&
         (puVar7 = puVar13 + uVar17 + 2, uVar22 = uVar6,
         *(uint *)((long)puVar13 + uVar17 * 8 + 0x14) <= *(uint *)((long)puVar13 + uVar17 * 8 + 0xc)
         )) {
        puVar7 = puVar13 + uVar17 + 1;
        uVar22 = uVar2;
      }
      *(undefined4 *)puVar13 = *(undefined4 *)puVar7;
      *(undefined4 *)((long)puVar13 + 4) = *(undefined4 *)((long)puVar7 + 4);
      puVar13 = puVar7;
      uVar17 = uVar22;
    } while ((long)uVar22 <= (long)(uVar10 - 2 >> 1));
    uVar27 = (undefined4)uVar31;
    uVar16 = (undefined4)((ulong)uVar31 >> 0x20);
    if (puVar7 == param_2 + -1) {
      *(undefined4 *)puVar7 = uVar27;
      *(undefined4 *)((long)puVar7 + 4) = uVar16;
    }
    else {
      *(undefined4 *)puVar7 = *(undefined4 *)(param_2 + -1);
      lVar23 = (long)puVar7 + (8 - (long)param_1) >> 3;
      *(undefined4 *)((long)puVar7 + 4) = *(undefined4 *)((long)param_2 - 4);
      *(undefined4 *)(param_2 + -1) = uVar27;
      *(undefined4 *)((long)param_2 - 4) = uVar16;
      if ((1 < lVar23) &&
         (uVar17 = lVar23 - 2U >> 1,
         *(uint *)((long)param_1 + uVar17 * 8 + 4) < *(uint *)((long)puVar7 + 4))) {
        uVar27 = *(undefined4 *)puVar7;
        uVar9 = *(uint *)((long)puVar7 + 4);
        do {
          puVar13 = param_1 + uVar17;
          *(undefined4 *)puVar7 = *(undefined4 *)puVar13;
          *(uint *)((long)puVar7 + 4) = *(uint *)((long)puVar13 + 4U);
          if (uVar17 == 0) break;
          uVar17 = uVar17 - 1 >> 1;
          puVar7 = puVar13;
        } while (*(uint *)((long)param_1 + uVar17 * 8 + 4) < uVar9);
        *(undefined4 *)puVar13 = uVar27;
        *(uint *)((long)puVar13 + 4U) = uVar9;
      }
    }
    bVar5 = (long)uVar10 < 3;
    uVar10 = uVar10 - 1;
    param_2 = param_2 + -1;
    if (bVar5) {
      return;
    }
  } while( true );
LAB_00517b84:
  param_2 = puVar19;
  if ((uVar10 & 1) != 0) {
    return;
  }
  goto LAB_00517504;
}



// ========================================
// Function: FUN_00518040
// Address: 00518040
// ========================================

bool FUN_00518040(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  long lVar6;
  ulong uVar7;
  uint *puVar8;
  undefined4 *puVar9;
  uint *puVar10;
  long lVar11;
  uint *puVar12;
  undefined4 *puVar13;
  int iVar14;
  undefined4 *puVar15;
  long lVar16;
  
  uVar7 = (long)param_2 - (long)param_1 >> 3;
  if ((long)uVar7 < 3) {
    if (uVar7 < 2) {
      return true;
    }
    if (uVar7 == 2) {
      if ((uint)param_1[1] <= (uint)param_2[-1]) {
        return true;
      }
      uVar1 = *param_1;
      *param_1 = param_2[-2];
      param_2[-2] = uVar1;
      uVar1 = param_1[1];
      param_1[1] = param_2[-1];
      param_2[-1] = uVar1;
      return true;
    }
  }
  else {
    if (uVar7 == 3) {
      puVar10 = param_1 + 1;
      uVar3 = *puVar10;
      puVar8 = param_1 + 3;
      uVar4 = *puVar8;
      puVar12 = param_2 + -1;
      if (uVar4 < uVar3) {
        uVar1 = *param_1;
        if (*puVar12 < uVar4) {
          *param_1 = param_2[-2];
        }
        else {
          uVar2 = param_1[2];
          param_1[2] = uVar1;
          param_1[3] = uVar3;
          *param_1 = uVar2;
          param_1[1] = uVar4;
          if (uVar3 <= *puVar12) {
            return true;
          }
          param_1[2] = param_2[-2];
          puVar10 = puVar8;
        }
        param_2[-2] = uVar1;
        puVar8 = puVar12;
      }
      else {
        if (uVar4 <= *puVar12) {
          return true;
        }
        uVar1 = param_1[2];
        param_1[2] = param_2[-2];
        param_2[-2] = uVar1;
        uVar1 = param_1[3];
        param_1[3] = param_2[-1];
        param_2[-1] = uVar1;
        if ((uint)param_1[1] <= (uint)param_1[3]) {
          return true;
        }
        uVar1 = *param_1;
        *param_1 = param_1[2];
        param_1[2] = uVar1;
      }
      uVar3 = *puVar10;
      *puVar10 = *puVar8;
      *puVar8 = uVar3;
      return true;
    }
    if (uVar7 == 4) {
      FUN_0051837c(param_1,param_1 + 2,param_1 + 4,param_2 + -2);
      return true;
    }
    if (uVar7 == 5) {
      FUN_0051837c(param_1,param_1 + 2,param_1 + 4,param_1 + 6);
      if ((uint)param_1[7] <= (uint)param_2[-1]) {
        return true;
      }
      uVar1 = param_1[6];
      param_1[6] = param_2[-2];
      param_2[-2] = uVar1;
      uVar1 = param_1[7];
      param_1[7] = param_2[-1];
      param_2[-1] = uVar1;
      uVar3 = param_1[7];
      uVar4 = param_1[5];
      if (uVar4 <= uVar3) {
        return true;
      }
      uVar5 = param_1[3];
      uVar1 = param_1[4];
      uVar2 = param_1[6];
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      param_1[6] = uVar1;
      param_1[7] = uVar4;
      if (uVar5 <= uVar3) {
        return true;
      }
      uVar4 = param_1[1];
      uVar1 = param_1[2];
      param_1[2] = uVar2;
      param_1[3] = uVar3;
      param_1[4] = uVar1;
      param_1[5] = uVar5;
      if (uVar4 <= uVar3) {
        return true;
      }
      uVar1 = *param_1;
      *param_1 = uVar2;
      param_1[1] = uVar3;
      param_1[2] = uVar1;
      param_1[3] = uVar4;
      return true;
    }
  }
  puVar12 = param_1 + 1;
  uVar3 = *puVar12;
  puVar10 = param_1 + 3;
  uVar4 = *puVar10;
  puVar8 = param_1 + 5;
  uVar5 = *puVar8;
  if (uVar4 < uVar3) {
    uVar1 = *param_1;
    if (uVar5 < uVar4) {
      uVar2 = param_1[4];
      param_1[4] = uVar1;
      *param_1 = uVar2;
      puVar10 = puVar12;
    }
    else {
      uVar2 = param_1[2];
      param_1[2] = uVar1;
      param_1[3] = uVar3;
      *param_1 = uVar2;
      param_1[1] = uVar4;
      if (uVar3 <= uVar5) goto LAB_005182cc;
      uVar2 = param_1[4];
      param_1[4] = uVar1;
      param_1[2] = uVar2;
    }
  }
  else {
    if (uVar4 <= uVar5) goto LAB_005182cc;
    uVar1 = param_1[4];
    uVar2 = param_1[2];
    param_1[2] = uVar1;
    param_1[3] = uVar5;
    param_1[4] = uVar2;
    param_1[5] = uVar4;
    if (uVar3 <= uVar5) goto LAB_005182cc;
    uVar2 = *param_1;
    *param_1 = uVar1;
    param_1[2] = uVar2;
    puVar8 = puVar10;
    puVar10 = puVar12;
  }
  *puVar10 = uVar5;
  *puVar8 = uVar3;
LAB_005182cc:
  if (param_1 + 6 != param_2) {
    lVar11 = 0;
    iVar14 = 0;
    puVar15 = param_1 + 6;
    puVar13 = param_1 + 4;
    do {
      puVar9 = puVar15;
      if ((uint)puVar9[1] < (uint)puVar13[1]) {
        uVar1 = *puVar9;
        uVar3 = puVar9[1];
        lVar6 = lVar11;
        do {
          lVar16 = lVar6;
          *(undefined4 *)((long)param_1 + lVar16 + 0x18) =
               *(undefined4 *)((long)param_1 + lVar16 + 0x10);
          *(undefined4 *)((long)param_1 + lVar16 + 0x1c) =
               *(undefined4 *)((long)param_1 + lVar16 + 0x14);
          puVar15 = param_1;
          if (lVar16 == -0x10) goto LAB_005182ec;
          lVar6 = lVar16 + -8;
        } while (uVar3 < *(uint *)((long)param_1 + lVar16 + 0xc));
        puVar15 = (undefined4 *)((long)param_1 + lVar16 + 0x10);
LAB_005182ec:
        iVar14 = iVar14 + 1;
        *puVar15 = uVar1;
        puVar15[1] = uVar3;
        if (iVar14 == 8) {
          return puVar9 + 2 == param_2;
        }
      }
      lVar11 = lVar11 + 8;
      puVar15 = puVar9 + 2;
      puVar13 = puVar9;
    } while (puVar9 + 2 != param_2);
  }
  return true;
}



// ========================================
// Function: FUN_0051837c
// Address: 0051837c
// ========================================

void FUN_0051837c(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint *puVar5;
  uint uVar6;
  uint *puVar7;
  uint *puVar8;
  
  puVar4 = param_2 + 1;
  uVar2 = *puVar4;
  puVar3 = param_1 + 1;
  puVar5 = param_3 + 1;
  uVar6 = *puVar5;
  puVar7 = puVar3;
  if (uVar2 < *puVar3) {
    uVar1 = *param_1;
    puVar8 = puVar5;
    if (uVar6 < uVar2) {
      *param_1 = *param_3;
      *param_3 = uVar1;
    }
    else {
      *param_1 = *param_2;
      *param_2 = uVar1;
      uVar2 = param_1[1];
      param_1[1] = param_2[1];
      param_2[1] = uVar2;
      uVar6 = *puVar5;
      if (uVar2 <= uVar6) goto LAB_00518464;
      uVar1 = *param_2;
      *param_2 = *param_3;
      *param_3 = uVar1;
      puVar7 = puVar4;
    }
  }
  else {
    if (uVar2 <= uVar6) goto LAB_00518464;
    uVar1 = *param_2;
    *param_2 = *param_3;
    *param_3 = uVar1;
    uVar6 = param_2[1];
    param_2[1] = param_3[1];
    param_3[1] = uVar6;
    if (*puVar3 <= (uint)param_2[1]) goto LAB_00518464;
    uVar1 = *param_1;
    *param_1 = *param_2;
    *param_2 = uVar1;
    puVar8 = puVar4;
  }
  uVar6 = *puVar7;
  *puVar7 = *puVar8;
  *puVar8 = uVar6;
  uVar6 = *puVar5;
LAB_00518464:
  if ((uint)param_4[1] < uVar6) {
    uVar1 = *param_3;
    *param_3 = *param_4;
    *param_4 = uVar1;
    uVar1 = param_3[1];
    param_3[1] = param_4[1];
    param_4[1] = uVar1;
    if ((uint)param_3[1] < *puVar4) {
      uVar1 = *param_2;
      *param_2 = *param_3;
      *param_3 = uVar1;
      uVar1 = param_2[1];
      param_2[1] = param_3[1];
      param_3[1] = uVar1;
      if ((uint)param_2[1] < *puVar3) {
        uVar1 = *param_1;
        *param_1 = *param_2;
        *param_2 = uVar1;
        uVar1 = param_1[1];
        param_1[1] = param_2[1];
        param_2[1] = uVar1;
      }
    }
  }
  return;
}



// ========================================
// Function: FUN_005184f4
// Address: 005184f4
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005184f4(long param_1,undefined8 *param_2,undefined4 *param_3,undefined1 *param_4)

{
  long lVar1;
  long lVar2;
  undefined4 uVar3;
  undefined1 uVar4;
  undefined1 uVar5;
  uint uVar6;
  long lVar7;
  undefined *puVar8;
  long *plVar9;
  void *pvVar10;
  long lVar11;
  long lVar12;
  ulong uVar13;
  void *pvVar14;
  undefined7 local_68;
  undefined1 uStack_61;
  
  lVar7 = tpidr_el0;
  lVar11 = *(long *)(lVar7 + 0x28);
  lVar12 = *(long *)(param_1 + 0x10);
  if (lVar12 == 0) {
    uVar6 = *(int *)(param_1 + 0x80) << (ulong)(*(uint *)(param_1 + 0x30) & 0x1f);
    uVar13 = (ulong)uVar6;
    pvVar10 = malloc(uVar13 * 0x120);
    if (pvVar10 == (void *)0x0) goto LAB_005185d4;
    FUN_004517fc(param_1 + 8,uVar13);
    if (uVar6 != 0) {
      lVar12 = *(long *)(param_1 + 0x10);
      pvVar14 = pvVar10;
      do {
        FUN_004517fc(param_1 + 8,lVar12 + 1);
        lVar12 = *(long *)(param_1 + 0x10);
        uVar13 = uVar13 - 1;
        *(void **)(*(long *)(param_1 + 8) + lVar12 * 8) = pvVar14;
        lVar12 = lVar12 + 1;
        pvVar14 = (void *)((long)pvVar14 + 0x120);
        *(long *)(param_1 + 0x10) = lVar12;
      } while (uVar13 != 0);
    }
    FUN_004518ec(param_1 + 0x28,*(long *)(param_1 + 0x30) + 1);
    lVar1 = *(long *)(param_1 + 8);
    lVar12 = *(long *)(param_1 + 0x10);
    lVar2 = *(long *)(param_1 + 0x30);
    *(void **)(*(long *)(param_1 + 0x28) + lVar2 * 8) = pvVar10;
    plVar9 = *(long **)(lVar1 + lVar12 * 8 + -8);
    *(long *)(param_1 + 0x30) = lVar2 + 1;
    if (lVar12 != 0) goto LAB_00518534;
  }
  else {
    plVar9 = *(long **)(*(long *)(param_1 + 8) + lVar12 * 8 + -8);
LAB_00518534:
    *(long *)(param_1 + 0x10) = lVar12 + -1;
  }
  lVar12 = param_2[1];
  lVar1 = param_2[2];
  param_2[2] = 0;
  puVar8 = PTR_DAT_005c61a8;
  local_68 = (undefined7)*(undefined8 *)((long)param_2 + 1);
  uStack_61 = (undefined1)lVar12;
  uVar4 = *(undefined1 *)param_2;
  *param_2 = 0;
  param_2[1] = 0;
  uVar3 = *param_3;
  *(undefined4 *)(plVar9 + 0x23) = 0;
  *plVar9 = (long)(puVar8 + 0x10);
  uVar5 = *param_4;
  plVar9[1] = 0;
  *(undefined1 *)(plVar9 + 2) = uVar4;
  *(undefined1 *)(plVar9 + 6) = uVar5;
  plVar9[7] = (long)(plVar9 + 10);
  plVar9[8] = 0;
  *(ulong *)((long)plVar9 + 0x11) = CONCAT17(uStack_61,local_68);
  plVar9[3] = lVar12;
  plVar9[4] = lVar1;
  plVar9[9] = 8;
  lVar1 = _UNK_001a0d48;
  lVar12 = _DAT_001a0d40;
  plVar9[0xe] = (long)(plVar9 + 0x11);
  plVar9[0x15] = (long)(plVar9 + 0x18);
  *(undefined4 *)(plVar9 + 5) = uVar3;
  *(undefined4 *)((long)plVar9 + 0x2c) = 0;
  *(undefined4 *)((long)plVar9 + 0x31) = 0;
  plVar9[0x10] = lVar1;
  plVar9[0xf] = lVar12;
  plVar9[0x17] = lVar1;
  plVar9[0x16] = lVar12;
  plVar9[0x1c] = (long)(plVar9 + 0x1f);
  plVar9[0x1e] = lVar1;
  plVar9[0x1d] = lVar12;
LAB_005185d4:
  if (*(long *)(lVar7 + 0x28) != lVar11) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_005186b0
// Address: 005186b0
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005186b0(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 00518718 to 0051873b has its CatchHandler @ 005187d0 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005187f8
// Address: 005187f8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005187f8(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 00518860 to 00518883 has its CatchHandler @ 00518918 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00518940
// Address: 00518940
// ========================================

void FUN_00518940(long *param_1,ulong param_2)

{
  long lVar1;
  long *plVar2;
  long *__ptr;
  ulong uVar3;
  ulong uVar4;
  long lVar5;
  long lVar6;
  
  if (param_2 >> 0x3d != 0) {
LAB_0051899c:
                    /* WARNING: Subroutine does not return */
    FUN_0058bdd0();
  }
  uVar3 = param_1[2];
  if (uVar3 < param_2) {
    if (uVar3 < 9) {
      uVar3 = 8;
    }
    do {
      uVar4 = uVar3;
      uVar3 = uVar4 << 1;
    } while (uVar4 < param_2);
    if (uVar4 < 9) {
      plVar2 = param_1 + 3;
    }
    else {
      plVar2 = (long *)malloc(uVar4 << 3);
      if (plVar2 == (long *)0x0) goto LAB_0051899c;
    }
    __ptr = plVar2;
    if ((plVar2 != (long *)*param_1) && (lVar5 = param_1[1], __ptr = (long *)*param_1, lVar5 != 0))
    {
      lVar6 = 0;
      do {
        lVar1 = lVar6 + 1;
        plVar2[lVar6] = *(long *)(*param_1 + lVar6 * 8);
        lVar6 = lVar1;
      } while (lVar5 != lVar1);
      __ptr = (long *)*param_1;
    }
    if (__ptr != param_1 + 3) {
      free(__ptr);
    }
    *param_1 = (long)plVar2;
    param_1[2] = uVar4;
  }
  return;
}



// ========================================
// Function: FUN_00518a10
// Address: 00518a10
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00518a10(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 00518a84 to 00518acf has its CatchHandler @ 00518b68 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar4);
  FUN_0044eab0(&local_1148,param_3);
  uVar4 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar4);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar6 = local_128 * 0x18;
    puVar5 = local_130;
    do {
      if ((undefined1 *)*puVar5 != auStack_1130) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar3;
  local_1140 = uVar2;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00518b90
// Address: 00518b90
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

long * FUN_00518b90(long *param_1,uint *param_2,undefined8 param_3,undefined8 *param_4)

{
  uint uVar1;
  undefined4 uVar2;
  ulong uVar3;
  long lVar4;
  long *plVar5;
  undefined8 uVar6;
  long lVar7;
  long *plVar8;
  long lVar9;
  undefined8 *puVar10;
  long lVar11;
  ulong uVar12;
  long lVar13;
  long *plVar14;
  long *plVar15;
  long *plVar16;
  long *plVar17;
  long *plVar18;
  long *unaff_x26;
  undefined2 uVar19;
  float fVar20;
  
  lVar4 = tpidr_el0;
  lVar7 = *(long *)(lVar4 + 0x28);
  plVar18 = (long *)param_1[1];
  uVar1 = *param_2;
  plVar17 = (long *)(ulong)uVar1;
  if (plVar18 != (long *)0x0) {
    uVar6 = CONCAT17(POPCOUNT((char)((ulong)plVar18 >> 0x38)),
                     CONCAT16(POPCOUNT((char)((ulong)plVar18 >> 0x30)),
                              CONCAT15(POPCOUNT((char)((ulong)plVar18 >> 0x28)),
                                       CONCAT14(POPCOUNT((char)((ulong)plVar18 >> 0x20)),
                                                CONCAT13(POPCOUNT((char)((ulong)plVar18 >> 0x18)),
                                                         CONCAT12(POPCOUNT((char)((ulong)plVar18 >>
                                                                                 0x10)),
                                                                  CONCAT11(POPCOUNT((char)((ulong)
                                                  plVar18 >> 8)),POPCOUNT((char)plVar18))))))));
    uVar19 = NEON_uaddlv(uVar6,1);
    uVar12 = CONCAT62((int6)((ulong)uVar6 >> 0x10),uVar19) & 0xffffffff;
    if (uVar12 < 2) {
      unaff_x26 = (long *)(ulong)((int)plVar18 - 1U & uVar1);
    }
    else {
      unaff_x26 = plVar17;
      if (plVar18 <= plVar17) {
        uVar3 = 0;
        if (plVar18 != (long *)0x0) {
          uVar3 = (ulong)plVar17 / (ulong)plVar18;
        }
        unaff_x26 = (long *)((long)plVar17 - uVar3 * (long)plVar18);
      }
    }
    puVar10 = *(undefined8 **)(*param_1 + (long)unaff_x26 * 8);
    if ((puVar10 != (undefined8 *)0x0) && (plVar16 = (long *)*puVar10, plVar16 != (long *)0x0)) {
      do {
        plVar14 = (long *)plVar16[1];
        if (plVar14 == plVar17) {
          if (*(uint *)(plVar16 + 2) == uVar1) {
            uVar6 = 0;
            goto LAB_00518e60;
          }
        }
        else {
          if (uVar12 < 2) {
            plVar14 = (long *)((ulong)plVar14 & (long)plVar18 - 1U);
          }
          else if (plVar18 <= plVar14) {
            uVar3 = 0;
            if (plVar18 != (long *)0x0) {
              uVar3 = (ulong)plVar14 / (ulong)plVar18;
            }
            plVar14 = (long *)((long)plVar14 - uVar3 * (long)plVar18);
          }
          if (plVar14 != unaff_x26) break;
        }
        plVar16 = (long *)*plVar16;
      } while (plVar16 != (long *)0x0);
    }
  }
  plVar14 = param_1 + 2;
  plVar16 = (long *)FUN_005a5d4c(0x70);
  lVar9 = _UNK_001a0d48;
  lVar13 = _DAT_001a0d40;
  lVar11 = param_1[3];
  uVar2 = *(undefined4 *)*param_4;
  *plVar16 = 0;
  plVar16[1] = (long)plVar17;
  plVar16[5] = lVar9;
  plVar16[4] = lVar13;
  fVar20 = *(float *)(param_1 + 4);
  *(undefined4 *)(plVar16 + 2) = uVar2;
  plVar16[3] = (long)(plVar16 + 6);
  plVar5 = plVar16;
  if ((plVar18 == (long *)0x0) || (fVar20 * (float)plVar18 < (float)(lVar11 + 1))) {
    if (plVar18 < (long *)0x3) {
      uVar12 = 1;
    }
    else {
      uVar12 = (ulong)(((ulong)plVar18 & (long)plVar18 - 1U) != 0);
    }
    plVar8 = (long *)(uVar12 | (long)plVar18 << 1);
    plVar15 = (long *)(long)((float)(lVar11 + 1) / fVar20);
    if (plVar8 <= plVar15) {
      plVar8 = plVar15;
    }
    if ((long)plVar8 - 1U == 0) {
      plVar8 = (long *)0x2;
    }
    else if (((ulong)plVar8 & (long)plVar8 - 1U) != 0) {
                    /* try { // try from 00518d24 to 00518daf has its CatchHandler @ 00518e90 */
      plVar5 = (long *)FUN_0055fe2c(plVar8);
      plVar18 = (long *)param_1[1];
      plVar8 = plVar5;
    }
    if (plVar18 < plVar8) {
LAB_00518d3c:
      plVar5 = (long *)FUN_00518f0c(param_1,plVar8);
    }
    else if (plVar8 < plVar18) {
      plVar5 = (long *)(long)((float)(ulong)param_1[3] / *(float *)(param_1 + 4));
      if ((plVar18 < (long *)0x3) ||
         (uVar6 = CONCAT17(POPCOUNT((char)((ulong)plVar18 >> 0x38)),
                           CONCAT16(POPCOUNT((char)((ulong)plVar18 >> 0x30)),
                                    CONCAT15(POPCOUNT((char)((ulong)plVar18 >> 0x28)),
                                             CONCAT14(POPCOUNT((char)((ulong)plVar18 >> 0x20)),
                                                      CONCAT13(POPCOUNT((char)((ulong)plVar18 >>
                                                                              0x18)),
                                                               CONCAT12(POPCOUNT((char)((ulong)
                                                  plVar18 >> 0x10)),
                                                  CONCAT11(POPCOUNT((char)((ulong)plVar18 >> 8)),
                                                           POPCOUNT((char)plVar18)))))))),
         uVar19 = NEON_uaddlv(uVar6,1),
         1 < (CONCAT62((int6)((ulong)uVar6 >> 0x10),uVar19) & 0xffffffff))) {
        plVar5 = (long *)FUN_0055fe2c();
      }
      else if ((long *)0x1 < plVar5) {
        plVar5 = (long *)(1L << (-LZCOUNT((long)plVar5 + -1) & 0x3fU));
      }
      if (plVar8 <= plVar5) {
        plVar8 = plVar5;
      }
      if (plVar8 < plVar18) goto LAB_00518d3c;
    }
    plVar18 = (long *)param_1[1];
    if (((ulong)plVar18 & (long)plVar18 - 1U) == 0) {
      unaff_x26 = (long *)(ulong)((int)plVar18 - 1U & uVar1);
    }
    else {
      unaff_x26 = plVar17;
      if (plVar18 <= plVar17) {
        uVar12 = 0;
        if (plVar18 != (long *)0x0) {
          uVar12 = (ulong)plVar17 / (ulong)plVar18;
        }
        unaff_x26 = (long *)((long)plVar17 - uVar12 * (long)plVar18);
      }
    }
  }
  lVar13 = *param_1;
  plVar17 = *(long **)(lVar13 + (long)unaff_x26 * 8);
  if (plVar17 == (long *)0x0) {
    lVar9 = *plVar14;
    *plVar14 = (long)plVar16;
    *plVar16 = lVar9;
    *(long **)(lVar13 + (long)unaff_x26 * 8) = plVar14;
    if (*plVar16 == 0) goto LAB_00518e50;
    plVar17 = *(long **)(*plVar16 + 8);
    if (((ulong)plVar18 & (long)plVar18 - 1U) == 0) {
      plVar17 = (long *)((ulong)plVar17 & (long)plVar18 - 1U);
    }
    else if (plVar18 <= plVar17) {
      uVar12 = 0;
      if (plVar18 != (long *)0x0) {
        uVar12 = (ulong)plVar17 / (ulong)plVar18;
      }
      plVar17 = (long *)((long)plVar17 - uVar12 * (long)plVar18);
    }
    plVar17 = (long *)(*param_1 + (long)plVar17 * 8);
  }
  else {
    *plVar16 = *plVar17;
  }
  *plVar17 = (long)plVar16;
LAB_00518e50:
  uVar6 = 1;
  param_1[3] = param_1[3] + 1;
  param_1 = plVar5;
LAB_00518e60:
  if (*(long *)(lVar4 + 0x28) == lVar7) {
    return plVar16;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(param_1,uVar6);
}



// ========================================
// Function: FUN_00518eb8
// Address: 00518eb8
// ========================================

void FUN_00518eb8(undefined8 *param_1)

{
  void *__ptr;
  
  __ptr = (void *)*param_1;
  *param_1 = 0;
  if (__ptr != (void *)0x0) {
    if (*(char *)(param_1 + 2) != '\0') {
      *(undefined8 *)((long)__ptr + 0x20) = 0;
      if (*(void **)((long)__ptr + 0x18) != (void *)((long)__ptr + 0x30)) {
        free(*(void **)((long)__ptr + 0x18));
      }
    }
    free(__ptr);
    return;
  }
  return;
}



// ========================================
// Function: FUN_00518f0c
// Address: 00518f0c
// ========================================

void FUN_00518f0c(long *param_1,ulong param_2)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  ulong uVar4;
  long *plVar5;
  ulong uVar6;
  long *plVar7;
  ulong uVar8;
  undefined2 uVar9;
  undefined8 uVar10;
  
  if (param_2 == 0) {
    pvVar3 = (void *)*param_1;
    *param_1 = 0;
    if (pvVar3 != (void *)0x0) {
      free(pvVar3);
    }
    param_1[1] = 0;
  }
  else {
    if (param_2 >> 0x3d != 0) {
                    /* WARNING: Subroutine does not return */
      FUN_0029fc3c();
    }
    lVar2 = FUN_005a5d4c(param_2 << 3);
    pvVar3 = (void *)*param_1;
    *param_1 = lVar2;
    if (pvVar3 != (void *)0x0) {
      free(pvVar3);
    }
    uVar4 = 0;
    param_1[1] = param_2;
    do {
      *(undefined8 *)(*param_1 + uVar4 * 8) = 0;
      uVar4 = uVar4 + 1;
    } while (param_2 != uVar4);
    plVar5 = (long *)param_1[2];
    if (plVar5 != (long *)0x0) {
      uVar4 = plVar5[1];
      uVar10 = CONCAT17(POPCOUNT((char)(param_2 >> 0x38)),
                        CONCAT16(POPCOUNT((char)(param_2 >> 0x30)),
                                 CONCAT15(POPCOUNT((char)(param_2 >> 0x28)),
                                          CONCAT14(POPCOUNT((char)(param_2 >> 0x20)),
                                                   CONCAT13(POPCOUNT((char)(param_2 >> 0x18)),
                                                            CONCAT12(POPCOUNT((char)(param_2 >> 0x10
                                                                                    )),
                                                                     CONCAT11(POPCOUNT((char)(
                                                  param_2 >> 8)),POPCOUNT((char)param_2))))))));
      uVar9 = NEON_uaddlv(uVar10,1);
      uVar6 = CONCAT62((int6)((ulong)uVar10 >> 0x10),uVar9) & 0xffffffff;
      if (uVar6 < 2) {
        uVar4 = uVar4 & param_2 - 1;
      }
      else if (param_2 <= uVar4) {
        uVar8 = 0;
        if (param_2 != 0) {
          uVar8 = uVar4 / param_2;
        }
        uVar4 = uVar4 - uVar8 * param_2;
      }
      *(long **)(*param_1 + uVar4 * 8) = param_1 + 2;
      plVar7 = (long *)*plVar5;
      if (plVar7 != (long *)0x0) {
        do {
          uVar8 = plVar7[1];
          if (uVar6 < 2) {
            uVar8 = uVar8 & param_2 - 1;
          }
          else if (param_2 <= uVar8) {
            uVar1 = 0;
            if (param_2 != 0) {
              uVar1 = uVar8 / param_2;
            }
            uVar8 = uVar8 - uVar1 * param_2;
          }
          if (uVar8 != uVar4) {
            if (*(long *)(*param_1 + uVar8 * 8) == 0) {
              *(long **)(*param_1 + uVar8 * 8) = plVar5;
              uVar4 = uVar8;
            }
            else {
              *plVar5 = *plVar7;
              *plVar7 = **(long **)(*param_1 + uVar8 * 8);
              **(undefined8 **)(*param_1 + uVar8 * 8) = plVar7;
              plVar7 = plVar5;
            }
          }
          plVar5 = plVar7;
          plVar7 = (long *)*plVar5;
        } while (plVar7 != (long *)0x0);
      }
    }
  }
  return;
}



// ========================================
// Function: FUN_00519068
// Address: 00519068
// ========================================

void FUN_00519068(undefined8 *param_1,ulong param_2)

{
  ulong uVar1;
  undefined8 *puVar2;
  undefined8 *__ptr;
  ulong uVar3;
  ulong uVar4;
  
  if (param_2 >> 0x3d != 0) {
LAB_005190c4:
                    /* WARNING: Subroutine does not return */
    FUN_0058bdd0();
  }
  uVar3 = param_1[2];
  if (uVar3 < param_2) {
    if (uVar3 < 9) {
      uVar3 = 8;
    }
    do {
      uVar4 = uVar3;
      uVar3 = uVar4 << 1;
    } while (uVar4 < param_2);
    if (uVar4 < 9) {
      puVar2 = param_1 + 3;
    }
    else {
      puVar2 = (undefined8 *)malloc(uVar4 << 3);
      if (puVar2 == (undefined8 *)0x0) goto LAB_005190c4;
    }
    __ptr = (undefined8 *)*param_1;
    if ((puVar2 != __ptr) && (param_1[1] != 0)) {
      uVar3 = 0;
      do {
        uVar1 = uVar3 + 1;
        puVar2[uVar3] = __ptr[uVar3];
        uVar3 = uVar1;
      } while (uVar1 < (ulong)param_1[1]);
    }
    if (__ptr != param_1 + 3) {
      free(__ptr);
    }
    *param_1 = puVar2;
    param_1[2] = uVar4;
  }
  return;
}



// ========================================
// Function: FUN_00519128
// Address: 00519128
// ========================================

void FUN_00519128(long *param_1,long *param_2,undefined4 *param_3,undefined4 *param_4)

{
  size_t __n;
  undefined8 *puVar1;
  long *plVar2;
  long *plVar3;
  long *plVar4;
  long *plVar6;
  long *plVar7;
  undefined4 *puVar8;
  long *plVar9;
  long lVar10;
  long lVar11;
  ulong uVar12;
  ulong uVar13;
  ulong uVar14;
  ulong uVar15;
  undefined4 *puVar16;
  undefined8 *puVar17;
  long *plVar18;
  undefined8 *puVar19;
  ulong uVar20;
  long lVar21;
  long lVar22;
  undefined8 uVar23;
  undefined8 uVar24;
  long lVar25;
  undefined8 uVar26;
  long *plVar5;
  
  plVar18 = (long *)*param_1;
  lVar21 = param_1[1];
  lVar22 = (long)param_4 - (long)param_3;
  uVar20 = lVar22 >> 2;
  plVar3 = (long *)((long)plVar18 + lVar21 * 4);
  uVar14 = lVar21 + uVar20;
  if (plVar3 == param_2) {
    FUN_00448aa4(param_1,uVar14);
    lVar21 = param_1[1];
    if (param_4 != param_3) {
      lVar22 = *param_1;
      uVar14 = uVar20;
      if (uVar20 < 2) {
        uVar14 = 1;
      }
      if ((uVar20 < 8) || (lVar10 = lVar21 * 4 + lVar22, (ulong)(lVar10 - (long)param_3) < 0x20)) {
        uVar12 = 0;
      }
      else {
        uVar12 = uVar14 & 0xfffffffffffffff8;
        puVar17 = (undefined8 *)(lVar10 + 0x10);
        puVar19 = (undefined8 *)(param_3 + 4);
        param_3 = param_3 + uVar12;
        uVar13 = uVar12;
        do {
          puVar1 = puVar19 + -1;
          uVar23 = puVar19[-2];
          uVar26 = puVar19[1];
          uVar24 = *puVar19;
          uVar13 = uVar13 - 8;
          puVar19 = puVar19 + 4;
          puVar17[-1] = *puVar1;
          puVar17[-2] = uVar23;
          puVar17[1] = uVar26;
          *puVar17 = uVar24;
          puVar17 = puVar17 + 4;
        } while (uVar13 != 0);
        if (uVar14 == uVar12) goto LAB_00519518;
      }
      lVar10 = uVar14 - uVar12;
      puVar8 = (undefined4 *)(lVar22 + uVar12 * 4 + lVar21 * 4);
      do {
        lVar10 = lVar10 + -1;
        *puVar8 = *param_3;
        param_3 = param_3 + 1;
        puVar8 = puVar8 + 1;
      } while (lVar10 != 0);
    }
    goto LAB_00519518;
  }
  if (uVar14 <= (ulong)param_1[2]) {
    lVar22 = (long)plVar3 + lVar22;
    if (param_4 != param_3) {
      lVar10 = 0;
      do {
        lVar11 = lVar10 + -4;
        *(int *)(lVar22 + lVar10 + -4) = (int)*(long *)(lVar11 + (long)plVar3);
        if ((long)param_3 + (4 - (long)param_4) == lVar10) break;
        lVar10 = lVar11;
      } while ((long *)(lVar11 + (long)plVar3) != param_2);
      plVar3 = (long *)((long)plVar3 + lVar11);
      lVar22 = lVar22 + lVar11;
    }
    __n = (long)plVar3 - (long)param_2;
    if (__n != 0) {
      memmove((void *)(lVar22 - __n),param_2,__n);
      plVar18 = (long *)*param_1;
      lVar21 = param_1[1];
    }
    plVar18 = (long *)((long)plVar18 + lVar21 * 4);
    if ((plVar18 != param_2) && (plVar3 = param_2, puVar8 = param_3, param_4 != param_3)) {
      do {
        param_3 = puVar8 + 1;
        param_2 = (long *)((long)plVar3 + 4);
        *(undefined4 *)plVar3 = *puVar8;
        if (param_2 == plVar18) break;
        plVar3 = param_2;
        puVar8 = param_3;
      } while (param_3 != param_4);
    }
    if (param_3 != param_4) {
      uVar14 = (long)param_4 + (-4 - (long)param_3);
      if ((0x1b < uVar14) && (0x1f < (ulong)((long)param_2 - (long)param_3))) {
        plVar3 = (long *)(param_3 + 4);
        plVar18 = param_2 + 2;
        uVar14 = (uVar14 >> 2) + 1;
        uVar13 = uVar14 & 0x7ffffffffffffff8;
        uVar12 = uVar13;
        do {
          plVar2 = plVar3 + -1;
          lVar22 = plVar3[-2];
          lVar11 = plVar3[1];
          lVar10 = *plVar3;
          uVar12 = uVar12 - 8;
          plVar3 = plVar3 + 4;
          plVar18[-1] = *plVar2;
          plVar18[-2] = lVar22;
          plVar18[1] = lVar11;
          *plVar18 = lVar10;
          plVar18 = plVar18 + 4;
        } while (uVar12 != 0);
        param_2 = (long *)((long)param_2 + uVar13 * 4);
        param_3 = param_3 + uVar13;
        if (uVar14 == uVar13) goto LAB_00519518;
      }
      do {
        puVar8 = param_3 + 1;
        *(undefined4 *)param_2 = *param_3;
        param_2 = (long *)((long)param_2 + 4);
        param_3 = puVar8;
      } while (puVar8 != param_4);
    }
    goto LAB_00519518;
  }
  if (uVar14 < 9) {
    uVar14 = 8;
  }
  do {
    uVar12 = uVar14;
    uVar14 = uVar12 << 1;
  } while (uVar12 < uVar20);
  if (uVar12 < 9) {
    plVar2 = param_1 + 3;
  }
  else {
    plVar2 = (long *)malloc(uVar12 << 2);
    if (plVar2 == (long *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_0058bdd0();
    }
  }
  plVar6 = plVar18;
  plVar9 = plVar2;
  if ((plVar2 != plVar18) && (plVar18 != param_2)) {
    uVar14 = (long)param_2 + (-4 - (long)plVar18);
    plVar5 = plVar18;
    plVar7 = plVar2;
    plVar6 = param_2;
    if ((0x1b < uVar14) && (0x1f < (ulong)((long)plVar2 - (long)plVar18))) {
      plVar5 = plVar2 + 2;
      plVar7 = plVar18 + 2;
      uVar14 = (uVar14 >> 2) + 1;
      uVar15 = uVar14 & 0x7ffffffffffffff8;
      plVar9 = (long *)((long)plVar2 + uVar15 * 4);
      uVar13 = uVar15;
      do {
        plVar4 = plVar7 + -1;
        lVar10 = plVar7[-2];
        lVar25 = plVar7[1];
        lVar11 = *plVar7;
        uVar13 = uVar13 - 8;
        plVar7 = plVar7 + 4;
        plVar5[-1] = *plVar4;
        plVar5[-2] = lVar10;
        plVar5[1] = lVar25;
        *plVar5 = lVar11;
        plVar5 = plVar5 + 4;
      } while (uVar13 != 0);
      plVar5 = (long *)((long)plVar18 + uVar15 * 4);
      plVar7 = plVar9;
      if (uVar14 == uVar15) goto LAB_005193c4;
    }
    do {
      plVar4 = (long *)((long)plVar5 + 4);
      plVar9 = (long *)((long)plVar7 + 4);
      *(int *)plVar7 = (int)*plVar5;
      plVar5 = plVar4;
      plVar7 = plVar9;
    } while (plVar4 != param_2);
  }
LAB_005193c4:
  plVar5 = plVar9;
  if (param_3 != param_4) {
    puVar8 = param_3;
    if ((0x1b < lVar22 - 4U) && (0x1f < (ulong)((long)plVar9 - (long)param_3))) {
      plVar7 = (long *)(param_3 + 4);
      uVar14 = (lVar22 - 4U >> 2) + 1;
      uVar15 = uVar14 & 0x7ffffffffffffff8;
      plVar5 = (long *)((long)plVar9 + uVar15 * 4);
      plVar9 = plVar9 + 2;
      uVar13 = uVar15;
      do {
        plVar4 = plVar7 + -1;
        lVar22 = plVar7[-2];
        lVar11 = plVar7[1];
        lVar10 = *plVar7;
        uVar13 = uVar13 - 8;
        plVar7 = plVar7 + 4;
        plVar9[-1] = *plVar4;
        plVar9[-2] = lVar22;
        plVar9[1] = lVar11;
        *plVar9 = lVar10;
        plVar9 = plVar9 + 4;
      } while (uVar13 != 0);
      plVar9 = plVar5;
      puVar8 = param_3 + uVar15;
      if (uVar14 == uVar15) goto LAB_00519468;
    }
    do {
      puVar16 = puVar8 + 1;
      *(undefined4 *)plVar9 = *puVar8;
      plVar5 = (long *)((long)plVar9 + 4);
      plVar9 = (long *)((long)plVar9 + 4);
      puVar8 = puVar16;
    } while (puVar16 != param_4);
  }
LAB_00519468:
  if ((plVar2 != plVar18 || param_3 != param_4) && (plVar6 != plVar3)) {
    uVar14 = (long)plVar3 + (-4 - (long)plVar6);
    if ((0x1b < uVar14) && (0x1f < (ulong)((long)plVar5 - (long)plVar6))) {
      uVar14 = (uVar14 >> 2) + 1;
      uVar15 = uVar14 & 0x7ffffffffffffff8;
      plVar9 = plVar5 + 2;
      plVar7 = plVar6 + 2;
      uVar13 = uVar15;
      do {
        plVar4 = plVar7 + -1;
        lVar22 = plVar7[-2];
        lVar11 = plVar7[1];
        lVar10 = *plVar7;
        uVar13 = uVar13 - 8;
        plVar7 = plVar7 + 4;
        plVar9[-1] = *plVar4;
        plVar9[-2] = lVar22;
        plVar9[1] = lVar11;
        *plVar9 = lVar10;
        plVar9 = plVar9 + 4;
      } while (uVar13 != 0);
      plVar6 = (long *)((long)plVar6 + uVar15 * 4);
      plVar5 = (long *)((long)plVar5 + uVar15 * 4);
      if (uVar14 == uVar15) goto LAB_005194f8;
    }
    do {
      plVar9 = (long *)((long)plVar6 + 4);
      *(int *)plVar5 = (int)*plVar6;
      plVar6 = plVar9;
      plVar5 = (long *)((long)plVar5 + 4);
    } while (plVar9 != plVar3);
  }
LAB_005194f8:
  if (plVar18 != param_1 + 3) {
    free(plVar18);
    lVar21 = param_1[1];
  }
  *param_1 = (long)plVar2;
  param_1[2] = uVar12;
LAB_00519518:
  param_1[1] = lVar21 + uVar20;
  return;
}



// ========================================
// Function: FUN_00519574
// Address: 00519574
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

long * FUN_00519574(long *param_1,uint *param_2,undefined8 param_3,undefined8 *param_4)

{
  uint uVar1;
  undefined4 uVar2;
  ulong uVar3;
  long lVar4;
  long *plVar5;
  undefined8 uVar6;
  long lVar7;
  long *plVar8;
  long lVar9;
  undefined8 *puVar10;
  long lVar11;
  ulong uVar12;
  long lVar13;
  long *plVar14;
  long *plVar15;
  long *plVar16;
  long *plVar17;
  long *plVar18;
  long *unaff_x26;
  undefined2 uVar19;
  float fVar20;
  
  lVar4 = tpidr_el0;
  lVar7 = *(long *)(lVar4 + 0x28);
  plVar18 = (long *)param_1[1];
  uVar1 = *param_2;
  plVar17 = (long *)(ulong)uVar1;
  if (plVar18 != (long *)0x0) {
    uVar6 = CONCAT17(POPCOUNT((char)((ulong)plVar18 >> 0x38)),
                     CONCAT16(POPCOUNT((char)((ulong)plVar18 >> 0x30)),
                              CONCAT15(POPCOUNT((char)((ulong)plVar18 >> 0x28)),
                                       CONCAT14(POPCOUNT((char)((ulong)plVar18 >> 0x20)),
                                                CONCAT13(POPCOUNT((char)((ulong)plVar18 >> 0x18)),
                                                         CONCAT12(POPCOUNT((char)((ulong)plVar18 >>
                                                                                 0x10)),
                                                                  CONCAT11(POPCOUNT((char)((ulong)
                                                  plVar18 >> 8)),POPCOUNT((char)plVar18))))))));
    uVar19 = NEON_uaddlv(uVar6,1);
    uVar12 = CONCAT62((int6)((ulong)uVar6 >> 0x10),uVar19) & 0xffffffff;
    if (uVar12 < 2) {
      unaff_x26 = (long *)(ulong)((int)plVar18 - 1U & uVar1);
    }
    else {
      unaff_x26 = plVar17;
      if (plVar18 <= plVar17) {
        uVar3 = 0;
        if (plVar18 != (long *)0x0) {
          uVar3 = (ulong)plVar17 / (ulong)plVar18;
        }
        unaff_x26 = (long *)((long)plVar17 - uVar3 * (long)plVar18);
      }
    }
    puVar10 = *(undefined8 **)(*param_1 + (long)unaff_x26 * 8);
    if ((puVar10 != (undefined8 *)0x0) && (plVar16 = (long *)*puVar10, plVar16 != (long *)0x0)) {
      do {
        plVar14 = (long *)plVar16[1];
        if (plVar14 == plVar17) {
          if (*(uint *)(plVar16 + 2) == uVar1) {
            uVar6 = 0;
            goto LAB_00519844;
          }
        }
        else {
          if (uVar12 < 2) {
            plVar14 = (long *)((ulong)plVar14 & (long)plVar18 - 1U);
          }
          else if (plVar18 <= plVar14) {
            uVar3 = 0;
            if (plVar18 != (long *)0x0) {
              uVar3 = (ulong)plVar14 / (ulong)plVar18;
            }
            plVar14 = (long *)((long)plVar14 - uVar3 * (long)plVar18);
          }
          if (plVar14 != unaff_x26) break;
        }
        plVar16 = (long *)*plVar16;
      } while (plVar16 != (long *)0x0);
    }
  }
  plVar14 = param_1 + 2;
  plVar16 = (long *)FUN_005a5d4c(0x70);
  lVar9 = _UNK_001a0d48;
  lVar13 = _DAT_001a0d40;
  lVar11 = param_1[3];
  uVar2 = *(undefined4 *)*param_4;
  *plVar16 = 0;
  plVar16[1] = (long)plVar17;
  plVar16[5] = lVar9;
  plVar16[4] = lVar13;
  fVar20 = *(float *)(param_1 + 4);
  *(undefined4 *)(plVar16 + 2) = uVar2;
  plVar16[3] = (long)(plVar16 + 6);
  plVar5 = plVar16;
  if ((plVar18 == (long *)0x0) || (fVar20 * (float)plVar18 < (float)(lVar11 + 1))) {
    if (plVar18 < (long *)0x3) {
      uVar12 = 1;
    }
    else {
      uVar12 = (ulong)(((ulong)plVar18 & (long)plVar18 - 1U) != 0);
    }
    plVar8 = (long *)(uVar12 | (long)plVar18 << 1);
    plVar15 = (long *)(long)((float)(lVar11 + 1) / fVar20);
    if (plVar8 <= plVar15) {
      plVar8 = plVar15;
    }
    if ((long)plVar8 - 1U == 0) {
      plVar8 = (long *)0x2;
    }
    else if (((ulong)plVar8 & (long)plVar8 - 1U) != 0) {
                    /* try { // try from 00519708 to 00519793 has its CatchHandler @ 00519874 */
      plVar5 = (long *)FUN_0055fe2c(plVar8);
      plVar18 = (long *)param_1[1];
      plVar8 = plVar5;
    }
    if (plVar18 < plVar8) {
LAB_00519720:
      plVar5 = (long *)FUN_00518f0c(param_1,plVar8);
    }
    else if (plVar8 < plVar18) {
      plVar5 = (long *)(long)((float)(ulong)param_1[3] / *(float *)(param_1 + 4));
      if ((plVar18 < (long *)0x3) ||
         (uVar6 = CONCAT17(POPCOUNT((char)((ulong)plVar18 >> 0x38)),
                           CONCAT16(POPCOUNT((char)((ulong)plVar18 >> 0x30)),
                                    CONCAT15(POPCOUNT((char)((ulong)plVar18 >> 0x28)),
                                             CONCAT14(POPCOUNT((char)((ulong)plVar18 >> 0x20)),
                                                      CONCAT13(POPCOUNT((char)((ulong)plVar18 >>
                                                                              0x18)),
                                                               CONCAT12(POPCOUNT((char)((ulong)
                                                  plVar18 >> 0x10)),
                                                  CONCAT11(POPCOUNT((char)((ulong)plVar18 >> 8)),
                                                           POPCOUNT((char)plVar18)))))))),
         uVar19 = NEON_uaddlv(uVar6,1),
         1 < (CONCAT62((int6)((ulong)uVar6 >> 0x10),uVar19) & 0xffffffff))) {
        plVar5 = (long *)FUN_0055fe2c();
      }
      else if ((long *)0x1 < plVar5) {
        plVar5 = (long *)(1L << (-LZCOUNT((long)plVar5 + -1) & 0x3fU));
      }
      if (plVar8 <= plVar5) {
        plVar8 = plVar5;
      }
      if (plVar8 < plVar18) goto LAB_00519720;
    }
    plVar18 = (long *)param_1[1];
    if (((ulong)plVar18 & (long)plVar18 - 1U) == 0) {
      unaff_x26 = (long *)(ulong)((int)plVar18 - 1U & uVar1);
    }
    else {
      unaff_x26 = plVar17;
      if (plVar18 <= plVar17) {
        uVar12 = 0;
        if (plVar18 != (long *)0x0) {
          uVar12 = (ulong)plVar17 / (ulong)plVar18;
        }
        unaff_x26 = (long *)((long)plVar17 - uVar12 * (long)plVar18);
      }
    }
  }
  lVar13 = *param_1;
  plVar17 = *(long **)(lVar13 + (long)unaff_x26 * 8);
  if (plVar17 == (long *)0x0) {
    lVar9 = *plVar14;
    *plVar14 = (long)plVar16;
    *plVar16 = lVar9;
    *(long **)(lVar13 + (long)unaff_x26 * 8) = plVar14;
    if (*plVar16 == 0) goto LAB_00519834;
    plVar17 = *(long **)(*plVar16 + 8);
    if (((ulong)plVar18 & (long)plVar18 - 1U) == 0) {
      plVar17 = (long *)((ulong)plVar17 & (long)plVar18 - 1U);
    }
    else if (plVar18 <= plVar17) {
      uVar12 = 0;
      if (plVar18 != (long *)0x0) {
        uVar12 = (ulong)plVar17 / (ulong)plVar18;
      }
      plVar17 = (long *)((long)plVar17 - uVar12 * (long)plVar18);
    }
    plVar17 = (long *)(*param_1 + (long)plVar17 * 8);
  }
  else {
    *plVar16 = *plVar17;
  }
  *plVar17 = (long)plVar16;
LAB_00519834:
  uVar6 = 1;
  param_1[3] = param_1[3] + 1;
  param_1 = plVar5;
LAB_00519844:
  if (*(long *)(lVar4 + 0x28) == lVar7) {
    return plVar16;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(param_1,uVar6);
}



// ========================================
// Function: FUN_0051989c
// Address: 0051989c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051989c(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1160;
  undefined8 local_1158;
  undefined8 uStack_1150;
  undefined1 auStack_1148 [4096];
  undefined8 *local_148;
  long local_140;
  undefined8 uStack_138;
  undefined8 local_130 [24];
  long local_70;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_70 = *(long *)(lVar1 + 0x28);
  uStack_138 = _UNK_001a0d48;
  local_140 = _DAT_001a0d40;
  uStack_1150 = _UNK_001a1328;
  local_1158 = _DAT_001a1320;
  local_1160 = auStack_1148;
  local_148 = local_130;
                    /* try { // try from 00519924 to 00519967 has its CatchHandler @ 00519a08 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1160,param_2,uVar4);
  FUN_00519a34(&local_1160,param_3,param_4,param_5,param_6,param_7,param_8);
  FUN_0044c6fc(param_1,&local_1160);
  if (local_140 != 0) {
    lVar6 = local_140 * 0x18;
    puVar5 = local_148;
    do {
      if ((undefined1 *)*puVar5 != auStack_1148) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1160 != auStack_1148) {
    free(local_1160);
  }
  local_140 = 0;
  uStack_1150 = uVar3;
  local_1158 = uVar2;
  local_1160 = auStack_1148;
  if (local_148 != local_130) {
    free(local_148);
  }
  if (*(long *)(lVar1 + 0x28) == local_70) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00519a34
// Address: 00519a34
// ========================================

void FUN_00519a34(undefined8 param_1,undefined4 *param_2,char *param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_70 [8];
  ulong local_68;
  void *local_60;
  long local_58;
  
  lVar2 = tpidr_el0;
  local_58 = *(long *)(lVar2 + 0x28);
  FUN_00562e2c(local_70,*param_2);
  uVar1 = (ulong)(local_70[0] >> 1);
  pvVar3 = (void *)((ulong)local_70 | 1);
  if ((local_70[0] & 1) != 0) {
    uVar1 = local_68;
    pvVar3 = local_60;
  }
                    /* try { // try from 00519aa4 to 00519aab has its CatchHandler @ 00519b18 */
  FUN_0044c958(param_1,pvVar3,uVar1);
  if ((local_70[0] & 1) != 0) {
    free(local_60);
  }
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar4);
  FUN_00519b48(param_1,param_4,param_5,param_6,param_7);
  if (*(long *)(lVar2 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_00519b48
// Address: 00519b48
// ========================================

void FUN_00519b48(undefined8 param_1,undefined4 *param_2,char *param_3,undefined8 param_4,
                 undefined8 param_5)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_60 [8];
  ulong local_58;
  void *local_50;
  long local_48;
  
  lVar2 = tpidr_el0;
  local_48 = *(long *)(lVar2 + 0x28);
  FUN_00562e2c(local_60,*param_2);
  uVar1 = (ulong)(local_60[0] >> 1);
  pvVar3 = (void *)((ulong)local_60 | 1);
  if ((local_60[0] & 1) != 0) {
    uVar1 = local_58;
    pvVar3 = local_50;
  }
                    /* try { // try from 00519bac to 00519bb3 has its CatchHandler @ 00519c14 */
  FUN_0044c958(param_1,pvVar3,uVar1);
  if ((local_60[0] & 1) != 0) {
    free(local_50);
  }
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar4);
  FUN_00519c44(param_1,param_4,param_5);
  if (*(long *)(lVar2 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_00519c44
// Address: 00519c44
// ========================================

void FUN_00519c44(undefined8 param_1,undefined4 *param_2,char *param_3)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  FUN_00562e2c(local_50,*param_2);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 00519c9c to 00519ca3 has its CatchHandler @ 00519cf0 */
  FUN_0044c958(param_1,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar4);
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_00519d20
// Address: 00519d20
// ========================================

void FUN_00519d20(long param_1,undefined4 *param_2,char *param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_70 [8];
  ulong local_68;
  void *local_60;
  long local_58;
  
  lVar2 = tpidr_el0;
  local_58 = *(long *)(lVar2 + 0x28);
  FUN_00562e2c(local_70,*param_2);
  uVar1 = (ulong)(local_70[0] >> 1);
  pvVar3 = (void *)((ulong)local_70 | 1);
  if ((local_70[0] & 1) != 0) {
    uVar1 = local_68;
    pvVar3 = local_60;
  }
                    /* try { // try from 00519d90 to 00519d97 has its CatchHandler @ 00519e1c */
  FUN_0044c958(param_1 + 0xc68,pvVar3,uVar1);
  if ((local_70[0] & 1) != 0) {
    free(local_60);
  }
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar4);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_00519e4c(param_1,param_4,param_5,param_6,param_7);
  if (*(long *)(lVar2 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_00519e4c
// Address: 00519e4c
// ========================================

void FUN_00519e4c(long param_1,undefined4 *param_2,char *param_3,undefined8 param_4,
                 undefined8 param_5)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_60 [8];
  ulong local_58;
  void *local_50;
  long local_48;
  
  lVar2 = tpidr_el0;
  local_48 = *(long *)(lVar2 + 0x28);
  FUN_00562e2c(local_60,*param_2);
  uVar1 = (ulong)(local_60[0] >> 1);
  pvVar3 = (void *)((ulong)local_60 | 1);
  if ((local_60[0] & 1) != 0) {
    uVar1 = local_58;
    pvVar3 = local_50;
  }
                    /* try { // try from 00519eb0 to 00519eb7 has its CatchHandler @ 00519f30 */
  FUN_0044c958(param_1 + 0xc68,pvVar3,uVar1);
  if ((local_60[0] & 1) != 0) {
    free(local_50);
  }
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar4);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  FUN_00519f60(param_1,param_4,param_5);
  if (*(long *)(lVar2 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_00519f60
// Address: 00519f60
// ========================================

void FUN_00519f60(long param_1,undefined4 *param_2,char *param_3)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  FUN_00562e2c(local_50,*param_2);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 00519fb8 to 00519fbf has its CatchHandler @ 0051a024 */
  FUN_0044c958(param_1 + 0xc68,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar4);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0051a054
// Address: 0051a054
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051a054(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 0051a0c8 to 0051a127 has its CatchHandler @ 0051a1c0 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051a1e8
// Address: 0051a1e8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051a1e8(undefined8 param_1,undefined8 *param_2,undefined8 param_3,byte *param_4,
                 undefined8 param_5)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined8 uVar9;
  undefined1 *local_1158;
  undefined8 local_1150;
  undefined8 uStack_1148;
  undefined1 auStack_1140 [4096];
  undefined8 *local_140;
  long local_138;
  undefined8 uStack_130;
  undefined8 local_128 [24];
  long local_68;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_68 = *(long *)(lVar3 + 0x28);
  uStack_130 = _UNK_001a0d48;
  local_138 = _DAT_001a0d40;
  uVar9 = *param_2;
  uStack_1148 = _UNK_001a1328;
  local_1150 = _DAT_001a1320;
  local_1158 = auStack_1140;
  local_140 = local_128;
                    /* try { // try from 0051a264 to 0051a2e3 has its CatchHandler @ 0051a380 */
  uVar6 = __strlen_chk(uVar9,0xffffffffffffffff);
  FUN_0044c958(&local_1158,uVar9,uVar6);
  uVar6 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1158,param_3,uVar6);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(&local_1158,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_5,0xffffffffffffffff);
  FUN_0044c958(&local_1158,param_5,uVar6);
  FUN_0044c6fc(param_1,&local_1158);
  if (local_138 != 0) {
    lVar8 = local_138 * 0x18;
    puVar7 = local_140;
    do {
      if ((undefined1 *)*puVar7 != auStack_1140) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1158 != auStack_1140) {
    free(local_1158);
  }
  local_138 = 0;
  uStack_1148 = uVar5;
  local_1150 = uVar4;
  local_1158 = auStack_1140;
  if (local_140 != local_128) {
    free(local_140);
  }
  if (*(long *)(lVar3 + 0x28) == local_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051a3a8
// Address: 0051a3a8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051a3a8(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 *param_4,
                 undefined8 param_5)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined8 uVar9;
  undefined1 *local_1158;
  undefined8 local_1150;
  undefined8 uStack_1148;
  undefined1 auStack_1140 [4096];
  undefined8 *local_140;
  long local_138;
  undefined8 uStack_130;
  undefined8 local_128 [24];
  long local_68;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_68 = *(long *)(lVar3 + 0x28);
  uStack_130 = _UNK_001a0d48;
  local_138 = _DAT_001a0d40;
  uStack_1148 = _UNK_001a1328;
  local_1150 = _DAT_001a1320;
  local_1158 = auStack_1140;
  local_140 = local_128;
                    /* try { // try from 0051a424 to 0051a4a3 has its CatchHandler @ 0051a540 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1158,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1158,pbVar2,uVar1);
  uVar9 = *param_4;
  uVar6 = __strlen_chk(uVar9,0xffffffffffffffff);
  FUN_0044c958(&local_1158,uVar9,uVar6);
  uVar6 = __strlen_chk(param_5,0xffffffffffffffff);
  FUN_0044c958(&local_1158,param_5,uVar6);
  FUN_0044c6fc(param_1,&local_1158);
  if (local_138 != 0) {
    lVar8 = local_138 * 0x18;
    puVar7 = local_140;
    do {
      if ((undefined1 *)*puVar7 != auStack_1140) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1158 != auStack_1140) {
    free(local_1158);
  }
  local_138 = 0;
  uStack_1148 = uVar5;
  local_1150 = uVar4;
  local_1158 = auStack_1140;
  if (local_140 != local_128) {
    free(local_140);
  }
  if (*(long *)(lVar3 + 0x28) == local_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051a568
// Address: 0051a568
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051a568(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 0051a5dc to 0051a627 has its CatchHandler @ 0051a6c0 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar4);
  FUN_0044eab0(&local_1148,param_3);
  uVar4 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar4);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar6 = local_128 * 0x18;
    puVar5 = local_130;
    do {
      if ((undefined1 *)*puVar5 != auStack_1130) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar3;
  local_1140 = uVar2;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051a6e8
// Address: 0051a6e8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051a6e8(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 0051a750 to 0051a773 has its CatchHandler @ 0051a808 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051a830
// Address: 0051a830
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051a830(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 0051a8a4 to 0051a903 has its CatchHandler @ 0051a99c */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051a9c4
// Address: 0051a9c4
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051a9c4(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
  local_1138 = auStack_1120;
  local_120 = local_108;
                    /* try { // try from 0051aa2c to 0051aa4f has its CatchHandler @ 0051aae4 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1138,param_2,uVar4);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar6 = local_118 * 0x18;
    puVar5 = local_120;
    do {
      if ((undefined1 *)*puVar5 != auStack_1120) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  uStack_1128 = uVar3;
  local_1130 = uVar2;
  local_1138 = auStack_1120;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051ab0c
// Address: 0051ab0c
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051ab0c(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 0051ab80 to 0051abdf has its CatchHandler @ 0051ac78 */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051aca0
// Address: 0051aca0
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051aca0(undefined8 param_1,undefined8 param_2,byte *param_3,undefined8 param_4)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
  local_1148 = auStack_1130;
  local_130 = local_118;
                    /* try { // try from 0051ad14 to 0051ad73 has its CatchHandler @ 0051ae0c */
  uVar6 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_2,uVar6);
  uVar1 = *(ulong *)(param_3 + 8);
  pbVar2 = *(byte **)(param_3 + 0x10);
  if ((*param_3 & 1) == 0) {
    pbVar2 = param_3 + 1;
    uVar1 = (ulong)(*param_3 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_4,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051ae34
// Address: 0051ae34
// ========================================

void FUN_0051ae34(undefined8 param_1,undefined4 *param_2,char *param_3)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_50 [8];
  ulong local_48;
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  FUN_00562e2c(local_50,*param_2);
  uVar1 = (ulong)(local_50[0] >> 1);
  pvVar3 = (void *)((ulong)local_50 | 1);
  if ((local_50[0] & 1) != 0) {
    uVar1 = local_48;
    pvVar3 = local_40;
  }
                    /* try { // try from 0051ae8c to 0051ae93 has its CatchHandler @ 0051aee0 */
  FUN_0044c958(param_1,pvVar3,uVar1);
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar4);
  if (*(long *)(lVar2 + 0x28) != local_38) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0051af10
// Address: 0051af10
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051af10(undefined8 param_1,byte *param_2,undefined8 param_3,byte *param_4,
                 undefined8 param_5)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
                    /* try { // try from 0051af9c to 0051b007 has its CatchHandler @ 0051b0a0 */
  local_1148 = auStack_1130;
  local_130 = local_118;
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_3,uVar6);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_5,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_5,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0051b0c8
// Address: 0051b0c8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051b0c8(undefined8 param_1,byte *param_2,undefined8 param_3,byte *param_4,
                 undefined8 param_5)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
                    /* try { // try from 0051b154 to 0051b1bf has its CatchHandler @ 0051b258 */
  local_1148 = auStack_1130;
  local_130 = local_118;
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_3,uVar6);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_5,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_5,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0051b280
// Address: 0051b280
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051b280(undefined8 param_1,byte *param_2,undefined8 param_3,byte *param_4,
                 undefined8 param_5)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1148;
  undefined8 local_1140;
  undefined8 uStack_1138;
  undefined1 auStack_1130 [4096];
  undefined8 *local_130;
  long local_128;
  undefined8 uStack_120;
  undefined8 local_118 [24];
  long local_58;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  uStack_120 = _UNK_001a0d48;
  local_128 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1138 = _UNK_001a1328;
  local_1140 = _DAT_001a1320;
                    /* try { // try from 0051b30c to 0051b377 has its CatchHandler @ 0051b410 */
  local_1148 = auStack_1130;
  local_130 = local_118;
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_3,uVar6);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(&local_1148,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_5,0xffffffffffffffff);
  FUN_0044c958(&local_1148,param_5,uVar6);
  FUN_0044c6fc(param_1,&local_1148);
  if (local_128 != 0) {
    lVar8 = local_128 * 0x18;
    puVar7 = local_130;
    do {
      if ((undefined1 *)*puVar7 != auStack_1130) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1148 != auStack_1130) {
    free(local_1148);
  }
  local_128 = 0;
  uStack_1138 = uVar5;
  local_1140 = uVar4;
  local_1148 = auStack_1130;
  if (local_130 != local_118) {
    free(local_130);
  }
  if (*(long *)(lVar3 + 0x28) != local_58) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0051b438
// Address: 0051b438
// ========================================

void FUN_0051b438(undefined8 param_1,undefined8 *param_2,char *param_3,byte *param_4,char *param_5,
                 byte *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  __s = (char *)*param_2;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  sVar3 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar3);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar3);
  uVar1 = *(ulong *)(param_6 + 8);
  pbVar2 = *(byte **)(param_6 + 0x10);
  if ((*param_6 & 1) == 0) {
    pbVar2 = param_6 + 1;
    uVar1 = (ulong)(*param_6 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  return;
}



// ========================================
// Function: FUN_0051b4fc
// Address: 0051b4fc
// ========================================

long * FUN_0051b4fc(long *param_1,uint *param_2,undefined8 param_3,undefined8 *param_4)

{
  uint uVar1;
  undefined4 uVar2;
  ulong uVar3;
  long lVar4;
  long *plVar5;
  undefined8 uVar6;
  long lVar7;
  long lVar8;
  long *plVar9;
  long lVar10;
  undefined8 *puVar11;
  ulong uVar12;
  long *plVar13;
  long *plVar14;
  long *plVar15;
  long *plVar16;
  long *plVar17;
  long *unaff_x26;
  undefined2 uVar18;
  float fVar19;
  
  lVar4 = tpidr_el0;
  lVar7 = *(long *)(lVar4 + 0x28);
  plVar17 = (long *)param_1[1];
  uVar1 = *param_2;
  plVar16 = (long *)(ulong)uVar1;
  if (plVar17 != (long *)0x0) {
    uVar6 = CONCAT17(POPCOUNT((char)((ulong)plVar17 >> 0x38)),
                     CONCAT16(POPCOUNT((char)((ulong)plVar17 >> 0x30)),
                              CONCAT15(POPCOUNT((char)((ulong)plVar17 >> 0x28)),
                                       CONCAT14(POPCOUNT((char)((ulong)plVar17 >> 0x20)),
                                                CONCAT13(POPCOUNT((char)((ulong)plVar17 >> 0x18)),
                                                         CONCAT12(POPCOUNT((char)((ulong)plVar17 >>
                                                                                 0x10)),
                                                                  CONCAT11(POPCOUNT((char)((ulong)
                                                  plVar17 >> 8)),POPCOUNT((char)plVar17))))))));
    uVar18 = NEON_uaddlv(uVar6,1);
    uVar12 = CONCAT62((int6)((ulong)uVar6 >> 0x10),uVar18) & 0xffffffff;
    if (uVar12 < 2) {
      unaff_x26 = (long *)(ulong)((int)plVar17 - 1U & uVar1);
    }
    else {
      unaff_x26 = plVar16;
      if (plVar17 <= plVar16) {
        uVar3 = 0;
        if (plVar17 != (long *)0x0) {
          uVar3 = (ulong)plVar16 / (ulong)plVar17;
        }
        unaff_x26 = (long *)((long)plVar16 - uVar3 * (long)plVar17);
      }
    }
    puVar11 = *(undefined8 **)(*param_1 + (long)unaff_x26 * 8);
    if ((puVar11 != (undefined8 *)0x0) && (plVar15 = (long *)*puVar11, plVar15 != (long *)0x0)) {
      do {
        plVar13 = (long *)plVar15[1];
        if (plVar13 == plVar16) {
          if (*(uint *)(plVar15 + 2) == uVar1) {
            uVar6 = 0;
            goto LAB_0051b7c4;
          }
        }
        else {
          if (uVar12 < 2) {
            plVar13 = (long *)((ulong)plVar13 & (long)plVar17 - 1U);
          }
          else if (plVar17 <= plVar13) {
            uVar3 = 0;
            if (plVar17 != (long *)0x0) {
              uVar3 = (ulong)plVar13 / (ulong)plVar17;
            }
            plVar13 = (long *)((long)plVar13 - uVar3 * (long)plVar17);
          }
          if (plVar13 != unaff_x26) break;
        }
        plVar15 = (long *)*plVar15;
      } while (plVar15 != (long *)0x0);
    }
  }
  plVar13 = param_1 + 2;
  plVar15 = (long *)FUN_005a5d4c(0x30);
  fVar19 = *(float *)(param_1 + 4);
  uVar2 = *(undefined4 *)*param_4;
  *plVar15 = 0;
  plVar15[1] = (long)plVar16;
  *(undefined4 *)(plVar15 + 2) = uVar2;
  lVar8 = param_1[3];
  plVar15[4] = 0;
  plVar15[5] = 0;
  plVar15[3] = 0;
  plVar5 = plVar15;
  if ((plVar17 == (long *)0x0) || (fVar19 * (float)plVar17 < (float)(lVar8 + 1))) {
    if (plVar17 < (long *)0x3) {
      uVar12 = 1;
    }
    else {
      uVar12 = (ulong)(((ulong)plVar17 & (long)plVar17 - 1U) != 0);
    }
    plVar9 = (long *)(uVar12 | (long)plVar17 << 1);
    plVar14 = (long *)(long)((float)(lVar8 + 1) / fVar19);
    if (plVar9 <= plVar14) {
      plVar9 = plVar14;
    }
    if ((long)plVar9 - 1U == 0) {
      plVar9 = (long *)0x2;
    }
    else if (((ulong)plVar9 & (long)plVar9 - 1U) != 0) {
                    /* try { // try from 0051b688 to 0051b713 has its CatchHandler @ 0051b7f4 */
      plVar5 = (long *)FUN_0055fe2c(plVar9);
      plVar17 = (long *)param_1[1];
      plVar9 = plVar5;
    }
    if (plVar17 < plVar9) {
LAB_0051b6a0:
      plVar5 = (long *)FUN_004fad14(param_1,plVar9);
    }
    else if (plVar9 < plVar17) {
      plVar5 = (long *)(long)((float)(ulong)param_1[3] / *(float *)(param_1 + 4));
      if ((plVar17 < (long *)0x3) ||
         (uVar6 = CONCAT17(POPCOUNT((char)((ulong)plVar17 >> 0x38)),
                           CONCAT16(POPCOUNT((char)((ulong)plVar17 >> 0x30)),
                                    CONCAT15(POPCOUNT((char)((ulong)plVar17 >> 0x28)),
                                             CONCAT14(POPCOUNT((char)((ulong)plVar17 >> 0x20)),
                                                      CONCAT13(POPCOUNT((char)((ulong)plVar17 >>
                                                                              0x18)),
                                                               CONCAT12(POPCOUNT((char)((ulong)
                                                  plVar17 >> 0x10)),
                                                  CONCAT11(POPCOUNT((char)((ulong)plVar17 >> 8)),
                                                           POPCOUNT((char)plVar17)))))))),
         uVar18 = NEON_uaddlv(uVar6,1),
         1 < (CONCAT62((int6)((ulong)uVar6 >> 0x10),uVar18) & 0xffffffff))) {
        plVar5 = (long *)FUN_0055fe2c();
      }
      else if ((long *)0x1 < plVar5) {
        plVar5 = (long *)(1L << (-LZCOUNT((long)plVar5 + -1) & 0x3fU));
      }
      if (plVar9 <= plVar5) {
        plVar9 = plVar5;
      }
      if (plVar9 < plVar17) goto LAB_0051b6a0;
    }
    plVar17 = (long *)param_1[1];
    if (((ulong)plVar17 & (long)plVar17 - 1U) == 0) {
      unaff_x26 = (long *)(ulong)((int)plVar17 - 1U & uVar1);
    }
    else {
      unaff_x26 = plVar16;
      if (plVar17 <= plVar16) {
        uVar12 = 0;
        if (plVar17 != (long *)0x0) {
          uVar12 = (ulong)plVar16 / (ulong)plVar17;
        }
        unaff_x26 = (long *)((long)plVar16 - uVar12 * (long)plVar17);
      }
    }
  }
  lVar8 = *param_1;
  plVar16 = *(long **)(lVar8 + (long)unaff_x26 * 8);
  if (plVar16 == (long *)0x0) {
    lVar10 = *plVar13;
    *plVar13 = (long)plVar15;
    *plVar15 = lVar10;
    *(long **)(lVar8 + (long)unaff_x26 * 8) = plVar13;
    if (*plVar15 == 0) goto LAB_0051b7b4;
    plVar16 = *(long **)(*plVar15 + 8);
    if (((ulong)plVar17 & (long)plVar17 - 1U) == 0) {
      plVar16 = (long *)((ulong)plVar16 & (long)plVar17 - 1U);
    }
    else if (plVar17 <= plVar16) {
      uVar12 = 0;
      if (plVar17 != (long *)0x0) {
        uVar12 = (ulong)plVar16 / (ulong)plVar17;
      }
      plVar16 = (long *)((long)plVar16 - uVar12 * (long)plVar17);
    }
    plVar16 = (long *)(*param_1 + (long)plVar16 * 8);
  }
  else {
    *plVar15 = *plVar16;
  }
  *plVar16 = (long)plVar15;
LAB_0051b7b4:
  uVar6 = 1;
  param_1[3] = param_1[3] + 1;
  param_1 = plVar5;
LAB_0051b7c4:
  if (*(long *)(lVar4 + 0x28) == lVar7) {
    return plVar15;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(param_1,uVar6);
}



// ========================================
// Function: FUN_0051b81c
// Address: 0051b81c
// ========================================

void FUN_0051b81c(long *param_1)

{
  undefined8 *__ptr;
  undefined8 *__ptr_00;
  long lVar1;
  long lVar2;
  void *pvVar3;
  void *pvVar4;
  
  if (param_1[3] != 0) {
    __ptr = (undefined8 *)param_1[2];
    while (__ptr != (undefined8 *)0x0) {
      pvVar3 = (void *)*__ptr;
      __ptr_00 = (undefined8 *)__ptr[7];
      while (__ptr_00 != (undefined8 *)0x0) {
        pvVar4 = (void *)*__ptr_00;
        free(__ptr_00);
        __ptr_00 = (undefined8 *)pvVar4;
      }
      pvVar4 = (void *)__ptr[5];
      __ptr[5] = 0;
      if (pvVar4 != (void *)0x0) {
        free(pvVar4);
      }
      if ((*(byte *)(__ptr + 2) & 1) != 0) {
        free((void *)__ptr[4]);
      }
      free(__ptr);
      __ptr = (undefined8 *)pvVar3;
    }
    lVar1 = param_1[1];
    param_1[2] = 0;
    if (lVar1 != 0) {
      lVar2 = 0;
      do {
        *(undefined8 *)(*param_1 + lVar2 * 8) = 0;
        lVar2 = lVar2 + 1;
      } while (lVar1 != lVar2);
    }
    param_1[3] = 0;
  }
  return;
}



// ========================================
// Function: FUN_0051b8c8
// Address: 0051b8c8
// ========================================

void FUN_0051b8c8(long param_1,char *param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6)

{
  long lVar1;
  ulong uVar2;
  size_t sVar3;
  undefined8 *puVar4;
  long *plVar5;
  uint uVar6;
  undefined1 local_80;
  undefined7 uStack_7f;
  undefined8 uStack_78;
  undefined8 local_70;
  long local_68;
  
  lVar1 = tpidr_el0;
  local_68 = *(long *)(lVar1 + 0x28);
  uVar2 = FUN_00448008();
  if ((uVar2 & 1) == 0) {
    plVar5 = *(long **)(param_1 + 0x1d58);
    if (plVar5 == (long *)0x0) {
      if (*(int *)(param_1 + 0x2018) != 0) {
        uVar6 = 0;
        do {
          FUN_0044c958(param_1 + 0xc68,&DAT_0018662c,4);
          uVar6 = uVar6 + 1;
        } while (uVar6 < *(uint *)(param_1 + 0x2018));
      }
      sVar3 = strlen(param_2);
      FUN_0044c958(param_1 + 0xc68,param_2,sVar3);
      *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
      FUN_0051bce4(param_1,param_3,param_4,param_5,param_6);
      local_80 = 10;
      FUN_0044c958(param_1 + 0xc68,&local_80,1);
      goto LAB_0051b980;
    }
    FUN_0051ba40(&local_80,param_2,param_3,param_4,param_5,param_6);
    FUN_0045c674(plVar5,plVar5[1] + 1);
    puVar4 = (undefined8 *)(*plVar5 + plVar5[1] * 0x18);
    puVar4[2] = local_70;
    puVar4[1] = uStack_78;
    *puVar4 = CONCAT71(uStack_7f,local_80);
    plVar5[1] = plVar5[1] + 1;
  }
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
LAB_0051b980:
  if (*(long *)(lVar1 + 0x28) == local_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051ba40
// Address: 0051ba40
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051ba40(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6)

{
  long lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  long lVar6;
  undefined1 *local_1158;
  undefined8 local_1150;
  undefined8 uStack_1148;
  undefined1 auStack_1140 [4096];
  undefined8 *local_140;
  long local_138;
  undefined8 uStack_130;
  undefined8 local_128 [24];
  long local_68;
  
  uVar3 = _UNK_001a1328;
  uVar2 = _DAT_001a1320;
  lVar1 = tpidr_el0;
  local_68 = *(long *)(lVar1 + 0x28);
  uStack_130 = _UNK_001a0d48;
  local_138 = _DAT_001a0d40;
  uStack_1148 = _UNK_001a1328;
  local_1150 = _DAT_001a1320;
  local_1158 = auStack_1140;
  local_140 = local_128;
                    /* try { // try from 0051bac0 to 0051bafb has its CatchHandler @ 0051bb98 */
  uVar4 = __strlen_chk(param_2,0xffffffffffffffff);
  FUN_0044c958(&local_1158,param_2,uVar4);
  FUN_0051bbc0(&local_1158,param_3,param_4,param_5,param_6);
  FUN_0044c6fc(param_1,&local_1158);
  if (local_138 != 0) {
    lVar6 = local_138 * 0x18;
    puVar5 = local_140;
    do {
      if ((undefined1 *)*puVar5 != auStack_1140) {
        free((undefined1 *)*puVar5);
      }
      lVar6 = lVar6 + -0x18;
      puVar5 = puVar5 + 3;
    } while (lVar6 != 0);
  }
  if (local_1158 != auStack_1140) {
    free(local_1158);
  }
  local_138 = 0;
  uStack_1148 = uVar3;
  local_1150 = uVar2;
  local_1158 = auStack_1140;
  if (local_140 != local_128) {
    free(local_140);
  }
  if (*(long *)(lVar1 + 0x28) == local_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051bbc0
// Address: 0051bbc0
// ========================================

void FUN_0051bbc0(undefined8 param_1,undefined4 *param_2,char *param_3,byte *param_4,char *param_5)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  void *pvVar4;
  size_t sVar5;
  byte local_60 [8];
  ulong local_58;
  void *local_50;
  long local_48;
  
  lVar3 = tpidr_el0;
  local_48 = *(long *)(lVar3 + 0x28);
  FUN_00562e2c(local_60,*param_2);
  uVar1 = (ulong)(local_60[0] >> 1);
  pvVar4 = (void *)((ulong)local_60 | 1);
  if ((local_60[0] & 1) != 0) {
    uVar1 = local_58;
    pvVar4 = local_50;
  }
                    /* try { // try from 0051bc24 to 0051bc2b has its CatchHandler @ 0051bcb4 */
  FUN_0044c958(param_1,pvVar4,uVar1);
  if ((local_60[0] & 1) != 0) {
    free(local_50);
  }
  sVar5 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar5);
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar5 = strlen(param_5);
  FUN_0044c958(param_1,param_5,sVar5);
  if (*(long *)(lVar3 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051bce4
// Address: 0051bce4
// ========================================

void FUN_0051bce4(long param_1,undefined4 *param_2,char *param_3,byte *param_4,char *param_5)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  void *pvVar4;
  size_t sVar5;
  byte local_60 [8];
  ulong local_58;
  void *local_50;
  long local_48;
  
  lVar3 = tpidr_el0;
  local_48 = *(long *)(lVar3 + 0x28);
  FUN_00562e2c(local_60,*param_2);
  uVar1 = (ulong)(local_60[0] >> 1);
  pvVar4 = (void *)((ulong)local_60 | 1);
  if ((local_60[0] & 1) != 0) {
    uVar1 = local_58;
    pvVar4 = local_50;
  }
                    /* try { // try from 0051bd48 to 0051bd4f has its CatchHandler @ 0051be08 */
  FUN_0044c958(param_1 + 0xc68,pvVar4,uVar1);
  if ((local_60[0] & 1) != 0) {
    free(local_50);
  }
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar5 = strlen(param_3);
  FUN_0044c958(param_1 + 0xc68,param_3,sVar5);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  uVar1 = *(ulong *)(param_4 + 8);
  pbVar2 = *(byte **)(param_4 + 0x10);
  if ((*param_4 & 1) == 0) {
    pbVar2 = param_4 + 1;
    uVar1 = (ulong)(*param_4 >> 1);
  }
  FUN_0044c958(param_1 + 0xc68,pbVar2,uVar1);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  sVar5 = strlen(param_5);
  FUN_0044c958(param_1 + 0xc68,param_5,sVar5);
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
  if (*(long *)(lVar3 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051be38
// Address: 0051be38
// ========================================

void FUN_0051be38(void)

{
  return;
}



// ========================================
// Function: free
// Address: 0051be3c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_0051be40
// Address: 0051be40
// ========================================

void FUN_0051be40(long param_1)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x20);
  uVar4 = *(undefined8 *)(param_1 + 0x10);
  uVar3 = *(undefined8 *)(param_1 + 8);
  uVar2 = *(undefined8 *)(param_1 + 0x18);
  *puVar1 = &PTR_FUN_005be9d0;
  puVar1[2] = uVar4;
  puVar1[1] = uVar3;
  puVar1[3] = uVar2;
  return;
}



// ========================================
// Function: FUN_0051be80
// Address: 0051be80
// ========================================

void FUN_0051be80(long param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  undefined8 uVar2;
  
  *param_2 = &PTR_FUN_005be9d0;
  uVar2 = *(undefined8 *)(param_1 + 0x10);
  uVar1 = *(undefined8 *)(param_1 + 8);
  param_2[3] = *(undefined8 *)(param_1 + 0x18);
  param_2[2] = uVar2;
  param_2[1] = uVar1;
  return;
}



// ========================================
// Function: FUN_0051bea0
// Address: 0051bea0
// ========================================

void FUN_0051bea0(void)

{
  return;
}



// ========================================
// Function: free
// Address: 0051bea4
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_0051bea8
// Address: 0051bea8
// ========================================

void FUN_0051bea8(long param_1)

{
  int iVar1;
  long lVar2;
  long lVar3;
  long lVar4;
  uint local_70 [4];
  void *local_60;
  undefined *local_58;
  byte local_50 [16];
  void *local_40;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  lVar4 = *(long *)(param_1 + 8);
  if (((*(char *)(lVar4 + 0x1d70) == '\0') || (299 < *(uint *)(lVar4 + 0x1d6c))) &&
     ((*(char *)(lVar4 + 0x1d70) != '\0' || (0x81 < *(uint *)(lVar4 + 0x1d6c))))) {
    lVar3 = FUN_0044d194(*(long *)(lVar4 + 0x28) +
                         (ulong)*(uint *)(*(long *)(param_1 + 0x18) + 0xc) * 0x18);
    iVar1 = *(int *)(lVar3 + 0x18);
    FUN_00493ffc(local_50,lVar4,*(undefined4 *)(*(long *)(param_1 + 0x10) + 8),1);
    local_58 = (&PTR_FUN_005be1d0)[(long)iVar1 * 4];
                    /* try { // try from 0051bfd8 to 0051bfe7 has its CatchHandler @ 0051c038 */
    FUN_00493ffc(local_70,lVar4,*(undefined4 *)(*(long *)(param_1 + 0x18) + 8),1);
                    /* try { // try from 0051bfe8 to 0051c00b has its CatchHandler @ 0051c020 */
    FUN_0051c260(lVar4,local_50,&local_58,&DAT_00167550,local_70,&DAT_00159d47);
    if ((local_70[0] & 1) != 0) {
      free(local_60);
    }
  }
  else {
    FUN_00493ffc(local_50,lVar4,*(undefined4 *)(*(long *)(param_1 + 0x10) + 8),1);
                    /* try { // try from 0051bf18 to 0051bf4f has its CatchHandler @ 0051c048 */
    local_70[0] = FUN_0043db00(lVar4,*(undefined4 *)(*(long *)(param_1 + 0x18) + 8),0x1e);
    FUN_0051c0a0(lVar4,local_50,&DAT_00167550,"gl_LastFragData[",local_70,&DAT_0017870e);
  }
  if ((local_50[0] & 1) != 0) {
    free(local_40);
  }
  if (*(long *)(lVar2 + 0x28) == local_38) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051c078
// Address: 0051c078
// ========================================

long FUN_0051c078(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN11spirv_cross12CompilerGLSL50emit_inout_fragment_outputs_copy_to_subpass_inputsEvE3$_0") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_0051c094
// Address: 0051c094
// ========================================

undefined ** FUN_0051c094(void)

{
  return &PTR_PTR_005bea30;
}



// ========================================
// Function: FUN_0051c0a0
// Address: 0051c0a0
// ========================================

void FUN_0051c0a0(long param_1,byte *param_2,char *param_3,char *param_4,undefined8 param_5,
                 undefined8 param_6)

{
  byte *pbVar1;
  long lVar2;
  ulong uVar3;
  size_t sVar4;
  undefined8 *puVar5;
  long *plVar6;
  uint uVar7;
  undefined1 local_80;
  undefined7 uStack_7f;
  undefined8 uStack_78;
  undefined8 local_70;
  long local_68;
  
  lVar2 = tpidr_el0;
  local_68 = *(long *)(lVar2 + 0x28);
  uVar3 = FUN_00448008();
  if ((uVar3 & 1) == 0) {
    plVar6 = *(long **)(param_1 + 0x1d58);
    if (plVar6 == (long *)0x0) {
      if (*(int *)(param_1 + 0x2018) != 0) {
        uVar7 = 0;
        do {
          FUN_0044c958(param_1 + 0xc68,&DAT_0018662c,4);
          uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint *)(param_1 + 0x2018));
      }
      uVar3 = *(ulong *)(param_2 + 8);
      pbVar1 = *(byte **)(param_2 + 0x10);
      if ((*param_2 & 1) == 0) {
        pbVar1 = param_2 + 1;
        uVar3 = (ulong)(*param_2 >> 1);
      }
      FUN_0044c958(param_1 + 0xc68,pbVar1,uVar3);
      *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
      sVar4 = strlen(param_3);
      FUN_0044c958(param_1 + 0xc68,param_3,sVar4);
      *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
      sVar4 = strlen(param_4);
      FUN_0044c958(param_1 + 0xc68,param_4,sVar4);
      *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
      FUN_00512b74(param_1,param_5,param_6);
      local_80 = 10;
      FUN_0044c958(param_1 + 0xc68,&local_80,1);
      goto LAB_0051c158;
    }
    FUN_0051c464(&local_80,param_2,param_3,param_4,param_5,param_6);
    FUN_0045c674(plVar6,plVar6[1] + 1);
    puVar5 = (undefined8 *)(*plVar6 + plVar6[1] * 0x18);
    puVar5[2] = local_70;
    puVar5[1] = uStack_78;
    *puVar5 = CONCAT71(uStack_7f,local_80);
    plVar6[1] = plVar6[1] + 1;
  }
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
LAB_0051c158:
  if (*(long *)(lVar2 + 0x28) == local_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051c260
// Address: 0051c260
// ========================================

void FUN_0051c260(long param_1,byte *param_2,undefined8 *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  byte *pbVar1;
  long lVar2;
  ulong uVar3;
  size_t sVar4;
  undefined8 *puVar5;
  char *__s;
  long *plVar6;
  uint uVar7;
  undefined1 local_80;
  undefined7 uStack_7f;
  undefined8 uStack_78;
  undefined8 local_70;
  long local_68;
  
  lVar2 = tpidr_el0;
  local_68 = *(long *)(lVar2 + 0x28);
  uVar3 = FUN_00448008();
  if ((uVar3 & 1) == 0) {
    plVar6 = *(long **)(param_1 + 0x1d58);
    if (plVar6 == (long *)0x0) {
      if (*(int *)(param_1 + 0x2018) != 0) {
        uVar7 = 0;
        do {
          FUN_0044c958(param_1 + 0xc68,&DAT_0018662c,4);
          uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint *)(param_1 + 0x2018));
      }
      uVar3 = *(ulong *)(param_2 + 8);
      pbVar1 = *(byte **)(param_2 + 0x10);
      if ((*param_2 & 1) == 0) {
        pbVar1 = param_2 + 1;
        uVar3 = (ulong)(*param_2 >> 1);
      }
      FUN_0044c958(param_1 + 0xc68,pbVar1,uVar3);
      *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
      __s = (char *)*param_3;
      sVar4 = strlen(__s);
      FUN_0044c958(param_1 + 0xc68,__s,sVar4);
      *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
      sVar4 = strlen(param_4);
      FUN_0044c958(param_1 + 0xc68,param_4,sVar4);
      *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
      uVar3 = *(ulong *)(param_5 + 8);
      pbVar1 = *(byte **)(param_5 + 0x10);
      if ((*param_5 & 1) == 0) {
        pbVar1 = param_5 + 1;
        uVar3 = (ulong)(*param_5 >> 1);
      }
      FUN_0044c958(param_1 + 0xc68,pbVar1,uVar3);
      *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
      sVar4 = strlen(param_6);
      FUN_0044c958(param_1 + 0xc68,param_6,sVar4);
      local_80 = 10;
      *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
      FUN_0044c958(param_1 + 0xc68,&local_80,1);
      goto LAB_0051c318;
    }
    FUN_0051c618(&local_80,param_2,param_3,param_4,param_5,param_6);
    FUN_0045c674(plVar6,plVar6[1] + 1);
    puVar5 = (undefined8 *)(*plVar6 + plVar6[1] * 0x18);
    puVar5[2] = local_70;
    puVar5[1] = uStack_78;
    *puVar5 = CONCAT71(uStack_7f,local_80);
    plVar6[1] = plVar6[1] + 1;
  }
  *(int *)(param_1 + 0x2300) = *(int *)(param_1 + 0x2300) + 1;
LAB_0051c318:
  if (*(long *)(lVar2 + 0x28) == local_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051c464
// Address: 0051c464
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051c464(undefined8 param_1,byte *param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6)

{
  ulong uVar1;
  byte *pbVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  long lVar8;
  undefined1 *local_1158;
  undefined8 local_1150;
  undefined8 uStack_1148;
  undefined1 auStack_1140 [4096];
  undefined8 *local_140;
  long local_138;
  undefined8 uStack_130;
  undefined8 local_128 [24];
  long local_68;
  
  uVar5 = _UNK_001a1328;
  uVar4 = _DAT_001a1320;
  lVar3 = tpidr_el0;
  local_68 = *(long *)(lVar3 + 0x28);
  uStack_130 = _UNK_001a0d48;
  local_138 = _DAT_001a0d40;
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  uStack_1148 = _UNK_001a1328;
  local_1150 = _DAT_001a1320;
                    /* try { // try from 0051c4f8 to 0051c553 has its CatchHandler @ 0051c5f0 */
  local_1158 = auStack_1140;
  local_140 = local_128;
  FUN_0044c958(&local_1158,pbVar2,uVar1);
  uVar6 = __strlen_chk(param_3,0xffffffffffffffff);
  FUN_0044c958(&local_1158,param_3,uVar6);
  uVar6 = __strlen_chk(param_4,0xffffffffffffffff);
  FUN_0044c958(&local_1158,param_4,uVar6);
  FUN_005125fc(&local_1158,param_5,param_6);
  FUN_0044c6fc(param_1,&local_1158);
  if (local_138 != 0) {
    lVar8 = local_138 * 0x18;
    puVar7 = local_140;
    do {
      if ((undefined1 *)*puVar7 != auStack_1140) {
        free((undefined1 *)*puVar7);
      }
      lVar8 = lVar8 + -0x18;
      puVar7 = puVar7 + 3;
    } while (lVar8 != 0);
  }
  if (local_1158 != auStack_1140) {
    free(local_1158);
  }
  local_138 = 0;
  uStack_1148 = uVar5;
  local_1150 = uVar4;
  local_1158 = auStack_1140;
  if (local_140 != local_128) {
    free(local_140);
  }
  if (*(long *)(lVar3 + 0x28) == local_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051c618
// Address: 0051c618
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051c618(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  long lVar1;
  undefined8 *puVar2;
  long lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined1 *local_1138;
  undefined8 local_1130;
  undefined8 uStack_1128;
  undefined1 auStack_1120 [4096];
  undefined8 *local_120;
  long local_118;
  undefined8 uStack_110;
  undefined8 local_108 [24];
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  uStack_110 = _UNK_001a0d48;
  local_118 = _DAT_001a0d40;
  uStack_1128 = _UNK_001a1328;
  local_1130 = _DAT_001a1320;
                    /* try { // try from 0051c690 to 0051c6a3 has its CatchHandler @ 0051c738 */
  uVar4 = _DAT_001a1320;
  uVar5 = _UNK_001a1328;
  local_1138 = auStack_1120;
  local_120 = local_108;
  FUN_0051c760(&local_1138,param_2,param_3,param_4,param_5,param_6,param_8,param_9,_DAT_001a1320,
               _UNK_001a1328);
  FUN_0044c6fc(param_1,&local_1138);
  if (local_118 != 0) {
    lVar3 = local_118 * 0x18;
    puVar2 = local_120;
    do {
      if ((undefined1 *)*puVar2 != auStack_1120) {
        free((undefined1 *)*puVar2);
      }
      lVar3 = lVar3 + -0x18;
      puVar2 = puVar2 + 3;
    } while (lVar3 != 0);
  }
  if (local_1138 != auStack_1120) {
    free(local_1138);
  }
  local_118 = 0;
  local_1138 = auStack_1120;
  local_1130 = uVar4;
  uStack_1128 = uVar5;
  if (local_120 != local_108) {
    free(local_120);
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051c760
// Address: 0051c760
// ========================================

void FUN_0051c760(undefined8 param_1,byte *param_2,undefined8 *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  uVar1 = *(ulong *)(param_2 + 8);
  pbVar2 = *(byte **)(param_2 + 0x10);
  if ((*param_2 & 1) == 0) {
    pbVar2 = param_2 + 1;
    uVar1 = (ulong)(*param_2 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  __s = (char *)*param_3;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0051c820
// Address: 0051c820
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051c820(long *param_1,undefined8 *param_2,undefined8 *param_3)

{
  ulong uVar1;
  ulong *puVar2;
  size_t __n;
  undefined1 *__dest;
  ulong uVar3;
  char *__s;
  long lVar4;
  ulong uVar5;
  long lVar6;
  
  lVar6 = _UNK_001a0d48;
  lVar4 = _DAT_001a0d40;
  uVar3 = (long)param_3 - (long)param_2 >> 3;
  *param_1 = (long)(param_1 + 3);
  param_1[2] = lVar6;
  param_1[1] = lVar4;
  FUN_0045c674(param_1,uVar3);
  if (param_3 != param_2) {
    lVar4 = 0;
    uVar5 = uVar3;
    if (uVar3 < 2) {
      uVar5 = 1;
    }
    do {
      __s = (char *)*param_2;
      lVar6 = *param_1;
      __n = strlen(__s);
      if (0xffffffffffffffef < __n) {
                    /* try { // try from 0051c924 to 0051c92b has its CatchHandler @ 0051c930 */
                    /* WARNING: Subroutine does not return */
        FUN_002d18a8(lVar6 + lVar4);
      }
      if (__n < 0x17) {
        __dest = (undefined1 *)(lVar6 + lVar4) + 1;
        *(undefined1 *)(lVar6 + lVar4) = (char)((int)__n << 1);
        if (__n != 0) goto LAB_0051c894;
      }
      else {
        uVar1 = (__n | 0xf) + 1;
                    /* try { // try from 0051c8e4 to 0051c8eb has its CatchHandler @ 0051c92c */
        __dest = (undefined1 *)FUN_005a5d4c(uVar1);
        puVar2 = (ulong *)(lVar6 + lVar4);
        puVar2[1] = __n;
        puVar2[2] = (ulong)__dest;
        *puVar2 = uVar1 | 1;
LAB_0051c894:
        memmove(__dest,__s,__n);
      }
      uVar5 = uVar5 - 1;
      param_2 = param_2 + 1;
      lVar4 = lVar4 + 0x18;
      __dest[__n] = 0;
    } while (uVar5 != 0);
  }
  param_1[1] = uVar3;
  return;
}



// ========================================
// Function: FUN_0051c934
// Address: 0051c934
// ========================================

undefined1  [16] FUN_0051c934(long *param_1,uint *param_2)

{
  uint uVar1;
  ulong uVar2;
  long *__ptr;
  long *plVar3;
  undefined8 uVar4;
  ulong uVar5;
  ulong uVar6;
  ulong uVar7;
  long lVar8;
  long lVar9;
  undefined2 uVar10;
  undefined1 auVar11 [16];
  
  __ptr = (long *)FUN_005a5d4c(0x18);
  uVar1 = *param_2;
  *(uint *)(__ptr + 2) = uVar1;
  *__ptr = 0;
  __ptr[1] = (ulong)uVar1;
                    /* try { // try from 0051c968 to 0051c96f has its CatchHandler @ 0051ca54 */
  plVar3 = (long *)FUN_0051ca68(param_1);
  if (plVar3 != (long *)0x0) {
    free(__ptr);
    uVar4 = 0;
    __ptr = plVar3;
    goto LAB_0051ca40;
  }
  uVar5 = param_1[1];
  uVar7 = __ptr[1];
  uVar4 = CONCAT17(POPCOUNT((char)(uVar5 >> 0x38)),
                   CONCAT16(POPCOUNT((char)(uVar5 >> 0x30)),
                            CONCAT15(POPCOUNT((char)(uVar5 >> 0x28)),
                                     CONCAT14(POPCOUNT((char)(uVar5 >> 0x20)),
                                              CONCAT13(POPCOUNT((char)(uVar5 >> 0x18)),
                                                       CONCAT12(POPCOUNT((char)(uVar5 >> 0x10)),
                                                                CONCAT11(POPCOUNT((char)(uVar5 >> 8)
                                                                                 ),
                                                                         POPCOUNT((char)uVar5)))))))
                  );
  uVar10 = NEON_uaddlv(uVar4,1);
  uVar6 = CONCAT62((int6)((ulong)uVar4 >> 0x10),uVar10) & 0xffffffff;
  if (uVar6 < 2) {
    uVar7 = uVar5 - 1 & uVar7;
  }
  else if (uVar5 <= uVar7) {
    uVar2 = 0;
    if (uVar5 != 0) {
      uVar2 = uVar7 / uVar5;
    }
    uVar7 = uVar7 - uVar2 * uVar5;
  }
  lVar8 = *param_1;
  plVar3 = *(long **)(lVar8 + uVar7 * 8);
  if (plVar3 == (long *)0x0) {
    plVar3 = param_1 + 2;
    lVar9 = *plVar3;
    *plVar3 = (long)__ptr;
    *__ptr = lVar9;
    *(long **)(lVar8 + uVar7 * 8) = plVar3;
    if (*__ptr != 0) {
      uVar7 = *(ulong *)(*__ptr + 8);
      if (uVar6 < 2) {
        uVar7 = uVar7 & uVar5 - 1;
      }
      else if (uVar5 <= uVar7) {
        uVar6 = 0;
        if (uVar5 != 0) {
          uVar6 = uVar7 / uVar5;
        }
        uVar7 = uVar7 - uVar6 * uVar5;
      }
      plVar3 = (long *)(*param_1 + uVar7 * 8);
      goto LAB_0051ca2c;
    }
  }
  else {
    *__ptr = *plVar3;
LAB_0051ca2c:
    *plVar3 = (long)__ptr;
  }
  uVar4 = 1;
  param_1[3] = param_1[3] + 1;
LAB_0051ca40:
  auVar11._8_8_ = uVar4;
  auVar11._0_8_ = __ptr;
  return auVar11;
}



// ========================================
// Function: FUN_0051ca68
// Address: 0051ca68
// ========================================

long * FUN_0051ca68(long *param_1,ulong param_2,int *param_3)

{
  ulong uVar1;
  long *plVar2;
  ulong uVar3;
  ulong uVar4;
  ulong uVar5;
  ulong uVar6;
  undefined2 uVar7;
  undefined8 uVar8;
  
  uVar6 = param_1[1];
  if (uVar6 != 0) {
    uVar8 = CONCAT17(POPCOUNT((char)(uVar6 >> 0x38)),
                     CONCAT16(POPCOUNT((char)(uVar6 >> 0x30)),
                              CONCAT15(POPCOUNT((char)(uVar6 >> 0x28)),
                                       CONCAT14(POPCOUNT((char)(uVar6 >> 0x20)),
                                                CONCAT13(POPCOUNT((char)(uVar6 >> 0x18)),
                                                         CONCAT12(POPCOUNT((char)(uVar6 >> 0x10)),
                                                                  CONCAT11(POPCOUNT((char)(uVar6 >> 
                                                  8)),POPCOUNT((char)uVar6))))))));
    uVar7 = NEON_uaddlv(uVar8,1);
    uVar4 = CONCAT62((int6)((ulong)uVar8 >> 0x10),uVar7) & 0xffffffff;
    if (uVar4 < 2) {
      uVar3 = uVar6 - 1 & param_2;
    }
    else {
      uVar3 = param_2;
      if (uVar6 <= param_2) {
        uVar3 = 0;
        if (uVar6 != 0) {
          uVar3 = param_2 / uVar6;
        }
        uVar3 = param_2 - uVar3 * uVar6;
      }
    }
    plVar2 = *(long **)(*param_1 + uVar3 * 8);
    if ((plVar2 != (long *)0x0) && (plVar2 = (long *)*plVar2, plVar2 != (long *)0x0)) {
      do {
        uVar5 = plVar2[1];
        if (uVar5 == param_2) {
          if ((int)plVar2[2] == *param_3) {
            return plVar2;
          }
        }
        else {
          if (uVar4 < 2) {
            uVar5 = uVar5 & uVar6 - 1;
          }
          else if (uVar6 <= uVar5) {
            uVar1 = 0;
            if (uVar6 != 0) {
              uVar1 = uVar5 / uVar6;
            }
            uVar5 = uVar5 - uVar1 * uVar6;
          }
          if (uVar5 != uVar3) break;
        }
        plVar2 = (long *)*plVar2;
      } while (plVar2 != (long *)0x0);
    }
  }
  if ((uVar6 != 0) && ((float)(param_1[3] + 1) <= *(float *)(param_1 + 4) * (float)uVar6)) {
    return (long *)0x0;
  }
  uVar4 = 1;
  if (2 < uVar6) {
    uVar4 = (ulong)((uVar6 & uVar6 - 1) != 0);
  }
  uVar4 = uVar4 | uVar6 << 1;
  uVar3 = (ulong)((float)(param_1[3] + 1) / *(float *)(param_1 + 4));
  if (uVar4 <= uVar3) {
    uVar4 = uVar3;
  }
  if (uVar4 - 1 == 0) {
    uVar4 = 2;
  }
  else if ((uVar4 & uVar4 - 1) != 0) {
    uVar4 = FUN_0055fe2c(uVar4);
    uVar6 = param_1[1];
  }
  if (uVar6 > uVar4 || uVar4 == uVar6) {
    if (uVar6 <= uVar4) {
      return (long *)0x0;
    }
    uVar3 = (ulong)((float)(ulong)param_1[3] / *(float *)(param_1 + 4));
    if ((uVar6 < 3) ||
       (uVar8 = CONCAT17(POPCOUNT((char)(uVar6 >> 0x38)),
                         CONCAT16(POPCOUNT((char)(uVar6 >> 0x30)),
                                  CONCAT15(POPCOUNT((char)(uVar6 >> 0x28)),
                                           CONCAT14(POPCOUNT((char)(uVar6 >> 0x20)),
                                                    CONCAT13(POPCOUNT((char)(uVar6 >> 0x18)),
                                                             CONCAT12(POPCOUNT((char)(uVar6 >> 0x10)
                                                                              ),
                                                                      CONCAT11(POPCOUNT((char)(uVar6
                                                                                              >> 8))
                                                                               ,POPCOUNT((char)uVar6
                                                                                        )))))))),
       uVar7 = NEON_uaddlv(uVar8,1), 1 < (uint)CONCAT62((int6)((ulong)uVar8 >> 0x10),uVar7))) {
      uVar3 = FUN_0055fe2c(uVar3);
    }
    else if (1 < uVar3) {
      uVar3 = 1L << (-LZCOUNT(uVar3 - 1) & 0x3fU);
    }
    if (uVar4 <= uVar3) {
      uVar4 = uVar3;
    }
    if (uVar6 <= uVar4) {
      return (long *)0x0;
    }
  }
  FUN_0042f7cc(param_1);
  return (long *)0x0;
}



// ========================================
// Function: FUN_0051cc50
// Address: 0051cc50
// ========================================

void FUN_0051cc50(uint *param_1,uint *param_2,long *param_3,long param_4,uint param_5)

{
  long lVar1;
  ulong uVar2;
  bool bVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  bool bVar7;
  uint *puVar8;
  long lVar9;
  ulong uVar10;
  ulong uVar11;
  uint uVar12;
  uint *puVar13;
  uint *puVar14;
  uint *puVar15;
  uint uVar16;
  uint uVar17;
  long lVar18;
  long lVar19;
  uint *puVar20;
  uint *puVar21;
  ulong uVar22;
  ulong uVar23;
  ulong uVar24;
  
LAB_0051cc80:
  do {
    puVar15 = param_1;
    uVar11 = (long)param_2 - (long)puVar15 >> 2;
    if (uVar11 - 2 == 0 || (long)uVar11 < 2) {
      if (uVar11 < 2) {
        return;
      }
      if (uVar11 == 2) {
        uVar12 = param_2[-1];
        uVar17 = *puVar15;
        uVar6 = *(uint *)(*param_3 + (ulong)uVar12 * 4);
        uVar16 = *(uint *)(*param_3 + (ulong)uVar17 * 4);
        bVar3 = (int)uVar12 < (int)uVar17;
        if (uVar6 != uVar16) {
          bVar3 = uVar16 < uVar6;
        }
        if (!bVar3) {
          return;
        }
        *puVar15 = uVar12;
        param_2[-1] = uVar17;
        return;
      }
    }
    else {
      if (uVar11 == 3) {
        uVar17 = *puVar15;
        uVar12 = puVar15[1];
        lVar9 = *param_3;
        uVar6 = param_2[-1];
        uVar16 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
        uVar4 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
        uVar5 = *(uint *)(lVar9 + (ulong)uVar6 * 4);
        bVar3 = (int)uVar12 < (int)uVar17;
        if (uVar16 != uVar4) {
          bVar3 = uVar4 < uVar16;
        }
        bVar7 = (int)uVar6 < (int)uVar12;
        if (uVar5 != uVar16) {
          bVar7 = uVar16 < uVar5;
        }
        if (bVar3) {
          if (bVar7) {
            *puVar15 = uVar6;
          }
          else {
            *puVar15 = uVar12;
            puVar15[1] = uVar17;
            uVar12 = param_2[-1];
            uVar6 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
            bVar3 = (int)uVar12 < (int)uVar17;
            if (uVar6 != uVar4) {
              bVar3 = uVar4 < uVar6;
            }
            if (!bVar3) {
              return;
            }
            puVar15[1] = uVar12;
          }
          param_2[-1] = uVar17;
          return;
        }
        if (!bVar7) {
          return;
        }
        puVar15[1] = uVar6;
        param_2[-1] = uVar12;
        uVar17 = *puVar15;
        uVar12 = puVar15[1];
        uVar6 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
        uVar16 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
        bVar3 = (int)uVar12 < (int)uVar17;
        if (uVar6 != uVar16) {
          bVar3 = uVar16 < uVar6;
        }
        if (!bVar3) {
          return;
        }
        *puVar15 = uVar12;
        puVar15[1] = uVar17;
        return;
      }
      if (uVar11 == 4) {
        FUN_0051dd40(puVar15,puVar15 + 1,puVar15 + 2,param_2 + -1,param_3);
        return;
      }
      if (uVar11 == 5) {
        FUN_0051dd40(puVar15,puVar15 + 1,puVar15 + 2,puVar15 + 3,param_3);
        uVar12 = param_2[-1];
        uVar17 = puVar15[3];
        lVar9 = *param_3;
        uVar6 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
        uVar16 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
        bVar3 = (int)uVar12 < (int)uVar17;
        if (uVar6 != uVar16) {
          bVar3 = uVar16 < uVar6;
        }
        if (!bVar3) {
          return;
        }
        puVar15[3] = uVar12;
        param_2[-1] = uVar17;
        uVar17 = puVar15[2];
        uVar12 = puVar15[3];
        uVar6 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
        uVar16 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
        bVar3 = (int)uVar12 < (int)uVar17;
        if (uVar6 != uVar16) {
          bVar3 = uVar16 < uVar6;
        }
        if (!bVar3) {
          return;
        }
        uVar16 = puVar15[1];
        puVar15[2] = uVar12;
        puVar15[3] = uVar17;
        uVar17 = *(uint *)(lVar9 + (ulong)uVar16 * 4);
        bVar3 = (int)uVar12 < (int)uVar16;
        if (uVar6 != uVar17) {
          bVar3 = uVar17 < uVar6;
        }
        if (!bVar3) {
          return;
        }
        uVar17 = *puVar15;
        puVar15[1] = uVar12;
        puVar15[2] = uVar16;
        uVar16 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
        bVar3 = (int)uVar12 < (int)uVar17;
        if (uVar6 != uVar16) {
          bVar3 = uVar16 < uVar6;
        }
        if (!bVar3) {
          return;
        }
        *puVar15 = uVar12;
        puVar15[1] = uVar17;
        return;
      }
    }
    if ((long)uVar11 < 0x18) {
      if ((param_5 & 1) == 0) {
        if (puVar15 == param_2) {
          return;
        }
        if (puVar15 + 1 == param_2) {
          return;
        }
        lVar9 = *param_3;
        puVar8 = puVar15 + 1;
        do {
          puVar14 = puVar8;
          uVar11 = (ulong)*puVar15;
          uVar17 = puVar15[1];
          uVar12 = *(uint *)(lVar9 + uVar11 * 4);
          uVar6 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
          bVar3 = (int)uVar17 < (int)*puVar15;
          if (uVar6 != uVar12) {
            bVar3 = uVar12 < uVar6;
          }
          puVar15 = puVar14;
          if (bVar3) {
            do {
              *puVar15 = (uint)uVar11;
              uVar11 = (ulong)puVar15[-2];
              puVar8 = puVar15 + -1;
              uVar12 = *(uint *)(lVar9 + uVar11 * 4);
              bVar3 = (int)uVar17 < (int)puVar15[-2];
              if (uVar6 != uVar12) {
                bVar3 = uVar12 < uVar6;
              }
              puVar15 = puVar8;
            } while (bVar3);
            *puVar8 = uVar17;
          }
          puVar8 = puVar14 + 1;
          puVar15 = puVar14;
        } while (puVar14 + 1 != param_2);
        return;
      }
      if (puVar15 == param_2) {
        return;
      }
      if (puVar15 + 1 == param_2) {
        return;
      }
      lVar19 = *param_3;
      lVar9 = 0;
      puVar8 = puVar15;
      puVar14 = puVar15 + 1;
      do {
        uVar11 = (ulong)*puVar8;
        uVar17 = puVar8[1];
        uVar12 = *(uint *)(lVar19 + uVar11 * 4);
        uVar6 = *(uint *)(lVar19 + (ulong)uVar17 * 4);
        bVar3 = (int)uVar17 < (int)*puVar8;
        if (uVar6 != uVar12) {
          bVar3 = uVar12 < uVar6;
        }
        lVar1 = lVar9;
        if (bVar3) {
          do {
            lVar18 = lVar1;
            *(int *)((long)puVar15 + lVar18 + 4) = (int)uVar11;
            puVar8 = puVar15;
            if (lVar18 == 0) goto LAB_0051d570;
            uVar12 = *(uint *)((long)puVar15 + lVar18 + -4);
            uVar11 = (ulong)uVar12;
            uVar16 = *(uint *)(lVar19 + uVar11 * 4);
            bVar3 = (int)uVar17 < (int)uVar12;
            if (uVar6 != uVar16) {
              bVar3 = uVar16 < uVar6;
            }
            lVar1 = lVar18 + -4;
          } while (bVar3);
          puVar8 = (uint *)((long)puVar15 + lVar18);
LAB_0051d570:
          *puVar8 = uVar17;
        }
        puVar13 = puVar14 + 1;
        lVar9 = lVar9 + 4;
        puVar8 = puVar14;
        puVar14 = puVar13;
        if (puVar13 == param_2) {
          return;
        }
      } while( true );
    }
    if (param_4 == 0) {
      if (puVar15 == param_2) {
        return;
      }
      uVar10 = uVar11 - 2 >> 1;
      lVar9 = *param_3;
      uVar24 = uVar10;
      do {
        if ((long)uVar24 <= (long)uVar10) {
          uVar23 = uVar24 << 1 | 1;
          uVar2 = uVar24 * 2 + 2;
          puVar8 = puVar15 + uVar23;
          uVar17 = *puVar8;
          puVar14 = puVar8;
          uVar22 = uVar23;
          uVar12 = uVar17;
          if ((long)uVar2 < (long)uVar11) {
            uVar6 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
            uVar12 = puVar8[1];
            uVar16 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
            bVar3 = (int)uVar17 < (int)uVar12;
            if (uVar6 != uVar16) {
              bVar3 = uVar16 < uVar6;
            }
            puVar14 = puVar8 + 1;
            uVar22 = uVar2;
            if (!bVar3) {
              puVar14 = puVar8;
              uVar22 = uVar23;
              uVar12 = uVar17;
            }
          }
          uVar6 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
          uVar17 = puVar15[uVar24];
          uVar16 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
          bVar3 = (int)uVar12 < (int)uVar17;
          if (uVar6 != uVar16) {
            bVar3 = uVar16 < uVar6;
          }
          puVar8 = puVar15 + uVar24;
          if (!bVar3) {
            do {
              puVar13 = puVar14;
              *puVar8 = uVar12;
              if ((long)uVar10 < (long)uVar22) break;
              uVar23 = uVar22 << 1 | 1;
              uVar2 = uVar22 * 2 + 2;
              puVar8 = puVar15 + uVar23;
              uVar6 = *puVar8;
              puVar14 = puVar8;
              uVar22 = uVar23;
              uVar12 = uVar6;
              if ((long)uVar2 < (long)uVar11) {
                uVar4 = *(uint *)(lVar9 + (ulong)uVar6 * 4);
                uVar12 = puVar8[1];
                uVar5 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
                bVar3 = (int)uVar6 < (int)uVar12;
                if (uVar4 != uVar5) {
                  bVar3 = uVar5 < uVar4;
                }
                puVar14 = puVar8 + 1;
                uVar22 = uVar2;
                if (!bVar3) {
                  puVar14 = puVar8;
                  uVar22 = uVar23;
                  uVar12 = uVar6;
                }
              }
              uVar6 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
              bVar3 = (int)uVar12 < (int)uVar17;
              if (uVar6 != uVar16) {
                bVar3 = uVar16 < uVar6;
              }
              puVar8 = puVar13;
            } while (!bVar3);
            *puVar13 = uVar17;
          }
        }
        bVar3 = uVar24 != 0;
        uVar24 = uVar24 - 1;
      } while (bVar3);
      do {
        uVar17 = *puVar15;
        lVar9 = *param_3;
        puVar8 = puVar15;
        uVar24 = 0;
        do {
          uVar2 = uVar24 << 1 | 1;
          uVar10 = uVar24 * 2 + 2;
          puVar13 = puVar8 + uVar24 + 1;
          uVar6 = *puVar13;
          puVar14 = puVar13;
          uVar23 = uVar2;
          uVar12 = uVar6;
          if ((long)uVar10 < (long)uVar11) {
            uVar12 = puVar8[uVar24 + 2];
            uVar16 = *(uint *)(lVar9 + (ulong)uVar6 * 4);
            uVar4 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
            bVar3 = (int)uVar6 < (int)uVar12;
            if (uVar16 != uVar4) {
              bVar3 = uVar4 < uVar16;
            }
            puVar14 = puVar8 + uVar24 + 2;
            uVar23 = uVar10;
            if (!bVar3) {
              puVar14 = puVar13;
              uVar23 = uVar2;
              uVar12 = uVar6;
            }
          }
          *puVar8 = uVar12;
          puVar8 = puVar14;
          uVar24 = uVar23;
        } while ((long)uVar23 <= (long)(uVar11 - 2 >> 1));
        param_2 = param_2 + -1;
        if (puVar14 == param_2) {
          *puVar14 = uVar17;
        }
        else {
          lVar19 = (long)puVar14 + (4 - (long)puVar15) >> 2;
          *puVar14 = *param_2;
          *param_2 = uVar17;
          if (1 < lVar19) {
            uVar24 = lVar19 - 2U >> 1;
            uVar17 = *puVar14;
            uVar6 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
            uVar12 = puVar15[uVar24];
            uVar10 = (ulong)uVar12;
            uVar16 = *(uint *)(lVar9 + uVar10 * 4);
            bVar3 = (int)uVar12 < (int)uVar17;
            if (uVar16 != uVar6) {
              bVar3 = uVar6 < uVar16;
            }
            puVar8 = puVar15 + uVar24;
            if (bVar3) {
              do {
                puVar13 = puVar8;
                *puVar14 = (uint)uVar10;
                if (uVar24 == 0) break;
                uVar24 = uVar24 - 1 >> 1;
                uVar12 = puVar15[uVar24];
                uVar10 = (ulong)uVar12;
                uVar16 = *(uint *)(lVar9 + uVar10 * 4);
                bVar3 = (int)uVar12 < (int)uVar17;
                if (uVar16 != uVar6) {
                  bVar3 = uVar6 < uVar16;
                }
                puVar14 = puVar13;
                puVar8 = puVar15 + uVar24;
              } while (bVar3);
              *puVar13 = uVar17;
            }
          }
        }
        bVar3 = (long)uVar11 < 3;
        uVar11 = uVar11 - 1;
        if (bVar3) {
          return;
        }
      } while( true );
    }
    lVar9 = *param_3;
    uVar17 = param_2[-1];
    puVar8 = puVar15 + (uVar11 >> 1);
    uVar12 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
    if (uVar11 < 0x81) {
      uVar6 = *puVar15;
      uVar16 = *puVar8;
      uVar4 = *(uint *)(lVar9 + (ulong)uVar6 * 4);
      uVar5 = *(uint *)(lVar9 + (ulong)uVar16 * 4);
      bVar3 = (int)uVar6 < (int)uVar16;
      if (uVar4 != uVar5) {
        bVar3 = uVar5 < uVar4;
      }
      bVar7 = (int)uVar17 < (int)uVar6;
      if (uVar12 != uVar4) {
        bVar7 = uVar4 < uVar12;
      }
      if (bVar3) {
        if (bVar7) {
          *puVar8 = uVar17;
        }
        else {
          *puVar8 = uVar6;
          *puVar15 = uVar16;
          uVar17 = param_2[-1];
          uVar12 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
          bVar3 = (int)uVar17 < (int)uVar16;
          if (uVar12 != uVar5) {
            bVar3 = uVar5 < uVar12;
          }
          if (!bVar3) goto LAB_0051d0bc;
          *puVar15 = uVar17;
        }
        param_2[-1] = uVar16;
      }
      else if (bVar7) {
        *puVar15 = uVar17;
        param_2[-1] = uVar6;
        uVar17 = *puVar15;
        uVar12 = *puVar8;
        uVar6 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
        uVar16 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
        bVar3 = (int)uVar17 < (int)uVar12;
        if (uVar6 != uVar16) {
          bVar3 = uVar16 < uVar6;
        }
        if (bVar3) {
          *puVar8 = uVar17;
          *puVar15 = uVar12;
        }
      }
    }
    else {
      uVar6 = *puVar8;
      uVar16 = *puVar15;
      uVar4 = *(uint *)(lVar9 + (ulong)uVar6 * 4);
      uVar5 = *(uint *)(lVar9 + (ulong)uVar16 * 4);
      bVar3 = (int)uVar6 < (int)uVar16;
      if (uVar4 != uVar5) {
        bVar3 = uVar5 < uVar4;
      }
      bVar7 = (int)uVar17 < (int)uVar6;
      if (uVar12 != uVar4) {
        bVar7 = uVar4 < uVar12;
      }
      if (bVar3) {
        if (bVar7) {
          *puVar15 = uVar17;
        }
        else {
          *puVar15 = uVar6;
          *puVar8 = uVar16;
          uVar17 = param_2[-1];
          uVar12 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
          bVar3 = (int)uVar17 < (int)uVar16;
          if (uVar12 != uVar5) {
            bVar3 = uVar5 < uVar12;
          }
          if (!bVar3) goto LAB_0051ce34;
          *puVar8 = uVar17;
        }
        param_2[-1] = uVar16;
      }
      else if (bVar7) {
        *puVar8 = uVar17;
        param_2[-1] = uVar6;
        uVar17 = *puVar8;
        uVar12 = *puVar15;
        uVar6 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
        uVar16 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
        bVar3 = (int)uVar17 < (int)uVar12;
        if (uVar6 != uVar16) {
          bVar3 = uVar16 < uVar6;
        }
        if (bVar3) {
          *puVar15 = uVar17;
          *puVar8 = uVar12;
        }
      }
LAB_0051ce34:
      uVar17 = puVar15[1];
      uVar12 = param_2[-2];
      puVar14 = puVar8 + -1;
      uVar6 = *puVar14;
      uVar16 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
      uVar4 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
      uVar5 = *(uint *)(lVar9 + (ulong)uVar6 * 4);
      bVar3 = (int)uVar6 < (int)uVar17;
      if (uVar5 != uVar16) {
        bVar3 = uVar16 < uVar5;
      }
      bVar7 = (int)uVar12 < (int)uVar6;
      if (uVar4 != uVar5) {
        bVar7 = uVar5 < uVar4;
      }
      if (bVar3) {
        if (bVar7) {
          puVar15[1] = uVar12;
        }
        else {
          puVar15[1] = uVar6;
          *puVar14 = uVar17;
          uVar12 = param_2[-2];
          uVar6 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
          bVar3 = (int)uVar12 < (int)uVar17;
          if (uVar6 != uVar16) {
            bVar3 = uVar16 < uVar6;
          }
          if (!bVar3) goto LAB_0051cf38;
          *puVar14 = uVar12;
        }
        param_2[-2] = uVar17;
      }
      else if (bVar7) {
        *puVar14 = uVar12;
        param_2[-2] = uVar6;
        uVar17 = *puVar14;
        uVar12 = puVar15[1];
        uVar6 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
        uVar16 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
        bVar3 = (int)uVar17 < (int)uVar12;
        if (uVar6 != uVar16) {
          bVar3 = uVar16 < uVar6;
        }
        if (bVar3) {
          puVar15[1] = uVar17;
          *puVar14 = uVar12;
        }
      }
LAB_0051cf38:
      puVar13 = puVar8 + 1;
      uVar6 = *puVar13;
      uVar17 = puVar15[2];
      uVar12 = param_2[-3];
      uVar16 = *(uint *)(lVar9 + (ulong)uVar6 * 4);
      uVar4 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
      uVar5 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
      bVar3 = (int)uVar6 < (int)uVar17;
      if (uVar16 != uVar4) {
        bVar3 = uVar4 < uVar16;
      }
      bVar7 = (int)uVar12 < (int)uVar6;
      if (uVar5 != uVar16) {
        bVar7 = uVar16 < uVar5;
      }
      if (bVar3) {
        if (bVar7) {
          puVar15[2] = uVar12;
        }
        else {
          puVar15[2] = uVar6;
          *puVar13 = uVar17;
          uVar12 = param_2[-3];
          uVar6 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
          bVar3 = (int)uVar12 < (int)uVar17;
          if (uVar6 != uVar4) {
            bVar3 = uVar4 < uVar6;
          }
          if (!bVar3) goto LAB_0051d000;
          *puVar13 = uVar12;
        }
        param_2[-3] = uVar17;
      }
      else if (bVar7) {
        *puVar13 = uVar12;
        param_2[-3] = uVar6;
        uVar17 = *puVar13;
        uVar12 = puVar15[2];
        uVar6 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
        uVar16 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
        bVar3 = (int)uVar17 < (int)uVar12;
        if (uVar6 != uVar16) {
          bVar3 = uVar16 < uVar6;
        }
        if (bVar3) {
          puVar15[2] = uVar17;
          *puVar13 = uVar12;
        }
      }
LAB_0051d000:
      uVar17 = *puVar8;
      uVar12 = *puVar14;
      uVar6 = *puVar13;
      uVar16 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
      uVar4 = *(uint *)(lVar9 + (ulong)uVar12 * 4);
      uVar5 = *(uint *)(lVar9 + (ulong)uVar6 * 4);
      bVar3 = (int)uVar17 < (int)uVar12;
      if (uVar16 != uVar4) {
        bVar3 = uVar4 < uVar16;
      }
      bVar7 = (int)uVar6 < (int)uVar17;
      if (uVar5 != uVar16) {
        bVar7 = uVar16 < uVar5;
      }
      if (bVar3) {
        uVar16 = uVar17;
        if (!bVar7) {
          *puVar14 = uVar17;
          *puVar8 = uVar12;
          bVar3 = (int)uVar6 < (int)uVar12;
          if (uVar5 != uVar4) {
            bVar3 = uVar4 < uVar5;
          }
          puVar14 = puVar8;
          uVar17 = uVar12;
          uVar16 = uVar6;
          if (!bVar3) goto LAB_0051d0b0;
        }
LAB_0051d0a8:
        *puVar14 = uVar6;
        *puVar13 = uVar12;
        uVar17 = uVar16;
      }
      else if (bVar7) {
        *puVar13 = uVar17;
        *puVar8 = uVar6;
        bVar3 = (int)uVar6 < (int)uVar12;
        if (uVar5 != uVar4) {
          bVar3 = uVar4 < uVar5;
        }
        puVar13 = puVar8;
        uVar17 = uVar6;
        uVar16 = uVar12;
        if (bVar3) goto LAB_0051d0a8;
      }
LAB_0051d0b0:
      uVar12 = *puVar15;
      *puVar15 = uVar17;
      *puVar8 = uVar12;
    }
LAB_0051d0bc:
    uVar17 = *puVar15;
    param_4 = param_4 + -1;
    param_1 = puVar15;
    if ((param_5 & 1) == 0) {
      uVar12 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
      uVar6 = *(uint *)(lVar9 + (ulong)puVar15[-1] * 4);
      bVar3 = (int)puVar15[-1] < (int)uVar17;
      if (uVar6 != uVar12) {
        bVar3 = uVar12 < uVar6;
      }
      if (!bVar3) {
        uVar6 = *(uint *)(lVar9 + (ulong)param_2[-1] * 4);
        bVar3 = (int)uVar17 < (int)param_2[-1];
        if (uVar12 != uVar6) {
          bVar3 = uVar6 < uVar12;
        }
        if (bVar3) {
          do {
            param_1 = param_1 + 1;
            uVar6 = *(uint *)(lVar9 + (ulong)*param_1 * 4);
            bVar3 = (int)uVar17 < (int)*param_1;
            if (uVar12 != uVar6) {
              bVar3 = uVar6 < uVar12;
            }
          } while (!bVar3);
        }
        else {
          do {
            param_1 = param_1 + 1;
            if (param_2 <= param_1) break;
            uVar6 = *(uint *)(lVar9 + (ulong)*param_1 * 4);
            bVar3 = (int)uVar17 < (int)*param_1;
            if (uVar12 != uVar6) {
              bVar3 = uVar6 < uVar12;
            }
          } while (!bVar3);
        }
        puVar8 = param_2;
        if (param_1 < param_2) {
          do {
            puVar8 = puVar8 + -1;
            uVar6 = *(uint *)(lVar9 + (ulong)*puVar8 * 4);
            bVar3 = (int)uVar17 < (int)*puVar8;
            if (uVar12 != uVar6) {
              bVar3 = uVar6 < uVar12;
            }
          } while (bVar3);
        }
        if (param_1 < puVar8) {
          uVar11 = (ulong)*param_1;
          uVar24 = (ulong)*puVar8;
          do {
            *param_1 = (uint)uVar24;
            *puVar8 = (uint)uVar11;
            do {
              param_1 = param_1 + 1;
              uVar11 = (ulong)*param_1;
              uVar6 = *(uint *)(lVar9 + uVar11 * 4);
              bVar3 = (int)uVar17 < (int)*param_1;
              if (uVar12 != uVar6) {
                bVar3 = uVar6 < uVar12;
              }
            } while (!bVar3);
            do {
              puVar8 = puVar8 + -1;
              uVar24 = (ulong)*puVar8;
              uVar6 = *(uint *)(lVar9 + uVar24 * 4);
              bVar3 = (int)uVar17 < (int)*puVar8;
              if (uVar12 != uVar6) {
                bVar3 = uVar6 < uVar12;
              }
            } while (bVar3);
          } while (param_1 < puVar8);
        }
        puVar8 = param_1 + -1;
        if (puVar8 != puVar15) {
          *puVar15 = *puVar8;
        }
        param_5 = 0;
        *puVar8 = uVar17;
        goto LAB_0051cc80;
      }
    }
    else {
      uVar12 = *(uint *)(lVar9 + (ulong)uVar17 * 4);
    }
    lVar19 = 0;
    do {
      lVar1 = lVar19 + 4;
      uVar6 = *(uint *)((long)puVar15 + lVar19 + 4);
      uVar11 = (ulong)uVar6;
      uVar16 = *(uint *)(lVar9 + uVar11 * 4);
      bVar3 = (int)uVar6 < (int)uVar17;
      if (uVar16 != uVar12) {
        bVar3 = uVar12 < uVar16;
      }
      lVar19 = lVar1;
    } while (bVar3);
    puVar8 = (uint *)((long)puVar15 + lVar1);
    puVar14 = param_2;
    if (lVar1 == 4) {
      do {
        if (puVar14 <= puVar8) break;
        puVar14 = puVar14 + -1;
        uVar6 = *(uint *)(lVar9 + (ulong)*puVar14 * 4);
        bVar3 = (int)*puVar14 < (int)uVar17;
        if (uVar6 != uVar12) {
          bVar3 = uVar12 < uVar6;
        }
      } while (!bVar3);
    }
    else {
      do {
        puVar14 = puVar14 + -1;
        uVar6 = *(uint *)(lVar9 + (ulong)*puVar14 * 4);
        bVar3 = (int)*puVar14 < (int)uVar17;
        if (uVar6 != uVar12) {
          bVar3 = uVar12 < uVar6;
        }
      } while (!bVar3);
    }
    if (puVar8 < puVar14) {
      uVar24 = (ulong)*puVar14;
      puVar20 = puVar8;
      puVar21 = puVar14;
      do {
        *puVar20 = (uint)uVar24;
        *puVar21 = (uint)uVar11;
        do {
          puVar13 = puVar20;
          puVar20 = puVar13 + 1;
          uVar11 = (ulong)*puVar20;
          uVar6 = *(uint *)(lVar9 + uVar11 * 4);
          bVar3 = (int)*puVar20 < (int)uVar17;
          if (uVar6 != uVar12) {
            bVar3 = uVar12 < uVar6;
          }
        } while (bVar3);
        do {
          puVar21 = puVar21 + -1;
          uVar24 = (ulong)*puVar21;
          uVar6 = *(uint *)(lVar9 + uVar24 * 4);
          bVar3 = (int)*puVar21 < (int)uVar17;
          if (uVar6 != uVar12) {
            bVar3 = uVar12 < uVar6;
          }
        } while (!bVar3);
      } while (puVar20 < puVar21);
    }
    else {
      puVar13 = puVar8 + -1;
    }
    if (puVar13 != puVar15) {
      *puVar15 = *puVar13;
    }
    *puVar13 = uVar17;
    if (puVar8 < puVar14) {
LAB_0051d250:
      FUN_0051cc50(puVar15,puVar13,param_3,param_4,param_5 & 1);
      param_5 = 0;
      param_1 = puVar13 + 1;
    }
    else {
      uVar11 = FUN_0051d974(puVar15,puVar13,param_3);
      uVar24 = FUN_0051d974(puVar13 + 1,param_2,param_3);
      if ((uVar24 & 1) == 0) {
        param_1 = puVar13 + 1;
        if ((uVar11 & 1) == 0) goto LAB_0051d250;
      }
      else {
        param_2 = puVar13;
        if ((uVar11 & 1) != 0) {
          return;
        }
      }
    }
  } while( true );
}



// ========================================
// Function: FUN_0051d974
// Address: 0051d974
// ========================================

/* WARNING: Type propagation algorithm not settling */

bool FUN_0051d974(uint *param_1,uint *param_2,long *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  long lVar7;
  bool bVar8;
  bool bVar9;
  ulong uVar10;
  long lVar11;
  int iVar12;
  uint *puVar13;
  uint *puVar14;
  long lVar15;
  uint *puVar16;
  long lVar17;
  uint *puVar18;
  
  uVar10 = (long)param_2 - (long)param_1 >> 2;
  if ((long)uVar10 < 3) {
    if (uVar10 < 2) {
      return true;
    }
    if (uVar10 == 2) {
      uVar2 = param_2[-1];
      uVar1 = *param_1;
      uVar3 = *(uint *)(*param_3 + (ulong)uVar2 * 4);
      uVar4 = *(uint *)(*param_3 + (ulong)uVar1 * 4);
      bVar8 = (int)uVar2 < (int)uVar1;
      if (uVar3 != uVar4) {
        bVar8 = uVar4 < uVar3;
      }
      if (!bVar8) {
        return true;
      }
      *param_1 = uVar2;
      param_2[-1] = uVar1;
      return true;
    }
  }
  else {
    if (uVar10 == 3) {
      uVar1 = *param_1;
      uVar2 = param_1[1];
      lVar11 = *param_3;
      uVar3 = param_2[-1];
      uVar4 = *(uint *)(lVar11 + (ulong)uVar2 * 4);
      uVar5 = *(uint *)(lVar11 + (ulong)uVar1 * 4);
      uVar6 = *(uint *)(lVar11 + (ulong)uVar3 * 4);
      bVar8 = (int)uVar2 < (int)uVar1;
      if (uVar4 != uVar5) {
        bVar8 = uVar5 < uVar4;
      }
      bVar9 = (int)uVar3 < (int)uVar2;
      if (uVar6 != uVar4) {
        bVar9 = uVar4 < uVar6;
      }
      if (bVar8) {
        if (bVar9) {
          *param_1 = uVar3;
        }
        else {
          *param_1 = uVar2;
          param_1[1] = uVar1;
          uVar2 = param_2[-1];
          uVar3 = *(uint *)(lVar11 + (ulong)uVar2 * 4);
          bVar8 = (int)uVar2 < (int)uVar1;
          if (uVar3 != uVar5) {
            bVar8 = uVar5 < uVar3;
          }
          if (!bVar8) {
            return true;
          }
          param_1[1] = uVar2;
        }
        param_2[-1] = uVar1;
        return true;
      }
      if (!bVar9) {
        return true;
      }
      param_1[1] = uVar3;
      param_2[-1] = uVar2;
      uVar1 = *param_1;
      uVar2 = param_1[1];
      uVar3 = *(uint *)(lVar11 + (ulong)uVar2 * 4);
      uVar4 = *(uint *)(lVar11 + (ulong)uVar1 * 4);
      bVar8 = (int)uVar2 < (int)uVar1;
      if (uVar3 != uVar4) {
        bVar8 = uVar4 < uVar3;
      }
      if (!bVar8) {
        return true;
      }
      *param_1 = uVar2;
      param_1[1] = uVar1;
      return true;
    }
    if (uVar10 == 4) {
      FUN_0051dd40(param_1,param_1 + 1,param_1 + 2,param_2 + -1,param_3);
      return true;
    }
    if (uVar10 == 5) {
      FUN_0051dd40(param_1,param_1 + 1,param_1 + 2,param_1 + 3,param_3);
      uVar2 = param_2[-1];
      uVar1 = param_1[3];
      lVar11 = *param_3;
      uVar3 = *(uint *)(lVar11 + (ulong)uVar2 * 4);
      uVar4 = *(uint *)(lVar11 + (ulong)uVar1 * 4);
      bVar8 = (int)uVar2 < (int)uVar1;
      if (uVar3 != uVar4) {
        bVar8 = uVar4 < uVar3;
      }
      if (!bVar8) {
        return true;
      }
      param_1[3] = uVar2;
      param_2[-1] = uVar1;
      uVar1 = param_1[2];
      uVar2 = param_1[3];
      uVar3 = *(uint *)(lVar11 + (ulong)uVar2 * 4);
      uVar4 = *(uint *)(lVar11 + (ulong)uVar1 * 4);
      bVar8 = (int)uVar2 < (int)uVar1;
      if (uVar3 != uVar4) {
        bVar8 = uVar4 < uVar3;
      }
      if (!bVar8) {
        return true;
      }
      uVar4 = param_1[1];
      param_1[2] = uVar2;
      param_1[3] = uVar1;
      uVar1 = *(uint *)(lVar11 + (ulong)uVar4 * 4);
      bVar8 = (int)uVar2 < (int)uVar4;
      if (uVar3 != uVar1) {
        bVar8 = uVar1 < uVar3;
      }
      if (!bVar8) {
        return true;
      }
      uVar1 = *param_1;
      param_1[1] = uVar2;
      param_1[2] = uVar4;
      uVar4 = *(uint *)(lVar11 + (ulong)uVar1 * 4);
      bVar8 = (int)uVar2 < (int)uVar1;
      if (uVar3 != uVar4) {
        bVar8 = uVar4 < uVar3;
      }
      if (!bVar8) {
        return true;
      }
      *param_1 = uVar2;
      param_1[1] = uVar1;
      return true;
    }
  }
  uVar1 = *param_1;
  lVar11 = *param_3;
  puVar13 = param_1 + 1;
  uVar2 = *puVar13;
  uVar4 = *(uint *)(lVar11 + (ulong)uVar1 * 4);
  puVar14 = param_1 + 2;
  uVar3 = *puVar14;
  uVar5 = *(uint *)(lVar11 + (ulong)uVar2 * 4);
  uVar6 = *(uint *)(lVar11 + (ulong)uVar3 * 4);
  bVar8 = (int)uVar2 < (int)uVar1;
  if (uVar5 != uVar4) {
    bVar8 = uVar4 < uVar5;
  }
  bVar9 = (int)uVar3 < (int)uVar2;
  if (uVar6 != uVar5) {
    bVar9 = uVar5 < uVar6;
  }
  puVar16 = param_1;
  if (bVar8) {
    puVar18 = puVar14;
    if (!bVar9) {
      *param_1 = uVar2;
      param_1[1] = uVar1;
      puVar16 = puVar13;
      bVar8 = (int)uVar3 < (int)uVar1;
      if (uVar6 != uVar4) {
        bVar8 = uVar4 < uVar6;
      }
      goto joined_r0x0051dc28;
    }
  }
  else {
    if (!bVar9) goto LAB_0051dc34;
    *puVar13 = uVar3;
    *puVar14 = uVar2;
    puVar18 = puVar13;
    bVar8 = (int)uVar3 < (int)uVar1;
    if (uVar6 != uVar4) {
      bVar8 = uVar4 < uVar6;
    }
joined_r0x0051dc28:
    if (!bVar8) goto LAB_0051dc34;
  }
  *puVar16 = uVar3;
  *puVar18 = uVar1;
LAB_0051dc34:
  if (param_1 + 3 != param_2) {
    iVar12 = 0;
    lVar15 = 0xc;
    puVar13 = param_1 + 3;
    do {
      puVar16 = puVar13;
      uVar1 = *puVar16;
      uVar10 = (ulong)*puVar14;
      uVar2 = *(uint *)(lVar11 + uVar10 * 4);
      uVar3 = *(uint *)(lVar11 + (ulong)uVar1 * 4);
      bVar8 = (int)uVar1 < (int)*puVar14;
      if (uVar3 != uVar2) {
        bVar8 = uVar2 < uVar3;
      }
      lVar17 = lVar15;
      if (bVar8) {
        do {
          lVar7 = lVar17 + -4;
          *(int *)((long)param_1 + lVar17) = (int)uVar10;
          puVar14 = param_1;
          if (lVar7 == 0) goto LAB_0051dc50;
          uVar2 = *(uint *)((long)param_1 + lVar17 + -8);
          uVar10 = (ulong)uVar2;
          uVar4 = *(uint *)(lVar11 + uVar10 * 4);
          bVar8 = (int)uVar1 < (int)uVar2;
          if (uVar3 != uVar4) {
            bVar8 = uVar4 < uVar3;
          }
          lVar17 = lVar7;
        } while (bVar8);
        puVar14 = (uint *)((long)param_1 + lVar7);
LAB_0051dc50:
        iVar12 = iVar12 + 1;
        *puVar14 = uVar1;
        if (iVar12 == 8) {
          return puVar16 + 1 == param_2;
        }
      }
      lVar15 = lVar15 + 4;
      puVar13 = puVar16 + 1;
      puVar14 = puVar16;
    } while (puVar16 + 1 != param_2);
  }
  return true;
}



// ========================================
// Function: FUN_0051dd40
// Address: 0051dd40
// ========================================

void FUN_0051dd40(uint *param_1,uint *param_2,uint *param_3,uint *param_4,long *param_5)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  bool bVar6;
  bool bVar7;
  long lVar8;
  uint uVar9;
  ulong uVar10;
  
  lVar8 = *param_5;
  uVar1 = *param_2;
  uVar2 = *param_1;
  uVar9 = *param_3;
  uVar3 = *(uint *)(lVar8 + (ulong)uVar1 * 4);
  uVar4 = *(uint *)(lVar8 + (ulong)uVar2 * 4);
  uVar5 = *(uint *)(lVar8 + (ulong)uVar9 * 4);
  bVar6 = (int)uVar1 < (int)uVar2;
  if (uVar3 != uVar4) {
    bVar6 = uVar4 < uVar3;
  }
  bVar7 = (int)uVar9 < (int)uVar1;
  if (uVar5 != uVar3) {
    bVar7 = uVar3 < uVar5;
  }
  if (bVar6) {
    if (bVar7) {
      *param_1 = uVar9;
    }
    else {
      *param_1 = uVar1;
      *param_2 = uVar2;
      uVar9 = *param_3;
      uVar10 = (ulong)uVar9;
      uVar1 = *(uint *)(lVar8 + uVar10 * 4);
      bVar6 = (int)uVar9 < (int)uVar2;
      if (uVar1 != uVar4) {
        bVar6 = uVar4 < uVar1;
      }
      if (!bVar6) goto LAB_0051de34;
      *param_2 = uVar9;
    }
    *param_3 = uVar2;
    uVar10 = (ulong)uVar2;
    uVar9 = uVar2;
  }
  else {
    uVar10 = (ulong)uVar9;
    if (bVar7) {
      *param_2 = uVar9;
      *param_3 = uVar1;
      uVar2 = *param_2;
      uVar3 = *param_1;
      uVar9 = *(uint *)(lVar8 + (ulong)uVar2 * 4);
      uVar4 = *(uint *)(lVar8 + (ulong)uVar3 * 4);
      bVar6 = (int)uVar2 < (int)uVar3;
      if (uVar9 != uVar4) {
        bVar6 = uVar4 < uVar9;
      }
      uVar10 = (ulong)uVar1;
      uVar9 = uVar1;
      if (bVar6) {
        *param_1 = uVar2;
        *param_2 = uVar3;
        uVar10 = (ulong)*param_3;
        uVar9 = *param_3;
      }
    }
  }
LAB_0051de34:
  uVar1 = *param_4;
  uVar2 = *(uint *)(lVar8 + uVar10 * 4);
  uVar3 = *(uint *)(lVar8 + (ulong)uVar1 * 4);
  bVar6 = (int)uVar1 < (int)uVar9;
  if (uVar3 != uVar2) {
    bVar6 = uVar2 < uVar3;
  }
  if (bVar6) {
    *param_3 = uVar1;
    *param_4 = uVar9;
    uVar1 = *param_3;
    uVar2 = *param_2;
    uVar9 = *(uint *)(lVar8 + (ulong)uVar1 * 4);
    uVar3 = *(uint *)(lVar8 + (ulong)uVar2 * 4);
    bVar6 = (int)uVar1 < (int)uVar2;
    if (uVar9 != uVar3) {
      bVar6 = uVar3 < uVar9;
    }
    if (bVar6) {
      *param_2 = uVar1;
      *param_3 = uVar2;
      uVar1 = *param_2;
      uVar2 = *param_1;
      uVar9 = *(uint *)(lVar8 + (ulong)uVar1 * 4);
      uVar3 = *(uint *)(lVar8 + (ulong)uVar2 * 4);
      bVar6 = (int)uVar1 < (int)uVar2;
      if (uVar9 != uVar3) {
        bVar6 = uVar3 < uVar9;
      }
      if (bVar6) {
        *param_1 = uVar1;
        *param_2 = uVar2;
      }
    }
  }
  return;
}



// ========================================
// Function: FUN_0051ded0
// Address: 0051ded0
// ========================================

void FUN_0051ded0(undefined8 param_1,char *param_2,undefined8 *param_3,char *param_4,byte *param_5,
                 char *param_6)

{
  ulong uVar1;
  byte *pbVar2;
  size_t sVar3;
  char *__s;
  
  sVar3 = strlen(param_2);
  FUN_0044c958(param_1,param_2,sVar3);
  __s = (char *)*param_3;
  sVar3 = strlen(__s);
  FUN_0044c958(param_1,__s,sVar3);
  sVar3 = strlen(param_4);
  FUN_0044c958(param_1,param_4,sVar3);
  uVar1 = *(ulong *)(param_5 + 8);
  pbVar2 = *(byte **)(param_5 + 0x10);
  if ((*param_5 & 1) == 0) {
    pbVar2 = param_5 + 1;
    uVar1 = (ulong)(*param_5 >> 1);
  }
  FUN_0044c958(param_1,pbVar2,uVar1);
  sVar3 = strlen(param_6);
  FUN_0044c958(param_1,param_6,sVar3);
  return;
}



// ========================================
// Function: FUN_0051df90
// Address: 0051df90
// ========================================

void FUN_0051df90(undefined8 param_1,undefined4 *param_2,char *param_3,undefined8 param_4)

{
  ulong uVar1;
  long lVar2;
  void *pvVar3;
  size_t sVar4;
  byte local_60 [8];
  ulong local_58;
  void *local_50;
  long local_48;
  
  lVar2 = tpidr_el0;
  local_48 = *(long *)(lVar2 + 0x28);
  FUN_00562e2c(local_60,*param_2);
  uVar1 = (ulong)(local_60[0] >> 1);
  pvVar3 = (void *)((ulong)local_60 | 1);
  if ((local_60[0] & 1) != 0) {
    uVar1 = local_58;
    pvVar3 = local_50;
  }
                    /* try { // try from 0051dff0 to 0051dff7 has its CatchHandler @ 0051e054 */
  FUN_0044c958(param_1,pvVar3,uVar1);
  if ((local_60[0] & 1) != 0) {
    free(local_50);
  }
  sVar4 = strlen(param_3);
  FUN_0044c958(param_1,param_3,sVar4);
  FUN_004f4f90(param_1,param_4);
  if (*(long *)(lVar2 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_0051e084
// Address: 0051e084
// ========================================

void FUN_0051e084(undefined8 *param_1)

{
  param_1[1] = 0;
  *param_1 = 0;
  param_1[3] = 0;
  param_1[2] = 0;
  param_1[5] = 0;
  param_1[4] = 0;
  param_1[7] = 0;
  param_1[6] = 0;
  *(undefined4 *)((long)param_1 + 0x3c) = 0x3f800000;
  *(undefined4 *)(param_1 + 5) = 0x3f800000;
  *(undefined4 *)((long)param_1 + 0x14) = 0x3f800000;
  *(undefined4 *)param_1 = 0x3f800000;
  return;
}



// ========================================
// Function: FUN_0051e0a8
// Address: 0051e0a8
// ========================================

void FUN_0051e0a8(undefined8 *param_1,float *param_2,undefined8 *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  float fVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  float fVar30;
  float fVar31;
  float fVar32;
  
  fVar12 = *param_2;
  fVar1 = param_2[1];
  fVar7 = param_2[9];
  fVar24 = param_2[4];
  fVar6 = param_2[5];
  fVar8 = param_2[0xd];
  fVar32 = param_2[0xe];
  fVar2 = (float)param_1[2];
  fVar3 = (float)((ulong)param_1[2] >> 0x20);
  fVar4 = (float)param_1[3];
  fVar5 = (float)((ulong)param_1[3] >> 0x20);
  fVar9 = param_2[8];
  fVar18 = (float)*param_1;
  fVar21 = (float)((ulong)*param_1 >> 0x20);
  fVar22 = (float)param_1[1];
  fVar23 = (float)((ulong)param_1[1] >> 0x20);
  fVar13 = param_2[0xc];
  fVar10 = param_2[2];
  fVar29 = param_2[3];
  fVar25 = (float)param_1[4];
  fVar26 = (float)((ulong)param_1[4] >> 0x20);
  fVar27 = (float)param_1[5];
  fVar28 = (float)((ulong)param_1[5] >> 0x20);
  fVar30 = param_2[6];
  fVar11 = param_2[7];
  fVar19 = param_2[10];
  fVar31 = param_2[0xb];
  fVar14 = (float)param_1[6];
  fVar15 = (float)((ulong)param_1[6] >> 0x20);
  fVar16 = (float)param_1[7];
  fVar17 = (float)((ulong)param_1[7] >> 0x20);
  fVar20 = param_2[0xf];
  param_3[1] = CONCAT44(fVar5 * fVar1 + fVar23 * fVar12 + fVar28 * fVar10 + fVar17 * fVar29,
                        fVar4 * fVar1 + fVar22 * fVar12 + fVar27 * fVar10 + fVar16 * fVar29);
  *param_3 = CONCAT44(fVar3 * fVar1 + fVar21 * fVar12 + fVar26 * fVar10 + fVar15 * fVar29,
                      fVar2 * fVar1 + fVar18 * fVar12 + fVar25 * fVar10 + fVar14 * fVar29);
  param_3[3] = CONCAT44(fVar5 * fVar6 + fVar23 * fVar24 + fVar28 * fVar30 + fVar17 * fVar11,
                        fVar4 * fVar6 + fVar22 * fVar24 + fVar27 * fVar30 + fVar16 * fVar11);
  param_3[2] = CONCAT44(fVar3 * fVar6 + fVar21 * fVar24 + fVar26 * fVar30 + fVar15 * fVar11,
                        fVar2 * fVar6 + fVar18 * fVar24 + fVar25 * fVar30 + fVar14 * fVar11);
  param_3[5] = CONCAT44(fVar5 * fVar7 + fVar23 * fVar9 + fVar28 * fVar19 + fVar17 * fVar31,
                        fVar4 * fVar7 + fVar22 * fVar9 + fVar27 * fVar19 + fVar16 * fVar31);
  param_3[4] = CONCAT44(fVar3 * fVar7 + fVar21 * fVar9 + fVar26 * fVar19 + fVar15 * fVar31,
                        fVar2 * fVar7 + fVar18 * fVar9 + fVar25 * fVar19 + fVar14 * fVar31);
  param_3[7] = CONCAT44(fVar5 * fVar8 + fVar23 * fVar13 + fVar28 * fVar32 + fVar17 * fVar20,
                        fVar4 * fVar8 + fVar22 * fVar13 + fVar27 * fVar32 + fVar16 * fVar20);
  param_3[6] = CONCAT44(fVar3 * fVar8 + fVar21 * fVar13 + fVar26 * fVar32 + fVar15 * fVar20,
                        fVar2 * fVar8 + fVar18 * fVar13 + fVar25 * fVar32 + fVar14 * fVar20);
  return;
}



// ========================================
// Function: FUN_0051e124
// Address: 0051e124
// ========================================

bool FUN_0051e124(float *param_1,float *param_2)

{
  double dVar1;
  double dVar2;
  float fVar3;
  double dVar4;
  double dVar5;
  float fVar6;
  double dVar7;
  float fVar8;
  float fVar9;
  double dVar10;
  double dVar11;
  float fVar12;
  double dVar13;
  float fVar14;
  double dVar15;
  double dVar16;
  float fVar17;
  double dVar18;
  double dVar19;
  double dVar20;
  float fVar21;
  double dVar22;
  float fVar23;
  double dVar24;
  double dVar25;
  float fVar26;
  double dVar27;
  double dVar28;
  float fVar29;
  double dVar30;
  double dVar31;
  float fVar32;
  float fVar33;
  double dVar34;
  float fVar35;
  double dVar36;
  double dVar37;
  double dVar38;
  float fVar39;
  float fVar40;
  double dVar41;
  
  dVar1 = DAT_001a09d8;
  fVar6 = param_1[3];
  fVar21 = param_1[4];
  fVar14 = param_1[1];
  fVar8 = param_1[2];
  fVar29 = *param_1;
  fVar26 = param_1[0xc];
  fVar39 = param_1[0xd];
  fVar40 = param_1[9];
  fVar17 = param_1[5];
  fVar35 = param_1[8];
  fVar12 = param_1[10];
  fVar3 = param_1[0xb];
  fVar33 = param_1[6];
  fVar23 = param_1[7];
  fVar32 = param_1[0xe];
  fVar9 = param_1[0xf];
  dVar4 = (double)(fVar29 + fVar17 * -(fVar21 * fVar14));
  dVar7 = (double)(fVar29 + fVar33 * -(fVar21 * fVar8));
  dVar11 = (double)(fVar40 + fVar9 * -(fVar39 * fVar3));
  dVar16 = (double)(fVar35 + fVar9 * -(fVar26 * fVar3));
  dVar38 = (double)(fVar12 + fVar9 * -(fVar32 * fVar3));
  dVar36 = (double)(fVar29 + fVar23 * -(fVar21 * fVar6));
  dVar24 = (double)(fVar40 + fVar32 * -(fVar39 * fVar12));
  dVar27 = (double)(fVar35 + fVar39 * -(fVar26 * fVar40));
  dVar5 = (double)(fVar14 + fVar33 * -(fVar17 * fVar8));
  dVar15 = (double)(fVar14 + fVar23 * -(fVar17 * fVar6));
  dVar28 = (double)(fVar35 + fVar32 * -(fVar26 * fVar12));
  dVar20 = (double)(fVar8 + fVar23 * -(fVar33 * fVar6));
  dVar18 = ((-(dVar7 * dVar11) + dVar38 * dVar4 + dVar24 * dVar36 + dVar16 * dVar5) -
           dVar28 * dVar15) + dVar27 * dVar20;
  dVar2 = ABS(dVar18);
  if (dVar2 < DAT_001a09d8) {
    param_2[2] = 0.0;
    param_2[3] = 0.0;
    param_2[0] = 0.0;
    param_2[1] = 0.0;
    param_2[6] = 0.0;
    param_2[7] = 0.0;
    param_2[4] = 0.0;
    param_2[5] = 0.0;
    param_2[10] = 0.0;
    param_2[0xb] = 0.0;
    param_2[8] = 0.0;
    param_2[9] = 0.0;
    param_2[0xe] = 0.0;
    param_2[0xf] = 0.0;
    param_2[0xc] = 0.0;
    param_2[0xd] = 0.0;
    param_2[0xf] = 1.0;
    param_2[10] = 1.0;
    param_2[5] = 1.0;
    *param_2 = 1.0;
  }
  else {
    dVar30 = (double)fVar17;
    dVar25 = (double)fVar39;
    dVar18 = 1.0 / dVar18;
    dVar31 = (double)fVar8;
    dVar41 = (double)fVar33;
    dVar13 = (double)fVar12;
    dVar34 = (double)fVar32;
    dVar22 = (double)fVar23;
    dVar19 = (double)fVar6;
    dVar10 = (double)fVar9;
    dVar37 = (double)fVar3;
    *param_2 = (float)((-(dVar41 * dVar11) + dVar38 * dVar30 + dVar24 * dVar22) * dVar18);
    param_2[1] = (float)(((dVar31 * dVar11 + dVar38 * (double)-fVar14) - dVar24 * dVar19) * dVar18);
    param_2[4] = (float)(((dVar41 * dVar16 + dVar38 * (double)-fVar21) - dVar28 * dVar22) * dVar18);
    param_2[5] = (float)((-(dVar31 * dVar16) + dVar38 * (double)fVar29 + dVar28 * dVar19) * dVar18);
    param_2[2] = (float)((-(dVar34 * dVar15) + dVar20 * dVar25 + dVar5 * dVar10) * dVar18);
    param_2[3] = (float)(((dVar15 * dVar13 + dVar20 * (double)-fVar40) - dVar5 * dVar37) * dVar18);
    param_2[8] = (float)((-(dVar30 * dVar16) + dVar11 * (double)fVar21 + dVar27 * dVar22) * dVar18);
    param_2[9] = (float)((((double)fVar14 * dVar16 + dVar11 * (double)-fVar29) - dVar27 * dVar19) *
                        dVar18);
    param_2[6] = (float)(((dVar36 * dVar34 + dVar20 * (double)-fVar26) - dVar7 * dVar10) * dVar18);
    param_2[7] = (float)((-(dVar13 * dVar36) + dVar20 * (double)fVar35 + dVar7 * dVar37) * dVar18);
    param_2[0xc] = (float)(((dVar30 * dVar28 + dVar24 * (double)-fVar21) - dVar27 * dVar41) * dVar18
                          );
    param_2[0xd] = (float)((-((double)fVar14 * dVar28) + dVar24 * (double)fVar29 + dVar27 * dVar31)
                          * dVar18);
    param_2[0xe] = (float)(((dVar7 * dVar25 + dVar5 * (double)-fVar26) - dVar4 * dVar34) * dVar18);
    param_2[0xf] = (float)((-((double)fVar40 * dVar7) + dVar5 * (double)fVar35 + dVar4 * dVar13) *
                          dVar18);
    param_2[10] = (float)((-(dVar25 * dVar36) + dVar15 * (double)fVar26 + dVar4 * dVar10) * dVar18);
    param_2[0xb] = (float)(((dVar36 * (double)fVar40 + dVar15 * (double)-fVar35) - dVar4 * dVar37) *
                          dVar18);
  }
  return dVar1 <= dVar2;
}



// ========================================
// Function: FUN_0051e4a8
// Address: 0051e4a8
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051e4a8(undefined8 *param_1)

{
  ulong uVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  size_t sVar6;
  void *pvVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  char *pcVar10;
  long lVar11;
  long lVar12;
  ulong local_88;
  size_t sStack_80;
  void *local_78;
  undefined8 local_70;
  long local_68;
  
  lVar2 = tpidr_el0;
  local_68 = *(long *)(lVar2 + 0x28);
  param_1[1] = 0;
  *param_1 = param_1 + 1;
  param_1[4] = 0;
  param_1[3] = param_1 + 4;
  param_1[2] = 0;
  param_1[5] = 0;
  *(undefined1 *)(param_1 + 6) = 1;
                    /* try { // try from 0051e50c to 0051e513 has its CatchHandler @ 0051e854 */
  puVar5 = (undefined8 *)FUN_005a5d4c(0x38);
  lVar12 = 0;
  puVar5[6] = 0;
  param_1[7] = puVar5;
  puVar5[1] = 0;
  *puVar5 = 0;
  puVar5[3] = 0;
  puVar5[2] = 0;
  puVar5[5] = 0;
  puVar5[4] = 0;
  param_1[9] = 0;
  param_1[8] = 0;
  param_1[0xb] = 0;
  param_1[10] = 0;
  param_1[0xd] = 0;
  param_1[0xc] = 0;
  param_1[0xf] = 0;
  param_1[0xe] = 0;
  param_1[0x11] = 0;
  param_1[0x10] = 0;
  param_1[0x13] = 0;
  param_1[0x12] = 0;
  param_1[0x15] = 0;
  param_1[0x14] = 0;
  param_1[0x17] = 0;
  param_1[0x16] = 0;
  param_1[0x19] = 0;
  param_1[0x18] = 0;
  param_1[0x1b] = 0;
  param_1[0x1a] = 0;
  param_1[0x1d] = 0;
  param_1[0x1c] = 0;
  param_1[0x1f] = 0;
  param_1[0x1e] = 0;
  uVar4 = _UNK_001a1488;
  uVar3 = _DAT_001a1480;
  puVar5[3] = puVar5 + 4;
  param_1[0x21] = uVar4;
  param_1[0x20] = uVar3;
  uVar3 = DAT_001a09e0;
  *(undefined4 *)(param_1 + 0x23) = 0x44160000;
  *(undefined8 *)((long)param_1 + 0x11c) = 0;
  *(undefined8 *)((long)param_1 + 0x121) = 0;
  param_1[0x22] = uVar3;
  uVar4 = _UNK_001a1418;
  uVar3 = _DAT_001a1410;
  *(undefined4 *)((long)param_1 + 0x13c) = 0x44000000;
  *(undefined8 *)((long)param_1 + 0x134) = uVar4;
  *(undefined8 *)((long)param_1 + 300) = uVar3;
  param_1[0x28] = 0;
  do {
    pcVar10 = *(char **)((long)&PTR_s_cameraPosition_005bea58 + lVar12);
    lVar11 = param_1[7];
    sVar6 = strlen(pcVar10);
    if (0xffffffffffffffef < sVar6) {
      if (*(long *)(lVar2 + 0x28) == local_68) {
                    /* try { // try from 0051e830 to 0051e837 has its CatchHandler @ 0051e87c */
                    /* WARNING: Subroutine does not return */
        FUN_002d18a8(&local_88);
      }
      goto LAB_0051e8dc;
    }
    if (sVar6 < 0x17) {
      local_88 = CONCAT71(local_88._1_7_,(char)((int)sVar6 << 1));
      pvVar7 = (void *)((ulong)&local_88 | 1);
      if (sVar6 != 0) goto LAB_0051e610;
    }
    else {
      uVar1 = (sVar6 | 0xf) + 1;
                    /* try { // try from 0051e5f8 to 0051e5ff has its CatchHandler @ 0051e86c */
      pvVar7 = (void *)FUN_005a5d4c(uVar1);
      local_88 = uVar1 | 1;
      sStack_80 = sVar6;
      local_78 = pvVar7;
LAB_0051e610:
      memmove(pvVar7,pcVar10,sVar6);
    }
    *(undefined1 *)((long)pvVar7 + sVar6) = 0;
                    /* try { // try from 0051e624 to 0051e647 has its CatchHandler @ 0051e888 */
    puVar5 = (undefined8 *)FUN_002d63b8(lVar11 + 0x18,&local_70,&local_88);
    puVar9 = (undefined8 *)*puVar5;
    if (puVar9 == (undefined8 *)0x0) {
      puVar9 = (undefined8 *)FUN_005a5d4c(0x40);
      pvVar7 = local_78;
      sVar6 = sStack_80;
      sStack_80 = 0;
      local_78 = (void *)0x0;
      puVar9[6] = pvVar7;
      puVar9[5] = sVar6;
      puVar9[4] = local_88;
      local_88 = 0;
      *(undefined4 *)(puVar9 + 7) = 0;
      *puVar9 = 0;
      puVar9[1] = 0;
      puVar9[2] = local_70;
      *puVar5 = puVar9;
      puVar8 = puVar9;
      if (**(long **)(lVar11 + 0x18) != 0) {
        *(long *)(lVar11 + 0x18) = **(long **)(lVar11 + 0x18);
        puVar8 = (undefined8 *)*puVar5;
      }
      FUN_002c1c30(*(undefined8 *)(lVar11 + 0x20),puVar8);
      *(long *)(lVar11 + 0x28) = *(long *)(lVar11 + 0x28) + 1;
    }
    *(undefined4 *)(puVar9 + 7) = 3;
    if ((local_88 & 1) != 0) {
      free(local_78);
    }
    lVar12 = lVar12 + 8;
  } while (lVar12 != 0x70);
  lVar12 = 0;
  do {
    pcVar10 = *(char **)((long)&PTR_s_eyeBrightness_005beac8 + lVar12);
    lVar11 = param_1[7];
    sVar6 = strlen(pcVar10);
    if (0xffffffffffffffef < sVar6) {
      if (*(long *)(lVar2 + 0x28) == local_68) {
                    /* try { // try from 0051e84c to 0051e853 has its CatchHandler @ 0051e874 */
                    /* WARNING: Subroutine does not return */
        FUN_002d18a8(&local_88);
      }
      goto LAB_0051e8dc;
    }
    if (sVar6 < 0x17) {
      local_88 = CONCAT71(local_88._1_7_,(char)((int)sVar6 << 1));
      pvVar7 = (void *)((ulong)&local_88 | 1);
      if (sVar6 != 0) goto LAB_0051e73c;
    }
    else {
      uVar1 = (sVar6 | 0xf) + 1;
                    /* try { // try from 0051e724 to 0051e72b has its CatchHandler @ 0051e864 */
      pvVar7 = (void *)FUN_005a5d4c(uVar1);
      local_88 = uVar1 | 1;
      sStack_80 = sVar6;
      local_78 = pvVar7;
LAB_0051e73c:
      memmove(pvVar7,pcVar10,sVar6);
    }
    *(undefined1 *)((long)pvVar7 + sVar6) = 0;
                    /* try { // try from 0051e750 to 0051e773 has its CatchHandler @ 0051e884 */
    puVar5 = (undefined8 *)FUN_002d63b8(lVar11 + 0x18,&local_70,&local_88);
    puVar9 = (undefined8 *)*puVar5;
    if (puVar9 == (undefined8 *)0x0) {
      puVar9 = (undefined8 *)FUN_005a5d4c(0x40);
      pvVar7 = local_78;
      sVar6 = sStack_80;
      sStack_80 = 0;
      local_78 = (void *)0x0;
      puVar9[6] = pvVar7;
      puVar9[5] = sVar6;
      puVar9[4] = local_88;
      local_88 = 0;
      *(undefined4 *)(puVar9 + 7) = 0;
      *puVar9 = 0;
      puVar9[1] = 0;
      puVar9[2] = local_70;
      *puVar5 = puVar9;
      puVar8 = puVar9;
      if (**(long **)(lVar11 + 0x18) != 0) {
        *(long *)(lVar11 + 0x18) = **(long **)(lVar11 + 0x18);
        puVar8 = (undefined8 *)*puVar5;
      }
      FUN_002c1c30(*(undefined8 *)(lVar11 + 0x20),puVar8);
      *(long *)(lVar11 + 0x28) = *(long *)(lVar11 + 0x28) + 1;
    }
    *(undefined4 *)(puVar9 + 7) = 2;
    if ((local_88 & 1) != 0) {
      free(local_78);
    }
    lVar12 = lVar12 + 8;
  } while (lVar12 != 0x20);
  if (*(long *)(lVar2 + 0x28) == local_68) {
    return;
  }
LAB_0051e8dc:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051e8e0
// Address: 0051e8e0
// ========================================

void FUN_0051e8e0(undefined8 *param_1)

{
  long *plVar1;
  void *__ptr;
  undefined8 *__ptr_00;
  void *pvVar2;
  void *pvVar3;
  
  __ptr_00 = (undefined8 *)*param_1;
  *param_1 = 0;
  if (__ptr_00 == (undefined8 *)0x0) {
    return;
  }
  FUN_00265270(__ptr_00 + 3,__ptr_00[4]);
  pvVar2 = (void *)*__ptr_00;
  if (pvVar2 != (void *)0x0) {
    pvVar3 = (void *)__ptr_00[1];
    __ptr = pvVar2;
    if (pvVar3 != pvVar2) {
      do {
        plVar1 = *(long **)((long)pvVar3 + -8);
        *(undefined8 *)((long)pvVar3 + -8) = 0;
        if (plVar1 != (long *)0x0) {
          (**(code **)(*plVar1 + 8))();
        }
        pvVar3 = (void *)((long)pvVar3 + -0x10);
      } while (pvVar3 != pvVar2);
      __ptr = (void *)*__ptr_00;
    }
    __ptr_00[1] = pvVar2;
    free(__ptr);
  }
  free(__ptr_00);
  return;
}



// ========================================
// Function: FUN_0051e97c
// Address: 0051e97c
// ========================================

void FUN_0051e97c(long param_1)

{
  long *plVar1;
  void *__ptr;
  undefined8 *__ptr_00;
  void *pvVar2;
  void *pvVar3;
  
  __ptr_00 = *(undefined8 **)(param_1 + 0x38);
  *(undefined8 *)(param_1 + 0x38) = 0;
  if (__ptr_00 != (undefined8 *)0x0) {
    FUN_00265270(__ptr_00 + 3,__ptr_00[4]);
    pvVar2 = (void *)*__ptr_00;
    if (pvVar2 != (void *)0x0) {
      pvVar3 = (void *)__ptr_00[1];
      __ptr = pvVar2;
      if (pvVar3 != pvVar2) {
        do {
          plVar1 = *(long **)((long)pvVar3 + -8);
          *(undefined8 *)((long)pvVar3 + -8) = 0;
          if (plVar1 != (long *)0x0) {
            (**(code **)(*plVar1 + 8))();
          }
          pvVar3 = (void *)((long)pvVar3 + -0x10);
        } while (pvVar3 != pvVar2);
        __ptr = (void *)*__ptr_00;
      }
      __ptr_00[1] = pvVar2;
      free(__ptr);
    }
    free(__ptr_00);
  }
  FUN_0029b560(param_1 + 0x18,*(undefined8 *)(param_1 + 0x20));
  FUN_00527624(param_1,*(undefined8 *)(param_1 + 8));
  return;
}



// ========================================
// Function: FUN_0051ea24
// Address: 0051ea24
// ========================================

long FUN_0051ea24(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  long lVar2;
  undefined1 uStack_31;
  undefined8 local_30;
  long local_28;
  
  lVar1 = tpidr_el0;
  local_28 = *(long *)(lVar1 + 0x28);
  local_30 = param_2;
  lVar2 = FUN_00527674(param_1,param_2,PTR_DAT_005c5e10,&local_30,&uStack_31);
  if (*(long *)(lVar1 + 0x28) == local_28) {
    return lVar2 + 0x38;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051ea80
// Address: 0051ea80
// ========================================

void FUN_0051ea80(long param_1,long param_2)

{
  byte *pbVar1;
  ulong uVar2;
  ulong __n;
  long *plVar3;
  byte *pbVar4;
  byte *pbVar5;
  byte bVar6;
  long lVar7;
  long *plVar8;
  ulong uVar9;
  ulong uVar10;
  undefined **ppuVar11;
  long lVar12;
  ulong uVar13;
  void *pvVar14;
  long *plVar15;
  undefined ***pppuVar16;
  undefined4 uVar17;
  undefined **ppuVar18;
  byte *pbVar19;
  byte *pbVar20;
  byte *pbVar21;
  byte *pbVar22;
  long lVar23;
  byte *pbVar24;
  ulong *local_198;
  long *local_190;
  ulong local_188;
  ulong local_180;
  void *local_178;
  undefined1 uStack_169;
  ulong *local_168;
  undefined **local_160;
  long lStack_158;
  undefined ***local_140;
  undefined **local_130;
  long lStack_128;
  undefined ***local_110;
  byte *local_100;
  ulong local_f8;
  undefined **local_f0;
  long lStack_e8;
  undefined ***local_d0;
  undefined **local_c0;
  long lStack_b8;
  undefined ***local_a0;
  long local_90;
  undefined8 local_88;
  undefined8 uStack_80;
  long local_70;
  
  lVar7 = tpidr_el0;
  local_70 = *(long *)(lVar7 + 0x28);
  pbVar24 = *(byte **)(param_2 + 0x18);
  pbVar4 = *(byte **)(param_2 + 0x20);
  if (pbVar24 != pbVar4) {
    lVar23 = *(long *)(param_1 + 0x38);
    ppuVar18 = (undefined **)((ulong)&local_100 | 1);
LAB_0051eaf8:
    uVar13 = *(ulong *)(pbVar24 + 8);
    pbVar5 = *(byte **)(pbVar24 + 0x10);
    if ((*pbVar24 & 1) == 0) {
      pbVar5 = pbVar24 + 1;
      uVar13 = (ulong)(*pbVar24 >> 1);
    }
    uVar10 = uVar13;
    if (7 < uVar13) {
      uVar10 = 8;
    }
    if (uVar13 != 0) {
      pbVar1 = pbVar5 + uVar10;
      pbVar19 = pbVar1;
      pbVar22 = pbVar5;
LAB_0051eb30:
      pbVar20 = pbVar19;
      pbVar21 = pbVar22 + 7;
      do {
        pbVar22 = pbVar21 + -6;
        if (pbVar21[-7] == 0x75) {
          if (pbVar22 == pbVar1) goto LAB_0051ebf8;
          if (*pbVar22 == 0x6e) {
            if (pbVar21 + -5 == pbVar1) goto LAB_0051ebf8;
            if (pbVar21[-5] == 0x69) {
              if (pbVar21 + -4 == pbVar1) goto LAB_0051ebf8;
              if (pbVar21[-4] == 0x66) {
                if (pbVar21 + -3 == pbVar1) goto LAB_0051ebf8;
                if (pbVar21[-3] == 0x6f) {
                  if (pbVar21 + -2 == pbVar1) goto LAB_0051ebf8;
                  if (pbVar21[-2] == 0x72) {
                    if (pbVar21 + -1 == pbVar1) goto LAB_0051ebf8;
                    if (pbVar21[-1] == 0x6d) goto code_r0x0051ebe0;
                  }
                }
              }
            }
          }
        }
        else if (pbVar22 == pbVar1) goto LAB_0051ebf8;
        pbVar21 = pbVar21 + 1;
      } while( true );
    }
    goto LAB_0051eaec;
  }
  goto LAB_0051f384;
code_r0x0051ebe0:
  if (pbVar21 == pbVar1) goto LAB_0051ebf8;
  pbVar19 = pbVar21 + -7;
  if (*pbVar21 != 0x2e) {
    pbVar19 = pbVar20;
  }
  goto LAB_0051eb30;
LAB_0051ebf8:
  if ((pbVar20 == pbVar1) || (pbVar20 != pbVar5)) {
    if (8 < uVar13) {
      uVar13 = 9;
    }
    pbVar1 = pbVar5 + uVar13;
    pbVar19 = pbVar5;
    pbVar22 = pbVar1;
    while( true ) {
      do {
        do {
          do {
            do {
              do {
                do {
                  do {
                    pbVar20 = pbVar22;
                    pbVar21 = pbVar19 + 8;
                    while (pbVar19 = pbVar21 + -7, pbVar21[-8] != 0x76) {
                      pbVar21 = pbVar21 + 1;
                      if (pbVar19 == pbVar1) goto LAB_0051ecfc;
                    }
                    if (pbVar19 == pbVar1) goto LAB_0051ecfc;
                    pbVar22 = pbVar20;
                  } while (*pbVar19 != 0x61);
                  if (pbVar21 + -6 == pbVar1) goto LAB_0051ecfc;
                } while (pbVar21[-6] != 0x72);
                if (pbVar21 + -5 == pbVar1) goto LAB_0051ecfc;
              } while (pbVar21[-5] != 0x69);
              if (pbVar21 + -4 == pbVar1) goto LAB_0051ecfc;
            } while (pbVar21[-4] != 0x61);
            if (pbVar21 + -3 == pbVar1) goto LAB_0051ecfc;
          } while (pbVar21[-3] != 0x62);
          if (pbVar21 + -2 == pbVar1) goto LAB_0051ecfc;
        } while (pbVar21[-2] != 0x6c);
        if (pbVar21 + -1 == pbVar1) goto LAB_0051ecfc;
      } while (pbVar21[-1] != 0x65);
      if (pbVar21 == pbVar1) break;
      pbVar22 = pbVar21 + -8;
      if (*pbVar21 != 0x2e) {
        pbVar22 = pbVar20;
      }
    }
LAB_0051ecfc:
    if ((pbVar20 == pbVar1) || (pbVar20 != pbVar5)) goto LAB_0051eaec;
  }
  uVar9 = FUN_00561270(pbVar24,0x2e,0);
  uVar13 = uVar9 + 1;
  uVar10 = FUN_00561270(pbVar24,0x2e,uVar13);
  if (uVar10 == 0xffffffffffffffff) goto LAB_0051eaec;
  bVar6 = *pbVar24;
  uVar2 = (ulong)(bVar6 >> 1);
  if ((bVar6 & 1) != 0) {
    uVar2 = *(ulong *)(pbVar24 + 8);
  }
  if (uVar2 < uVar13) {
    if (*(long *)(lVar7 + 0x28) == local_70) {
                    /* WARNING: Subroutine does not return */
      FUN_002d64d0(&local_100);
    }
    goto LAB_0051f4e8;
  }
  pbVar5 = pbVar24 + 1;
  if ((bVar6 & 1) != 0) {
    pbVar5 = *(byte **)(pbVar24 + 0x10);
  }
  __n = uVar2 - uVar13;
  if (uVar10 + ~uVar9 <= uVar2 - uVar13) {
    __n = uVar10 + ~uVar9;
  }
  if (0xffffffffffffffef < __n) {
    if (*(long *)(lVar7 + 0x28) == local_70) {
                    /* WARNING: Subroutine does not return */
      FUN_002d18a8(&local_100);
    }
    goto LAB_0051f4e8;
  }
  if (__n < 0x17) {
    local_100 = (byte *)CONCAT71(local_100._1_7_,(char)((int)__n << 1));
    ppuVar11 = ppuVar18;
    if (__n != 0) goto LAB_0051edbc;
  }
  else {
    ppuVar11 = (undefined **)FUN_005a5d4c((__n | 0xf) + 1);
    local_100 = (byte *)((__n | 0xf) + 2);
    local_f8 = __n;
    local_f0 = ppuVar11;
LAB_0051edbc:
    memmove(ppuVar11,pbVar5 + uVar13,__n);
  }
  *(undefined1 *)((long)ppuVar11 + __n) = 0;
  bVar6 = *pbVar24;
  uVar13 = (ulong)(bVar6 >> 1);
  if ((bVar6 & 1) != 0) {
    uVar13 = *(ulong *)(pbVar24 + 8);
  }
  if (uVar13 <= uVar10) {
    if (*(long *)(lVar7 + 0x28) == local_70) {
                    /* try { // try from 0051f420 to 0051f427 has its CatchHandler @ 0051f4b8 */
                    /* WARNING: Subroutine does not return */
      FUN_002d64d0(&local_188);
    }
    goto LAB_0051f4e8;
  }
  uVar10 = uVar10 + 1;
  uVar9 = uVar13 - uVar10;
  pbVar5 = pbVar24 + 1;
  if ((bVar6 & 1) != 0) {
    pbVar5 = *(byte **)(pbVar24 + 0x10);
  }
  if (0xffffffffffffffef < uVar9) {
    if (*(long *)(lVar7 + 0x28) == local_70) {
                    /* try { // try from 0051f3cc to 0051f3d3 has its CatchHandler @ 0051f4b8 */
                    /* WARNING: Subroutine does not return */
      FUN_002d18a8(&local_188);
    }
    goto LAB_0051f4e8;
  }
  if (uVar9 < 0x17) {
    local_188 = CONCAT71(local_188._1_7_,(char)((int)uVar9 << 1));
    pvVar14 = (void *)((ulong)&local_188 | 1);
    if (uVar13 != uVar10) goto LAB_0051ee48;
  }
  else {
    uVar13 = (uVar9 | 0xf) + 1;
                    /* try { // try from 0051ee30 to 0051ee37 has its CatchHandler @ 0051f480 */
    pvVar14 = (void *)FUN_005a5d4c(uVar13);
    local_188 = uVar13 | 1;
    local_180 = uVar9;
    local_178 = pvVar14;
LAB_0051ee48:
    memmove(pvVar14,pbVar5 + uVar10,uVar9);
  }
  *(undefined1 *)((long)pvVar14 + uVar9) = 0;
  uVar13 = (ulong)local_100 >> 1 & 0x7f;
  if (((ulong)local_100 & 1) != 0) {
    uVar13 = local_f8;
  }
  if (uVar13 == 4) {
    ppuVar11 = ppuVar18;
    if (((ulong)local_100 & 1) != 0) {
      ppuVar11 = local_f0;
    }
    if (*(int *)ppuVar11 == 0x32636576) {
      uVar17 = 2;
    }
    else if (*(int *)ppuVar11 == 0x33636576) {
      uVar17 = 3;
    }
    else {
      uVar17 = 4;
      if (*(int *)ppuVar11 != 0x34636576) {
        uVar17 = 1;
      }
    }
  }
  else {
    uVar17 = 1;
  }
                    /* try { // try from 0051eeec to 0051ef07 has its CatchHandler @ 0051f484 */
  local_198 = &local_188;
  lVar12 = FUN_002d65ec(lVar23 + 0x18,&local_188,PTR_DAT_005c5e10,&local_198,&local_168);
  *(undefined4 *)(lVar12 + 0x38) = uVar17;
  if ((local_188 & 1) != 0) {
    free(local_178);
  }
  if (((ulong)local_100 & 1) != 0) {
    free(local_f0);
  }
LAB_0051eaec:
  pbVar24 = pbVar24 + 0x30;
  if (pbVar24 == pbVar4) goto LAB_0051ef30;
  goto LAB_0051eaf8;
code_r0x0051f05c:
  if (pbVar21 == pbVar1) goto LAB_0051f074;
  pbVar19 = pbVar21 + -7;
  if (*pbVar21 != 0x2e) {
    pbVar19 = pbVar20;
  }
  goto LAB_0051efac;
LAB_0051f074:
  if ((pbVar20 == pbVar1) || (pbVar20 != pbVar5)) {
    if (8 < uVar13) {
      uVar13 = 9;
    }
    pbVar1 = pbVar5 + uVar13;
    pbVar19 = pbVar5;
    pbVar22 = pbVar1;
    while( true ) {
      do {
        do {
          do {
            do {
              do {
                do {
                  do {
                    pbVar20 = pbVar22;
                    pbVar21 = pbVar19 + 8;
                    while (pbVar19 = pbVar21 + -7, pbVar21[-8] != 0x76) {
                      pbVar21 = pbVar21 + 1;
                      if (pbVar19 == pbVar1) goto LAB_0051f178;
                    }
                    if (pbVar19 == pbVar1) goto LAB_0051f178;
                    pbVar22 = pbVar20;
                  } while (*pbVar19 != 0x61);
                  if (pbVar21 + -6 == pbVar1) goto LAB_0051f178;
                } while (pbVar21[-6] != 0x72);
                if (pbVar21 + -5 == pbVar1) goto LAB_0051f178;
              } while (pbVar21[-5] != 0x69);
              if (pbVar21 + -4 == pbVar1) goto LAB_0051f178;
            } while (pbVar21[-4] != 0x61);
            if (pbVar21 + -3 == pbVar1) goto LAB_0051f178;
          } while (pbVar21[-3] != 0x62);
          if (pbVar21 + -2 == pbVar1) goto LAB_0051f178;
        } while (pbVar21[-2] != 0x6c);
        if (pbVar21 + -1 == pbVar1) goto LAB_0051f178;
      } while (pbVar21[-1] != 0x65);
      if (pbVar21 == pbVar1) break;
      pbVar22 = pbVar21 + -8;
      if (*pbVar21 != 0x2e) {
        pbVar22 = pbVar20;
      }
    }
LAB_0051f178:
    if ((pbVar20 == pbVar1) || (pbVar20 != pbVar5)) goto LAB_0051ef68;
  }
  lVar12 = FUN_00561270(pbVar24,0x2e,0);
  uVar13 = FUN_00561270(pbVar24,0x2e,lVar12 + 1);
  if (uVar13 == 0xffffffffffffffff) goto LAB_0051ef68;
  bVar6 = *pbVar24;
  uVar10 = (ulong)(bVar6 >> 1);
  if ((bVar6 & 1) != 0) {
    uVar10 = *(ulong *)(pbVar24 + 8);
  }
  if (uVar10 <= uVar13) {
    if (*(long *)(lVar7 + 0x28) == local_70) {
                    /* WARNING: Subroutine does not return */
      FUN_002d64d0(&local_188);
    }
    goto LAB_0051f4e8;
  }
  uVar13 = uVar13 + 1;
  uVar9 = uVar10 - uVar13;
  pbVar5 = pbVar24 + 1;
  if ((bVar6 & 1) != 0) {
    pbVar5 = *(byte **)(pbVar24 + 0x10);
  }
  if (0xffffffffffffffef < uVar9) {
    if (*(long *)(lVar7 + 0x28) == local_70) {
                    /* WARNING: Subroutine does not return */
      FUN_002d18a8(&local_188);
    }
    goto LAB_0051f4e8;
  }
  if (uVar9 < 0x17) {
    local_188 = CONCAT71(local_188._1_7_,(char)((int)uVar9 << 1));
    pvVar14 = (void *)((ulong)&local_188 | 1);
    if (uVar10 != uVar13) goto LAB_0051f228;
  }
  else {
    pvVar14 = (void *)FUN_005a5d4c((uVar9 | 0xf) + 1);
    local_188 = (uVar9 | 0xf) + 2;
    local_180 = uVar9;
    local_178 = pvVar14;
LAB_0051f228:
    memmove(pvVar14,pbVar5 + uVar13,uVar9);
  }
  local_168 = &local_188;
  local_110 = &local_130;
  local_100 = pbVar24 + 0x18;
  local_140 = &local_160;
  *(undefined1 *)((long)pvVar14 + uVar9) = 0;
  local_130 = &PTR_FUN_005bfdf8;
  local_160 = &PTR_FUN_005bfe88;
  local_f0 = &PTR_FUN_005bfdf8;
  local_c0 = &PTR_FUN_005bfe88;
  local_88 = 0;
  uStack_80 = 0;
                    /* try { // try from 0051f294 to 0051f2c3 has its CatchHandler @ 0051f49c */
  lStack_158 = lVar23;
  lStack_128 = param_1;
  lStack_e8 = param_1;
  local_d0 = &local_f0;
  lStack_b8 = lVar23;
  local_a0 = &local_c0;
  local_90 = lVar23 + 0x30;
  lVar12 = FUN_00527674(param_1,&local_188,PTR_DAT_005c5e10,&local_168,&uStack_169);
  local_198 = (ulong *)(lVar12 + 0x38);
  FUN_0051f4ec(&local_190,&local_100);
  plVar8 = local_190;
  plVar3 = *(long **)(lVar23 + 8);
  if (plVar3 < *(long **)(lVar23 + 0x10)) {
    plVar15 = plVar3 + 2;
    *plVar3 = (long)local_198;
    local_190 = (long *)0x0;
    plVar3[1] = (long)plVar8;
  }
  else {
                    /* try { // try from 0051f2f0 to 0051f2fb has its CatchHandler @ 0051f460 */
    plVar15 = (long *)FUN_00527ac8(lVar23,&local_198);
  }
  plVar3 = local_190;
  *(long **)(lVar23 + 8) = plVar15;
  local_190 = (long *)0x0;
  if (plVar3 != (long *)0x0) {
    (**(code **)(*plVar3 + 8))();
  }
  if (local_a0 == &local_c0) {
    lVar12 = 4;
    pppuVar16 = &local_c0;
LAB_0051f338:
    (*(code *)(*pppuVar16)[lVar12])();
  }
  else if (local_a0 != (undefined ***)0x0) {
    lVar12 = 5;
    pppuVar16 = local_a0;
    goto LAB_0051f338;
  }
  if (local_d0 == &local_f0) {
    lVar12 = 4;
    pppuVar16 = &local_f0;
LAB_0051f364:
    (*(code *)(*pppuVar16)[lVar12])();
  }
  else if (local_d0 != (undefined ***)0x0) {
    lVar12 = 5;
    pppuVar16 = local_d0;
    goto LAB_0051f364;
  }
  if ((local_188 & 1) != 0) {
    free(local_178);
  }
LAB_0051ef68:
  pbVar24 = pbVar24 + 0x30;
  if (pbVar24 == pbVar4) goto LAB_0051f384;
  goto LAB_0051ef74;
LAB_0051ef30:
  pbVar24 = *(byte **)(param_2 + 0x18);
  pbVar4 = *(byte **)(param_2 + 0x20);
  if (pbVar24 != pbVar4) {
LAB_0051ef74:
    uVar13 = *(ulong *)(pbVar24 + 8);
    pbVar5 = *(byte **)(pbVar24 + 0x10);
    if ((*pbVar24 & 1) == 0) {
      pbVar5 = pbVar24 + 1;
      uVar13 = (ulong)(*pbVar24 >> 1);
    }
    uVar10 = uVar13;
    if (7 < uVar13) {
      uVar10 = 8;
    }
    if (uVar13 != 0) {
      pbVar1 = pbVar5 + uVar10;
      pbVar19 = pbVar1;
      pbVar22 = pbVar5;
LAB_0051efac:
      pbVar20 = pbVar19;
      pbVar21 = pbVar22 + 7;
      do {
        pbVar22 = pbVar21 + -6;
        if (pbVar21[-7] == 0x75) {
          if (pbVar22 == pbVar1) goto LAB_0051f074;
          if (*pbVar22 == 0x6e) {
            if (pbVar21 + -5 == pbVar1) goto LAB_0051f074;
            if (pbVar21[-5] == 0x69) {
              if (pbVar21 + -4 == pbVar1) goto LAB_0051f074;
              if (pbVar21[-4] == 0x66) {
                if (pbVar21 + -3 == pbVar1) goto LAB_0051f074;
                if (pbVar21[-3] == 0x6f) {
                  if (pbVar21 + -2 == pbVar1) goto LAB_0051f074;
                  if (pbVar21[-2] == 0x72) {
                    if (pbVar21 + -1 == pbVar1) goto LAB_0051f074;
                    if (pbVar21[-1] == 0x6d) goto code_r0x0051f05c;
                  }
                }
              }
            }
          }
        }
        else if (pbVar22 == pbVar1) goto LAB_0051f074;
        pbVar21 = pbVar21 + 1;
      } while( true );
    }
    goto LAB_0051ef68;
  }
LAB_0051f384:
  if (*(long *)(lVar7 + 0x28) == local_70) {
    return;
  }
LAB_0051f4e8:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051f4ec
// Address: 0051f4ec
// ========================================

void FUN_0051f4ec(undefined8 *param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  ulong uVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 local_98;
  undefined **local_90 [4];
  undefined ***local_70;
  long local_58;
  
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  FUN_005222e4(param_1);
  puVar5 = (undefined8 *)*param_1;
                    /* try { // try from 0051f544 to 0051f54f has its CatchHandler @ 0051f618 */
  while (uVar3 = FUN_00522448(param_2,&DAT_0019164b), (uVar3 & 1) != 0) {
    *param_1 = 0;
                    /* try { // try from 0051f558 to 0051f563 has its CatchHandler @ 0051f5f8 */
    FUN_005222e4(&local_98,param_2);
    local_90[0] = &PTR_FUN_005bfd78;
    local_70 = local_90;
                    /* try { // try from 0051f56c to 0051f573 has its CatchHandler @ 0051f5d8 */
    puVar4 = (undefined8 *)FUN_005a5d4c(0x50);
    uVar2 = local_98;
    *puVar4 = &PTR_FUN_005bfd38;
    puVar4[1] = puVar5;
    *param_1 = puVar4;
    local_98 = 0;
    puVar4[3] = 0;
    puVar4[2] = 0;
    puVar4[7] = 0;
    puVar4[6] = 0;
    puVar4[9] = 0;
    puVar4[8] = 0;
    puVar5 = puVar4 + 4;
    puVar4[5] = 0;
    *puVar5 = 0;
    puVar4[2] = uVar2;
    puVar4[8] = puVar5;
    *puVar5 = &PTR_FUN_005bfd78;
    puVar5 = puVar4;
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0051f650
// Address: 0051f650
// ========================================

void FUN_0051f650(long param_1)

{
  long *plVar1;
  long *plVar2;
  long lVar3;
  
  plVar1 = *(long **)(param_1 + 0x60);
  plVar2 = (long *)(param_1 + 0x40);
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) goto LAB_0051f690;
    lVar3 = 5;
    plVar2 = plVar1;
  }
  (**(code **)(*plVar2 + lVar3 * 8))();
LAB_0051f690:
  plVar1 = *(long **)(param_1 + 0x30);
  plVar2 = (long *)(param_1 + 0x10);
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) {
      return;
    }
    lVar3 = 5;
    plVar2 = plVar1;
  }
                    /* WARNING: Could not recover jumptable at 0x0051f6c4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar2 + lVar3 * 8))();
  return;
}



// ========================================
// Function: FUN_0051f6d4
// Address: 0051f6d4
// ========================================

void FUN_0051f6d4(long param_1,uint param_2,uint param_3)

{
  *(float *)(param_1 + 0x138) = (float)param_2;
  *(float *)(param_1 + 0x13c) = (float)param_3;
  return;
}



// ========================================
// Function: FUN_0051f6e8
// Address: 0051f6e8
// ========================================

void FUN_0051f6e8(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 long param_5)

{
  *(undefined4 *)(param_5 + 0x104) = param_1;
  *(undefined4 *)(param_5 + 0x108) = param_2;
  *(undefined4 *)(param_5 + 0x10c) = param_3;
  *(undefined4 *)(param_5 + 0x110) = param_4;
  return;
}



// ========================================
// Function: FUN_0051f6fc
// Address: 0051f6fc
// ========================================

void FUN_0051f6fc(float param_1,float param_2,long param_3,undefined4 *param_4)

{
  uint uVar1;
  byte bVar2;
  bool bVar3;
  bool bVar4;
  uint uVar5;
  long *plVar6;
  uint uVar7;
  int iVar8;
  char cVar9;
  long lVar10;
  undefined8 uVar11;
  bool bVar12;
  bool bVar13;
  long lVar14;
  undefined4 uVar15;
  uint *puVar16;
  uint uVar17;
  double dVar18;
  long *plVar19;
  float *pfVar20;
  float *pfVar21;
  undefined8 *puVar22;
  float fVar23;
  float fVar24;
  undefined4 uVar25;
  double dVar26;
  double dVar27;
  double dVar28;
  float fVar29;
  float fVar30;
  double dVar31;
  double dVar32;
  float fVar33;
  float fVar34;
  float fVar35;
  float fVar36;
  float fVar37;
  float fVar38;
  float fVar39;
  double dVar40;
  undefined8 uVar41;
  float fVar42;
  undefined4 uVar43;
  float fVar44;
  float fVar45;
  float fVar46;
  float fVar47;
  float fVar48;
  float local_340;
  float fStack_33c;
  float local_338;
  float fStack_334;
  float local_330;
  float fStack_32c;
  double local_328;
  double dStack_320;
  double local_318;
  double dStack_310;
  double local_308;
  double dStack_300;
  double local_2f8;
  double dStack_2f0;
  double local_2e8;
  double dStack_2e0;
  double local_2d8;
  double dStack_2d0;
  double local_2c8;
  double dStack_2c0;
  double local_2b8;
  double dStack_2b0;
  double local_2a8;
  double dStack_2a0;
  double local_298;
  double dStack_290;
  double local_288;
  double dStack_280;
  double local_278;
  double dStack_270;
  double local_268;
  double dStack_260;
  double local_258;
  double dStack_250;
  double local_248;
  double dStack_240;
  double local_238;
  double dStack_230;
  double local_228;
  double dStack_220;
  double local_218;
  double dStack_210;
  double local_208;
  double dStack_200;
  double local_1f8;
  double dStack_1f0;
  long local_1e8;
  long lStack_1e0;
  long local_1d8;
  long lStack_1d0;
  long local_1c8;
  long lStack_1c0;
  long local_1b8;
  long lStack_1b0;
  long local_1a8;
  long lStack_1a0;
  undefined1 uStack_191;
  uint *local_190;
  uint local_188;
  char cStack_184;
  undefined2 uStack_183;
  char cStack_181;
  char cStack_180;
  char cStack_17f;
  undefined2 uStack_17e;
  uint uStack_17c;
  char cStack_178;
  undefined1 uStack_177;
  undefined6 uStack_176;
  undefined1 auStack_170 [64];
  undefined4 local_130;
  undefined8 local_12c;
  undefined8 uStack_124;
  ulong local_11c;
  undefined8 uStack_114;
  long local_10c;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  ulong local_f8;
  undefined1 auStack_f0 [64];
  long local_b0;
  
  lVar10 = tpidr_el0;
  local_b0 = *(long *)(lVar10 + 0x28);
  local_1e8 = param_3;
  lStack_1e0 = param_3;
  local_1d8 = param_3;
  lStack_1d0 = param_3;
  local_1c8 = param_3;
  lStack_1c0 = param_3;
  local_1b8 = param_3;
  lStack_1b0 = param_3;
  local_1a8 = param_3;
  lStack_1a0 = param_3;
  FUN_00521a8c(&local_1a8,"viewWidth");
  FUN_00521a8c(param_2,&local_1a8,"viewHeight");
  FUN_00521a8c(param_1 / param_2,&local_1a8,"aspectRatio");
  fVar29 = (float)param_4[0xc6];
  if (fVar29 <= 16.0) {
    fVar29 = 256.0;
  }
  FUN_00521a8c(0x3d4ccccd,&local_1a8,&DAT_0017ed88);
  FUN_00521a8c(fVar29,&local_1a8,&DAT_00186085);
  fVar39 = 256.0;
  if (256.0 <= fVar29 * 4.0) {
    fVar39 = fVar29 * 4.0;
  }
  *(float *)(param_3 + 0x100) = fVar39;
  FUN_00521a8c(param_4[0xe1],&local_1a8,"frameTime");
  fVar29 = (float)param_4[0xe1];
  *(float *)(*(long *)(param_3 + 0x38) + 0x30) = fVar29;
  dVar26 = *(double *)(param_3 + 0x140) + (double)fVar29;
  if (3600.0 <= dVar26) {
    dVar26 = dVar26 + -3600.0;
  }
  *(double *)(param_3 + 0x140) = dVar26;
  FUN_00521a8c((float)dVar26,&local_1a8,"frameTimeCounter");
  FUN_00521a8c((float)((int)param_4[0xe7] % 0xaff50),&local_1a8,"frameCounter");
  fVar39 = 0.0;
  uVar7 = param_4[0xe9];
  fVar29 = 12.0;
  if ((uVar7 & 2) != 0) {
    fVar29 = 0.0;
  }
  uVar1 = uVar7 & 6;
  fVar42 = (float)param_4[0xe4];
  if (uVar1 != 0) {
    fVar42 = fVar29;
  }
  fVar29 = fmodf(fVar42 + -6.0 + 4.8e+07,24000.0);
  fVar23 = fmodf(fVar42 / 24.0 + -0.25 + 1.0,1.0);
  dVar27 = DAT_005d7138;
  dVar26 = DAT_001a0840;
  if ((float)param_4[0xe5] <= 0.5) {
    fVar24 = (float)param_4[0xcb];
    fVar39 = fVar24 - DAT_0098d048;
    bVar2 = 0;
    if (0.0 <= fVar39) {
      bVar2 = DAT_0098d04c;
    }
    if ((bVar2 & fVar39 < 1.0) == 0) {
      fVar39 = (float)param_4[0xe1];
    }
    DAT_0098d04c = 1;
    dVar40 = (double)fVar39;
    dVar31 = DAT_005d7148 + dVar40;
    if ((uVar7 & 8) != 0) {
      dVar31 = 0.0;
    }
    DAT_005d7148 = dVar31;
    DAT_0098d048 = fVar24;
    if ((uVar1 != 0) || ((*(char *)(param_3 + 0x128) != '\0' && (5.0 <= dVar31)))) {
      bVar13 = false;
      if (((uVar7 >> 4 & 1) == 0) && (fVar39 = (float)param_4[0xc6], 0.0 < fVar39)) {
        if (2.0 <= fVar39 * (float)param_4[0xc4]) {
          bVar13 = 24.0 <= fVar39 * (float)param_4[0xc5];
        }
        else {
          bVar13 = false;
        }
      }
      fVar39 = (float)param_4[0xe6];
      bVar12 = false;
      if (0.98 <= fVar39) {
        bVar12 = bVar13;
      }
      bVar3 = false;
      if (fVar39 <= 0.02) {
        bVar3 = bVar13;
      }
      if (0.0 <= DAT_005d7138) {
LAB_0051fcf8:
        dVar26 = DAT_005d7138;
        if ((uVar1 != 0) || (DAT_0098d040 == 0)) {
LAB_0051fd84:
          dVar27 = dVar40 * 20.0;
          if (0.0 < DAT_0098d028) goto LAB_0051fd9c;
          DAT_005d7138 = dVar26;
          if (uVar1 != 0) goto LAB_005202a8;
          dVar18 = fmod(DAT_005d7138,24000.0);
          bVar13 = false;
          if (dVar18 < 12000.0) {
            bVar13 = bVar3;
          }
          if ((bVar13) || (((13000.0 <= dVar18 && (dVar18 < 23000.0)) && (bVar12)))) {
            DAT_0098d030 = DAT_0098d030 + dVar40;
            if (2.5 <= DAT_0098d030) {
              dVar28 = 600.0;
              if (!bVar12) {
                dVar28 = 16000.0;
              }
              DAT_0098d028 = fmod((dVar28 - dVar18) + 24000.0,24000.0);
              goto LAB_0051fe9c;
            }
          }
          else {
LAB_0051fe9c:
            DAT_0098d030 = 0.0;
          }
          bVar13 = false;
          if (23000.0 <= dVar18) {
            bVar13 = bVar3;
          }
          if (((bool)(bVar12 & (dVar18 < 13000.0 && 12000.0 <= dVar18))) || (bVar13)) {
            dVar27 = 0.0;
            DAT_0098d038 = DAT_0098d038 + dVar40;
            DAT_005d7138 = dVar26;
            if (DAT_0098d038 < 420.0) goto LAB_005202a8;
            DAT_0098d040 = -1;
            if (bVar12) {
              DAT_0098d040 = 1;
            }
          }
          DAT_0098d038 = 0.0;
          DAT_005d7138 = dVar26;
          goto LAB_005202a8;
        }
        bVar4 = bVar12;
        if (DAT_0098d040 < 1) {
          bVar4 = bVar3;
        }
        if (!bVar4) {
          if (!bVar13) goto LAB_0051fef0;
          DAT_0098d040 = 0;
          goto LAB_0051fd84;
        }
        dVar18 = 6000.0;
        if (DAT_0098d040 < 1) {
          dVar18 = 18000.0;
        }
        dVar28 = fmod(DAT_005d7138,24000.0);
        dVar27 = dVar40 * 8000.0;
        if (dVar18 - dVar28 <= dVar40 * 8000.0) {
          dVar27 = dVar18 - dVar28;
        }
        if (dVar27 <= -(dVar40 * 8000.0)) {
          dVar27 = -(dVar40 * 8000.0);
        }
        dVar27 = dVar26 + dVar27;
      }
      else {
        if (uVar1 == 0) {
          DAT_005d7140 = DAT_005d7140 - dVar40;
          if (DAT_005d7140 <= 0.0) {
            DAT_005d7138 = 3880.0;
            fVar24 = 0.5;
            if ((uVar7 & 0x10) != 0) {
              fVar24 = 0.02;
            }
            if (fVar39 < fVar24) {
              DAT_005d7138 = 18000.0;
            }
            goto LAB_0051fcf8;
          }
LAB_0051fef0:
          bVar13 = false;
          dVar27 = DAT_005d7138;
          goto joined_r0x0051fef8;
        }
        DAT_005d7138 = 0.0;
        dVar27 = dVar40 * 20.0;
        if (0.0 < DAT_0098d028) {
LAB_0051fd9c:
          dVar27 = dVar40 * 8000.0;
          if (DAT_0098d028 <= dVar40 * 8000.0) {
            dVar27 = DAT_0098d028;
          }
          DAT_0098d028 = DAT_0098d028 - dVar27;
          dVar27 = dVar40 * 20.0 + dVar27;
        }
LAB_005202a8:
        dVar27 = DAT_005d7138 + dVar27;
      }
      bVar13 = false;
      DAT_005d7138 = dVar27;
    }
    else {
      fVar24 = ABS((float)param_4[0xcd]);
      fVar39 = (float)param_4[0xe6];
      uVar17 = (uint)(0.98 <= fVar39);
      if (fVar39 <= 0.02) {
        uVar17 = 1;
      }
      uVar5 = 0;
      if (0.0 < (float)param_4[0xcd]) {
        uVar5 = (uint)((uVar7 & 0x10) == 0) &
                ((uVar7 >> 5 | (uint)((uVar7 & 8) == 0) | uVar17 | (uint)(0.34 <= fVar24)) ^
                0xffffffff);
      }
      if (0.0 <= DAT_005d7138) {
        dVar18 = dVar40 * 20.0;
        if (DAT_0098d028 <= 0.0) {
          if ((uVar7 >> 3 & 1) == 0) {
            DAT_005d7138 = dVar18 + DAT_005d7138;
            bVar13 = false;
            dVar27 = DAT_005d7138;
            goto joined_r0x0051ff50;
          }
          dVar40 = (double)fVar23 + -0.25;
          dVar40 = dVar40 - (double)(long)dVar40;
          sincos(dVar40 * DAT_001a0840,&dStack_1f0,&local_1f8);
          dVar28 = dVar40 - (((dVar40 * 2.0 + 0.5) - local_1f8 * 0.5) / 3.0 - dVar40) /
                            ((dStack_1f0 * dVar26 * 0.5 + 2.0) / 3.0);
          sincos(dVar28 * dVar26,&dStack_210,&local_218);
          dVar28 = dVar28 - (((dVar28 * 2.0 + 0.5) - local_218 * 0.5) / 3.0 - dVar40) /
                            ((dStack_210 * dVar26 * 0.5 + 2.0) / 3.0);
          sincos(dVar28 * dVar26,&dStack_230,&local_238);
          dVar28 = dVar28 - (((dVar28 * 2.0 + 0.5) - local_238 * 0.5) / 3.0 - dVar40) /
                            ((dStack_230 * dVar26 * 0.5 + 2.0) / 3.0);
          sincos(dVar28 * dVar26,&dStack_250,&local_258);
          dVar40 = fmod(((dVar28 - (((dVar28 * 2.0 + 0.5) - local_258 * 0.5) / 3.0 - dVar40) /
                                   ((dStack_250 * dVar26 * 0.5 + 2.0) / 3.0)) + 1.25) * 24000.0,
                        24000.0);
          dVar28 = fmod(dVar40 - dVar27,24000.0);
          dVar32 = (double)fVar23 + 0.5 + -0.25;
          dVar40 = dVar28 + 24000.0;
          if (-12000.0 <= dVar28) {
            dVar40 = dVar28;
          }
          if (12000.0 <= dVar28) {
            dVar40 = dVar28 + -24000.0;
          }
          dVar32 = dVar32 - (double)(long)dVar32;
          sincos(dVar32 * dVar26,&dStack_200,&local_208);
          dVar28 = dVar32 - (((dVar32 * 2.0 + 0.5) - local_208 * 0.5) / 3.0 - dVar32) /
                            ((dStack_200 * dVar26 * 0.5 + 2.0) / 3.0);
          sincos(dVar28 * dVar26,&dStack_220,&local_228);
          dVar28 = dVar28 - (((dVar28 * 2.0 + 0.5) - local_228 * 0.5) / 3.0 - dVar32) /
                            ((dStack_220 * dVar26 * 0.5 + 2.0) / 3.0);
          sincos(dVar28 * dVar26,&dStack_240,&local_248);
          dVar28 = dVar28 - (((dVar28 * 2.0 + 0.5) - local_248 * 0.5) / 3.0 - dVar32) /
                            ((dStack_240 * dVar26 * 0.5 + 2.0) / 3.0);
          sincos(dVar28 * dVar26,&dStack_260,&local_268);
          dVar26 = fmod(((dVar28 - (((dVar28 * 2.0 + 0.5) - local_268 * 0.5) / 3.0 - dVar32) /
                                   ((dStack_260 * dVar26 * 0.5 + 2.0) / 3.0)) + 1.25) * 24000.0,
                        24000.0);
          dVar28 = fmod(dVar26 - dVar27,24000.0);
          dVar26 = dVar28 + 24000.0;
          if (-12000.0 <= dVar28) {
            dVar26 = dVar28;
          }
          if (12000.0 <= dVar28) {
            dVar26 = dVar28 + -24000.0;
          }
          if ((uVar7 >> 5 & 1) == 0) {
            if (fVar24 < 0.34) {
              if ((ABS(dVar26) <= 600.0) && (ABS(dVar26) < ABS(dVar40))) {
                uVar17 = 1;
                goto LAB_005206d4;
              }
            }
            uVar17 = 0;
            if (1200.0 < ABS(dVar40)) {
              uVar17 = uVar5;
            }
            if (uVar17 == 0) {
              dVar26 = dVar40;
            }
          }
          else {
            uVar17 = 0;
            dVar26 = dVar40;
          }
LAB_005206d4:
          if (ABS(dVar26) <= 1200.0) {
            dVar28 = dVar18 * 1.5;
            dVar40 = 0.0;
            if (0.0 <= dVar18 + dVar26) {
              dVar40 = dVar18 + dVar26;
            }
            dVar18 = dVar28;
            if (dVar40 <= dVar28) {
              dVar18 = dVar40;
            }
          }
          else {
            DAT_0098d028 = dVar26;
            if (dVar26 <= 0.0) {
              DAT_0098d028 = dVar26 + 24000.0;
            }
          }
        }
        else {
          dVar26 = dVar40 * 8000.0;
          if (DAT_0098d028 <= dVar40 * 8000.0) {
            dVar26 = DAT_0098d028;
          }
          DAT_0098d028 = DAT_0098d028 - dVar26;
          dVar18 = dVar18 + dVar26;
          uVar17 = uVar5;
        }
        DAT_005d7138 = dVar27 + dVar18;
        if (uVar17 == 0) {
joined_r0x0051ff50:
          bVar13 = false;
          dVar26 = DAT_001a0840;
          dVar27 = DAT_005d7138;
        }
        else {
LAB_00520744:
          dVar27 = DAT_005d7138;
          fVar23 = fmodf(fVar23 + 0.5,1.0);
          bVar13 = true;
          dVar26 = DAT_001a0840;
        }
      }
      else {
        DAT_005d7140 = DAT_005d7140 - dVar40;
        if ((uVar7 >> 5 & uVar7 >> 3 & 1) == 0) {
          if ((DAT_005d7140 <= 0.0) && ((uVar7 >> 3 & 1) != 0)) {
            bVar13 = true;
            bVar12 = false;
            if (fVar24 < 0.2) {
              bVar13 = false;
              bVar12 = true;
              if (!NAN(fVar39)) {
                bVar13 = fVar39 < 0.98;
                bVar12 = false;
              }
            }
            if ((bVar13 != bVar12) && (0.34 <= fVar24 || (uVar7 & 0x10) == 0)) {
              dVar27 = (double)fVar23 + 0.5;
              if (uVar5 == 0) {
                dVar27 = (double)fVar23;
              }
              dVar27 = (dVar27 + -0.25) - (double)(long)(dVar27 + -0.25);
              sincos(dVar27 * DAT_001a0840,&dStack_270,&local_278);
              dVar40 = dVar27 - (((dVar27 * 2.0 + 0.5) - local_278 * 0.5) / 3.0 - dVar27) /
                                ((dStack_270 * dVar26 * 0.5 + 2.0) / 3.0);
              sincos(dVar40 * dVar26,&dStack_280,&local_288);
              dVar40 = dVar40 - (((dVar40 * 2.0 + 0.5) - local_288 * 0.5) / 3.0 - dVar27) /
                                ((dStack_280 * dVar26 * 0.5 + 2.0) / 3.0);
              sincos(dVar40 * dVar26,&dStack_290,&local_298);
              dVar40 = dVar40 - (((dVar40 * 2.0 + 0.5) - local_298 * 0.5) / 3.0 - dVar27) /
                                ((dStack_290 * dVar26 * 0.5 + 2.0) / 3.0);
              sincos(dVar40 * dVar26,&dStack_2a0,&local_2a8);
              DAT_005d7138 = fmod(((dVar40 - (((dVar40 * 2.0 + 0.5) - local_2a8 * 0.5) / 3.0 -
                                             dVar27) / ((dStack_2a0 * dVar26 * 0.5 + 2.0) / 3.0)) +
                                  1.25) * 24000.0,24000.0);
              if (uVar5 == 0) goto joined_r0x0051ff50;
              goto LAB_00520744;
            }
          }
          if (uVar5 != 0) goto LAB_00520744;
          bVar13 = false;
        }
        else {
          dVar27 = ((double)fVar23 + -0.25) - (double)(long)((double)fVar23 + -0.25);
          sincos(dVar27 * DAT_001a0840,&dStack_2b0,&local_2b8);
          dVar40 = dVar27 - (((dVar27 * 2.0 + 0.5) - local_2b8 * 0.5) / 3.0 - dVar27) /
                            ((dStack_2b0 * dVar26 * 0.5 + 2.0) / 3.0);
          sincos(dVar40 * dVar26,&dStack_2c0,&local_2c8);
          dVar40 = dVar40 - (((dVar40 * 2.0 + 0.5) - local_2c8 * 0.5) / 3.0 - dVar27) /
                            ((dStack_2c0 * dVar26 * 0.5 + 2.0) / 3.0);
          sincos(dVar40 * dVar26,&dStack_2d0,&local_2d8);
          dVar40 = dVar40 - (((dVar40 * 2.0 + 0.5) - local_2d8 * 0.5) / 3.0 - dVar27) /
                            ((dStack_2d0 * dVar26 * 0.5 + 2.0) / 3.0);
          sincos(dVar40 * dVar26,&dStack_2e0,&local_2e8);
          DAT_005d7138 = fmod(((dVar40 - (((dVar40 * 2.0 + 0.5) - local_2e8 * 0.5) / 3.0 - dVar27) /
                                         ((dStack_2e0 * dVar26 * 0.5 + 2.0) / 3.0)) + 1.25) *
                              24000.0,24000.0);
          bVar13 = false;
          dVar26 = DAT_001a0840;
          dVar27 = DAT_005d7138;
        }
      }
joined_r0x0051ff50:
      DAT_001a0840 = dVar26;
      if (dVar27 < 0.0) {
        dVar18 = ((double)fVar23 + -0.25) - (double)(long)((double)fVar23 + -0.25);
        sincos(dVar18 * dVar26,&dStack_2f0,&local_2f8);
        dVar40 = dVar18 - (((dVar18 * 2.0 + 0.5) - local_2f8 * 0.5) / 3.0 - dVar18) /
                          ((dStack_2f0 * dVar26 * 0.5 + 2.0) / 3.0);
        sincos(dVar40 * dVar26,&dStack_300,&local_308);
        dVar40 = dVar40 - (((dVar40 * 2.0 + 0.5) - local_308 * 0.5) / 3.0 - dVar18) /
                          ((dStack_300 * dVar26 * 0.5 + 2.0) / 3.0);
        sincos(dVar40 * dVar26,&dStack_310,&local_318);
        dVar40 = dVar40 - (((dVar40 * 2.0 + 0.5) - local_318 * 0.5) / 3.0 - dVar18) /
                          ((dStack_310 * dVar26 * 0.5 + 2.0) / 3.0);
        sincos(dVar40 * dVar26,&dStack_320,&local_328);
        dVar26 = fmod(((dVar40 - (((dVar40 * 2.0 + 0.5) - local_328 * 0.5) / 3.0 - dVar18) /
                                 ((dStack_320 * dVar26 * 0.5 + 2.0) / 3.0)) + 1.25) * 24000.0,
                      24000.0);
        fVar29 = (float)dVar26;
      }
    }
joined_r0x0051fef8:
    if (0.0 <= dVar27) {
      dVar26 = fmod(dVar27,24000.0);
      fVar29 = (float)dVar26;
      fVar39 = (float)(double)(long)(dVar27 / 24000.0);
      if (uVar1 == 0) {
        bVar12 = false;
        if ((*(char *)(param_3 + 0x128) != '\0') && (1.0 < dVar31)) {
          dVar26 = dVar26 / 24000.0 + -0.25;
          dVar26 = dVar26 - (double)(long)dVar26;
          dVar27 = cos(dVar26 * DAT_001a0840);
          goto LAB_0051fa10;
        }
        goto LAB_00520774;
      }
    }
    else {
      fVar39 = 0.0;
    }
LAB_00520770:
    bVar12 = false;
  }
  else {
    if (uVar1 != 0) {
      bVar13 = false;
      goto LAB_00520770;
    }
    dVar26 = (double)fVar29 / 24000.0 + -0.25;
    dVar26 = dVar26 - (double)(long)dVar26;
    dVar27 = cos(dVar26 * DAT_001a0840);
    bVar13 = false;
LAB_0051fa10:
    bVar12 = true;
    dVar26 = ((0.5 - dVar27 * 0.5) + dVar26 * 2.0) / 3.0 + 0.25;
    fVar23 = (float)(dVar26 - (double)(long)dVar26);
  }
LAB_00520774:
  if (0.0002 <= ABS(fVar23 + -0.5)) {
    fVar24 = 1.0 - fVar23;
    if (fVar23 <= 1.0 - fVar23) {
      fVar24 = fVar23;
    }
    fVar30 = 0.0002;
    if (0.0002 <= fVar24) goto LAB_005207c0;
  }
  else {
    fVar30 = 0.5002;
  }
  fVar23 = fVar30;
LAB_005207c0:
  FUN_00521a8c((int)fVar29,&local_1a8,"worldTime");
  FUN_00521a8c(fVar39,&local_1a8,"worldDay");
  fVar39 = 0.0;
  FUN_00521a8c(0,&local_1a8,"moonPhase");
  FUN_00521a8c(fVar23,&local_1a8,"sunAngle");
  fVar29 = fVar23;
  if (0.5 <= fVar23) {
    fVar29 = fVar23 + -0.5;
  }
  FUN_00521a8c(fVar29,&local_1a8,"shadowAngle");
  fVar29 = 0.0;
  if (uVar1 == 0) {
    iVar8 = param_4[0xe8];
    uVar17 = (uint)param_4[0xe9] >> 4 & 1;
    if (iVar8 != 0) {
      uVar17 = (uint)(2 < iVar8);
    }
    fVar39 = 1.0;
    if (uVar17 == 0) {
      fVar39 = 0.0;
    }
    fVar29 = 1.0;
    if (iVar8 != 4) {
      fVar29 = 0.0;
    }
    cVar9 = *(char *)(param_3 + 0x30);
  }
  else {
    cVar9 = *(char *)(param_3 + 0x30);
  }
  if (cVar9 == '\0') {
    fVar34 = (float)param_4[0xe1];
    fVar35 = *(float *)(param_3 + 0x124);
    fVar39 = fVar39 - *(float *)(param_3 + 0x11c);
    fVar29 = fVar29 - *(float *)(param_3 + 0x120);
    fVar30 = fVar34 * 0.2;
    fVar33 = -(fVar34 * 0.2);
    fVar24 = fVar30;
    if (fVar39 <= fVar30) {
      fVar24 = fVar39;
    }
    fVar36 = fVar33;
    if (fVar33 <= fVar39) {
      fVar36 = fVar24;
    }
    fVar39 = *(float *)(param_3 + 0x11c) + fVar36;
    if (fVar29 <= fVar30) {
      fVar30 = fVar29;
    }
    if (fVar33 <= fVar29) {
      fVar33 = fVar30;
    }
    *(float *)(param_3 + 0x11c) = fVar39;
    fVar29 = *(float *)(param_3 + 0x118) * 0.1;
    if (fVar39 <= fVar35) {
      fVar29 = 20.0;
    }
    fVar24 = 1.0;
    *(float *)(param_3 + 0x120) = *(float *)(param_3 + 0x120) + fVar33;
    if (0.0 < fVar29) {
      fVar24 = expf((fVar34 * -0.6931472) / fVar29);
      fVar24 = 1.0 - fVar24;
    }
    *(float *)(param_3 + 0x124) = (fVar39 - fVar35) + fVar24 * fVar35;
  }
  else {
    *(float *)(param_3 + 0x124) = fVar39;
    *(float *)(param_3 + 0x11c) = fVar39;
    *(float *)(param_3 + 0x120) = fVar29;
  }
  FUN_00521a8c(fVar39,&local_1a8,"rainStrength");
  FUN_00521a8c(*(undefined4 *)(param_3 + 0x124),&local_1a8,"wetness");
  FUN_00521a8c(*(undefined4 *)(param_3 + 0x120),&local_1a8,"thunderStrength");
  FUN_00521a8c(1.0 - *(float *)(param_3 + 0x11c),&local_1a8,"ml_SkyFade");
  fVar29 = -(float)param_4[0xce];
  fVar39 = -(float)param_4[0xcc];
  fVar24 = -(float)param_4[0xcd];
  if (!bVar13) {
    fVar29 = (float)param_4[0xce];
    fVar39 = (float)param_4[0xcc];
    fVar24 = (float)param_4[0xcd];
  }
  if (bVar12) {
    sincosf(fVar23 * 6.2831855,&fStack_32c,&local_330);
    fVar29 = 0.0;
    fVar39 = local_330;
    fVar24 = fStack_32c;
  }
  if (uVar1 != 0) {
    sincosf(((fVar42 + -6.0) / 12.0) * 3.1415927,&fStack_334,&local_338);
    fVar29 = 0.0;
    fVar39 = local_338;
    fVar24 = fStack_334;
  }
  *(float *)(param_3 + 300) = fVar39;
  sincosf((*(float *)(param_3 + 0x114) * 3.1415927) / 180.0,&fStack_33c,&local_340);
  fVar44 = fVar24 * local_340;
  fVar29 = fVar29 - fStack_33c * fVar24;
  *(float *)(param_3 + 0x130) = fVar44;
  *(float *)(param_3 + 0x134) = fVar29;
  fVar30 = (float)param_4[0x24];
  fVar33 = (float)param_4[0x25];
  fVar34 = (float)param_4[0x26];
  fVar36 = (float)param_4[0x20];
  fVar45 = (float)param_4[0x21];
  fVar47 = (float)param_4[0x22];
  fVar38 = (float)param_4[0x28];
  fVar46 = (float)param_4[0x29];
  fVar48 = (float)param_4[0x2a];
  fVar35 = fVar38 + fVar29 * (fVar36 + fVar39 * fVar30 * fVar44);
  fVar37 = fVar46 + fVar29 * (fVar45 + fVar39 * fVar44 * fVar33);
  fVar24 = fVar48 + fVar29 * (fVar47 + fVar39 * fVar44 * fVar34);
  fVar39 = fVar35 * 100.0;
  fVar42 = fVar37 * 100.0;
  fVar35 = -(fVar35 * 100.0);
  fVar29 = fVar24 * 100.0;
  fVar24 = -(fVar24 * 100.0);
  fVar37 = -(fVar37 * 100.0);
  FUN_00521bd4(fVar39,fVar42,fVar29,&local_1c8,"sunPosition");
  FUN_00521bd4(fVar35,fVar37,fVar24,&local_1c8,"moonPosition");
  if (fVar44 < 0.0) {
    fVar29 = fVar24;
    fVar39 = fVar35;
    fVar42 = fVar37;
  }
  FUN_00521bd4(fVar39,fVar42,fVar29,&local_1c8,"shadowLightPosition");
  FUN_00521bd4((fVar38 + (fVar36 + fVar30 * 0.0) * 0.0) * 100.0,
               (fVar46 + (fVar45 + fVar33 * 0.0) * 0.0) * 100.0,
               (fVar48 + (fVar47 + fVar34 * 0.0) * 0.0) * 100.0,&local_1c8,"upPosition");
  fVar29 = (float)param_4[0xd4];
  fVar30 = (float)param_4[0xd6];
  fVar35 = (float)param_4[0xd8];
  fVar34 = (float)param_4[0xda];
  fVar42 = (float)param_4[0xd5] + 80.0;
  fVar33 = (float)param_4[0xd9] + 80.0;
  FUN_00521bd4(fVar29,fVar42,fVar30,&local_1c8,"cameraPosition");
  FUN_00521bd4(fVar35,fVar33,fVar34,&local_1c8,"previousCameraPosition");
  FUN_00521a8c(fVar42,&local_1a8,"eyeAltitude");
  fVar39 = (float)(int)fVar29;
  fVar36 = (float)(int)fVar42;
  fVar24 = (float)(int)fVar30;
  FUN_00521bd4(fVar29 - fVar39,fVar42 - fVar36,fVar30 - fVar24,&local_1c8,"cameraPositionFract");
  FUN_00521bd4(fVar39,fVar36,fVar24,&local_1c8,"cameraPositionInt");
  dVar26 = fmod(*(double *)(param_3 + 0x140) * 20.0,131072.0);
  FUN_00521d34(fVar29 - fVar39,fVar42 - fVar36,fVar30 - fVar24,(float)dVar26,&local_1d8,
               "ml_RainCamera");
  FUN_00521d34(fVar39,fVar36,fVar24,*(undefined4 *)(param_3 + 0x11c),&local_1d8,"ml_RainCell");
  FUN_00521bd4(fVar35 - (float)(int)fVar35,fVar33 - (float)(int)fVar33,fVar34 - (float)(int)fVar34,
               &local_1c8,"previousCameraPositionFract");
  FUN_00521bd4((int)fVar35,(int)fVar33,(int)fVar34,&local_1c8,"previousCameraPositionInt");
  fVar39 = ((float)param_4[0x30] + (float)param_4[0x34] * 0.0 * 0.0) - (float)param_4[0x38];
  fVar24 = ((float)param_4[0x32] + (float)param_4[0x36] * 0.0 * 0.0) - (float)param_4[0x3a];
  FUN_00521bd4(fVar39,((float)param_4[0x31] + (float)param_4[0x35] * 0.0 * 0.0) -
                      (float)param_4[0x39],fVar24,&local_1c8,"playerLookVector");
  FUN_00521bd4(fVar39,0,fVar24,&local_1c8,"playerBodyVector");
  FUN_00521bd4(fVar29,fVar42,fVar30,&local_1c8,"eyePosition");
  FUN_00521bd4(0,0,0,&local_1c8,"relativeEyePosition");
  puVar22 = (undefined8 *)(param_3 + 0x40);
  *(undefined8 *)(param_3 + 0x48) = 0;
  *puVar22 = 0;
  fVar29 = *(float *)(param_3 + 0x100);
  *(undefined8 *)(param_3 + 0x58) = 0;
  *(undefined8 *)(param_3 + 0x50) = 0;
  *(undefined8 *)(param_3 + 0x68) = 0;
  *(undefined8 *)(param_3 + 0x60) = 0;
  *(undefined8 *)(param_3 + 0x78) = 0;
  *(undefined8 *)(param_3 + 0x70) = 0;
  fVar39 = -(fVar29 + 0.05) / (fVar29 + -0.05);
  fVar29 = (fVar29 * -2.0 * 0.05) / (fVar29 + -0.05);
  *(undefined4 *)puVar22 = *param_4;
  uVar25 = param_4[5];
  *(undefined4 *)(param_3 + 0x6c) = 0xbf800000;
  *(float *)(param_3 + 0x68) = fVar39;
  *(undefined4 *)(param_3 + 0x54) = uVar25;
  *(float *)(param_3 + 0x78) = fVar29;
  FUN_0051e124(puVar22,auStack_f0);
  uStack_114 = 0;
  uStack_100 = 0;
  uStack_fc = 0;
  local_130 = param_4[0x70];
  uStack_124 = 0;
  local_12c = 0;
  local_11c = (ulong)(uint)param_4[0x75];
  local_10c = (ulong)(uint)fVar39 << 0x20;
  uStack_104 = 0xbf800000;
  local_f8 = (ulong)(uint)fVar29;
  FUN_00521e98(&local_1e8,"gbufferProjection",puVar22);
  FUN_00521e98(&local_1e8,"gbufferProjectionInverse",auStack_f0);
  FUN_00521e98(&local_1e8,"gbufferPreviousProjection",&local_130);
  FUN_00521e98(&local_1e8,"gbufferModelView",param_4 + 0x20);
  FUN_00521e98(&local_1e8,"gbufferModelViewInverse",param_4 + 0x30);
  FUN_00521e98(&local_1e8,"gbufferPreviousModelView",param_4 + 0x60);
  bVar13 = fVar44 < 0.0;
  fVar29 = *(float *)(param_3 + 0x130);
  if (bVar13) {
    fVar29 = -*(float *)(param_3 + 0x130);
  }
  fVar39 = *(float *)(param_3 + 300);
  if (bVar13) {
    fVar39 = -*(float *)(param_3 + 300);
  }
  fVar42 = *(float *)(param_3 + 0x134);
  if (bVar13) {
    fVar42 = -*(float *)(param_3 + 0x134);
  }
  fVar24 = SQRT(fVar42 + fVar42 * (fVar39 + fVar39 * fVar29 * fVar29));
  if (1e-06 < fVar24) {
    fVar39 = fVar39 / fVar24;
    fVar29 = fVar29 / fVar24;
    fVar42 = fVar42 / fVar24;
  }
  fVar33 = fVar42 * 0.0 - fVar29;
  fVar30 = fVar39 + fVar42 * -0.0;
  fVar34 = fVar29 + fVar39 * -0.0 * 0.0;
  fVar24 = SQRT(fVar34 + fVar34 * (fVar33 + fVar33 * fVar30 * fVar30));
  if (1e-06 < fVar24) {
    fVar33 = fVar33 / fVar24;
    fVar30 = fVar30 / fVar24;
    fVar34 = fVar34 / fVar24;
  }
  fVar35 = *(float *)(param_3 + 0x110);
  fVar24 = fVar29 + fVar34 * -(fVar42 * fVar30);
  if (fVar35 <= 0.0) {
    fVar35 = 1.0;
  }
  fVar36 = fVar39 + fVar30 * fVar33 * -fVar29;
  fVar44 = fVar42 + fVar33 * -(fVar39 * fVar34);
  fVar37 = fmodf((float)param_4[0xd0],fVar35);
  fVar38 = fmodf((float)param_4[0xd1],fVar35);
  fVar35 = fmodf((float)param_4[0xd2],fVar35);
  *(float *)(param_3 + 0x90) = fVar30;
  *(float *)(param_3 + 0x94) = fVar44;
  pfVar20 = (float *)(param_3 + 0xc0);
  *(undefined8 *)(param_3 + 200) = 0;
  pfVar20[0] = 0.0;
  pfVar20[1] = 0.0;
  pfVar21 = (float *)(param_3 + 0x80);
  *pfVar21 = fVar33;
  *(float *)(param_3 + 0x84) = fVar24;
  *(float *)(param_3 + 0x88) = fVar39;
  fVar45 = 1.0 / *(float *)(param_3 + 0x104);
  *(float *)(param_3 + 0x98) = fVar29;
  *(undefined4 *)(param_3 + 0x8c) = 0;
  fVar46 = *(float *)(param_3 + 0x10c) - *(float *)(param_3 + 0x108);
  *(undefined4 *)(param_3 + 0x9c) = 0;
  *(float *)(param_3 + 0xa0) = fVar34;
  *(float *)(param_3 + 0xa4) = fVar36;
  *(float *)(param_3 + 0xa8) = fVar42;
  *(undefined4 *)(param_3 + 0xac) = 0;
  *(undefined4 *)(param_3 + 0xbc) = 0x3f800000;
  *(undefined8 *)(param_3 + 0xd8) = 0;
  *(undefined8 *)(param_3 + 0xd0) = 0;
  *(undefined8 *)(param_3 + 0xe8) = 0;
  *(undefined8 *)(param_3 + 0xe0) = 0;
  *(float *)(param_3 + 0xb0) = fVar34 + fVar35 * (fVar33 + fVar37 * fVar30 * fVar38);
  *(float *)(param_3 + 0xb4) = fVar36 + fVar35 * (fVar24 + fVar37 * fVar38 * fVar44);
  *(undefined8 *)(param_3 + 0xf8) = 0;
  *(undefined8 *)(param_3 + 0xf0) = 0;
  *pfVar20 = fVar45;
  *(float *)(param_3 + 0xb8) = fVar42 + fVar35 * (fVar39 + fVar37 * fVar38 * fVar29) + -100.0;
  *(float *)(param_3 + 0xd4) = fVar45;
  *(undefined4 *)(param_3 + 0xfc) = 0x3f800000;
  *(float *)(param_3 + 0xe8) = -2.0 / fVar46;
  *(float *)(param_3 + 0xf8) = -(*(float *)(param_3 + 0x108) + *(float *)(param_3 + 0x10c)) / fVar46
  ;
  FUN_00521e98(&local_1e8,"shadowModelView",pfVar21);
  FUN_0051e124(pfVar21,auStack_170);
  FUN_00521e98(&local_1e8,"shadowModelViewInverse",auStack_170);
  FUN_00521e98(&local_1e8,"shadowProjection",pfVar20);
  FUN_0051e124(pfVar20,auStack_170);
  FUN_00521e98(&local_1e8,"shadowProjectionInverse",auStack_170);
  uVar41 = NEON_fmov(0x3f800000,4);
  if (uVar1 == 0) {
    fVar39 = sinf(fVar23 * 6.2831855);
    fVar29 = 0.0;
    if (0.0 <= fVar39 + 1.0) {
      fVar29 = fVar39 + 1.0;
    }
    fVar39 = 1.0;
    if (fVar29 <= 1.0) {
      fVar39 = fVar29;
    }
    fVar29 = (float)*(undefined8 *)(param_3 + 0x11c);
    fVar42 = (float)((ulong)uVar41 >> 0x20) +
             (float)((ulong)*(undefined8 *)(param_3 + 0x11c) >> 0x20) * -0.5;
    fVar23 = ((float)uVar41 + fVar29 * -0.5) * fVar42;
    FUN_00521bd4((fVar39 + 0.056399997) * 0.7529 * fVar23,(fVar39 + 0.056399997) * 0.8471 * fVar23,
                 (fVar39 + 0.08190001) * (1.0 - fVar29 * 0.4) * fVar42,&local_1c8,"fogColor");
    fVar24 = 1.0 - *(float *)(param_3 + 0x11c) * 0.75;
    fVar23 = (fVar39 + (fVar39 * 0.4706 + fVar39 * 0.6549 * 0.59 * 0.3) * 0.11) * 0.6 *
             (1.0 - fVar24);
    fVar29 = fVar39 * 0.6549 + fVar24 * fVar23;
    fVar42 = fVar39 * 0.4706 + fVar24 * fVar23;
    fVar39 = fVar39 + fVar24 * fVar23;
    fVar24 = 1.0 - *(float *)(param_3 + 0x120) * 0.75;
    fVar23 = (1.0 - fVar24) * (fVar39 + (fVar42 + fVar29 * 0.59 * 0.3) * 0.11) * 0.2;
    fVar42 = fVar42 + fVar24 * fVar23;
    fVar29 = fVar29 + fVar24 * fVar23;
    fVar39 = fVar39 + fVar24 * fVar23;
    FUN_00521bd4(fVar42,fVar29,fVar39,&local_1c8,"skyColor");
  }
  else {
    FUN_00521bd4(param_4[0xc0],param_4[0xc1],param_4[0xc2],&local_1c8,"fogColor");
    FUN_00521bd4(0,0,0,&local_1c8,"skyColor");
    fVar42 = 0.0;
    fVar29 = 0.0;
    fVar39 = 0.0;
  }
  FUN_00521bd4(fVar42,fVar29,fVar39,&local_1c8,"ml_SkyColor");
  FUN_00521a8c((float)param_4[0xc4] * (float)param_4[0xc6],&local_1a8,"fogStart");
  FUN_00521a8c((float)param_4[0xc5] * (float)param_4[0xc6],&local_1a8,"fogEnd");
  FUN_00521a8c(0x3f800000,&local_1a8,"fogDensity");
  FUN_00521a8c(0x46180400,&local_1a8,"fogMode");
  cStack_17f = 0;
  local_190 = &local_188;
  local_188 = 0x676f6610;
  cStack_184 = 0x43;
  uStack_183 = 0x6c6f;
  cStack_181 = 0x6f;
  cStack_180 = 0x72;
                    /* try { // try from 005213b8 to 005213d3 has its CatchHandler @ 00521a54 */
  lVar14 = FUN_00527674(param_3,&local_188,PTR_DAT_005c5e10,&local_190,&uStack_191);
  if ((local_188 & 1) != 0) {
    free((void *)CONCAT62(uStack_176,CONCAT11(uStack_177,cStack_178)));
  }
  FUN_00521bd4(*(undefined4 *)(lVar14 + 0x38),*(undefined4 *)(lVar14 + 0x3c),
               *(undefined4 *)(lVar14 + 0x40),&local_1c8,"ml_FogColor");
  FUN_00521a8c(0x3f800000,&local_1a8,"ml_FogDensity");
  cStack_17f = 0;
  local_190 = &local_188;
  local_188 = 0x676f6610;
  cStack_184 = 0x53;
  uStack_183 = 0x6174;
  cStack_181 = 0x72;
  cStack_180 = 0x74;
                    /* try { // try from 0052143c to 0052146b has its CatchHandler @ 00521a5c */
  lVar14 = FUN_00527674(param_3,&local_188,PTR_DAT_005c5e10,&local_190,&uStack_191);
  FUN_00521a8c(*(undefined4 *)(lVar14 + 0x38),&local_1a8,"ml_FogStart");
  if ((local_188 & 1) != 0) {
    free((void *)CONCAT62(uStack_176,CONCAT11(uStack_177,cStack_178)));
  }
  cStack_181 = 0;
  uStack_183 = 0x646e;
  local_190 = &local_188;
  local_188 = 0x676f660c;
  cStack_184 = 0x45;
                    /* try { // try from 005214a4 to 005214d3 has its CatchHandler @ 00521a58 */
  lVar14 = FUN_00527674(param_3,&local_188,PTR_DAT_005c5e10,&local_190,&uStack_191);
  FUN_00521a8c(*(undefined4 *)(lVar14 + 0x38),&local_1a8,"ml_FogEnd");
  if ((local_188 & 1) != 0) {
    free((void *)CONCAT62(uStack_176,CONCAT11(uStack_177,cStack_178)));
  }
  FUN_00521a8c(0,&local_1a8,"fogShape");
  uVar43 = 0x3f800000;
  uVar25 = uVar43;
  if ((float)param_4[0xf4] <= 0.5) {
    uVar25 = 0;
  }
  FUN_00521a8c(uVar25,&local_1a8,"isEyeInWater");
  FUN_00521a8c(0,&local_1a8,"nightVision");
  FUN_00521a8c(0,&local_1a8,"blindness");
  FUN_00521a8c(0,&local_1a8,"darknessFactor");
  FUN_00521a8c(0,&local_1a8,"darknessLightFactor");
  FUN_00521a8c(0x3f000000,&local_1a8,"screenBrightness");
  FUN_00521a8c(0,&local_1a8,"playerMood");
  FUN_00521a8c(0,&local_1a8,"constantMood");
  FUN_00521a8c(0,&local_1a8,"hideGUI");
  FUN_00521a8c(0,&local_1a8,"heldItemId");
  FUN_00521a8c(0,&local_1a8,"heldItemId2");
  FUN_00521a8c(0,&local_1a8,"heldBlockLightValue");
  FUN_00521a8c(0,&local_1a8,"heldBlockLightValue2");
  FUN_00521a8c(0x3f7d70a4,&local_1a8,"centerDepthSmooth");
  uVar15 = 0x43700000;
  uVar25 = uVar43;
  if (uVar1 != 0) {
    uVar25 = 0;
  }
  if (uVar1 != 0) {
    uVar15 = 0;
  }
  FUN_00521ff4(0,uVar15,&local_1b8,"eyeBrightness");
  FUN_00521ff4(0,uVar15,&local_1b8,"eyeBrightnessSmooth");
  FUN_00521ff4(*(undefined4 *)(param_3 + 0x138),*(undefined4 *)(param_3 + 0x13c),&local_1b8,
               "atlasSize");
  FUN_00521ff4(*(undefined4 *)(param_3 + 0x138),*(undefined4 *)(param_3 + 0x13c),&local_1b8,
               "terrainTextureSize");
  FUN_00521a8c(0x41800000,&local_1a8,"terrainIconSize");
  FUN_00521a8c(0x3dcccccd,&local_1a8,"alphaTestRef");
  FUN_00521a8c(0xbf800000,&local_1a8,"biome");
  FUN_00521a8c(0xbf800000,&local_1a8,"biome_category");
  FUN_00521a8c(0x3f800000,&local_1a8,"biome_precipitation");
  FUN_00521a8c(0x3f000000,&local_1a8,"rainfall");
  FUN_00521a8c(0x3f333333,&local_1a8,"temperature");
  FUN_00521a8c(0x3f800000,&local_1a8,"is_on_ground");
  FUN_00521a8c(0,&local_1a8,"isSpectator");
  FUN_00521a8c(0,&local_1a8,"lightningBoltPosition");
  FUN_00521a8c(0x3f800000,&local_1a8,"currentPlayerHealth");
  FUN_00521a8c(0x41a00000,&local_1a8,"maxPlayerHealth");
  FUN_00521a8c(0x3f800000,&local_1a8,"currentPlayerHunger");
  FUN_00521a8c(0x41a00000,&local_1a8,"maxPlayerHunger");
  FUN_00521a8c(0x3f800000,&local_1a8,"currentPlayerAir");
  FUN_00521a8c(0x43960000,&local_1a8,"maxPlayerAir");
  FUN_00521a8c(0,&local_1a8,"currentPlayerArmor");
  FUN_00521a8c(0x41a00000,&local_1a8,"maxPlayerArmor");
  FUN_00521a8c(0x3f800000,&local_1a8,"firstPersonCamera");
  FUN_00521a8c(0x43400000,&local_1a8,"cloudHeight");
  FUN_00521a8c(0xc2800000,&local_1a8,"bedrockLevel");
  FUN_00521a8c(0x43c00000,&local_1a8,"heightLimit");
  FUN_00521a8c(0x43c00000,&local_1a8,"logicalHeightLimit");
  FUN_00521a8c(uVar25,&local_1a8,"hasSkylight");
  bVar13 = (uVar7 & 2) != 0;
  uVar25 = 0;
  if (bVar13) {
    uVar25 = uVar43;
  }
  uVar43 = 0;
  if (bVar13) {
    uVar43 = 0x3dcccccd;
  }
  FUN_00521a8c(uVar25,&local_1a8,"hasCeiling");
  FUN_00521a8c(uVar43,&local_1a8,"ambientLight");
  local_190 = &local_188;
  uStack_177 = 0;
  cStack_17f = (char)s_ml_TextureMatrix_0018e018._8_8_;
  uStack_17e = SUB82(s_ml_TextureMatrix_0018e018._8_8_,1);
  uStack_17c = SUB84(s_ml_TextureMatrix_0018e018._8_8_,3);
  cStack_178 = SUB81(s_ml_TextureMatrix_0018e018._8_8_,7);
  local_188 = CONCAT31((int3)s_ml_TextureMatrix_0018e018._0_8_,0x20);
  cStack_184 = SUB81(s_ml_TextureMatrix_0018e018._0_8_,3);
  uStack_183 = SUB82(s_ml_TextureMatrix_0018e018._0_8_,4);
  cStack_181 = SUB81(s_ml_TextureMatrix_0018e018._0_8_,6);
  cStack_180 = SUB81(s_ml_TextureMatrix_0018e018._0_8_,7);
                    /* try { // try from 005218fc to 00521917 has its CatchHandler @ 00521a50 */
  lVar14 = FUN_00527674(param_3,&local_188,PTR_DAT_005c5e10,&local_190,&uStack_191);
  if ((local_188 & 1) != 0) {
    free((void *)CONCAT62(uStack_176,CONCAT11(uStack_177,cStack_178)));
  }
  uVar11 = DAT_001a0870;
  *(undefined8 *)(lVar14 + 0x70) = 0;
  *(undefined8 *)(lVar14 + 0x68) = 0;
  *(undefined8 *)(lVar14 + 0x80) = 0;
  *(undefined8 *)(lVar14 + 0x78) = 0;
  *(undefined8 *)(lVar14 + 0x74) = uVar11;
  *(undefined8 *)(lVar14 + 0x60) = 0;
  *(undefined8 *)(lVar14 + 0x58) = 0;
  *(undefined8 *)(lVar14 + 0x50) = 0;
  *(undefined8 *)(lVar14 + 0x48) = 0;
  *(undefined8 *)(lVar14 + 0x40) = 0;
  *(undefined8 *)(lVar14 + 0x38) = 0;
  *(undefined4 *)(lVar14 + 0x60) = 0x3f800000;
  *(undefined4 *)(lVar14 + 0x4c) = 0x3f800000;
  *(undefined4 *)(lVar14 + 0x38) = 0x3f800000;
  *(undefined8 *)(lVar14 + 0xa0) = 0;
  *(undefined8 *)(lVar14 + 0x98) = 0;
  *(undefined8 *)(lVar14 + 0x90) = 0;
  *(undefined8 *)(lVar14 + 0x88) = 0;
  *(undefined8 *)(lVar14 + 0xb0) = 0;
  *(undefined8 *)(lVar14 + 0xa8) = 0;
  *(undefined4 *)(lVar14 + 0xa0) = 0x3f800000;
  *(undefined4 *)(lVar14 + 0x8c) = 0x3b800000;
  *(undefined8 *)(lVar14 + 0xa8) = 0x3d0000003d000000;
  *(undefined8 *)(lVar14 + 0xf0) = 0;
  *(undefined8 *)(lVar14 + 0xe8) = 0;
  *(undefined8 *)(lVar14 + 0xe0) = 0;
  *(undefined8 *)(lVar14 + 0xd8) = 0;
  *(undefined8 *)(lVar14 + 0xd0) = 0;
  *(undefined8 *)(lVar14 + 200) = 0;
  *(undefined8 *)(lVar14 + 0xc0) = 0;
  *(undefined8 *)(lVar14 + 0xb8) = 0;
  *(undefined4 *)(lVar14 + 0xf4) = 0x3f800000;
  *(undefined4 *)(lVar14 + 0xe0) = 0x3f800000;
  *(undefined4 *)(lVar14 + 0xcc) = 0x3f800000;
  *(undefined8 *)(lVar14 + 0xb4) = uVar41;
  plVar6 = (long *)(*(long **)(param_3 + 0x38))[1];
  for (plVar19 = (long *)**(long **)(param_3 + 0x38); plVar19 != plVar6; plVar19 = plVar19 + 2) {
    (**(code **)(*(long *)plVar19[1] + 0x10))(&local_188);
    puVar16 = (uint *)*plVar19;
    *puVar16 = local_188;
    puVar16[1] = CONCAT13(cStack_181,CONCAT21(uStack_183,cStack_184));
    puVar16[2] = CONCAT22(uStack_17e,CONCAT11(cStack_17f,cStack_180));
    puVar16[3] = uStack_17c;
  }
  *(undefined1 *)(param_3 + 0x30) = 0;
  if (*(long *)(lVar10 + 0x28) == local_b0) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00521a8c
// Address: 00521a8c
// ========================================

void FUN_00521a8c(undefined4 param_1,undefined8 *param_2,char *param_3)

{
  long lVar1;
  size_t __n;
  long lVar2;
  undefined8 uVar3;
  void *__dest;
  ulong local_80;
  size_t local_78;
  void *local_70;
  undefined1 uStack_61;
  undefined1 *local_60;
  long local_58;
  
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uVar3 = *param_2;
  FUN_00527488(param_2 + 1);
  __n = strlen(param_3);
  if (0xffffffffffffffef < __n) {
    if (*(long *)(lVar1 + 0x28) == local_58) {
                    /* WARNING: Subroutine does not return */
      FUN_002d18a8(&local_80);
    }
    goto LAB_00521bd0;
  }
  if (__n < 0x17) {
    __dest = (void *)((ulong)&local_80 | 1);
    local_80 = CONCAT71(local_80._1_7_,(char)((int)__n << 1));
    if (__n != 0) goto LAB_00521b14;
  }
  else {
    __dest = (void *)FUN_005a5d4c((__n | 0xf) + 1);
    local_80 = (__n | 0xf) + 2;
    local_78 = __n;
    local_70 = __dest;
LAB_00521b14:
    memcpy(__dest,param_3,__n);
  }
  *(undefined1 *)((long)__dest + __n) = 0;
                    /* try { // try from 00521b30 to 00521b4b has its CatchHandler @ 00521ba4 */
  local_60 = (undefined1 *)&local_80;
  lVar2 = FUN_00527674(uVar3,&local_80,PTR_DAT_005c5e10,&local_60,&uStack_61);
  *(undefined4 *)(lVar2 + 0x38) = param_1;
  if ((local_80 & 1) != 0) {
    free(local_70);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
LAB_00521bd0:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00521bd4
// Address: 00521bd4
// ========================================

void FUN_00521bd4(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 *param_4,
                 char *param_5)

{
  long lVar1;
  size_t __n;
  long lVar2;
  undefined8 uVar3;
  void *__dest;
  ulong local_90;
  size_t local_88;
  void *local_80;
  undefined1 uStack_71;
  undefined1 *local_70;
  long local_68;
  
  lVar1 = tpidr_el0;
  local_68 = *(long *)(lVar1 + 0x28);
  uVar3 = *param_4;
  FUN_00527488(param_4 + 1);
  __n = strlen(param_5);
  if (0xffffffffffffffef < __n) {
    if (*(long *)(lVar1 + 0x28) == local_68) {
                    /* WARNING: Subroutine does not return */
      FUN_002d18a8(&local_90);
    }
    goto LAB_00521d30;
  }
  if (__n < 0x17) {
    __dest = (void *)((ulong)&local_90 | 1);
    local_90 = CONCAT71(local_90._1_7_,(char)((int)__n << 1));
    if (__n != 0) goto LAB_00521c68;
  }
  else {
    __dest = (void *)FUN_005a5d4c((__n | 0xf) + 1);
    local_90 = (__n | 0xf) + 2;
    local_88 = __n;
    local_80 = __dest;
LAB_00521c68:
    memcpy(__dest,param_5,__n);
  }
  *(undefined1 *)((long)__dest + __n) = 0;
                    /* try { // try from 00521c84 to 00521c9f has its CatchHandler @ 00521d04 */
  local_70 = (undefined1 *)&local_90;
  lVar2 = FUN_00527674(uVar3,&local_90,PTR_DAT_005c5e10,&local_70,&uStack_71);
  if ((local_90 & 1) != 0) {
    free(local_80);
  }
  *(undefined4 *)(lVar2 + 0x38) = param_1;
  *(undefined4 *)(lVar2 + 0x3c) = param_2;
  *(undefined4 *)(lVar2 + 0x40) = param_3;
  if (*(long *)(lVar1 + 0x28) == local_68) {
    return;
  }
LAB_00521d30:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00521d34
// Address: 00521d34
// ========================================

void FUN_00521d34(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined8 *param_5,char *param_6)

{
  long lVar1;
  size_t __n;
  long lVar2;
  undefined8 uVar3;
  void *__dest;
  ulong local_90;
  size_t local_88;
  void *local_80;
  undefined1 uStack_71;
  undefined1 *local_70;
  long local_68;
  
  lVar1 = tpidr_el0;
  local_68 = *(long *)(lVar1 + 0x28);
  uVar3 = *param_5;
  FUN_00527488(param_5 + 1);
  __n = strlen(param_6);
  if (0xffffffffffffffef < __n) {
    if (*(long *)(lVar1 + 0x28) == local_68) {
                    /* WARNING: Subroutine does not return */
      FUN_002d18a8(&local_90);
    }
    goto LAB_00521e94;
  }
  if (__n < 0x17) {
    __dest = (void *)((ulong)&local_90 | 1);
    local_90 = CONCAT71(local_90._1_7_,(char)((int)__n << 1));
    if (__n != 0) goto LAB_00521dcc;
  }
  else {
    __dest = (void *)FUN_005a5d4c((__n | 0xf) + 1);
    local_90 = (__n | 0xf) + 2;
    local_88 = __n;
    local_80 = __dest;
LAB_00521dcc:
    memcpy(__dest,param_6,__n);
  }
  *(undefined1 *)((long)__dest + __n) = 0;
                    /* try { // try from 00521de8 to 00521e03 has its CatchHandler @ 00521e68 */
  local_70 = (undefined1 *)&local_90;
  lVar2 = FUN_00527674(uVar3,&local_90,PTR_DAT_005c5e10,&local_70,&uStack_71);
  if ((local_90 & 1) != 0) {
    free(local_80);
  }
  *(undefined4 *)(lVar2 + 0x38) = param_1;
  *(undefined4 *)(lVar2 + 0x3c) = param_2;
  *(undefined4 *)(lVar2 + 0x40) = param_3;
  *(undefined4 *)(lVar2 + 0x44) = param_4;
  if (*(long *)(lVar1 + 0x28) == local_68) {
    return;
  }
LAB_00521e94:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00521e98
// Address: 00521e98
// ========================================

void FUN_00521e98(undefined8 *param_1,char *param_2,undefined8 *param_3)

{
  long lVar1;
  size_t __n;
  long lVar2;
  undefined8 uVar3;
  void *__dest;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  ulong local_80;
  size_t local_78;
  void *local_70;
  undefined1 uStack_61;
  undefined1 *local_60;
  long local_58;
  
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uVar3 = *param_1;
  FUN_00527488(param_1 + 1);
  __n = strlen(param_2);
  if (0xffffffffffffffef < __n) {
    if (*(long *)(lVar1 + 0x28) == local_58) {
                    /* WARNING: Subroutine does not return */
      FUN_002d18a8(&local_80);
    }
    goto LAB_00521ff0;
  }
  if (__n < 0x17) {
    __dest = (void *)((ulong)&local_80 | 1);
    local_80 = CONCAT71(local_80._1_7_,(char)((int)__n << 1));
    if (__n != 0) goto LAB_00521f20;
  }
  else {
    __dest = (void *)FUN_005a5d4c((__n | 0xf) + 1);
    local_80 = (__n | 0xf) + 2;
    local_78 = __n;
    local_70 = __dest;
LAB_00521f20:
    memcpy(__dest,param_2,__n);
  }
  *(undefined1 *)((long)__dest + __n) = 0;
                    /* try { // try from 00521f3c to 00521f57 has its CatchHandler @ 00521fc4 */
  local_60 = (undefined1 *)&local_80;
  lVar2 = FUN_00527674(uVar3,&local_80,PTR_DAT_005c5e10,&local_60,&uStack_61);
  uVar5 = param_3[5];
  uVar4 = param_3[4];
  uVar3 = param_3[6];
  uVar7 = param_3[1];
  uVar6 = *param_3;
  uVar9 = param_3[3];
  uVar8 = param_3[2];
  *(undefined8 *)(lVar2 + 0x70) = param_3[7];
  *(undefined8 *)(lVar2 + 0x68) = uVar3;
  *(undefined8 *)(lVar2 + 0x60) = uVar5;
  *(undefined8 *)(lVar2 + 0x58) = uVar4;
  *(undefined8 *)(lVar2 + 0x50) = uVar9;
  *(undefined8 *)(lVar2 + 0x48) = uVar8;
  *(undefined8 *)(lVar2 + 0x40) = uVar7;
  *(undefined8 *)(lVar2 + 0x38) = uVar6;
  if ((local_80 & 1) != 0) {
    free(local_70);
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
LAB_00521ff0:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00521ff4
// Address: 00521ff4
// ========================================

void FUN_00521ff4(undefined4 param_1,undefined4 param_2,undefined8 *param_3,char *param_4)

{
  long lVar1;
  size_t __n;
  long lVar2;
  undefined8 uVar3;
  void *__dest;
  ulong local_80;
  size_t local_78;
  void *local_70;
  undefined1 uStack_61;
  undefined1 *local_60;
  long local_58;
  
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  uVar3 = *param_3;
  FUN_00527488(param_3 + 1);
  __n = strlen(param_4);
  if (0xffffffffffffffef < __n) {
    if (*(long *)(lVar1 + 0x28) == local_58) {
                    /* WARNING: Subroutine does not return */
      FUN_002d18a8(&local_80);
    }
    goto LAB_00522140;
  }
  if (__n < 0x17) {
    __dest = (void *)((ulong)&local_80 | 1);
    local_80 = CONCAT71(local_80._1_7_,(char)((int)__n << 1));
    if (__n != 0) goto LAB_00522080;
  }
  else {
    __dest = (void *)FUN_005a5d4c((__n | 0xf) + 1);
    local_80 = (__n | 0xf) + 2;
    local_78 = __n;
    local_70 = __dest;
LAB_00522080:
    memcpy(__dest,param_4,__n);
  }
  *(undefined1 *)((long)__dest + __n) = 0;
                    /* try { // try from 0052209c to 005220b7 has its CatchHandler @ 00522114 */
  local_60 = (undefined1 *)&local_80;
  lVar2 = FUN_00527674(uVar3,&local_80,PTR_DAT_005c5e10,&local_60,&uStack_61);
  if ((local_80 & 1) != 0) {
    free(local_70);
  }
  *(undefined4 *)(lVar2 + 0x38) = param_1;
  *(undefined4 *)(lVar2 + 0x3c) = param_2;
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
LAB_00522140:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00522144
// Address: 00522144
// ========================================

undefined8 FUN_00522144(long param_1,byte *param_2)

{
  ulong uVar1;
  size_t sVar2;
  ulong uVar3;
  byte *pbVar4;
  bool bVar5;
  void *pvVar6;
  int iVar7;
  long *plVar8;
  
  plVar8 = *(long **)(param_1 + 0x20);
  if (plVar8 != (long *)0x0) {
    uVar3 = *(ulong *)(param_2 + 8);
    pbVar4 = *(byte **)(param_2 + 0x10);
    if ((*param_2 & 1) == 0) {
      pbVar4 = param_2 + 1;
      uVar3 = (ulong)(*param_2 >> 1);
    }
    do {
      uVar1 = (ulong)(*(byte *)(plVar8 + 4) >> 1);
      pvVar6 = (void *)((long)plVar8 + 0x21);
      if ((*(byte *)(plVar8 + 4) & 1) != 0) {
        uVar1 = plVar8[5];
        pvVar6 = (void *)plVar8[6];
      }
      sVar2 = uVar1;
      if (uVar3 <= uVar1) {
        sVar2 = uVar3;
      }
      iVar7 = memcmp(pbVar4,pvVar6,sVar2);
      bVar5 = uVar3 < uVar1;
      if (iVar7 != 0) {
        bVar5 = iVar7 < 0;
      }
      if (!bVar5) {
        iVar7 = memcmp(pvVar6,pbVar4,sVar2);
        bVar5 = uVar1 < uVar3;
        if (iVar7 != 0) {
          bVar5 = iVar7 < 0;
        }
        if (!bVar5) {
          return 1;
        }
        plVar8 = plVar8 + 1;
      }
      plVar8 = (long *)*plVar8;
    } while (plVar8 != (long *)0x0);
  }
  plVar8 = *(long **)(*(long *)(param_1 + 0x38) + 0x20);
  if (plVar8 != (long *)0x0) {
    uVar3 = *(ulong *)(param_2 + 8);
    pbVar4 = *(byte **)(param_2 + 0x10);
    if ((*param_2 & 1) == 0) {
      pbVar4 = param_2 + 1;
      uVar3 = (ulong)(*param_2 >> 1);
    }
    do {
      uVar1 = (ulong)(*(byte *)(plVar8 + 4) >> 1);
      pvVar6 = (void *)((long)plVar8 + 0x21);
      if ((*(byte *)(plVar8 + 4) & 1) != 0) {
        uVar1 = plVar8[5];
        pvVar6 = (void *)plVar8[6];
      }
      sVar2 = uVar1;
      if (uVar3 <= uVar1) {
        sVar2 = uVar3;
      }
      iVar7 = memcmp(pbVar4,pvVar6,sVar2);
      bVar5 = uVar3 < uVar1;
      if (iVar7 != 0) {
        bVar5 = iVar7 < 0;
      }
      if (!bVar5) {
        iVar7 = memcmp(pvVar6,pbVar4,sVar2);
        bVar5 = uVar1 < uVar3;
        if (iVar7 != 0) {
          bVar5 = iVar7 < 0;
        }
        if (!bVar5) {
          return 1;
        }
        plVar8 = plVar8 + 1;
      }
      plVar8 = (long *)*plVar8;
    } while (plVar8 != (long *)0x0);
  }
  return 0;
}



// ========================================
// Function: FUN_005222e4
// Address: 005222e4
// ========================================

void FUN_005222e4(undefined8 *param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  ulong uVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 local_98;
  undefined **local_90 [4];
  undefined ***local_70;
  long local_58;
  
  lVar1 = tpidr_el0;
  local_58 = *(long *)(lVar1 + 0x28);
  FUN_00522520(param_1);
  puVar5 = (undefined8 *)*param_1;
                    /* try { // try from 0052233c to 00522347 has its CatchHandler @ 00522410 */
  while (uVar3 = FUN_00522448(param_2,&DAT_001518cc), (uVar3 & 1) != 0) {
    *param_1 = 0;
                    /* try { // try from 00522350 to 0052235b has its CatchHandler @ 005223f0 */
    FUN_00522520(&local_98,param_2);
    local_90[0] = &PTR_FUN_005bfcb8;
    local_70 = local_90;
                    /* try { // try from 00522364 to 0052236b has its CatchHandler @ 005223d0 */
    puVar4 = (undefined8 *)FUN_005a5d4c(0x50);
    uVar2 = local_98;
    *puVar4 = &PTR_FUN_005bfd38;
    puVar4[1] = puVar5;
    *param_1 = puVar4;
    local_98 = 0;
    puVar4[3] = 0;
    puVar4[2] = 0;
    puVar4[7] = 0;
    puVar4[6] = 0;
    puVar4[9] = 0;
    puVar4[8] = 0;
    puVar5 = puVar4 + 4;
    puVar4[5] = 0;
    *puVar5 = 0;
    puVar4[2] = uVar2;
    puVar4[8] = puVar5;
    *puVar5 = &PTR_FUN_005bfcb8;
    puVar5 = puVar4;
  }
  if (*(long *)(lVar1 + 0x28) == local_58) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00522448
// Address: 00522448
// ========================================

bool FUN_00522448(undefined8 *param_1,char *param_2)

{
  byte *pbVar1;
  ulong uVar2;
  bool bVar3;
  int iVar4;
  size_t sVar5;
  byte *pbVar6;
  ulong uVar7;
  
  pbVar6 = (byte *)*param_1;
  uVar7 = param_1[0xf];
  bVar3 = (*pbVar6 & 1) == 0;
  uVar2 = (ulong)(*pbVar6 >> 1);
  if (!bVar3) {
    uVar2 = *(ulong *)(pbVar6 + 8);
  }
  if (uVar7 < uVar2) {
    do {
      pbVar1 = pbVar6 + 1;
      if (!bVar3) {
        pbVar1 = *(byte **)(pbVar6 + 0x10);
      }
      if (pbVar1[uVar7] != 0x20 && pbVar1[uVar7] - 0xe < 0xfffffffb) break;
      uVar7 = uVar7 + 1;
      param_1[0xf] = uVar7;
      bVar3 = (*pbVar6 & 1) == 0;
      uVar2 = (ulong)(*pbVar6 >> 1);
      if (!bVar3) {
        uVar2 = *(ulong *)(pbVar6 + 8);
      }
    } while (uVar7 < uVar2);
  }
  sVar5 = strlen(param_2);
  iVar4 = FUN_00561a10(*param_1,param_1[0xf],sVar5,param_2);
  if (iVar4 == 0) {
    param_1[0xf] = param_1[0xf] + sVar5;
  }
  return iVar4 == 0;
}



// ========================================
// Function: FUN_00522520
// Address: 00522520
// ========================================

void FUN_00522520(undefined8 *param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  ulong uVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 local_1c0;
  undefined8 local_1b8;
  undefined8 local_1b0;
  undefined8 local_1a8;
  undefined8 local_1a0;
  undefined8 local_198;
  undefined **local_190 [4];
  undefined ***local_170;
  undefined **local_160 [4];
  undefined ***local_140;
  undefined **local_130 [4];
  undefined ***local_110;
  undefined **local_100 [4];
  undefined ***local_e0;
  undefined **local_d0 [4];
  undefined ***local_b0;
  undefined **local_a0 [4];
  undefined ***local_80;
  long local_70;
  
  lVar1 = tpidr_el0;
  local_70 = *(long *)(lVar1 + 0x28);
  FUN_005229a4(param_1);
  puVar5 = (undefined8 *)*param_1;
  while( true ) {
    while( true ) {
      while( true ) {
        while( true ) {
          while( true ) {
            while( true ) {
                    /* try { // try from 00522598 to 005225a3 has its CatchHandler @ 00522968 */
              uVar3 = FUN_00522448(param_2,&DAT_0013cb74);
              if ((uVar3 & 1) == 0) break;
              *param_1 = 0;
                    /* try { // try from 005225ac to 005225b7 has its CatchHandler @ 0052294c */
              FUN_005229a4(&local_198,param_2);
              local_a0[0] = &PTR_FUN_005bf9b8;
              local_80 = local_a0;
                    /* try { // try from 005225c0 to 005225c7 has its CatchHandler @ 00522928 */
              puVar4 = (undefined8 *)FUN_005a5d4c(0x50);
              uVar2 = local_198;
              *puVar4 = &PTR_FUN_005bfd38;
              puVar4[1] = puVar5;
              *param_1 = puVar4;
              local_198 = 0;
              puVar4[3] = 0;
              puVar4[2] = 0;
              puVar4[7] = 0;
              puVar4[6] = 0;
              puVar4[9] = 0;
              puVar4[8] = 0;
              puVar5 = puVar4 + 4;
              puVar4[5] = 0;
              *puVar5 = 0;
              puVar4[2] = uVar2;
              puVar4[8] = puVar5;
              *puVar5 = &PTR_FUN_005bf9b8;
              puVar5 = puVar4;
            }
                    /* try { // try from 00522600 to 0052260b has its CatchHandler @ 00522968 */
            uVar3 = FUN_00522448(param_2,&DAT_0015d2c0);
            if ((uVar3 & 1) == 0) break;
            *param_1 = 0;
                    /* try { // try from 00522614 to 0052261f has its CatchHandler @ 00522908 */
            FUN_005229a4(&local_1a0,param_2);
            local_b0 = local_d0;
            local_d0[0] = &PTR_FUN_005bfa38;
                    /* try { // try from 0052262c to 00522633 has its CatchHandler @ 00522914 */
            puVar4 = (undefined8 *)FUN_005a5d4c(0x50);
            uVar2 = local_1a0;
            *puVar4 = &PTR_FUN_005bfd38;
            puVar4[1] = puVar5;
            *param_1 = puVar4;
            local_1a0 = 0;
            puVar4[3] = 0;
            puVar4[2] = 0;
            puVar4[7] = 0;
            puVar4[6] = 0;
            puVar4[9] = 0;
            puVar4[8] = 0;
            puVar5 = puVar4 + 4;
            puVar4[5] = 0;
            *puVar5 = 0;
            puVar4[2] = uVar2;
            puVar4[8] = puVar5;
            *puVar5 = &PTR_FUN_005bfa38;
            puVar5 = puVar4;
          }
                    /* try { // try from 0052266c to 0052268f has its CatchHandler @ 00522968 */
          uVar3 = FUN_00522448(param_2,&DAT_0018667c);
          if ((uVar3 & 1) == 0) break;
          *param_1 = 0;
                    /* try { // try from 00522794 to 0052279f has its CatchHandler @ 005228e8 */
          FUN_005229a4(&local_1a8,param_2);
          local_e0 = local_100;
          local_100[0] = &PTR_FUN_005bfab8;
                    /* try { // try from 005227b4 to 005227bb has its CatchHandler @ 005228f4 */
          puVar4 = (undefined8 *)FUN_005a5d4c(0x50);
          uVar2 = local_1a8;
          *puVar4 = &PTR_FUN_005bfd38;
          puVar4[1] = puVar5;
          *param_1 = puVar4;
          local_1a8 = 0;
          puVar4[3] = 0;
          puVar4[2] = 0;
          puVar4[7] = 0;
          puVar4[6] = 0;
          puVar4[9] = 0;
          puVar4[8] = 0;
          puVar5 = puVar4 + 4;
          puVar4[5] = 0;
          *puVar5 = 0;
          puVar4[2] = uVar2;
          puVar4[8] = puVar5;
          *puVar5 = &PTR_FUN_005bfab8;
          puVar5 = puVar4;
        }
        uVar3 = FUN_00522448(param_2,&DAT_0018bf76);
        if ((uVar3 & 1) == 0) break;
        *param_1 = 0;
                    /* try { // try from 005226a0 to 005226ab has its CatchHandler @ 005228c8 */
        FUN_005229a4(&local_1b0,param_2);
        local_110 = local_130;
        local_130[0] = &PTR_FUN_005bfb38;
                    /* try { // try from 005226c0 to 005226c7 has its CatchHandler @ 005228d4 */
        puVar4 = (undefined8 *)FUN_005a5d4c(0x50);
        uVar2 = local_1b0;
        *puVar4 = &PTR_FUN_005bfd38;
        puVar4[1] = puVar5;
        *param_1 = puVar4;
        local_1b0 = 0;
        puVar4[3] = 0;
        puVar4[2] = 0;
        puVar4[7] = 0;
        puVar4[6] = 0;
        puVar4[9] = 0;
        puVar4[8] = 0;
        puVar5 = puVar4 + 4;
        puVar4[5] = 0;
        *puVar5 = 0;
        puVar4[2] = uVar2;
        puVar4[8] = puVar5;
        *puVar5 = &PTR_FUN_005bfb38;
        puVar5 = puVar4;
      }
                    /* try { // try from 0052270c to 0052272f has its CatchHandler @ 00522968 */
      uVar3 = FUN_00522448(param_2,&DAT_0014c531);
      if ((uVar3 & 1) == 0) break;
      *param_1 = 0;
                    /* try { // try from 005227f8 to 00522803 has its CatchHandler @ 005228a8 */
      FUN_005229a4(&local_1b8,param_2);
      local_140 = local_160;
      local_160[0] = &PTR_FUN_005bfbb8;
                    /* try { // try from 00522818 to 0052281f has its CatchHandler @ 005228b4 */
      puVar4 = (undefined8 *)FUN_005a5d4c(0x50);
      uVar2 = local_1b8;
      *puVar4 = &PTR_FUN_005bfd38;
      puVar4[1] = puVar5;
      *param_1 = puVar4;
      local_1b8 = 0;
      puVar4[3] = 0;
      puVar4[2] = 0;
      puVar4[7] = 0;
      puVar4[6] = 0;
      puVar4[9] = 0;
      puVar4[8] = 0;
      puVar5 = puVar4 + 4;
      puVar4[5] = 0;
      *puVar5 = 0;
      puVar4[2] = uVar2;
      puVar4[8] = puVar5;
      *puVar5 = &PTR_FUN_005bfbb8;
      puVar5 = puVar4;
    }
    uVar3 = FUN_00522448(param_2,&DAT_00159e69);
    if ((uVar3 & 1) == 0) break;
    *param_1 = 0;
                    /* try { // try from 00522738 to 00522743 has its CatchHandler @ 0052288c */
    FUN_005229a4(&local_1c0,param_2);
    local_170 = local_190;
    local_190[0] = &PTR_FUN_005bfc38;
                    /* try { // try from 00522750 to 00522757 has its CatchHandler @ 00522894 */
    puVar4 = (undefined8 *)FUN_005a5d4c(0x50);
    uVar2 = local_1c0;
    *puVar4 = &PTR_FUN_005bfd38;
    puVar4[1] = puVar5;
    *param_1 = puVar4;
    local_1c0 = 0;
    puVar4[3] = 0;
    puVar4[2] = 0;
    puVar4[7] = 0;
    puVar4[6] = 0;
    puVar4[9] = 0;
    puVar4[8] = 0;
    puVar5 = puVar4 + 4;
    puVar4[5] = 0;
    *puVar5 = 0;
    puVar4[2] = uVar2;
    puVar4[8] = puVar5;
    *puVar5 = &PTR_FUN_005bfc38;
    puVar5 = puVar4;
  }
  if (*(long *)(lVar1 + 0x28) != local_70) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_005229a4
// Address: 005229a4
// ========================================

void FUN_005229a4(undefined8 *param_1,undefined8 param_2)

{
  long lVar1;
  undefined8 uVar2;
  ulong uVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 local_e0;
  undefined8 local_d8;
  undefined **local_d0 [4];
  undefined ***local_b0;
  undefined **local_a0 [4];
  undefined ***local_80;
  long local_68;
  
  lVar1 = tpidr_el0;
  local_68 = *(long *)(lVar1 + 0x28);
  FUN_00522bb4(param_1);
  puVar5 = (undefined8 *)*param_1;
  while( true ) {
                    /* try { // try from 00522a18 to 00522a23 has its CatchHandler @ 00522b78 */
    while (uVar3 = FUN_00522448(param_2,&DAT_00140391), (uVar3 & 1) != 0) {
      *param_1 = 0;
                    /* try { // try from 00522a2c to 00522a37 has its CatchHandler @ 00522b5c */
      FUN_00522bb4(&local_d8,param_2);
      local_a0[0] = &PTR_FUN_005bf8b8;
      local_80 = local_a0;
                    /* try { // try from 00522a40 to 00522a47 has its CatchHandler @ 00522b3c */
      puVar4 = (undefined8 *)FUN_005a5d4c(0x50);
      uVar2 = local_d8;
      *puVar4 = &PTR_FUN_005bfd38;
      puVar4[1] = puVar5;
      *param_1 = puVar4;
      local_d8 = 0;
      puVar4[3] = 0;
      puVar4[2] = 0;
      puVar4[7] = 0;
      puVar4[6] = 0;
      puVar4[9] = 0;
      puVar4[8] = 0;
      puVar5 = puVar4 + 4;
      puVar4[5] = 0;
      *puVar5 = 0;
      puVar4[2] = uVar2;
      puVar4[8] = puVar5;
      *puVar5 = &PTR_FUN_005bf8b8;
      puVar5 = puVar4;
    }
                    /* try { // try from 00522a80 to 00522a8b has its CatchHandler @ 00522b78 */
    uVar3 = FUN_00522448(param_2,&DAT_00181349);
    if ((uVar3 & 1) == 0) break;
    *param_1 = 0;
                    /* try { // try from 00522a94 to 00522a9f has its CatchHandler @ 00522b1c */
    FUN_00522bb4(&local_e0,param_2);
    local_d0[0] = &PTR_FUN_005bf938;
    local_b0 = local_d0;
                    /* try { // try from 00522aa8 to 00522aaf has its CatchHandler @ 00522b28 */
    puVar4 = (undefined8 *)FUN_005a5d4c(0x50);
    uVar2 = local_e0;
    *puVar4 = &PTR_FUN_005bfd38;
    puVar4[1] = puVar5;
    *param_1 = puVar4;
    local_e0 = 0;
    puVar4[3] = 0;
    puVar4[2] = 0;
    puVar4[7] = 0;
    puVar4[6] = 0;
    puVar4[9] = 0;
    puVar4[8] = 0;
    puVar5 = puVar4 + 4;
    puVar4[5] = 0;
    *puVar5 = 0;
    puVar4[2] = uVar2;
    puVar4[8] = puVar5;
    *puVar5 = &PTR_FUN_005bf938;
    puVar5 = puVar4;
  }
  if (*(long *)(lVar1 + 0x28) == local_68) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00522bb4
// Address: 00522bb4
// ========================================

void FUN_00522bb4(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  int iVar2;
  byte bVar3;
  long lVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  ulong uVar7;
  undefined8 *puVar8;
  undefined8 *local_118;
  undefined8 *local_110;
  undefined8 *local_108;
  undefined **local_100 [4];
  undefined ***local_e0;
  undefined **local_d0 [4];
  undefined ***local_b0;
  undefined **local_a0 [4];
  undefined ***local_80;
  long local_70;
  
  lVar4 = tpidr_el0;
  local_70 = *(long *)(lVar4 + 0x28);
  if ((*(int *)(param_2 + 0x10) < 0x40) &&
     (iVar1 = *(int *)((long)param_2 + 0x84), *(int *)((long)param_2 + 0x84) = iVar1 + 1,
     iVar1 < 0x400)) {
    *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + 1;
    FUN_00523024(param_1,param_2);
    puVar6 = (undefined8 *)*param_1;
    *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + -1;
  }
  else {
    bVar3 = *(byte *)*param_2;
    uVar7 = (ulong)(bVar3 >> 1);
    if ((bVar3 & 1) != 0) {
      uVar7 = *(ulong *)((byte *)*param_2 + 8);
    }
    param_2[0xf] = uVar7;
    puVar6 = (undefined8 *)FUN_005a5d4c(0x20);
    puVar6[2] = 0;
    puVar6[3] = 0;
    *puVar6 = &PTR_FUN_005beaf8;
    puVar6[1] = 0;
    *(undefined4 *)(puVar6 + 3) = 1;
    *param_1 = puVar6;
  }
  while( true ) {
    while( true ) {
                    /* try { // try from 00522ca4 to 00522caf has its CatchHandler @ 00522fe8 */
      while (uVar7 = FUN_00522448(param_2,&DAT_0017d25f), (uVar7 & 1) != 0) {
        iVar1 = *(int *)(param_2 + 0x10);
        *param_1 = 0;
        if ((iVar1 < 0x40) &&
           (iVar2 = *(int *)((long)param_2 + 0x84), *(int *)((long)param_2 + 0x84) = iVar2 + 1,
           iVar2 < 0x400)) {
          *(int *)(param_2 + 0x10) = iVar1 + 1;
                    /* try { // try from 00522d84 to 00522d8f has its CatchHandler @ 00522fcc */
          FUN_00523024(&local_108,param_2);
          *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + -1;
        }
        else {
          bVar3 = *(byte *)*param_2;
          uVar7 = (ulong)(bVar3 >> 1);
          if ((bVar3 & 1) != 0) {
            uVar7 = *(ulong *)((byte *)*param_2 + 8);
          }
          param_2[0xf] = uVar7;
                    /* try { // try from 00522cf4 to 00522cfb has its CatchHandler @ 00522fcc */
          local_108 = (undefined8 *)FUN_005a5d4c(0x20);
          local_108[2] = 0;
          local_108[3] = 0;
          *local_108 = &PTR_FUN_005beaf8;
          local_108[1] = 0;
          *(undefined4 *)(local_108 + 3) = 1;
        }
        local_80 = local_a0;
        local_a0[0] = &PTR_FUN_005bf728;
                    /* try { // try from 00522da8 to 00522daf has its CatchHandler @ 00522fa8 */
        puVar8 = (undefined8 *)FUN_005a5d4c(0x50);
        puVar5 = local_108;
        *puVar8 = &PTR_FUN_005bfd38;
        puVar8[1] = puVar6;
        *param_1 = puVar8;
        local_108 = (undefined8 *)0x0;
        puVar8[3] = 0;
        puVar8[2] = 0;
        puVar8[7] = 0;
        puVar8[6] = 0;
        puVar8[9] = 0;
        puVar8[8] = 0;
        puVar6 = puVar8 + 4;
        puVar8[5] = 0;
        *puVar6 = 0;
        puVar8[2] = puVar5;
        puVar8[8] = puVar6;
        *puVar6 = &PTR_FUN_005bf728;
        puVar6 = puVar8;
      }
                    /* try { // try from 00522d10 to 00522d1b has its CatchHandler @ 00522fe8 */
      uVar7 = FUN_00522448(param_2,&DAT_00147c0a);
      if ((uVar7 & 1) == 0) break;
      iVar1 = *(int *)(param_2 + 0x10);
      *param_1 = 0;
      if ((iVar1 < 0x40) &&
         (iVar2 = *(int *)((long)param_2 + 0x84), *(int *)((long)param_2 + 0x84) = iVar2 + 1,
         iVar2 < 0x400)) {
        *(int *)(param_2 + 0x10) = iVar1 + 1;
                    /* try { // try from 00522df0 to 00522dfb has its CatchHandler @ 00522f88 */
        FUN_00523024(&local_110,param_2);
        *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + -1;
      }
      else {
        bVar3 = *(byte *)*param_2;
        uVar7 = (ulong)(bVar3 >> 1);
        if ((bVar3 & 1) != 0) {
          uVar7 = *(ulong *)((byte *)*param_2 + 8);
        }
        param_2[0xf] = uVar7;
                    /* try { // try from 00522d60 to 00522d67 has its CatchHandler @ 00522f88 */
        local_110 = (undefined8 *)FUN_005a5d4c(0x20);
        local_110[2] = 0;
        local_110[3] = 0;
        *local_110 = &PTR_FUN_005beaf8;
        local_110[1] = 0;
        *(undefined4 *)(local_110 + 3) = 1;
      }
      local_b0 = local_d0;
      local_d0[0] = &PTR_FUN_005bf7b8;
                    /* try { // try from 00522e14 to 00522e1b has its CatchHandler @ 00522f94 */
      puVar8 = (undefined8 *)FUN_005a5d4c(0x50);
      puVar5 = local_110;
      *puVar8 = &PTR_FUN_005bfd38;
      puVar8[1] = puVar6;
      *param_1 = puVar8;
      local_110 = (undefined8 *)0x0;
      puVar8[3] = 0;
      puVar8[2] = 0;
      puVar8[7] = 0;
      puVar8[6] = 0;
      puVar8[9] = 0;
      puVar8[8] = 0;
      puVar6 = puVar8 + 4;
      puVar8[5] = 0;
      *puVar6 = 0;
      puVar8[2] = puVar5;
      puVar8[8] = puVar6;
      *puVar6 = &PTR_FUN_005bf7b8;
      puVar6 = puVar8;
    }
                    /* try { // try from 00522e54 to 00522e63 has its CatchHandler @ 00522fe8 */
    uVar7 = FUN_00522448(param_2,&DAT_00140393);
    if ((uVar7 & 1) == 0) break;
    iVar1 = *(int *)(param_2 + 0x10);
    *param_1 = 0;
    if ((iVar1 < 0x40) &&
       (iVar2 = *(int *)((long)param_2 + 0x84), *(int *)((long)param_2 + 0x84) = iVar2 + 1,
       iVar2 < 0x400)) {
      *(int *)(param_2 + 0x10) = iVar1 + 1;
      FUN_00523024(&local_118,param_2);
      *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + -1;
    }
    else {
      bVar3 = *(byte *)*param_2;
      uVar7 = (ulong)(bVar3 >> 1);
      if ((bVar3 & 1) != 0) {
        uVar7 = *(ulong *)((byte *)*param_2 + 8);
      }
      param_2[0xf] = uVar7;
                    /* try { // try from 00522ea8 to 00522ed7 has its CatchHandler @ 00522f80 */
      local_118 = (undefined8 *)FUN_005a5d4c(0x20);
      local_118[2] = 0;
      local_118[3] = 0;
      *local_118 = &PTR_FUN_005beaf8;
      local_118[1] = 0;
      *(undefined4 *)(local_118 + 3) = 1;
    }
    local_e0 = local_100;
    local_100[0] = &PTR_FUN_005bf838;
                    /* try { // try from 00522ef8 to 00522eff has its CatchHandler @ 00522f6c */
    puVar8 = (undefined8 *)FUN_005a5d4c(0x50);
    puVar5 = local_118;
    *puVar8 = &PTR_FUN_005bfd38;
    puVar8[1] = puVar6;
    *param_1 = puVar8;
    local_118 = (undefined8 *)0x0;
    puVar8[3] = 0;
    puVar8[2] = 0;
    puVar8[7] = 0;
    puVar8[6] = 0;
    puVar8[9] = 0;
    puVar8[8] = 0;
    puVar6 = puVar8 + 4;
    puVar8[5] = 0;
    *puVar6 = 0;
    puVar8[2] = puVar5;
    puVar8[8] = puVar6;
    *puVar6 = &PTR_FUN_005bf838;
    puVar6 = puVar8;
  }
  if (*(long *)(lVar4 + 0x28) != local_70) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}



// ========================================
// Function: FUN_00523024
// Address: 00523024
// ========================================

void FUN_00523024(undefined8 *param_1,undefined8 *param_2)

{
  byte bVar1;
  long lVar2;
  bool bVar3;
  int iVar4;
  byte *pbVar5;
  ulong uVar6;
  undefined8 *puVar7;
  ulong uVar8;
  byte *pbVar9;
  undefined8 *puVar10;
  uint uVar11;
  ulong uVar12;
  byte bVar13;
  ulong uVar14;
  ulong uVar15;
  undefined **ppuVar16;
  float fVar17;
  undefined8 *local_d8;
  undefined8 *local_d0;
  char *local_c8 [2];
  void *local_b8;
  undefined **local_b0 [4];
  undefined ***local_90;
  undefined **local_80 [4];
  undefined ***local_60;
  long local_48;
  
  lVar2 = tpidr_el0;
  local_48 = *(long *)(lVar2 + 0x28);
  pbVar5 = (byte *)*param_2;
  uVar8 = param_2[0xf];
  bVar1 = *pbVar5;
  uVar12 = *(ulong *)(pbVar5 + 8);
  uVar14 = (ulong)(bVar1 >> 1);
  bVar13 = bVar1 & 1;
  uVar6 = uVar14;
  if ((bVar1 & 1) != 0) {
    uVar6 = uVar12;
  }
  if (uVar8 < uVar6) {
    pbVar9 = *(byte **)(pbVar5 + 0x10);
    if ((bVar1 & 1) == 0) {
      pbVar9 = pbVar5 + 1;
    }
    if (pbVar9[uVar8] == 0x20 || 0xfffffffa < pbVar9[uVar8] - 0xe) {
      do {
        uVar8 = uVar8 + 1;
        param_2[0xf] = uVar8;
        bVar1 = *pbVar5;
        uVar12 = *(ulong *)(pbVar5 + 8);
        uVar14 = (ulong)(bVar1 >> 1);
        bVar13 = bVar1 & 1;
        uVar6 = uVar14;
        if ((bVar1 & 1) != 0) {
          uVar6 = uVar12;
        }
        if (uVar6 <= uVar8) goto LAB_005230ec;
        pbVar9 = pbVar5 + 1;
        if ((bVar1 & 1) != 0) {
          pbVar9 = *(byte **)(pbVar5 + 0x10);
        }
      } while (pbVar9[uVar8] == 0x20 || 0xfffffffa < pbVar9[uVar8] - 0xe);
    }
    uVar14 = (ulong)(bVar1 >> 1);
    bVar13 = bVar1 & 1;
  }
LAB_005230ec:
  if (bVar13 != 0) {
    uVar14 = uVar12;
  }
  if (uVar8 < uVar14) {
    pbVar9 = *(byte **)(pbVar5 + 0x10);
    if (bVar13 == 0) {
      pbVar9 = pbVar5 + 1;
    }
    if ((pbVar9[uVar8] != 0x21) || (iVar4 = FUN_00561a10(pbVar5,uVar8,2,&DAT_0015d2c0), iVar4 == 0))
    goto LAB_00523198;
    param_2[0xf] = param_2[0xf] + 1;
    if ((*(int *)(param_2 + 0x10) < 0x40) &&
       (iVar4 = *(int *)((long)param_2 + 0x84), *(int *)((long)param_2 + 0x84) = iVar4 + 1,
       iVar4 < 0x400)) {
      *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + 1;
      FUN_00523024(&local_d0,param_2);
      *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + -1;
    }
    else {
      bVar13 = *(byte *)*param_2;
      uVar6 = (ulong)(bVar13 >> 1);
      if ((bVar13 & 1) != 0) {
        uVar6 = *(ulong *)((byte *)*param_2 + 8);
      }
      param_2[0xf] = uVar6;
      local_d0 = (undefined8 *)FUN_005a5d4c(0x20);
      local_d0[2] = 0;
      local_d0[3] = 0;
      *local_d0 = &PTR_FUN_005beaf8;
      local_d0[1] = 0;
      *(undefined4 *)(local_d0 + 3) = 1;
    }
    ppuVar16 = &PTR_FUN_005beb88;
    local_60 = local_80;
    local_80[0] = &PTR_FUN_005beb88;
                    /* try { // try from 00523460 to 00523467 has its CatchHandler @ 00523614 */
    puVar7 = (undefined8 *)FUN_005a5d4c(0x40);
    puVar10 = local_d0;
LAB_00523470:
    puVar7[5] = 0;
    puVar7[4] = 0;
    puVar7[7] = 0;
    puVar7[6] = 0;
    *puVar7 = &PTR_FUN_005beb48;
    puVar7[1] = puVar10;
    puVar10 = puVar7 + 2;
    puVar7[3] = 0;
    *puVar10 = 0;
    puVar7[6] = puVar10;
    *puVar10 = ppuVar16;
  }
  else {
LAB_00523198:
    uVar6 = FUN_00522448(param_2,&DAT_00181349);
    if ((uVar6 & 1) != 0) {
      if ((*(int *)(param_2 + 0x10) < 0x40) &&
         (iVar4 = *(int *)((long)param_2 + 0x84), *(int *)((long)param_2 + 0x84) = iVar4 + 1,
         iVar4 < 0x400)) {
        *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + 1;
        FUN_00523024(&local_d8,param_2);
        *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + -1;
      }
      else {
        bVar13 = *(byte *)*param_2;
        uVar6 = (ulong)(bVar13 >> 1);
        if ((bVar13 & 1) != 0) {
          uVar6 = *(ulong *)((byte *)*param_2 + 8);
        }
        param_2[0xf] = uVar6;
        local_d8 = (undefined8 *)FUN_005a5d4c(0x20);
        local_d8[2] = 0;
        local_d8[3] = 0;
        *local_d8 = &PTR_FUN_005beaf8;
        local_d8[1] = 0;
        *(undefined4 *)(local_d8 + 3) = 1;
      }
      ppuVar16 = &PTR_FUN_005bec18;
      local_90 = local_b0;
      local_b0[0] = &PTR_FUN_005bec18;
                    /* try { // try from 005232cc to 005232d3 has its CatchHandler @ 0052361c */
      puVar7 = (undefined8 *)FUN_005a5d4c(0x40);
      puVar10 = local_d8;
      goto LAB_00523470;
    }
    uVar6 = FUN_00522448(param_2,&DAT_00140391);
    if ((uVar6 & 1) == 0) {
      uVar6 = FUN_00522448(param_2,&DAT_001673b5);
      if ((uVar6 & 1) != 0) {
        FUN_0051f4ec(param_1,param_2);
                    /* try { // try from 00523284 to 00523293 has its CatchHandler @ 005235f4 */
        FUN_00522448(param_2,&DAT_00157c5d);
        goto LAB_00523494;
      }
      pbVar5 = (byte *)*param_2;
      uVar8 = param_2[0xf];
      bVar13 = *pbVar5;
      uVar15 = (ulong)bVar13;
      uVar12 = *(ulong *)(pbVar5 + 8);
      uVar14 = (ulong)(bVar13 >> 1);
      uVar11 = bVar13 & 1;
      uVar6 = uVar14;
      if ((bVar13 & 1) != 0) {
        uVar6 = uVar12;
      }
      if (uVar8 < uVar6) {
        pbVar9 = *(byte **)(pbVar5 + 0x10);
        if ((bVar13 & 1) == 0) {
          pbVar9 = pbVar5 + 1;
        }
        if ((pbVar9[uVar8] == 0x20) || (0xfffffffa < pbVar9[uVar8] - 0xe)) {
          do {
            uVar8 = uVar8 + 1;
            param_2[0xf] = uVar8;
            bVar13 = *pbVar5;
            uVar12 = *(ulong *)(pbVar5 + 8);
            uVar14 = (ulong)(bVar13 >> 1);
            uVar11 = bVar13 & 1;
            uVar6 = uVar14;
            if ((bVar13 & 1) != 0) {
              uVar6 = uVar12;
            }
            if (uVar6 <= uVar8) goto LAB_00523384;
            pbVar9 = pbVar5 + 1;
            if ((bVar13 & 1) != 0) {
              pbVar9 = *(byte **)(pbVar5 + 0x10);
            }
          } while (pbVar9[uVar8] == 0x20 || 0xfffffffa < pbVar9[uVar8] - 0xe);
          uVar15 = (ulong)(uint)bVar13;
        }
        uVar14 = uVar15 >> 1;
        uVar11 = (uint)uVar15 & 1;
      }
LAB_00523384:
      bVar3 = uVar11 == 0;
      if (!bVar3) {
        uVar14 = uVar12;
      }
      if (uVar14 <= uVar8) goto LAB_005233e4;
      pbVar9 = *(byte **)(pbVar5 + 0x10);
      if (uVar11 == 0) {
        pbVar9 = pbVar5 + 1;
      }
      bVar13 = pbVar9[uVar8];
      if ((bVar13 != 0x2e) && (9 < bVar13 - 0x30)) {
        uVar6 = uVar8;
        if ((bVar13 == 0x5f) || (0xffffffe5 < (bVar13 & 0xffffffdf) - 0x5b)) {
          do {
            pbVar9 = pbVar5 + 1;
            if (!bVar3) {
              pbVar9 = *(byte **)(pbVar5 + 0x10);
            }
            if (((pbVar9[uVar6] - 0x3a < 0xfffffff6 &&
                  (pbVar9[uVar6] & 0xffffffdf) - 0x5b < 0xffffffe6) && (pbVar9[uVar6] != 0x5f)) &&
               (pbVar9[uVar6] != 0x2e)) break;
            uVar6 = uVar6 + 1;
            param_2[0xf] = uVar6;
            bVar3 = (*pbVar5 & 1) == 0;
            uVar14 = (ulong)(*pbVar5 >> 1);
            if (!bVar3) {
              uVar14 = *(ulong *)(pbVar5 + 8);
            }
          } while (uVar6 < uVar14);
          FUN_002dd7a4(local_c8,pbVar5,uVar8,uVar6 - uVar8);
                    /* try { // try from 00523590 to 005235c7 has its CatchHandler @ 005235dc */
          uVar6 = FUN_00522448(param_2,&DAT_001673b5);
          if ((uVar6 & 1) == 0) {
            FUN_00524764(param_1,param_2,local_c8);
          }
          else {
            FUN_00523908(param_1,param_2,local_c8);
          }
          if (((ulong)local_c8[0] & 1) != 0) {
            free(local_b8);
          }
          goto LAB_00523494;
        }
        uVar6 = uVar8 + 1;
        goto LAB_0052325c;
      }
      local_c8[0] = (char *)0x0;
      fVar17 = strtof((char *)(pbVar9 + uVar8),local_c8);
      param_2[0xf] = local_c8[0] + (param_2[0xf] - (long)(pbVar9 + uVar8));
      puVar7 = (undefined8 *)FUN_005a5d4c(0x20);
      puVar7[2] = 0;
      puVar7[3] = 0;
      *puVar7 = &PTR_FUN_005beaf8;
      *(undefined8 *)((long)puVar7 + 0xc) = 0;
      *(undefined8 *)((long)puVar7 + 0x14) = 0x100000000;
      *(float *)(puVar7 + 1) = fVar17;
    }
    else {
      if ((*(int *)(param_2 + 0x10) < 0x40) &&
         (iVar4 = *(int *)((long)param_2 + 0x84), *(int *)((long)param_2 + 0x84) = iVar4 + 1,
         iVar4 < 0x400)) {
        *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + 1;
        FUN_00523024(param_1,param_2);
        *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + -1;
        goto LAB_00523494;
      }
      bVar13 = *(byte *)*param_2;
      uVar6 = (ulong)(bVar13 >> 1);
      if ((bVar13 & 1) != 0) {
        uVar6 = *(ulong *)((byte *)*param_2 + 8);
      }
LAB_0052325c:
      param_2[0xf] = uVar6;
LAB_005233e4:
      puVar7 = (undefined8 *)FUN_005a5d4c(0x20);
      puVar7[2] = 0;
      puVar7[3] = 0;
      *puVar7 = &PTR_FUN_005beaf8;
      puVar7[1] = 0;
      *(undefined4 *)(puVar7 + 3) = 1;
    }
  }
  *param_1 = puVar7;
LAB_00523494:
  if (*(long *)(lVar2 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: free
// Address: 00523654
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00523658
// Address: 00523658
// ========================================

void FUN_00523658(undefined8 *param_1,long param_2)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uVar2 = *(undefined8 *)(param_2 + 8);
  uVar1 = *(undefined4 *)(param_2 + 0x18);
  param_1[1] = *(undefined8 *)(param_2 + 0x10);
  *param_1 = uVar2;
  *(undefined4 *)(param_1 + 2) = uVar1;
  return;
}



// ========================================
// Function: FUN_0052366c
// Address: 0052366c
// ========================================

void FUN_0052366c(undefined8 *param_1)

{
  long *plVar1;
  long *plVar2;
  long lVar3;
  
  plVar1 = (long *)param_1[6];
  plVar2 = param_1 + 2;
  *param_1 = &PTR_FUN_005beb48;
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) goto LAB_005236b8;
    lVar3 = 5;
    plVar2 = plVar1;
  }
  (**(code **)(*plVar2 + lVar3 * 8))();
LAB_005236b8:
  plVar2 = (long *)param_1[1];
  param_1[1] = 0;
  if (plVar2 != (long *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x005236d4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar2 + 8))();
    return;
  }
  return;
}



// ========================================
// Function: FUN_005236e4
// Address: 005236e4
// ========================================

void FUN_005236e4(undefined8 *param_1)

{
  long *plVar1;
  long *plVar2;
  long lVar3;
  
  plVar1 = (long *)param_1[6];
  plVar2 = param_1 + 2;
  *param_1 = &PTR_FUN_005beb48;
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) goto LAB_00523730;
    lVar3 = 5;
    plVar2 = plVar1;
  }
  (**(code **)(*plVar2 + lVar3 * 8))();
LAB_00523730:
  plVar2 = (long *)param_1[1];
  param_1[1] = 0;
  if (plVar2 != (long *)0x0) {
    (**(code **)(*plVar2 + 8))();
  }
  free(param_1);
  return;
}



// ========================================
// Function: FUN_00523758
// Address: 00523758
// ========================================

void FUN_00523758(long param_1,long param_2)

{
  int iVar1;
  long lVar2;
  long *plVar3;
  long lVar4;
  undefined4 uVar5;
  undefined4 local_3c;
  long local_38;
  
  lVar2 = tpidr_el0;
  local_38 = *(long *)(lVar2 + 0x28);
  (**(code **)(**(long **)(param_2 + 8) + 0x10))();
  if (0 < *(int *)(param_1 + 0x10)) {
    lVar4 = 0;
    do {
      local_3c = *(undefined4 *)(param_1 + lVar4 * 4);
      plVar3 = *(long **)(param_2 + 0x30);
      if (plVar3 == (long *)0x0) {
        if (*(long *)(lVar2 + 0x28) == local_38) {
                    /* WARNING: Subroutine does not return */
          FUN_002efc90();
        }
        goto LAB_0052380c;
      }
      uVar5 = (**(code **)(*plVar3 + 0x30))(plVar3,&local_3c);
      iVar1 = *(int *)(param_1 + 0x10);
      *(undefined4 *)(param_1 + lVar4 * 4) = uVar5;
      lVar4 = lVar4 + 1;
    } while (lVar4 < iVar1);
  }
  if (*(long *)(lVar2 + 0x28) == local_38) {
    return;
  }
LAB_0052380c:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: free
// Address: 00523810
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00523814
// Address: 00523814
// ========================================

void FUN_00523814(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005beb88;
  return;
}



// ========================================
// Function: FUN_00523838
// Address: 00523838
// ========================================

void FUN_00523838(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005beb88;
  return;
}



// ========================================
// Function: FUN_00523848
// Address: 00523848
// ========================================

void FUN_00523848(void)

{
  return;
}



// ========================================
// Function: free
// Address: 0052384c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00523850
// Address: 00523850
// ========================================

undefined4 FUN_00523850(undefined8 param_1,float *param_2)

{
  undefined4 uVar1;
  
  uVar1 = 0x3f800000;
  if (*param_2 != 0.0) {
    uVar1 = 0;
  }
  return uVar1;
}



// ========================================
// Function: FUN_00523868
// Address: 00523868
// ========================================

long FUN_00523868(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser10unary_termEvEUlfE_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00523884
// Address: 00523884
// ========================================

undefined ** FUN_00523884(void)

{
  return &PTR_PTR_005bebf8;
}



// ========================================
// Function: FUN_00523890
// Address: 00523890
// ========================================

void FUN_00523890(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00523894
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00523898
// Address: 00523898
// ========================================

void FUN_00523898(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bec18;
  return;
}



// ========================================
// Function: FUN_005238bc
// Address: 005238bc
// ========================================

void FUN_005238bc(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bec18;
  return;
}



// ========================================
// Function: FUN_005238cc
// Address: 005238cc
// ========================================

void FUN_005238cc(void)

{
  return;
}



// ========================================
// Function: free
// Address: 005238d0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_005238d4
// Address: 005238d4
// ========================================

float FUN_005238d4(undefined8 param_1,float *param_2)

{
  return -*param_2;
}



// ========================================
// Function: FUN_005238e0
// Address: 005238e0
// ========================================

long FUN_005238e0(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser10unary_termEvEUlfE0_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_005238fc
// Address: 005238fc
// ========================================

undefined ** FUN_005238fc(void)

{
  return &PTR_PTR_005bec78;
}



// ========================================
// Function: FUN_00523908
// Address: 00523908
// ========================================

void FUN_00523908(undefined8 *param_1,long param_2,byte *param_3)

{
  byte bVar1;
  long lVar2;
  undefined **ppuVar3;
  bool bVar4;
  ulong uVar5;
  long lVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  undefined ***pppuVar9;
  long *plVar10;
  byte *pbVar11;
  byte *pbVar12;
  undefined8 uVar13;
  ulong uVar14;
  undefined ***pppuVar15;
  undefined ****ppppuVar16;
  long lVar17;
  ulong uVar18;
  long *plVar19;
  long *plVar20;
  long *plVar21;
  long lVar22;
  long lVar23;
  long *local_e8;
  long *local_e0;
  long *local_d8;
  undefined **local_d0;
  code *local_c8;
  undefined ***local_b0 [2];
  undefined **local_a0;
  code *pcStack_98;
  undefined ***local_80;
  long local_68;
  
  lVar2 = tpidr_el0;
  local_68 = *(long *)(lVar2 + 0x28);
  local_e8 = (long *)0x0;
  local_e0 = (long *)0x0;
  local_d8 = (long *)0x0;
                    /* try { // try from 0052394c to 00523957 has its CatchHandler @ 00524710 */
  uVar5 = FUN_00522448(param_2,&DAT_00157c5d);
  plVar20 = (long *)0x0;
  if ((uVar5 & 1) == 0) {
    do {
                    /* try { // try from 00523970 to 0052397b has its CatchHandler @ 00524738 */
      FUN_0051f4ec(&local_a0,param_2);
      if (local_e0 < local_d8) {
        *local_e0 = (long)local_a0;
        plVar20 = local_e0;
      }
      else {
        lVar17 = (long)local_e0 - (long)local_e8;
        uVar5 = (lVar17 >> 3) + 1;
        if (uVar5 >> 0x3d != 0) {
          if (*(long *)(lVar2 + 0x28) == local_68) {
                    /* try { // try from 005246b4 to 005246cf has its CatchHandler @ 00524718 */
            FUN_00524bcc();
LAB_005246b8:
            if (*(long *)(lVar2 + 0x28) == local_68) {
                    /* WARNING: Subroutine does not return */
              FUN_0029fc3c();
            }
          }
          goto LAB_00524760;
        }
        uVar14 = (long)local_d8 - (long)local_e8 >> 2;
        if (uVar14 <= uVar5) {
          uVar14 = uVar5;
        }
        if (0x7ffffffffffffff7 < (ulong)((long)local_d8 - (long)local_e8)) {
          uVar14 = 0x1fffffffffffffff;
        }
        if (uVar14 == 0) {
          lVar6 = 0;
        }
        else {
          if (uVar14 >> 0x3d != 0) goto LAB_005246b8;
                    /* try { // try from 005239d8 to 005239db has its CatchHandler @ 00524714 */
          lVar6 = FUN_005a5d4c(uVar14 << 3);
        }
        ppuVar3 = local_a0;
        plVar20 = (long *)(lVar6 + (lVar17 >> 3) * 8);
        local_d8 = (long *)(lVar6 + uVar14 * 8);
        local_a0 = (undefined **)0x0;
        *plVar20 = (long)ppuVar3;
        plVar10 = local_e0;
        plVar19 = plVar20;
        if ((long)local_e0 - (long)local_e8 != 0) {
          uVar5 = ((long)local_e0 - (long)local_e8) - 8;
          if (uVar5 < 0x138) {
LAB_00523a14:
            do {
              plVar10 = plVar10 + -1;
              lVar17 = *plVar10;
              *plVar10 = 0;
              plVar19 = plVar19 + -1;
              *plVar19 = lVar17;
            } while (plVar10 != local_e8);
          }
          else {
            plVar21 = local_e0 + -1;
            uVar14 = (long)plVar21 - (long)local_e8 & 0xfffffffffffffff8;
            if (((plVar21 < (long *)((long)plVar21 - uVar14)) ||
                (uVar18 = (lVar6 + lVar17) - 8, uVar18 < uVar18 - uVar14)) ||
               ((uVar14 = (long)plVar21 - (long)local_e8 & 0xfffffffffffffff8,
                (long *)((long)plVar21 - uVar14) < plVar20 &&
                ((long *)(lVar6 + (lVar17 - uVar14) + -8) < local_e0)))) goto LAB_00523a14;
            plVar10 = local_e0 + -2;
            plVar21 = (long *)(lVar6 + lVar17 + -0x10);
            uVar5 = (uVar5 >> 3) + 1;
            uVar18 = uVar5 & 0x3ffffffffffffffc;
            plVar19 = plVar20 + -uVar18;
            uVar14 = uVar18;
            do {
              lVar23 = plVar10[-1];
              lVar22 = plVar10[-2];
              lVar6 = plVar10[1];
              lVar17 = *plVar10;
              uVar14 = uVar14 - 4;
              plVar10[-1] = 0;
              plVar10[-2] = 0;
              plVar10[1] = 0;
              *plVar10 = 0;
              plVar10 = plVar10 + -4;
              plVar21[-1] = lVar23;
              plVar21[-2] = lVar22;
              plVar21[1] = lVar6;
              *plVar21 = lVar17;
              plVar21 = plVar21 + -4;
            } while (uVar14 != 0);
            plVar10 = local_e0 + -uVar18;
            if (uVar5 != uVar18) goto LAB_00523a14;
          }
          while (plVar10 = local_e8, local_e0 != local_e8) {
            local_e0 = local_e0 + -1;
            plVar10 = (long *)*local_e0;
            *local_e0 = 0;
            if (plVar10 != (long *)0x0) {
              (**(code **)(*plVar10 + 8))();
            }
          }
        }
        local_e8 = plVar19;
        if (plVar10 != (long *)0x0) {
          free(plVar10);
        }
        if (local_a0 != (undefined **)0x0) {
          (**(code **)(*local_a0 + 8))();
        }
      }
                    /* try { // try from 00523a94 to 00523a9f has its CatchHandler @ 00524734 */
      plVar20 = plVar20 + 1;
      uVar5 = FUN_00522448(param_2,&DAT_0015542e);
      local_e0 = plVar20;
    } while ((uVar5 & 1) != 0);
                    /* try { // try from 00523b64 to 00523b73 has its CatchHandler @ 00524710 */
    FUN_00522448(param_2,&DAT_00157c5d);
  }
  bVar1 = *param_3;
  uVar5 = (ulong)(bVar1 >> 1);
  if ((bVar1 & 1) != 0) {
    uVar5 = *(ulong *)(param_3 + 8);
  }
  if (uVar5 == 6) {
    pbVar11 = *(byte **)(param_3 + 0x10);
    if ((bVar1 & 1) == 0) {
      pbVar11 = param_3 + 1;
    }
    if (*(int *)pbVar11 != 0x6f6f6d73 || *(short *)(pbVar11 + 4) != 0x6874) goto LAB_00523c44;
                    /* try { // try from 00523fe0 to 00523fe7 has its CatchHandler @ 00524700 */
    puVar7 = (undefined8 *)FUN_005a5d4c(0x30);
    *puVar7 = &PTR_FUN_005becd8;
    uVar13 = *(undefined8 *)(param_2 + 0x70);
    uVar5 = (long)plVar20 - (long)local_e8 >> 3;
    plVar19 = puVar7 + 1;
    puVar7[2] = 0;
    *plVar19 = 0;
    puVar7[4] = 0;
    puVar7[3] = 0;
    puVar7[4] = uVar13;
    puVar7[5] = 0;
    *(undefined1 *)(puVar7 + 5) = 0;
    if ((long)plVar20 - (long)local_e8 == 0x20) {
      uVar14 = 1;
      if (uVar5 < 2) goto LAB_00524178;
LAB_00524034:
      lVar17 = local_e8[uVar14];
      local_e8[uVar14] = 0;
      bVar4 = lVar17 == 0;
      *plVar19 = lVar17;
    }
    else {
      if ((uVar5 < 2) || (*local_e8 == 0)) {
        uVar14 = 0;
        if (uVar5 == 0) goto LAB_00524178;
        goto LAB_00524034;
      }
      lVar17 = FUN_0058c594(*local_e8,&PTR_PTR_005beb10,&PTR_PTR_005beb20,0);
      uVar14 = (ulong)(lVar17 != 0);
      if (uVar14 < uVar5) goto LAB_00524034;
LAB_00524178:
      bVar4 = true;
    }
    uVar18 = uVar14 + 1;
    if (uVar18 < uVar5) {
      lVar17 = local_e8[uVar18];
      local_e8[uVar18] = 0;
      puVar7[2] = lVar17;
    }
    uVar14 = uVar14 | 2;
    if (uVar14 < uVar5) {
      lVar17 = local_e8[uVar14];
      local_e8[uVar14] = 0;
      puVar7[3] = lVar17;
    }
    if (bVar4) {
                    /* try { // try from 005241b8 to 005241bf has its CatchHandler @ 005246f0 */
      puVar8 = (undefined8 *)FUN_005a5d4c(0x20);
      puVar8[2] = 0;
      puVar8[3] = 0;
      *puVar8 = &PTR_FUN_005beaf8;
      puVar8[1] = 0;
      *(undefined4 *)(puVar8 + 3) = 1;
      *plVar19 = (long)puVar8;
    }
    *param_1 = puVar7;
    if (local_e8 != (long *)0x0) {
      while (plVar20 != local_e8) {
        plVar20 = plVar20 + -1;
        plVar19 = (long *)*plVar20;
        *plVar20 = 0;
        if (plVar19 != (long *)0x0) {
          (**(code **)(*plVar19 + 8))();
        }
      }
      if (*(long *)(lVar2 + 0x28) == local_68) {
        free(local_e8);
        return;
      }
      goto LAB_00524760;
    }
  }
  else {
    if (uVar5 == 3) {
      pbVar11 = *(byte **)(param_3 + 0x10);
      if ((bVar1 & 1) == 0) {
        pbVar11 = param_3 + 1;
      }
      if (*(short *)pbVar11 == 0x6669 && pbVar11[2] == 0x62) {
LAB_00523be8:
                    /* try { // try from 00523be8 to 00523bef has its CatchHandler @ 00524704 */
        puVar7 = (undefined8 *)FUN_005a5d4c(0x20);
        *puVar7 = &PTR_FUN_005bec98;
        puVar7[1] = local_e8;
        puVar7[2] = plVar20;
        puVar7[3] = local_d8;
        *param_1 = puVar7;
        goto LAB_00524520;
      }
    }
    else if (uVar5 == 2) {
      pbVar11 = *(byte **)(param_3 + 0x10);
      if ((bVar1 & 1) == 0) {
        pbVar11 = param_3 + 1;
      }
      if (*(short *)pbVar11 == 0x6669) goto LAB_00523be8;
    }
LAB_00523c44:
                    /* try { // try from 00523c44 to 00523c4b has its CatchHandler @ 0052470c */
    puVar7 = (undefined8 *)FUN_005a5d4c(0x50);
    *puVar7 = &PTR_FUN_005bed18;
    puVar8 = puVar7 + 1;
    *puVar8 = 0;
    pppuVar9 = (undefined ***)(puVar7 + 4);
    puVar7[5] = 0;
    *pppuVar9 = (undefined **)0x0;
    puVar7[7] = 0;
    puVar7[6] = 0;
    puVar7[9] = 0;
    puVar7[8] = 0;
    puVar7[2] = 0;
    puVar7[3] = 0;
    if ((long)uVar5 < 5) {
      if (uVar5 == 3) {
        pbVar12 = *(byte **)(param_3 + 0x10);
        pbVar11 = pbVar12;
        if ((bVar1 & 1) == 0) {
          pbVar11 = param_3 + 1;
        }
        if (*(short *)pbVar11 == 0x6973 && pbVar11[2] == 0x6e) {
          local_c8 = sinf;
        }
        else if (*(short *)pbVar11 == 0x6f63 && pbVar11[2] == 0x73) {
          local_c8 = cosf;
        }
        else if (*(short *)pbVar11 == 0x6174 && pbVar11[2] == 0x6e) {
          local_c8 = tanf;
        }
        else if (*(short *)pbVar11 == 0x6261 && pbVar11[2] == 0x73) {
          local_c8 = FUN_00525894;
        }
        else if (*(short *)pbVar11 == 0x7865 && pbVar11[2] == 0x70) {
          local_c8 = expf;
        }
        else {
          if (*(short *)pbVar11 == 0x6f6c && pbVar11[2] == 0x67) {
            local_80 = &local_a0;
            local_a0 = &PTR_FUN_005bed58;
            pcStack_98 = FUN_005258d4;
                    /* try { // try from 00524378 to 0052437f has its CatchHandler @ 005246dc */
            local_b0[0] = (undefined ***)FUN_005a5d4c(0x40);
            local_b0[0][3] = (undefined **)FUN_005258d4;
            *local_b0[0] = &PTR_FUN_005bee68;
            local_b0[0][2] = &PTR_FUN_005bed58;
            local_b0[0][6] = (undefined **)(local_b0[0] + 2);
            goto LAB_00524400;
          }
          if ((bVar1 & 1) == 0) {
            pbVar12 = param_3 + 1;
          }
          if (*(short *)pbVar12 != 0x6f6e || pbVar12[2] != 0x74) goto LAB_00523db8;
          local_c8 = FUN_00525c8c;
        }
      }
      else {
        if (uVar5 != 4) goto LAB_00523db8;
        pbVar12 = *(byte **)(param_3 + 0x10);
        pbVar11 = pbVar12;
        if ((bVar1 & 1) == 0) {
          pbVar11 = param_3 + 1;
        }
        if (*(int *)pbVar11 == 0x6e697361) {
          local_c8 = asinf;
        }
        else if (*(int *)pbVar11 == 0x736f6361) {
          local_c8 = acosf;
        }
        else {
          if (*(int *)pbVar11 == 0x6e617461) {
                    /* try { // try from 00524244 to 0052424b has its CatchHandler @ 005246e0 */
            local_b0[0] = (undefined ***)FUN_005a5d4c(0x40);
            *local_b0[0] = &PTR_FUN_005bede8;
            local_b0[0][2] = &PTR_FUN_005bed58;
            local_b0[0][6] = (undefined **)(local_b0[0] + 2);
            local_b0[0][3] = (undefined **)atanf;
            goto LAB_00524400;
          }
          if (*(int *)pbVar11 == 0x6c696563) {
            local_c8 = FUN_005258a4;
          }
          else {
            if (*(int *)pbVar11 == 0x63617266) goto LAB_005242a4;
            if (*(int *)pbVar11 == 0x32707865) {
              local_c8 = exp2f;
            }
            else if (*(int *)pbVar11 == 0x32676f6c) {
              local_c8 = FUN_00525c04;
            }
            else {
              if (*(int *)pbVar11 != 0x74727173) {
                if ((bVar1 & 1) == 0) {
                  pbVar12 = param_3 + 1;
                }
                if (*(int *)pbVar12 == 0x6e676973) goto LAB_00524050;
                goto LAB_00523db8;
              }
              local_c8 = FUN_00525c5c;
            }
          }
        }
      }
LAB_005243f8:
      local_d0 = &PTR_FUN_005bed58;
      local_b0[0] = &local_d0;
    }
    else {
      if (uVar5 == 5) {
        pbVar11 = *(byte **)(param_3 + 0x10);
        if ((bVar1 & 1) == 0) {
          pbVar11 = param_3 + 1;
        }
        if (*(int *)pbVar11 == 0x61726f74 && pbVar11[4] == 100) {
          local_c8 = FUN_00525854;
        }
        else if (*(int *)pbVar11 == 0x65646f74 && pbVar11[4] == 0x67) {
          local_c8 = FUN_00525874;
        }
        else if (*(int *)pbVar11 == 0x6f6f6c66 && pbVar11[4] == 0x72) {
          local_c8 = FUN_0052589c;
        }
        else if (*(int *)pbVar11 == 0x6e756f72 && pbVar11[4] == 100) {
          local_c8 = FUN_005258ac;
        }
        else if (*(int *)pbVar11 == 0x63617266 && pbVar11[4] == 0x74) {
LAB_005242a4:
          local_c8 = FUN_005258b4;
        }
        else if (*(int *)pbVar11 == 0x31707865 && pbVar11[4] == 0x30) {
          local_c8 = FUN_005258c8;
        }
        else {
          if (*(int *)pbVar11 != 0x31676f6c || pbVar11[4] != 0x30) goto LAB_00523db8;
          local_c8 = FUN_00525c30;
        }
        goto LAB_005243f8;
      }
      if (uVar5 == 6) {
        pbVar11 = *(byte **)(param_3 + 0x10);
        if ((bVar1 & 1) == 0) {
          pbVar11 = param_3 + 1;
        }
        if (*(int *)pbVar11 != 0x6e676973 || *(short *)(pbVar11 + 4) != 0x6d75) {
          if (*(int *)pbVar11 != 0x646e6172 || *(short *)(pbVar11 + 4) != 0x6d6f) goto LAB_00523db8;
          local_d0 = &PTR_FUN_005beee8;
          goto LAB_00524138;
        }
LAB_00524050:
        local_c8 = FUN_00525c70;
        goto LAB_005243f8;
      }
LAB_00523db8:
      uVar5 = FUN_0029c65c(param_3,"atan2");
      if ((uVar5 & 1) == 0) {
        uVar5 = FUN_0029c65c(param_3,&DAT_00197377);
        if ((uVar5 & 1) != 0) {
          local_d0 = &PTR_FUN_005befe8;
          goto LAB_005240d0;
        }
        uVar5 = FUN_0029c65c(param_3,&DAT_0018d835);
        if (((uVar5 & 1) != 0) || (uVar5 = FUN_0029c65c(param_3,&DAT_0014c3b8), (uVar5 & 1) != 0)) {
          local_d0 = &PTR_FUN_005bf068;
          goto LAB_005240d0;
        }
        uVar5 = FUN_0029c65c(param_3,&DAT_0014083e);
        if ((uVar5 & 1) == 0) {
          uVar5 = FUN_0029c65c(param_3,&DAT_0015820b);
          if ((uVar5 & 1) == 0) {
            uVar5 = FUN_0029c65c(param_3,"clamp");
            if ((uVar5 & 1) == 0) {
              uVar5 = FUN_0029c65c(param_3,&DAT_00196bb5);
              if ((uVar5 & 1) == 0) {
                uVar5 = FUN_0029c65c(param_3,&DAT_00176ce7);
                if ((uVar5 & 1) == 0) {
                  uVar5 = FUN_0029c65c(param_3,&DAT_00145c83);
                  if ((uVar5 & 1) == 0) {
                    uVar5 = FUN_0029c65c(param_3,"smoothstep");
                    if ((uVar5 & 1) == 0) {
                      uVar5 = FUN_0029c65c(param_3,"equals");
                      if ((uVar5 & 1) == 0) {
                        uVar5 = FUN_0029c65c(param_3,"between");
                        if ((uVar5 & 1) == 0) {
                          uVar5 = FUN_0029c65c(param_3,&DAT_00155b3c);
                          if ((uVar5 & 1) == 0) {
                            uVar5 = FUN_0029c65c(param_3,&DAT_00169377);
                            if ((((uVar5 & 1) != 0) ||
                                (uVar5 = FUN_0029c65c(param_3,&DAT_00169433), (uVar5 & 1) != 0)) ||
                               (uVar5 = FUN_0029c65c(param_3,&DAT_0015d19d), (uVar5 & 1) != 0)) {
                              pbVar11 = *(byte **)(param_3 + 0x10);
                              local_b0[0] = &local_d0;
                              if ((*param_3 & 1) == 0) {
                                pbVar11 = param_3 + 1;
                              }
                              local_d0 = &PTR_FUN_005bf5e8;
                              local_c8 = (code *)CONCAT44(local_c8._4_4_,pbVar11[3] - 0x30);
                              goto LAB_00524400;
                            }
                            local_d0 = &PTR_FUN_005bf668;
                          }
                          else {
                            local_d0 = &PTR_FUN_005bf568;
                          }
                          goto LAB_00524138;
                        }
                        local_d0 = &PTR_FUN_005bf4e8;
                      }
                      else {
                        local_d0 = &PTR_FUN_005bf468;
                      }
                    }
                    else {
                      local_d0 = &PTR_FUN_005bf3e8;
                    }
                  }
                  else {
                    local_d0 = &PTR_FUN_005bf368;
                  }
                }
                else {
                  local_d0 = &PTR_FUN_005bf2e8;
                }
              }
              else {
                local_d0 = &PTR_FUN_005bf268;
              }
            }
            else {
              local_d0 = &PTR_FUN_005bf1e8;
            }
            goto LAB_005240d0;
          }
          local_d0 = &PTR_FUN_005bf168;
        }
        else {
          local_d0 = &PTR_FUN_005bf0e8;
        }
LAB_00524138:
        local_b0[0] = &local_d0;
      }
      else {
        local_d0 = &PTR_FUN_005bef68;
LAB_005240d0:
        local_b0[0] = &local_d0;
        local_c8 = (code *)((ulong)local_c8 & 0xffffffffffffff00);
      }
    }
LAB_00524400:
    ppppuVar16 = (undefined ****)(puVar7 + 8);
    pppuVar15 = *ppppuVar16;
    *ppppuVar16 = (undefined ***)0x0;
    if (pppuVar15 == pppuVar9) {
      lVar17 = 4;
      pppuVar15 = pppuVar9;
LAB_0052442c:
      (*(code *)(*pppuVar15)[lVar17])(pppuVar15);
      if (local_b0[0] != (undefined ***)0x0) goto LAB_00524444;
LAB_00524464:
      *ppppuVar16 = (undefined ***)0x0;
    }
    else {
      if (pppuVar15 != (undefined ***)0x0) {
        lVar17 = 5;
        goto LAB_0052442c;
      }
LAB_00524444:
      if (local_b0[0] != &local_d0) {
        *ppppuVar16 = local_b0[0];
        ppppuVar16 = local_b0;
        goto LAB_00524464;
      }
      *ppppuVar16 = pppuVar9;
                    /* try { // try from 00524478 to 00524483 has its CatchHandler @ 00524708 */
      (*(code *)local_d0[3])(&local_d0,pppuVar9);
    }
    if (local_b0[0] == &local_d0) {
      lVar17 = 4;
      pppuVar9 = &local_d0;
LAB_005244a8:
      (*(code *)(*pppuVar9)[lVar17])();
    }
    else if (local_b0[0] != (undefined ***)0x0) {
      lVar17 = 5;
      pppuVar9 = local_b0[0];
      goto LAB_005244a8;
    }
    plVar19 = (long *)*puVar8;
    if (plVar19 != (long *)0x0) {
      plVar21 = (long *)puVar7[2];
      plVar10 = plVar19;
      if (plVar21 != plVar19) {
        do {
          plVar21 = plVar21 + -1;
          plVar10 = (long *)*plVar21;
          *plVar21 = 0;
          if (plVar10 != (long *)0x0) {
            (**(code **)(*plVar10 + 8))();
          }
        } while (plVar21 != plVar19);
        plVar10 = (long *)*puVar8;
      }
      puVar7[2] = plVar19;
      free(plVar10);
      *puVar8 = 0;
      puVar7[2] = 0;
      puVar7[3] = 0;
    }
    puVar7[1] = local_e8;
    puVar7[2] = plVar20;
    puVar7[3] = local_d8;
    *param_1 = puVar7;
  }
LAB_00524520:
  if (*(long *)(lVar2 + 0x28) == local_68) {
    return;
  }
LAB_00524760:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00524764
// Address: 00524764
// ========================================

void FUN_00524764(undefined8 *param_1,long param_2,byte *param_3)

{
  ulong uVar1;
  byte bVar2;
  long lVar3;
  undefined4 uVar4;
  long lVar5;
  undefined8 *puVar6;
  long *plVar7;
  undefined8 uVar8;
  byte *pbVar9;
  uint uVar10;
  uint uVar11;
  byte local_60 [16];
  void *local_50;
  long local_48;
  
  lVar3 = tpidr_el0;
  local_48 = *(long *)(lVar3 + 0x28);
  bVar2 = *param_3;
  uVar1 = (ulong)(bVar2 >> 1);
  if ((bVar2 & 1) != 0) {
    uVar1 = *(ulong *)(param_3 + 8);
  }
  if ((long)uVar1 < 5) {
    if (uVar1 != 2) {
      if (uVar1 == 4) {
        pbVar9 = *(byte **)(param_3 + 0x10);
        if ((bVar2 & 1) == 0) {
          pbVar9 = param_3 + 1;
        }
        if (*(int *)pbVar9 == 0x65757274) {
LAB_005249c0:
          puVar6 = (undefined8 *)FUN_005a5d4c(0x20);
          puVar6[2] = 0;
          puVar6[3] = 0;
          *puVar6 = &PTR_FUN_005beaf8;
          *(undefined8 *)((long)puVar6 + 0x14) = 0x100000000;
          uVar4 = 0x3f800000;
          goto LAB_005249e4;
        }
      }
      goto LAB_005248f0;
    }
    pbVar9 = *(byte **)(param_3 + 0x10);
    if ((bVar2 & 1) == 0) {
      pbVar9 = param_3 + 1;
    }
    if (*(short *)pbVar9 != 0x6970) goto LAB_005248f0;
    puVar6 = (undefined8 *)FUN_005a5d4c(0x20);
    puVar6[2] = 0;
    puVar6[3] = 0;
    *puVar6 = &PTR_FUN_005beaf8;
    *(undefined8 *)((long)puVar6 + 0x14) = 0x100000000;
    uVar4 = 0x40490fdb;
LAB_005249e4:
    *(undefined8 *)((long)puVar6 + 0xc) = 0;
    *(undefined4 *)(puVar6 + 1) = uVar4;
LAB_005249ec:
    *param_1 = puVar6;
LAB_00524ac4:
    if (*(long *)(lVar3 + 0x28) == local_48) {
      return;
    }
  }
  else {
    if (uVar1 == 5) {
      pbVar9 = *(byte **)(param_3 + 0x10);
      if ((bVar2 & 1) == 0) {
        pbVar9 = param_3 + 1;
      }
      if (*(int *)pbVar9 == 0x736c6166 && pbVar9[4] == 0x65) {
LAB_0052499c:
        puVar6 = (undefined8 *)FUN_005a5d4c(0x20);
        puVar6[2] = 0;
        puVar6[3] = 0;
        *puVar6 = &PTR_FUN_005beaf8;
        puVar6[1] = 0;
        *(undefined4 *)(puVar6 + 3) = 1;
        goto LAB_005249ec;
      }
    }
    else if (uVar1 == 8) {
      pbVar9 = *(byte **)(param_3 + 0x10);
      if ((bVar2 & 1) == 0) {
        pbVar9 = param_3 + 1;
      }
      if (*(long *)pbVar9 == 0x454e4f4e5f545050) goto LAB_0052499c;
      if (*(long *)pbVar9 == 0x4e4941525f545050) goto LAB_005249c0;
      if (*(long *)pbVar9 == 0x574f4e535f545050) {
        puVar6 = (undefined8 *)FUN_005a5d4c(0x20);
        puVar6[2] = 0;
        puVar6[3] = 0;
        *puVar6 = &PTR_FUN_005beaf8;
        *(undefined8 *)((long)puVar6 + 0x14) = 0x100000000;
        uVar4 = 0x40000000;
        goto LAB_005249e4;
      }
    }
LAB_005248f0:
    puVar6 = (undefined8 *)FUN_005a5d4c(0x18);
    puVar6[1] = 0;
    puVar6[2] = 0;
    *puVar6 = &PTR_FUN_005bf6e8;
    lVar5 = FUN_00561270(param_3,0x2e,0);
    *(undefined4 *)((long)puVar6 + 0x14) = 0xffffffff;
    if (lVar5 != -1) {
      bVar2 = *param_3;
      uVar1 = (ulong)(bVar2 >> 1);
      if ((bVar2 & 1) != 0) {
        uVar1 = *(ulong *)(param_3 + 8);
      }
      if (uVar1 <= lVar5 + 1U) goto LAB_00524a5c;
      pbVar9 = *(byte **)(param_3 + 0x10);
      if ((bVar2 & 1) == 0) {
        pbVar9 = param_3 + 1;
      }
      bVar2 = pbVar9[lVar5 + 1U];
      uVar10 = bVar2 - 0x30;
      if (uVar10 < 10) {
        if (lVar5 + 3U < uVar1) {
          uVar10 = ((uint)pbVar9[lVar5 + 3U] + (uint)bVar2 * 4) - 0xf0;
        }
        uVar11 = 0;
        if (uVar10 < 0x10) {
          uVar11 = uVar10;
        }
      }
      else {
        uVar11 = 1;
        if (bVar2 < 0x71) {
          if (bVar2 < 0x67) {
            if (bVar2 == 0x61) goto LAB_00524aec;
            if (bVar2 != 0x62) goto LAB_00524a5c;
LAB_00524a44:
            uVar11 = 2;
          }
          else if (bVar2 != 0x67) {
            if (bVar2 == 0x70) goto LAB_00524a44;
LAB_00524a5c:
            uVar11 = 0;
          }
        }
        else if (bVar2 < 0x77) {
          if (bVar2 == 0x71) goto LAB_00524aec;
          if (bVar2 != 0x74) goto LAB_00524a5c;
        }
        else if (bVar2 == 0x77) {
LAB_00524aec:
          uVar11 = 3;
        }
        else if (bVar2 != 0x79) {
          if (bVar2 == 0x7a) goto LAB_00524a44;
          goto LAB_00524a5c;
        }
      }
      *(uint *)((long)puVar6 + 0x14) = uVar11;
    }
                    /* try { // try from 00524a64 to 00524a73 has its CatchHandler @ 00524b08 */
    FUN_002dd7a4(local_60,param_3,0);
    plVar7 = *(long **)(param_2 + 0x30);
    if (plVar7 != (long *)0x0) {
                    /* try { // try from 00524a84 to 00524b07 has its CatchHandler @ 00524b10 */
      uVar8 = (**(code **)(*plVar7 + 0x30))(plVar7,local_60);
      plVar7 = *(long **)(param_2 + 0x60);
      puVar6[1] = uVar8;
      if (plVar7 != (long *)0x0) {
        uVar4 = (**(code **)(*plVar7 + 0x30))(plVar7,local_60);
        *(undefined4 *)(puVar6 + 2) = uVar4;
        *param_1 = puVar6;
        if ((local_60[0] & 1) != 0) {
          free(local_50);
        }
        goto LAB_00524ac4;
      }
    }
    if (*(long *)(lVar3 + 0x28) == local_48) {
                    /* WARNING: Subroutine does not return */
      FUN_002efc90();
    }
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00524b50
// Address: 00524b50
// ========================================

void FUN_00524b50(undefined8 *param_1)

{
  long *plVar1;
  long *plVar2;
  long *plVar3;
  
  plVar2 = (long *)*param_1;
  if (plVar2 == (long *)0x0) {
    return;
  }
  plVar3 = (long *)param_1[1];
  plVar1 = plVar2;
  if (plVar3 != plVar2) {
    do {
      plVar3 = plVar3 + -1;
      plVar1 = (long *)*plVar3;
      *plVar3 = 0;
      if (plVar1 != (long *)0x0) {
        (**(code **)(*plVar1 + 8))();
      }
    } while (plVar3 != plVar2);
    plVar1 = (long *)*param_1;
  }
  param_1[1] = plVar2;
  free(plVar1);
  return;
}



// ========================================
// Function: FUN_00524bcc
// Address: 00524bcc
// ========================================

void FUN_00524bcc(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0029fbbc("vector");
}



// ========================================
// Function: FUN_00524be0
// Address: 00524be0
// ========================================

void FUN_00524be0(undefined8 *param_1)

{
  long *plVar1;
  long *plVar2;
  long *plVar3;
  
  plVar2 = (long *)param_1[1];
  *param_1 = &PTR_FUN_005bec98;
  if (plVar2 == (long *)0x0) {
    return;
  }
  plVar3 = (long *)param_1[2];
  plVar1 = plVar2;
  if (plVar3 != plVar2) {
    do {
      plVar3 = plVar3 + -1;
      plVar1 = (long *)*plVar3;
      *plVar3 = 0;
      if (plVar1 != (long *)0x0) {
        (**(code **)(*plVar1 + 8))();
      }
    } while (plVar3 != plVar2);
    plVar1 = (long *)param_1[1];
  }
  param_1[2] = plVar2;
  free(plVar1);
  return;
}



// ========================================
// Function: FUN_00524c68
// Address: 00524c68
// ========================================

void FUN_00524c68(undefined8 *param_1)

{
  long *plVar1;
  long *plVar2;
  long *plVar3;
  
  plVar2 = (long *)param_1[1];
  *param_1 = &PTR_FUN_005bec98;
  if (plVar2 != (long *)0x0) {
    plVar3 = (long *)param_1[2];
    plVar1 = plVar2;
    if (plVar3 != plVar2) {
      do {
        plVar3 = plVar3 + -1;
        plVar1 = (long *)*plVar3;
        *plVar3 = 0;
        if (plVar1 != (long *)0x0) {
          (**(code **)(*plVar1 + 8))();
        }
      } while (plVar3 != plVar2);
      plVar1 = (long *)param_1[1];
    }
    param_1[2] = plVar2;
    free(plVar1);
  }
  free(param_1);
  return;
}



// ========================================
// Function: FUN_00524ce8
// Address: 00524ce8
// ========================================

void FUN_00524ce8(undefined4 *param_1,long param_2)

{
  long lVar1;
  long lVar2;
  long lVar3;
  undefined8 *puVar4;
  ulong uVar5;
  ulong uVar6;
  float local_4c [5];
  long local_38;
  
  lVar1 = tpidr_el0;
  local_38 = *(long *)(lVar1 + 0x28);
  puVar4 = *(undefined8 **)(param_2 + 8);
  uVar5 = *(long *)(param_2 + 0x10) - (long)puVar4 >> 3;
  if (uVar5 < 2) {
    uVar6 = 0;
    if (uVar5 == 0) {
LAB_00524de0:
      *(undefined8 *)(param_1 + 1) = 0;
      *(undefined8 *)(param_1 + 3) = 0x100000000;
      *param_1 = 0;
    }
    else {
LAB_00524d58:
      (**(code **)(*(long *)puVar4[uVar6] + 0x10))();
    }
  }
  else {
    (**(code **)(*(long *)*puVar4 + 0x10))(local_4c);
    if (local_4c[0] == 0.0) {
      lVar2 = 0;
      do {
        lVar3 = lVar2;
        puVar4 = *(undefined8 **)(param_2 + 8);
        uVar5 = *(long *)(param_2 + 0x10) - (long)puVar4 >> 3;
        if (uVar5 <= lVar3 + 3U) {
          uVar6 = lVar3 + 2;
          if (uVar5 <= uVar6) goto LAB_00524de0;
          goto LAB_00524d58;
        }
        (**(code **)(*(long *)puVar4[lVar3 + 2] + 0x10))(local_4c);
        lVar2 = lVar3 + 2;
      } while (local_4c[0] == 0.0);
      lVar3 = lVar3 + 3;
    }
    else {
      lVar3 = 1;
    }
    (**(code **)(**(long **)(*(long *)(param_2 + 8) + lVar3 * 8) + 0x10))(param_1);
  }
  if (*(long *)(lVar1 + 0x28) == local_38) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00524e18
// Address: 00524e18
// ========================================

void FUN_00524e18(undefined8 *param_1)

{
  long *plVar1;
  
  plVar1 = (long *)param_1[3];
  param_1[3] = 0;
  *param_1 = &PTR_FUN_005becd8;
  if (plVar1 != (long *)0x0) {
    (**(code **)(*plVar1 + 8))();
  }
  plVar1 = (long *)param_1[2];
  param_1[2] = 0;
  if (plVar1 != (long *)0x0) {
    (**(code **)(*plVar1 + 8))();
  }
  plVar1 = (long *)param_1[1];
  param_1[1] = 0;
  if (plVar1 != (long *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00524e80. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar1 + 8))();
    return;
  }
  return;
}



// ========================================
// Function: FUN_00524e90
// Address: 00524e90
// ========================================

void FUN_00524e90(undefined8 *param_1)

{
  long *plVar1;
  
  plVar1 = (long *)param_1[3];
  param_1[3] = 0;
  *param_1 = &PTR_FUN_005becd8;
  if (plVar1 != (long *)0x0) {
    (**(code **)(*plVar1 + 8))();
  }
  plVar1 = (long *)param_1[2];
  param_1[2] = 0;
  if (plVar1 != (long *)0x0) {
    (**(code **)(*plVar1 + 8))();
  }
  plVar1 = (long *)param_1[1];
  param_1[1] = 0;
  if (plVar1 != (long *)0x0) {
    (**(code **)(*plVar1 + 8))();
  }
  free(param_1);
  return;
}



// ========================================
// Function: FUN_00524f04
// Address: 00524f04
// ========================================

void FUN_00524f04(float *param_1,long param_2)

{
  long lVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float local_5c [5];
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  (**(code **)(**(long **)(param_2 + 8) + 0x10))(local_5c);
  fVar2 = local_5c[0];
  if (*(char *)(param_2 + 0x28) == '\0') {
    *(undefined1 *)(param_2 + 0x28) = 1;
  }
  else {
    if (*(long **)(param_2 + 0x10) == (long *)0x0) {
      fVar4 = 1.0;
    }
    else {
      (**(code **)(**(long **)(param_2 + 0x10) + 0x10))(local_5c);
      fVar4 = local_5c[0];
    }
    fVar3 = fVar4;
    if (*(long **)(param_2 + 0x18) != (long *)0x0) {
      (**(code **)(**(long **)(param_2 + 0x18) + 0x10))(local_5c);
      fVar3 = local_5c[0];
    }
    fVar6 = *(float *)(param_2 + 0x2c);
    fVar5 = 1.0;
    if (fVar2 <= fVar6) {
      fVar4 = fVar3;
    }
    if (0.0 < fVar4) {
      fVar5 = expf(**(float **)(param_2 + 0x20) / ((fVar4 * -0.1) / 0.6931472));
      fVar5 = 1.0 - fVar5;
    }
    local_5c[0] = (fVar2 - fVar6) + fVar5 * fVar6;
  }
  *(float *)(param_2 + 0x2c) = local_5c[0];
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  param_1[4] = 1.4013e-45;
  *param_1 = local_5c[0];
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00525040
// Address: 00525040
// ========================================

void FUN_00525040(undefined8 *param_1)

{
  long *plVar1;
  long lVar2;
  long *plVar3;
  long *plVar4;
  
  plVar1 = (long *)param_1[8];
  plVar3 = param_1 + 4;
  *param_1 = &PTR_FUN_005bed18;
  if (plVar1 == plVar3) {
    lVar2 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) goto LAB_00525090;
    lVar2 = 5;
    plVar3 = plVar1;
  }
  (**(code **)(*plVar3 + lVar2 * 8))();
LAB_00525090:
  plVar3 = (long *)param_1[1];
  if (plVar3 == (long *)0x0) {
    return;
  }
  plVar4 = (long *)param_1[2];
  plVar1 = plVar3;
  if (plVar4 != plVar3) {
    do {
      plVar4 = plVar4 + -1;
      plVar1 = (long *)*plVar4;
      *plVar4 = 0;
      if (plVar1 != (long *)0x0) {
        (**(code **)(*plVar1 + 8))();
      }
    } while (plVar4 != plVar3);
    plVar1 = (long *)param_1[1];
  }
  param_1[2] = plVar3;
  free(plVar1);
  return;
}



// ========================================
// Function: FUN_005250f8
// Address: 005250f8
// ========================================

void FUN_005250f8(undefined8 *param_1)

{
  long *plVar1;
  long lVar2;
  long *plVar3;
  long *plVar4;
  
  plVar1 = (long *)param_1[8];
  plVar3 = param_1 + 4;
  *param_1 = &PTR_FUN_005bed18;
  if (plVar1 == plVar3) {
    lVar2 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) goto LAB_00525148;
    lVar2 = 5;
    plVar3 = plVar1;
  }
  (**(code **)(*plVar3 + lVar2 * 8))();
LAB_00525148:
  plVar3 = (long *)param_1[1];
  if (plVar3 != (long *)0x0) {
    plVar4 = (long *)param_1[2];
    plVar1 = plVar3;
    if (plVar4 != plVar3) {
      do {
        plVar4 = plVar4 + -1;
        plVar1 = (long *)*plVar4;
        *plVar4 = 0;
        if (plVar1 != (long *)0x0) {
          (**(code **)(*plVar1 + 8))();
        }
      } while (plVar4 != plVar3);
      plVar1 = (long *)param_1[1];
    }
    param_1[2] = plVar3;
    free(plVar1);
  }
  free(param_1);
  return;
}



// ========================================
// Function: FUN_005251a8
// Address: 005251a8
// ========================================

void FUN_005251a8(undefined8 param_1,long param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  long lVar3;
  undefined8 *__ptr;
  undefined8 *puVar4;
  long *plVar5;
  undefined8 uVar6;
  long lVar7;
  undefined8 *puVar8;
  long lVar9;
  undefined8 *puVar10;
  ulong uVar11;
  ulong uVar12;
  undefined8 *puVar13;
  undefined8 uVar14;
  undefined8 *local_98;
  undefined8 *local_90;
  undefined8 *local_88;
  undefined8 local_7c;
  undefined8 uStack_74;
  undefined4 local_6c;
  long local_68;
  
  lVar3 = tpidr_el0;
  local_68 = *(long *)(lVar3 + 0x28);
  puVar1 = *(undefined8 **)(param_2 + 8);
  puVar2 = *(undefined8 **)(param_2 + 0x10);
  local_98 = (undefined8 *)0x0;
  local_90 = (undefined8 *)0x0;
  local_88 = (undefined8 *)0x0;
  lVar9 = (long)puVar2 - (long)puVar1;
  puVar13 = local_90;
  if (lVar9 != 0) {
    uVar12 = lVar9 >> 3;
    if (0xccccccccccccccc < uVar12) {
      if (*(long *)(lVar3 + 0x28) == local_68) {
        uVar6 = FUN_00525468();
                    /* catch() { ... } // from try @ 00525210 with catch @ 0052542c
                       catch() { ... } // from try @ 0052537c with catch @ 0052542c
                       catch() { ... } // from try @ 00525410 with catch @ 0052542c */
                    /* catch() { ... } // from try @ 00525290 with catch @ 00525434 */
        if (local_98 != (undefined8 *)0x0) {
          local_90 = local_98;
          free(local_98);
        }
        if (*(long *)(lVar3 + 0x28) == local_68) {
                    /* WARNING: Subroutine does not return */
          FUN_005a7fec(uVar6);
        }
      }
      goto LAB_00525464;
    }
                    /* try { // try from 00525210 to 00525213 has its CatchHandler @ 0052542c */
    local_98 = (undefined8 *)FUN_005a5d4c(uVar12 * 0x14);
    local_88 = (undefined8 *)((long)local_98 + uVar12 * 0x14);
    puVar13 = local_98;
  }
  for (; local_90 = puVar13, puVar1 != puVar2; puVar1 = puVar1 + 1) {
                    /* try { // try from 00525290 to 005252f7 has its CatchHandler @ 00525434 */
    (**(code **)(*(long *)*puVar1 + 0x10))(&local_7c);
    puVar4 = local_98;
    if (puVar13 < local_88) {
      puVar8 = (undefined8 *)((long)puVar13 + 0x14);
      *(undefined4 *)(puVar13 + 2) = local_6c;
      puVar13[1] = uStack_74;
      *puVar13 = local_7c;
    }
    else {
      lVar9 = (long)puVar13 - (long)local_98 >> 2;
      uVar12 = lVar9 * -0x3333333333333333 + 1;
      if (0xccccccccccccccc < uVar12) {
        if (*(long *)(lVar3 + 0x28) == local_68) {
                    /* try { // try from 005253e0 to 005253fb has its CatchHandler @ 00525430 */
          FUN_00525468();
LAB_005253e4:
          if (*(long *)(lVar3 + 0x28) == local_68) {
                    /* WARNING: Subroutine does not return */
            FUN_0029fc3c();
          }
        }
        goto LAB_00525464;
      }
      lVar7 = (long)local_88 - (long)local_98 >> 2;
      uVar11 = lVar7 * -0x6666666666666666;
      if (uVar11 < uVar12 || uVar11 - uVar12 == 0) {
        uVar11 = uVar12;
      }
      if (0x666666666666665 < (ulong)(lVar7 * -0x3333333333333333)) {
        uVar11 = 0xccccccccccccccc;
      }
      if (uVar11 == 0) {
        lVar7 = 0;
      }
      else {
        if (0xccccccccccccccc < uVar11) goto LAB_005253e4;
        lVar7 = FUN_005a5d4c(uVar11 * 0x14);
      }
      puVar8 = (undefined8 *)(lVar7 + lVar9 * 4);
      *(undefined4 *)(puVar8 + 2) = local_6c;
      puVar8[1] = uStack_74;
      *puVar8 = local_7c;
      puVar10 = puVar8;
      __ptr = puVar13;
      for (; puVar13 != puVar4; puVar13 = (undefined8 *)((long)puVar13 + -0x14)) {
        uVar14 = *(undefined8 *)((long)puVar13 + -0xc);
        uVar6 = *(undefined8 *)((long)puVar13 + -0x14);
        *(undefined4 *)((long)puVar10 + -4) = *(undefined4 *)((long)puVar13 + -4);
        *(undefined8 *)((long)puVar10 + -0xc) = uVar14;
        *(undefined8 *)((long)puVar10 + -0x14) = uVar6;
        puVar10 = (undefined8 *)((long)puVar10 + -0x14);
        __ptr = local_98;
      }
      local_88 = (undefined8 *)(lVar7 + uVar11 * 0x14);
      puVar8 = (undefined8 *)((long)puVar8 + 0x14);
      local_98 = puVar10;
      if (__ptr != (undefined8 *)0x0) {
        local_90 = puVar8;
        free(__ptr);
      }
    }
    puVar13 = puVar8;
  }
  plVar5 = *(long **)(param_2 + 0x40);
  if (plVar5 == (long *)0x0) {
    if (*(long *)(lVar3 + 0x28) == local_68) {
                    /* WARNING: Subroutine does not return */
                    /* try { // try from 00525410 to 0052542b has its CatchHandler @ 0052542c */
      FUN_002efc90();
    }
  }
  else {
                    /* try { // try from 0052537c to 00525387 has its CatchHandler @ 0052542c */
    (**(code **)(*plVar5 + 0x30))(param_1,plVar5,&local_98);
    if (local_98 != (undefined8 *)0x0) {
      local_90 = local_98;
      free(local_98);
    }
    if (*(long *)(lVar3 + 0x28) == local_68) {
      return;
    }
  }
LAB_00525464:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00525468
// Address: 00525468
// ========================================

void FUN_00525468(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0029fbbc("vector");
}



// ========================================
// Function: free
// Address: 0052547c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00525480
// Address: 00525480
// ========================================

void FUN_00525480(long param_1)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar2 = *(undefined8 *)(param_1 + 8);
  *puVar1 = &PTR_FUN_005bed58;
  puVar1[1] = uVar2;
  return;
}



// ========================================
// Function: FUN_005254b4
// Address: 005254b4
// ========================================

void FUN_005254b4(long param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  
  uVar1 = *(undefined8 *)(param_1 + 8);
  *param_2 = &PTR_FUN_005bed58;
  param_2[1] = uVar1;
  return;
}



// ========================================
// Function: FUN_005254c8
// Address: 005254c8
// ========================================

void FUN_005254c8(void)

{
  return;
}



// ========================================
// Function: free
// Address: 005254cc
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_005254d0
// Address: 005254d0
// ========================================

void FUN_005254d0(undefined8 *param_1,long param_2,long *param_3)

{
  undefined8 *puVar1;
  uint uVar2;
  ulong uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  
  puVar1 = (undefined8 *)*param_3;
  if (puVar1 == (undefined8 *)param_3[1]) {
    *(undefined8 *)((long)param_1 + 4) = 0;
    *(undefined8 *)((long)param_1 + 0xc) = 0x100000000;
    uVar2 = 1;
    *(undefined4 *)param_1 = 0;
  }
  else {
    uVar2 = *(uint *)(puVar1 + 2);
    uVar5 = *puVar1;
    param_1[1] = puVar1[1];
    *param_1 = uVar5;
    *(uint *)(param_1 + 2) = uVar2;
    if ((int)uVar2 < 1) {
      return;
    }
  }
  uVar3 = (ulong)uVar2;
  do {
    uVar4 = (**(code **)(param_2 + 8))(*(undefined4 *)param_1);
    uVar3 = uVar3 - 1;
    *(undefined4 *)param_1 = uVar4;
    param_1 = (undefined8 *)((long)param_1 + 4);
  } while (uVar3 != 0);
  return;
}



// ========================================
// Function: FUN_00525550
// Address: 00525550
// ========================================

long FUN_00525550(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser4eachEPFffEEUlRKNSt6__ndk16vectorINS0_3VecENS4_9allocatorIS6_EEEEE_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_0052556c
// Address: 0052556c
// ========================================

undefined ** FUN_0052556c(void)

{
  return &PTR_PTR_005bedc8;
}



// ========================================
// Function: sinf
// Address: 00525578
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float sinf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_sinf_005c6fc0)();
  return fVar1;
}



// ========================================
// Function: cosf
// Address: 0052557c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float cosf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_cosf_005c6fc8)();
  return fVar1;
}



// ========================================
// Function: tanf
// Address: 00525580
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float tanf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_tanf_005c6fd0)();
  return fVar1;
}



// ========================================
// Function: asinf
// Address: 00525584
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float asinf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_asinf_005c6fd8)();
  return fVar1;
}



// ========================================
// Function: acosf
// Address: 00525588
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float acosf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_acosf_005c6fe0)();
  return fVar1;
}



// ========================================
// Function: atanf
// Address: 0052558c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float atanf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_atanf_005c6fe8)();
  return fVar1;
}



// ========================================
// Function: FUN_00525590
// Address: 00525590
// ========================================

void FUN_00525590(undefined8 *param_1)

{
  long *plVar1;
  long *plVar2;
  long lVar3;
  
  plVar1 = (long *)param_1[6];
  plVar2 = param_1 + 2;
  *param_1 = &PTR_FUN_005bede8;
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) {
      return;
    }
    lVar3 = 5;
    plVar2 = plVar1;
  }
                    /* WARNING: Could not recover jumptable at 0x005255cc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar2 + lVar3 * 8))();
  return;
}



// ========================================
// Function: FUN_005255d4
// Address: 005255d4
// ========================================

void FUN_005255d4(undefined8 *param_1)

{
  long *plVar1;
  long *plVar2;
  long lVar3;
  
  plVar1 = (long *)param_1[6];
  plVar2 = param_1 + 2;
  *param_1 = &PTR_FUN_005bede8;
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) goto LAB_00525620;
    lVar3 = 5;
    plVar2 = plVar1;
  }
  (**(code **)(*plVar2 + lVar3 * 8))();
LAB_00525620:
  free(param_1);
  return;
}



// ========================================
// Function: FUN_00525630
// Address: 00525630
// ========================================

undefined8 * FUN_00525630(long param_1)

{
  undefined8 *puVar1;
  long *plVar2;
  long lVar3;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x40);
  plVar2 = *(long **)(param_1 + 0x30);
  *puVar1 = &PTR_FUN_005bede8;
  if (plVar2 != (long *)0x0) {
    if (plVar2 == (long *)(param_1 + 0x10)) {
      lVar3 = *plVar2;
      puVar1[6] = puVar1 + 2;
      (**(code **)(lVar3 + 0x18))();
      return puVar1;
    }
                    /* try { // try from 00525678 to 00525693 has its CatchHandler @ 005256a4 */
    plVar2 = (long *)(**(code **)(*plVar2 + 0x10))();
  }
  puVar1[6] = plVar2;
  return puVar1;
}



// ========================================
// Function: FUN_005256b8
// Address: 005256b8
// ========================================

void FUN_005256b8(long param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  long *plVar2;
  
  plVar2 = *(long **)(param_1 + 0x30);
  *param_2 = &PTR_FUN_005bede8;
  if (plVar2 == (long *)0x0) {
    param_2[6] = 0;
  }
  else {
    if (plVar2 == (long *)(param_1 + 0x10)) {
      param_2[6] = param_2 + 2;
                    /* WARNING: Could not recover jumptable at 0x00525728. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(**(long **)(param_1 + 0x30) + 0x18))();
      return;
    }
    uVar1 = (**(code **)(*plVar2 + 0x10))(plVar2);
    param_2[6] = uVar1;
  }
  return;
}



// ========================================
// Function: FUN_0052572c
// Address: 0052572c
// ========================================

void FUN_0052572c(long param_1)

{
  long *plVar1;
  long *plVar2;
  long lVar3;
  
  plVar1 = *(long **)(param_1 + 0x30);
  plVar2 = (long *)(param_1 + 0x10);
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) {
      return;
    }
    lVar3 = 5;
    plVar2 = plVar1;
  }
                    /* WARNING: Could not recover jumptable at 0x0052575c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar2 + lVar3 * 8))();
  return;
}



// ========================================
// Function: FUN_00525764
// Address: 00525764
// ========================================

void FUN_00525764(void *param_1)

{
  long *plVar1;
  long *plVar2;
  long lVar3;
  
  plVar1 = *(long **)((long)param_1 + 0x30);
  plVar2 = (long *)((long)param_1 + 0x10);
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) goto LAB_005257a4;
    lVar3 = 5;
    plVar2 = plVar1;
  }
  (**(code **)(*plVar2 + lVar3 * 8))();
LAB_005257a4:
  free(param_1);
  return;
}



// ========================================
// Function: FUN_005257b4
// Address: 005257b4
// ========================================

void FUN_005257b4(float *param_1,long param_2,long *param_3)

{
  float *pfVar1;
  float fVar2;
  
  pfVar1 = (float *)*param_3;
  if (1 < (ulong)((param_3[1] - (long)pfVar1 >> 2) * -0x3333333333333333)) {
    fVar2 = atan2f(*pfVar1,pfVar1[5]);
    param_1[1] = 0.0;
    param_1[2] = 0.0;
    param_1[3] = 0.0;
    param_1[4] = 1.4013e-45;
    *param_1 = fVar2;
    return;
  }
  if (*(long **)(param_2 + 0x30) != (long *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00525824. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(long **)(param_2 + 0x30) + 0x30))();
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_002efc90();
}



// ========================================
// Function: FUN_0052582c
// Address: 0052582c
// ========================================

long FUN_0052582c(long param_1,long param_2)

{
  param_1 = param_1 + 0x10;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00525848
// Address: 00525848
// ========================================

undefined ** FUN_00525848(void)

{
  return &PTR_PTR_005bee48;
}



// ========================================
// Function: FUN_00525854
// Address: 00525854
// ========================================

float FUN_00525854(float param_1)

{
  return (param_1 * 3.1415927) / 180.0;
}



// ========================================
// Function: FUN_00525874
// Address: 00525874
// ========================================

float FUN_00525874(float param_1)

{
  return (param_1 * 180.0) / 3.1415927;
}



// ========================================
// Function: FUN_00525894
// Address: 00525894
// ========================================

float FUN_00525894(float param_1)

{
  return ABS(param_1);
}



// ========================================
// Function: FUN_0052589c
// Address: 0052589c
// ========================================

int FUN_0052589c(float param_1)

{
  return (int)param_1;
}



// ========================================
// Function: FUN_005258a4
// Address: 005258a4
// ========================================

int FUN_005258a4(float param_1)

{
  return (int)param_1;
}



// ========================================
// Function: FUN_005258ac
// Address: 005258ac
// ========================================

int FUN_005258ac(float param_1)

{
  return (int)param_1;
}



// ========================================
// Function: FUN_005258b4
// Address: 005258b4
// ========================================

float FUN_005258b4(float param_1)

{
  return param_1 - (float)(int)param_1;
}



// ========================================
// Function: expf
// Address: 005258c0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float expf(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_expf_005c6fb8)();
  return fVar1;
}



// ========================================
// Function: exp2f
// Address: 005258c4
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

float exp2f(float __x)

{
  float fVar1;
  
  fVar1 = (float)(*(code *)PTR_exp2f_005c6b40)();
  return fVar1;
}



// ========================================
// Function: FUN_005258c8
// Address: 005258c8
// ========================================

void FUN_005258c8(float param_1)

{
  powf(10.0,param_1);
  return;
}



// ========================================
// Function: FUN_005258d4
// Address: 005258d4
// ========================================

float FUN_005258d4(float param_1)

{
  float fVar1;
  
  fVar1 = logf(param_1);
  if (param_1 <= 0.0) {
    fVar1 = 0.0;
  }
  return fVar1;
}



// ========================================
// Function: FUN_00525900
// Address: 00525900
// ========================================

void FUN_00525900(undefined8 *param_1)

{
  long *plVar1;
  long *plVar2;
  long lVar3;
  
  plVar1 = (long *)param_1[6];
  plVar2 = param_1 + 2;
  *param_1 = &PTR_FUN_005bee68;
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) {
      return;
    }
    lVar3 = 5;
    plVar2 = plVar1;
  }
                    /* WARNING: Could not recover jumptable at 0x0052593c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar2 + lVar3 * 8))();
  return;
}



// ========================================
// Function: FUN_00525944
// Address: 00525944
// ========================================

void FUN_00525944(undefined8 *param_1)

{
  long *plVar1;
  long *plVar2;
  long lVar3;
  
  plVar1 = (long *)param_1[6];
  plVar2 = param_1 + 2;
  *param_1 = &PTR_FUN_005bee68;
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) goto LAB_00525990;
    lVar3 = 5;
    plVar2 = plVar1;
  }
  (**(code **)(*plVar2 + lVar3 * 8))();
LAB_00525990:
  free(param_1);
  return;
}



// ========================================
// Function: FUN_005259a0
// Address: 005259a0
// ========================================

undefined8 * FUN_005259a0(long param_1)

{
  undefined8 *puVar1;
  long *plVar2;
  long lVar3;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x40);
  plVar2 = *(long **)(param_1 + 0x30);
  *puVar1 = &PTR_FUN_005bee68;
  if (plVar2 != (long *)0x0) {
    if (plVar2 == (long *)(param_1 + 0x10)) {
      lVar3 = *plVar2;
      puVar1[6] = puVar1 + 2;
      (**(code **)(lVar3 + 0x18))();
      return puVar1;
    }
                    /* try { // try from 005259e8 to 00525a03 has its CatchHandler @ 00525a14 */
    plVar2 = (long *)(**(code **)(*plVar2 + 0x10))();
  }
  puVar1[6] = plVar2;
  return puVar1;
}



// ========================================
// Function: FUN_00525a28
// Address: 00525a28
// ========================================

void FUN_00525a28(long param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  long *plVar2;
  
  plVar2 = *(long **)(param_1 + 0x30);
  *param_2 = &PTR_FUN_005bee68;
  if (plVar2 == (long *)0x0) {
    param_2[6] = 0;
  }
  else {
    if (plVar2 == (long *)(param_1 + 0x10)) {
      param_2[6] = param_2 + 2;
                    /* WARNING: Could not recover jumptable at 0x00525a98. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(**(long **)(param_1 + 0x30) + 0x18))();
      return;
    }
    uVar1 = (**(code **)(*plVar2 + 0x10))(plVar2);
    param_2[6] = uVar1;
  }
  return;
}



// ========================================
// Function: FUN_00525a9c
// Address: 00525a9c
// ========================================

void FUN_00525a9c(long param_1)

{
  long *plVar1;
  long *plVar2;
  long lVar3;
  
  plVar1 = *(long **)(param_1 + 0x30);
  plVar2 = (long *)(param_1 + 0x10);
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) {
      return;
    }
    lVar3 = 5;
    plVar2 = plVar1;
  }
                    /* WARNING: Could not recover jumptable at 0x00525acc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar2 + lVar3 * 8))();
  return;
}



// ========================================
// Function: FUN_00525ad4
// Address: 00525ad4
// ========================================

void FUN_00525ad4(void *param_1)

{
  long *plVar1;
  long *plVar2;
  long lVar3;
  
  plVar1 = *(long **)((long)param_1 + 0x30);
  plVar2 = (long *)((long)param_1 + 0x10);
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) goto LAB_00525b14;
    lVar3 = 5;
    plVar2 = plVar1;
  }
  (**(code **)(*plVar2 + lVar3 * 8))();
LAB_00525b14:
  free(param_1);
  return;
}



// ========================================
// Function: FUN_00525b24
// Address: 00525b24
// ========================================

void FUN_00525b24(float *param_1,long param_2,long *param_3)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  
  pfVar1 = (float *)*param_3;
  if (1 < (ulong)((param_3[1] - (long)pfVar1 >> 2) * -0x3333333333333333)) {
    fVar3 = 0.0;
    if (((0.0 < *pfVar1) && (fVar2 = logf(*pfVar1), fVar2 != 0.0)) && (0.0 < pfVar1[5])) {
      fVar3 = logf(pfVar1[5]);
      fVar3 = fVar3 / fVar2;
    }
    param_1[1] = 0.0;
    param_1[2] = 0.0;
    param_1[3] = 0.0;
    param_1[4] = 1.4013e-45;
    *param_1 = fVar3;
    return;
  }
  if (*(long **)(param_2 + 0x30) != (long *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00525b70. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(long **)(param_2 + 0x30) + 0x30))();
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_002efc90();
}



// ========================================
// Function: FUN_00525bdc
// Address: 00525bdc
// ========================================

long FUN_00525bdc(long param_1,long param_2)

{
  param_1 = param_1 + 0x10;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE0_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00525bf8
// Address: 00525bf8
// ========================================

undefined ** FUN_00525bf8(void)

{
  return &PTR_PTR_005beec8;
}



// ========================================
// Function: FUN_00525c04
// Address: 00525c04
// ========================================

float FUN_00525c04(float param_1)

{
  float fVar1;
  
  fVar1 = log2f(param_1);
  if (param_1 <= 0.0) {
    fVar1 = 0.0;
  }
  return fVar1;
}



// ========================================
// Function: FUN_00525c30
// Address: 00525c30
// ========================================

float FUN_00525c30(float param_1)

{
  float fVar1;
  
  fVar1 = log10f(param_1);
  if (param_1 <= 0.0) {
    fVar1 = 0.0;
  }
  return fVar1;
}



// ========================================
// Function: FUN_00525c5c
// Address: 00525c5c
// ========================================

float FUN_00525c5c(float param_1)

{
  float fVar1;
  
  fVar1 = SQRT(param_1);
  if (param_1 <= 0.0) {
    fVar1 = 0.0;
  }
  return fVar1;
}



// ========================================
// Function: FUN_00525c70
// Address: 00525c70
// ========================================

undefined4 FUN_00525c70(float param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = 0xbf800000;
  if (0.0 <= param_1) {
    uVar1 = 0;
  }
  uVar2 = 0x3f800000;
  if (param_1 <= 0.0) {
    uVar2 = uVar1;
  }
  return uVar2;
}



// ========================================
// Function: FUN_00525c8c
// Address: 00525c8c
// ========================================

undefined4 FUN_00525c8c(float param_1)

{
  undefined4 uVar1;
  
  uVar1 = 0x3f800000;
  if (param_1 != 0.0) {
    uVar1 = 0;
  }
  return uVar1;
}



// ========================================
// Function: free
// Address: 00525ca0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00525ca4
// Address: 00525ca4
// ========================================

void FUN_00525ca4(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005beee8;
  return;
}



// ========================================
// Function: FUN_00525cc8
// Address: 00525cc8
// ========================================

void FUN_00525cc8(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005beee8;
  return;
}



// ========================================
// Function: FUN_00525cd8
// Address: 00525cd8
// ========================================

void FUN_00525cd8(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00525cdc
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00525ce0
// Address: 00525ce0
// ========================================

void FUN_00525ce0(float *param_1)

{
  int iVar1;
  
  iVar1 = rand();
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  param_1[4] = 1.4013e-45;
  *param_1 = (float)iVar1 / 2.1474836e+09;
  return;
}



// ========================================
// Function: FUN_00525d14
// Address: 00525d14
// ========================================

long FUN_00525d14(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE1_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00525d30
// Address: 00525d30
// ========================================

undefined ** FUN_00525d30(void)

{
  return &PTR_PTR_005bef48;
}



// ========================================
// Function: free
// Address: 00525d3c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00525d40
// Address: 00525d40
// ========================================

void FUN_00525d40(long param_1)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar1 = *(undefined1 *)(param_1 + 8);
  *puVar2 = &PTR_FUN_005bef68;
  *(undefined1 *)(puVar2 + 1) = uVar1;
  return;
}



// ========================================
// Function: FUN_00525d78
// Address: 00525d78
// ========================================

void FUN_00525d78(long param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bef68;
  *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_1 + 8);
  return;
}



// ========================================
// Function: FUN_00525d90
// Address: 00525d90
// ========================================

void FUN_00525d90(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00525d94
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00525d98
// Address: 00525d98
// ========================================

void FUN_00525d98(float *param_1,undefined8 param_2,long *param_3)

{
  float *pfVar1;
  int iVar2;
  float __y;
  float fVar3;
  
  pfVar1 = (float *)*param_3;
  fVar3 = 0.0;
  iVar2 = (int)((ulong)(param_3[1] - (long)pfVar1) >> 2) * -0x33333333;
  if (iVar2 < 1) {
    __y = 0.0;
  }
  else {
    __y = *pfVar1;
    if (iVar2 != 1) {
      fVar3 = pfVar1[5];
    }
  }
  fVar3 = atan2f(__y,fVar3);
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  param_1[4] = 1.4013e-45;
  *param_1 = fVar3;
  return;
}



// ========================================
// Function: FUN_00525e00
// Address: 00525e00
// ========================================

long FUN_00525e00(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE2_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00525e1c
// Address: 00525e1c
// ========================================

undefined ** FUN_00525e1c(void)

{
  return &PTR_PTR_005befc8;
}



// ========================================
// Function: free
// Address: 00525e28
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00525e2c
// Address: 00525e2c
// ========================================

void FUN_00525e2c(long param_1)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar1 = *(undefined1 *)(param_1 + 8);
  *puVar2 = &PTR_FUN_005befe8;
  *(undefined1 *)(puVar2 + 1) = uVar1;
  return;
}



// ========================================
// Function: FUN_00525e64
// Address: 00525e64
// ========================================

void FUN_00525e64(long param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005befe8;
  *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_1 + 8);
  return;
}



// ========================================
// Function: FUN_00525e7c
// Address: 00525e7c
// ========================================

void FUN_00525e7c(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00525e80
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00525e84
// Address: 00525e84
// ========================================

void FUN_00525e84(float *param_1,undefined8 param_2,long *param_3)

{
  float *pfVar1;
  int iVar2;
  float __x;
  float fVar3;
  
  pfVar1 = (float *)*param_3;
  fVar3 = 0.0;
  iVar2 = (int)((ulong)(param_3[1] - (long)pfVar1) >> 2) * -0x33333333;
  if (iVar2 < 1) {
    __x = 0.0;
  }
  else {
    __x = *pfVar1;
    if (iVar2 != 1) {
      fVar3 = pfVar1[5];
    }
  }
  fVar3 = powf(__x,fVar3);
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  param_1[4] = 1.4013e-45;
  *param_1 = fVar3;
  return;
}



// ========================================
// Function: FUN_00525eec
// Address: 00525eec
// ========================================

long FUN_00525eec(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE3_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00525f08
// Address: 00525f08
// ========================================

undefined ** FUN_00525f08(void)

{
  return &PTR_PTR_005bf048;
}



// ========================================
// Function: free
// Address: 00525f14
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00525f18
// Address: 00525f18
// ========================================

void FUN_00525f18(long param_1)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar1 = *(undefined1 *)(param_1 + 8);
  *puVar2 = &PTR_FUN_005bf068;
  *(undefined1 *)(puVar2 + 1) = uVar1;
  return;
}



// ========================================
// Function: FUN_00525f50
// Address: 00525f50
// ========================================

void FUN_00525f50(long param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf068;
  *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_1 + 8);
  return;
}



// ========================================
// Function: FUN_00525f68
// Address: 00525f68
// ========================================

void FUN_00525f68(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00525f6c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00525f70
// Address: 00525f70
// ========================================

void FUN_00525f70(float *param_1,undefined8 param_2,long *param_3)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  
  pfVar1 = (float *)*param_3;
  fVar2 = 0.0;
  if ((1 < (int)((ulong)(param_3[1] - (long)pfVar1) >> 2) * -0x33333333) &&
     (fVar3 = pfVar1[5], fVar3 != 0.0)) {
    fVar2 = *pfVar1 - (float)(int)(*pfVar1 / fVar3) * fVar3;
  }
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  param_1[4] = 1.4013e-45;
  *param_1 = fVar2;
  return;
}



// ========================================
// Function: FUN_00525fc4
// Address: 00525fc4
// ========================================

long FUN_00525fc4(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE4_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00525fe0
// Address: 00525fe0
// ========================================

undefined ** FUN_00525fe0(void)

{
  return &PTR_PTR_005bf0c8;
}



// ========================================
// Function: free
// Address: 00525fec
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00525ff0
// Address: 00525ff0
// ========================================

void FUN_00525ff0(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bf0e8;
  return;
}



// ========================================
// Function: FUN_00526014
// Address: 00526014
// ========================================

void FUN_00526014(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf0e8;
  return;
}



// ========================================
// Function: FUN_00526024
// Address: 00526024
// ========================================

void FUN_00526024(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526028
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_0052602c
// Address: 0052602c
// ========================================

void FUN_0052602c(float *param_1,undefined8 param_2,long *param_3)

{
  float fVar1;
  float *pfVar2;
  float fVar4;
  float *pfVar3;
  
  pfVar2 = (float *)*param_3;
  if (pfVar2 == (float *)param_3[1]) {
    fVar4 = 0.0;
  }
  else {
    fVar4 = *pfVar2;
    do {
      pfVar3 = pfVar2 + 5;
      fVar1 = *pfVar2;
      if (fVar4 <= *pfVar2) {
        fVar1 = fVar4;
      }
      fVar4 = fVar1;
      pfVar2 = pfVar3;
    } while (pfVar3 != (float *)param_3[1]);
  }
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  param_1[4] = 1.4013e-45;
  *param_1 = fVar4;
  return;
}



// ========================================
// Function: FUN_0052606c
// Address: 0052606c
// ========================================

long FUN_0052606c(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE5_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526088
// Address: 00526088
// ========================================

undefined ** FUN_00526088(void)

{
  return &PTR_PTR_005bf148;
}



// ========================================
// Function: free
// Address: 00526094
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526098
// Address: 00526098
// ========================================

void FUN_00526098(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bf168;
  return;
}



// ========================================
// Function: FUN_005260bc
// Address: 005260bc
// ========================================

void FUN_005260bc(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf168;
  return;
}



// ========================================
// Function: FUN_005260cc
// Address: 005260cc
// ========================================

void FUN_005260cc(void)

{
  return;
}



// ========================================
// Function: free
// Address: 005260d0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_005260d4
// Address: 005260d4
// ========================================

void FUN_005260d4(float *param_1,undefined8 param_2,long *param_3)

{
  float fVar1;
  float *pfVar2;
  float fVar4;
  float *pfVar3;
  
  pfVar2 = (float *)*param_3;
  if (pfVar2 == (float *)param_3[1]) {
    fVar4 = 0.0;
  }
  else {
    fVar4 = *pfVar2;
    do {
      pfVar3 = pfVar2 + 5;
      fVar1 = *pfVar2;
      if (*pfVar2 <= fVar4) {
        fVar1 = fVar4;
      }
      fVar4 = fVar1;
      pfVar2 = pfVar3;
    } while (pfVar3 != (float *)param_3[1]);
  }
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  param_1[4] = 1.4013e-45;
  *param_1 = fVar4;
  return;
}



// ========================================
// Function: FUN_00526114
// Address: 00526114
// ========================================

long FUN_00526114(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE6_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526130
// Address: 00526130
// ========================================

undefined ** FUN_00526130(void)

{
  return &PTR_PTR_005bf1c8;
}



// ========================================
// Function: free
// Address: 0052613c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526140
// Address: 00526140
// ========================================

void FUN_00526140(long param_1)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar1 = *(undefined1 *)(param_1 + 8);
  *puVar2 = &PTR_FUN_005bf1e8;
  *(undefined1 *)(puVar2 + 1) = uVar1;
  return;
}



// ========================================
// Function: FUN_00526178
// Address: 00526178
// ========================================

void FUN_00526178(long param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf1e8;
  *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_1 + 8);
  return;
}



// ========================================
// Function: FUN_00526190
// Address: 00526190
// ========================================

void FUN_00526190(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526194
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526198
// Address: 00526198
// ========================================

void FUN_00526198(float *param_1,undefined8 param_2,long *param_3)

{
  float *pfVar1;
  uint uVar2;
  bool bVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  pfVar1 = (float *)*param_3;
  fVar4 = 0.0;
  fVar5 = 0.0;
  uVar2 = (int)((ulong)(param_3[1] - (long)pfVar1) >> 2) * -0x33333333;
  if (((int)uVar2 < 1) || (fVar5 = *pfVar1, uVar2 == 1)) {
    bVar3 = fVar5 < 0.0;
    fVar6 = 0.0;
  }
  else {
    fVar6 = pfVar1[5];
    bVar3 = fVar5 < fVar6;
    if (2 < uVar2) {
      fVar4 = pfVar1[10];
    }
  }
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  if (!bVar3) {
    fVar6 = fVar5;
  }
  param_1[3] = 0.0;
  param_1[4] = 1.4013e-45;
  if (fVar6 <= fVar4) {
    fVar4 = fVar6;
  }
  *param_1 = fVar4;
  return;
}



// ========================================
// Function: FUN_00526214
// Address: 00526214
// ========================================

long FUN_00526214(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE7_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526230
// Address: 00526230
// ========================================

undefined ** FUN_00526230(void)

{
  return &PTR_PTR_005bf248;
}



// ========================================
// Function: free
// Address: 0052623c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526240
// Address: 00526240
// ========================================

void FUN_00526240(long param_1)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar1 = *(undefined1 *)(param_1 + 8);
  *puVar2 = &PTR_FUN_005bf268;
  *(undefined1 *)(puVar2 + 1) = uVar1;
  return;
}



// ========================================
// Function: FUN_00526278
// Address: 00526278
// ========================================

void FUN_00526278(long param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf268;
  *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_1 + 8);
  return;
}



// ========================================
// Function: FUN_00526290
// Address: 00526290
// ========================================

void FUN_00526290(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526294
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526298
// Address: 00526298
// ========================================

void FUN_00526298(float *param_1,undefined8 param_2,long *param_3)

{
  float *pfVar1;
  uint uVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  pfVar1 = (float *)*param_3;
  fVar3 = 0.0;
  uVar2 = (int)((ulong)(param_3[1] - (long)pfVar1) >> 2) * -0x33333333;
  if ((int)uVar2 < 1) {
    fVar5 = 0.0;
    fVar4 = 0.0;
  }
  else {
    fVar4 = *pfVar1;
    if (uVar2 == 1) {
      fVar5 = 0.0 - fVar4;
    }
    else {
      fVar5 = pfVar1[5] - fVar4;
      if (2 < uVar2) {
        fVar3 = pfVar1[10];
      }
    }
  }
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  param_1[4] = 1.4013e-45;
  *param_1 = fVar5 + fVar3 * fVar4;
  return;
}



// ========================================
// Function: FUN_00526304
// Address: 00526304
// ========================================

long FUN_00526304(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE8_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526320
// Address: 00526320
// ========================================

undefined ** FUN_00526320(void)

{
  return &PTR_PTR_005bf2c8;
}



// ========================================
// Function: free
// Address: 0052632c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526330
// Address: 00526330
// ========================================

void FUN_00526330(long param_1)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar1 = *(undefined1 *)(param_1 + 8);
  *puVar2 = &PTR_FUN_005bf2e8;
  *(undefined1 *)(puVar2 + 1) = uVar1;
  return;
}



// ========================================
// Function: FUN_00526368
// Address: 00526368
// ========================================

void FUN_00526368(long param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf2e8;
  *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_1 + 8);
  return;
}



// ========================================
// Function: FUN_00526380
// Address: 00526380
// ========================================

void FUN_00526380(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526384
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526388
// Address: 00526388
// ========================================

void FUN_00526388(float *param_1,undefined8 param_2,long *param_3)

{
  float *pfVar1;
  int iVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  pfVar1 = (float *)*param_3;
  fVar4 = 0.0;
  iVar2 = (int)((ulong)(param_3[1] - (long)pfVar1) >> 2) * -0x33333333;
  if (iVar2 < 2) {
    fVar3 = 0.0;
    fVar6 = 0.0;
    fVar5 = 0.0;
    if (iVar2 != 1) goto LAB_005263dc;
  }
  else {
    fVar3 = pfVar1[5];
    if (iVar2 != 2) {
      fVar4 = pfVar1[10];
    }
    fVar4 = fVar4 - fVar3;
  }
  fVar5 = *pfVar1;
  fVar6 = fVar3;
LAB_005263dc:
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  param_1[4] = 1.4013e-45;
  *param_1 = fVar4 + fVar5 * fVar6;
  return;
}



// ========================================
// Function: FUN_005263f4
// Address: 005263f4
// ========================================

long FUN_005263f4(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE9_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526410
// Address: 00526410
// ========================================

undefined ** FUN_00526410(void)

{
  return &PTR_PTR_005bf348;
}



// ========================================
// Function: free
// Address: 0052641c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526420
// Address: 00526420
// ========================================

void FUN_00526420(long param_1)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar1 = *(undefined1 *)(param_1 + 8);
  *puVar2 = &PTR_FUN_005bf368;
  *(undefined1 *)(puVar2 + 1) = uVar1;
  return;
}



// ========================================
// Function: FUN_00526458
// Address: 00526458
// ========================================

void FUN_00526458(long param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf368;
  *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_1 + 8);
  return;
}



// ========================================
// Function: FUN_00526470
// Address: 00526470
// ========================================

void FUN_00526470(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526474
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526478
// Address: 00526478
// ========================================

void FUN_00526478(undefined4 *param_1,undefined8 param_2,long *param_3)

{
  float *pfVar1;
  int iVar2;
  float fVar3;
  undefined4 uVar4;
  float fVar5;
  
  pfVar1 = (float *)*param_3;
  iVar2 = (int)((ulong)(param_3[1] - (long)pfVar1) >> 2) * -0x33333333;
  if (iVar2 < 2) {
    fVar3 = 0.0;
    fVar5 = 0.0;
    if (iVar2 != 1) goto LAB_005264b4;
  }
  else {
    fVar3 = pfVar1[5];
  }
  fVar5 = *pfVar1;
LAB_005264b4:
  uVar4 = 0x3f800000;
  *(undefined8 *)(param_1 + 1) = 0;
  *(undefined8 *)(param_1 + 3) = 0x100000000;
  if (fVar3 < fVar5) {
    uVar4 = 0;
  }
  *param_1 = uVar4;
  return;
}



// ========================================
// Function: FUN_005264d8
// Address: 005264d8
// ========================================

long FUN_005264d8(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE10_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_005264f4
// Address: 005264f4
// ========================================

undefined ** FUN_005264f4(void)

{
  return &PTR_PTR_005bf3c8;
}



// ========================================
// Function: free
// Address: 00526500
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526504
// Address: 00526504
// ========================================

void FUN_00526504(long param_1)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar1 = *(undefined1 *)(param_1 + 8);
  *puVar2 = &PTR_FUN_005bf3e8;
  *(undefined1 *)(puVar2 + 1) = uVar1;
  return;
}



// ========================================
// Function: FUN_0052653c
// Address: 0052653c
// ========================================

void FUN_0052653c(long param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf3e8;
  *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_1 + 8);
  return;
}



// ========================================
// Function: FUN_00526554
// Address: 00526554
// ========================================

void FUN_00526554(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526558
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_0052655c
// Address: 0052655c
// ========================================

void FUN_0052655c(float *param_1,undefined8 param_2,long *param_3)

{
  float *pfVar1;
  uint uVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  pfVar1 = (float *)*param_3;
  fVar4 = 0.0;
  uVar2 = (int)((ulong)(param_3[1] - (long)pfVar1) >> 2) * -0x33333333;
  if (0 < (int)uVar2) {
    fVar3 = *pfVar1;
    if (uVar2 == 1) {
      fVar5 = 0.0;
      fVar6 = 0.0;
      if (fVar3 == 0.0) goto LAB_005265dc;
    }
    else {
      fVar5 = pfVar1[5];
      if (fVar5 == fVar3) goto LAB_005265dc;
      fVar6 = 0.0;
      if (2 < uVar2) {
        fVar6 = pfVar1[10];
      }
    }
    fVar4 = (fVar6 - fVar3) / (fVar5 - fVar3);
    fVar3 = 0.0;
    if (0.0 <= fVar4) {
      fVar3 = fVar4;
    }
    fVar4 = 1.0;
    if (fVar3 <= 1.0) {
      fVar4 = fVar3;
    }
  }
LAB_005265dc:
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  param_1[4] = 1.4013e-45;
  *param_1 = fVar4 * fVar4 * (fVar4 + -6.0);
  return;
}



// ========================================
// Function: FUN_00526604
// Address: 00526604
// ========================================

long FUN_00526604(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE11_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526620
// Address: 00526620
// ========================================

undefined ** FUN_00526620(void)

{
  return &PTR_PTR_005bf448;
}



// ========================================
// Function: free
// Address: 0052662c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526630
// Address: 00526630
// ========================================

void FUN_00526630(long param_1)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar1 = *(undefined1 *)(param_1 + 8);
  *puVar2 = &PTR_FUN_005bf468;
  *(undefined1 *)(puVar2 + 1) = uVar1;
  return;
}



// ========================================
// Function: FUN_00526668
// Address: 00526668
// ========================================

void FUN_00526668(long param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf468;
  *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_1 + 8);
  return;
}



// ========================================
// Function: FUN_00526680
// Address: 00526680
// ========================================

void FUN_00526680(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526684
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526688
// Address: 00526688
// ========================================

void FUN_00526688(undefined4 *param_1,undefined8 param_2,long *param_3)

{
  float *pfVar1;
  uint uVar2;
  undefined4 uVar3;
  float fVar4;
  float fVar5;
  
  pfVar1 = (float *)*param_3;
  fVar4 = 0.0;
  fVar5 = 0.0;
  uVar2 = (int)((ulong)(param_3[1] - (long)pfVar1) >> 2) * -0x33333333;
  if (((int)uVar2 < 1) || (fVar5 = *pfVar1, uVar2 == 1)) {
    fVar5 = ABS(fVar5);
  }
  else {
    fVar5 = ABS(fVar5 - pfVar1[5]);
    if (2 < uVar2) {
      fVar4 = pfVar1[10];
    }
  }
  uVar3 = 0x3f800000;
  *(undefined8 *)(param_1 + 1) = 0;
  *(undefined8 *)(param_1 + 3) = 0x100000000;
  if (fVar4 < fVar5) {
    uVar3 = 0;
  }
  *param_1 = uVar3;
  return;
}



// ========================================
// Function: FUN_005266f8
// Address: 005266f8
// ========================================

long FUN_005266f8(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE12_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526714
// Address: 00526714
// ========================================

undefined ** FUN_00526714(void)

{
  return &PTR_PTR_005bf4c8;
}



// ========================================
// Function: free
// Address: 00526720
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526724
// Address: 00526724
// ========================================

void FUN_00526724(long param_1)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar1 = *(undefined1 *)(param_1 + 8);
  *puVar2 = &PTR_FUN_005bf4e8;
  *(undefined1 *)(puVar2 + 1) = uVar1;
  return;
}



// ========================================
// Function: FUN_0052675c
// Address: 0052675c
// ========================================

void FUN_0052675c(long param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf4e8;
  *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_1 + 8);
  return;
}



// ========================================
// Function: FUN_00526774
// Address: 00526774
// ========================================

void FUN_00526774(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526778
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_0052677c
// Address: 0052677c
// ========================================

void FUN_0052677c(float *param_1,undefined8 param_2,long *param_3)

{
  float *pfVar1;
  uint uVar2;
  bool bVar3;
  float fVar4;
  float fVar5;
  
  pfVar1 = (float *)*param_3;
  fVar4 = 0.0;
  fVar5 = 0.0;
  uVar2 = (int)((ulong)(param_3[1] - (long)pfVar1) >> 2) * -0x33333333;
  if (0 < (int)uVar2) {
    fVar4 = *pfVar1;
    if (uVar2 == 1) {
      if (fVar4 < 0.0) goto LAB_005267e0;
    }
    else {
      if (fVar4 < pfVar1[5]) goto LAB_005267e0;
      if (2 < uVar2) {
        fVar5 = pfVar1[10];
      }
    }
  }
  bVar3 = fVar5 < fVar4;
  fVar5 = 1.0;
  if (bVar3) {
    fVar5 = 0.0;
  }
LAB_005267e0:
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  param_1[4] = 1.4013e-45;
  *param_1 = fVar5;
  return;
}



// ========================================
// Function: FUN_005267f4
// Address: 005267f4
// ========================================

long FUN_005267f4(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE13_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526810
// Address: 00526810
// ========================================

undefined ** FUN_00526810(void)

{
  return &PTR_PTR_005bf548;
}



// ========================================
// Function: free
// Address: 0052681c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526820
// Address: 00526820
// ========================================

void FUN_00526820(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bf568;
  return;
}



// ========================================
// Function: FUN_00526844
// Address: 00526844
// ========================================

void FUN_00526844(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf568;
  return;
}



// ========================================
// Function: FUN_00526854
// Address: 00526854
// ========================================

void FUN_00526854(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526858
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_0052685c
// Address: 0052685c
// ========================================

void FUN_0052685c(undefined4 *param_1,undefined8 param_2,long *param_3)

{
  float *pfVar1;
  ulong uVar2;
  long lVar3;
  undefined4 uVar4;
  float fVar5;
  
  pfVar1 = (float *)*param_3;
  uVar4 = 0;
  uVar2 = (param_3[1] - (long)pfVar1 >> 2) * -0x3333333333333333;
  if (1 < uVar2) {
    fVar5 = *pfVar1;
    lVar3 = uVar2 - 1;
    do {
      pfVar1 = pfVar1 + 5;
      if (*pfVar1 == fVar5) {
        uVar4 = 0x3f800000;
        break;
      }
      lVar3 = lVar3 + -1;
    } while (lVar3 != 0);
  }
  *(undefined8 *)(param_1 + 1) = 0;
  *(undefined8 *)(param_1 + 3) = 0x100000000;
  *param_1 = uVar4;
  return;
}



// ========================================
// Function: FUN_005268bc
// Address: 005268bc
// ========================================

long FUN_005268bc(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE14_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_005268d8
// Address: 005268d8
// ========================================

undefined ** FUN_005268d8(void)

{
  return &PTR_PTR_005bf5c8;
}



// ========================================
// Function: free
// Address: 005268e4
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_005268e8
// Address: 005268e8
// ========================================

void FUN_005268e8(long param_1)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar1 = *(undefined4 *)(param_1 + 8);
  *puVar2 = &PTR_FUN_005bf5e8;
  *(undefined4 *)(puVar2 + 1) = uVar1;
  return;
}



// ========================================
// Function: FUN_00526920
// Address: 00526920
// ========================================

void FUN_00526920(long param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 8);
  *param_2 = &PTR_FUN_005bf5e8;
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



// ========================================
// Function: FUN_00526938
// Address: 00526938
// ========================================

void FUN_00526938(void)

{
  return;
}



// ========================================
// Function: free
// Address: 0052693c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526940
// Address: 00526940
// ========================================

void FUN_00526940(undefined8 *param_1,long param_2,long *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  uint uVar3;
  uint uVar4;
  ulong uVar5;
  long lVar6;
  ulong uVar7;
  undefined4 *puVar8;
  ulong uVar9;
  undefined8 *puVar10;
  ulong uVar11;
  undefined4 *__src;
  int iVar12;
  undefined4 uVar13;
  
  puVar8 = (undefined4 *)*param_3;
  puVar2 = (undefined4 *)param_3[1];
  uVar3 = *(uint *)(param_2 + 8);
  *param_1 = 0;
  param_1[1] = 0;
  *(uint *)(param_1 + 2) = uVar3;
  if (puVar8 != puVar2) {
    iVar12 = 0;
    __src = puVar8;
    do {
      uVar4 = __src[4];
      if ((0 < (int)uVar4) && (iVar12 < 4)) {
        uVar1 = uVar4 - 1;
        if (3U - iVar12 <= uVar4 - 1) {
          uVar1 = 3U - iVar12;
        }
        memcpy((void *)((long)param_1 + (long)iVar12 * 4),__src,(ulong)uVar1 * 4 + 4);
        uVar11 = (ulong)uVar4 - 1;
        if (3U - (long)iVar12 <= (ulong)uVar4 - 1) {
          uVar11 = 3U - (long)iVar12;
        }
        iVar12 = iVar12 + (int)uVar11 + 1;
      }
      __src = __src + 5;
    } while (__src != puVar2);
  }
  if ((((long)puVar2 - (long)puVar8 == 0x14) && (puVar8[4] == 1)) && (1 < (int)uVar3)) {
    uVar13 = *puVar8;
    if (uVar3 < 9) {
      uVar5 = 1;
    }
    else {
      uVar7 = (ulong)uVar3 - 1;
      puVar10 = (undefined8 *)((long)param_1 + 0x14);
      uVar9 = uVar7 & 0xfffffffffffffff8;
      uVar5 = uVar9 | 1;
      uVar11 = uVar9;
      do {
        puVar10[-1] = CONCAT44(uVar13,uVar13);
        puVar10[-2] = CONCAT44(uVar13,uVar13);
        puVar10[1] = CONCAT44(uVar13,uVar13);
        *puVar10 = CONCAT44(uVar13,uVar13);
        uVar11 = uVar11 - 8;
        puVar10 = puVar10 + 4;
      } while (uVar11 != 0);
      if (uVar7 == uVar9) {
        return;
      }
    }
    lVar6 = uVar3 - uVar5;
    puVar8 = (undefined4 *)((long)param_1 + uVar5 * 4);
    do {
      lVar6 = lVar6 + -1;
      *puVar8 = uVar13;
      puVar8 = puVar8 + 1;
    } while (lVar6 != 0);
  }
  return;
}



// ========================================
// Function: FUN_00526a74
// Address: 00526a74
// ========================================

long FUN_00526a74(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE15_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526a90
// Address: 00526a90
// ========================================

undefined ** FUN_00526a90(void)

{
  return &PTR_PTR_005bf648;
}



// ========================================
// Function: FUN_00526a9c
// Address: 00526a9c
// ========================================

void FUN_00526a9c(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526aa0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526aa4
// Address: 00526aa4
// ========================================

void FUN_00526aa4(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bf668;
  return;
}



// ========================================
// Function: FUN_00526ac8
// Address: 00526ac8
// ========================================

void FUN_00526ac8(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf668;
  return;
}



// ========================================
// Function: FUN_00526ad8
// Address: 00526ad8
// ========================================

void FUN_00526ad8(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526adc
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526ae0
// Address: 00526ae0
// ========================================

void FUN_00526ae0(undefined8 *param_1,undefined8 param_2,long *param_3)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  
  puVar1 = (undefined8 *)*param_3;
  if (puVar1 != (undefined8 *)param_3[1]) {
    uVar3 = *puVar1;
    uVar2 = *(undefined4 *)(puVar1 + 2);
    param_1[1] = puVar1[1];
    *param_1 = uVar3;
    *(undefined4 *)(param_1 + 2) = uVar2;
    return;
  }
  *(undefined8 *)((long)param_1 + 4) = 0;
  *(undefined8 *)((long)param_1 + 0xc) = 0x100000000;
  *(undefined4 *)param_1 = 0;
  return;
}



// ========================================
// Function: FUN_00526b14
// Address: 00526b14
// ========================================

long FUN_00526b14(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12_GLOBAL__N_16Parser8functionERKNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEUlRKNS2_6vectorINS0_3VecENS6_ISC_EEEEE16_"
     ) {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526b30
// Address: 00526b30
// ========================================

undefined ** FUN_00526b30(void)

{
  return &PTR_PTR_005bf6c8;
}



// ========================================
// Function: FUN_00526b3c
// Address: 00526b3c
// ========================================

void FUN_00526b3c(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526b40
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526b44
// Address: 00526b44
// ========================================

void FUN_00526b44(undefined8 *param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = *(uint *)(param_2 + 0x14);
  *param_1 = 0;
  param_1[1] = 0;
  *(undefined4 *)(param_1 + 2) = 1;
  if (-1 < (int)uVar1) {
    *(undefined4 *)param_1 = *(undefined4 *)(*(long *)(param_2 + 8) + (ulong)uVar1 * 4);
    return;
  }
  iVar2 = *(int *)(param_2 + 0x10);
  uVar1 = iVar2 - 1;
  *(int *)(param_1 + 2) = iVar2;
  if (0 < iVar2) {
    if (2 < uVar1) {
      uVar1 = 3;
    }
    memcpy(param_1,*(void **)(param_2 + 8),(ulong)(uVar1 * 4 + 4));
    return;
  }
  return;
}



// ========================================
// Function: free
// Address: 00526b9c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526ba0
// Address: 00526ba0
// ========================================

void FUN_00526ba0(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bf728;
  return;
}



// ========================================
// Function: FUN_00526bc4
// Address: 00526bc4
// ========================================

void FUN_00526bc4(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf728;
  return;
}



// ========================================
// Function: FUN_00526bd4
// Address: 00526bd4
// ========================================

void FUN_00526bd4(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526bd8
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526bdc
// Address: 00526bdc
// ========================================

float FUN_00526bdc(undefined8 param_1,float *param_2,float *param_3)

{
  return *param_2 * *param_3;
}



// ========================================
// Function: FUN_00526bec
// Address: 00526bec
// ========================================

long FUN_00526bec(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser14multiplicativeEvEUlffE_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526c08
// Address: 00526c08
// ========================================

undefined ** FUN_00526c08(void)

{
  return &PTR_PTR_005bf798;
}



// ========================================
// Function: free
// Address: 00526c14
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526c18
// Address: 00526c18
// ========================================

void FUN_00526c18(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bf7b8;
  return;
}



// ========================================
// Function: FUN_00526c3c
// Address: 00526c3c
// ========================================

void FUN_00526c3c(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf7b8;
  return;
}



// ========================================
// Function: FUN_00526c4c
// Address: 00526c4c
// ========================================

void FUN_00526c4c(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526c50
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526c54
// Address: 00526c54
// ========================================

float FUN_00526c54(undefined8 param_1,float *param_2,float *param_3)

{
  float fVar1;
  
  fVar1 = *param_2 / *param_3;
  if (*param_3 == 0.0) {
    fVar1 = 0.0;
  }
  return fVar1;
}



// ========================================
// Function: FUN_00526c70
// Address: 00526c70
// ========================================

long FUN_00526c70(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser14multiplicativeEvEUlffE0_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526c8c
// Address: 00526c8c
// ========================================

undefined ** FUN_00526c8c(void)

{
  return &PTR_PTR_005bf818;
}



// ========================================
// Function: free
// Address: 00526c98
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526c9c
// Address: 00526c9c
// ========================================

void FUN_00526c9c(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bf838;
  return;
}



// ========================================
// Function: FUN_00526cc0
// Address: 00526cc0
// ========================================

void FUN_00526cc0(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf838;
  return;
}



// ========================================
// Function: FUN_00526cd0
// Address: 00526cd0
// ========================================

void FUN_00526cd0(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526cd4
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526cd8
// Address: 00526cd8
// ========================================

float FUN_00526cd8(undefined8 param_1,float *param_2,float *param_3)

{
  float fVar1;
  float __y;
  
  __y = *param_3;
  fVar1 = fmodf(*param_2,__y);
  if (__y == 0.0) {
    fVar1 = 0.0;
  }
  return fVar1;
}



// ========================================
// Function: FUN_00526d0c
// Address: 00526d0c
// ========================================

long FUN_00526d0c(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser14multiplicativeEvEUlffE1_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526d28
// Address: 00526d28
// ========================================

undefined ** FUN_00526d28(void)

{
  return &PTR_PTR_005bf898;
}



// ========================================
// Function: free
// Address: 00526d34
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526d38
// Address: 00526d38
// ========================================

void FUN_00526d38(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bf8b8;
  return;
}



// ========================================
// Function: FUN_00526d5c
// Address: 00526d5c
// ========================================

void FUN_00526d5c(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf8b8;
  return;
}



// ========================================
// Function: FUN_00526d6c
// Address: 00526d6c
// ========================================

void FUN_00526d6c(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526d70
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526d74
// Address: 00526d74
// ========================================

float FUN_00526d74(undefined8 param_1,float *param_2,float *param_3)

{
  return *param_2 + *param_3;
}



// ========================================
// Function: FUN_00526d84
// Address: 00526d84
// ========================================

long FUN_00526d84(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser8additiveEvEUlffE_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526da0
// Address: 00526da0
// ========================================

undefined ** FUN_00526da0(void)

{
  return &PTR_PTR_005bf918;
}



// ========================================
// Function: free
// Address: 00526dac
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526db0
// Address: 00526db0
// ========================================

void FUN_00526db0(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bf938;
  return;
}



// ========================================
// Function: FUN_00526dd4
// Address: 00526dd4
// ========================================

void FUN_00526dd4(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf938;
  return;
}



// ========================================
// Function: FUN_00526de4
// Address: 00526de4
// ========================================

void FUN_00526de4(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526de8
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526dec
// Address: 00526dec
// ========================================

float FUN_00526dec(undefined8 param_1,float *param_2,float *param_3)

{
  return *param_2 - *param_3;
}



// ========================================
// Function: FUN_00526dfc
// Address: 00526dfc
// ========================================

long FUN_00526dfc(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser8additiveEvEUlffE0_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526e18
// Address: 00526e18
// ========================================

undefined ** FUN_00526e18(void)

{
  return &PTR_PTR_005bf998;
}



// ========================================
// Function: free
// Address: 00526e24
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526e28
// Address: 00526e28
// ========================================

void FUN_00526e28(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bf9b8;
  return;
}



// ========================================
// Function: FUN_00526e4c
// Address: 00526e4c
// ========================================

void FUN_00526e4c(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bf9b8;
  return;
}



// ========================================
// Function: FUN_00526e5c
// Address: 00526e5c
// ========================================

void FUN_00526e5c(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526e60
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526e64
// Address: 00526e64
// ========================================

undefined4 FUN_00526e64(undefined8 param_1,float *param_2,float *param_3)

{
  undefined4 uVar1;
  
  uVar1 = 0x3f800000;
  if (*param_2 != *param_3) {
    uVar1 = 0;
  }
  return uVar1;
}



// ========================================
// Function: FUN_00526e80
// Address: 00526e80
// ========================================

long FUN_00526e80(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser10comparisonEvEUlffE_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526e9c
// Address: 00526e9c
// ========================================

undefined ** FUN_00526e9c(void)

{
  return &PTR_PTR_005bfa18;
}



// ========================================
// Function: free
// Address: 00526ea8
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526eac
// Address: 00526eac
// ========================================

void FUN_00526eac(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bfa38;
  return;
}



// ========================================
// Function: FUN_00526ed0
// Address: 00526ed0
// ========================================

void FUN_00526ed0(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bfa38;
  return;
}



// ========================================
// Function: FUN_00526ee0
// Address: 00526ee0
// ========================================

void FUN_00526ee0(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526ee4
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526ee8
// Address: 00526ee8
// ========================================

undefined4 FUN_00526ee8(undefined8 param_1,float *param_2,float *param_3)

{
  undefined4 uVar1;
  
  uVar1 = 0x3f800000;
  if (*param_2 == *param_3) {
    uVar1 = 0;
  }
  return uVar1;
}



// ========================================
// Function: FUN_00526f04
// Address: 00526f04
// ========================================

long FUN_00526f04(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser10comparisonEvEUlffE0_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526f20
// Address: 00526f20
// ========================================

undefined ** FUN_00526f20(void)

{
  return &PTR_PTR_005bfa98;
}



// ========================================
// Function: free
// Address: 00526f2c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526f30
// Address: 00526f30
// ========================================

void FUN_00526f30(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bfab8;
  return;
}



// ========================================
// Function: FUN_00526f54
// Address: 00526f54
// ========================================

void FUN_00526f54(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bfab8;
  return;
}



// ========================================
// Function: FUN_00526f64
// Address: 00526f64
// ========================================

void FUN_00526f64(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526f68
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526f6c
// Address: 00526f6c
// ========================================

undefined4 FUN_00526f6c(undefined8 param_1,float *param_2,float *param_3)

{
  undefined4 uVar1;
  
  uVar1 = 0x3f800000;
  if (*param_2 < *param_3) {
    uVar1 = 0;
  }
  return uVar1;
}



// ========================================
// Function: FUN_00526f88
// Address: 00526f88
// ========================================

long FUN_00526f88(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser10comparisonEvEUlffE1_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00526fa4
// Address: 00526fa4
// ========================================

undefined ** FUN_00526fa4(void)

{
  return &PTR_PTR_005bfb18;
}



// ========================================
// Function: free
// Address: 00526fb0
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526fb4
// Address: 00526fb4
// ========================================

void FUN_00526fb4(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bfb38;
  return;
}



// ========================================
// Function: FUN_00526fd8
// Address: 00526fd8
// ========================================

void FUN_00526fd8(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bfb38;
  return;
}



// ========================================
// Function: FUN_00526fe8
// Address: 00526fe8
// ========================================

void FUN_00526fe8(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00526fec
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00526ff0
// Address: 00526ff0
// ========================================

undefined4 FUN_00526ff0(undefined8 param_1,float *param_2,float *param_3)

{
  undefined4 uVar1;
  
  uVar1 = 0x3f800000;
  if (*param_3 < *param_2) {
    uVar1 = 0;
  }
  return uVar1;
}



// ========================================
// Function: FUN_0052700c
// Address: 0052700c
// ========================================

long FUN_0052700c(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser10comparisonEvEUlffE2_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00527028
// Address: 00527028
// ========================================

undefined ** FUN_00527028(void)

{
  return &PTR_PTR_005bfb98;
}



// ========================================
// Function: free
// Address: 00527034
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00527038
// Address: 00527038
// ========================================

void FUN_00527038(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bfbb8;
  return;
}



// ========================================
// Function: FUN_0052705c
// Address: 0052705c
// ========================================

void FUN_0052705c(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bfbb8;
  return;
}



// ========================================
// Function: FUN_0052706c
// Address: 0052706c
// ========================================

void FUN_0052706c(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00527070
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00527074
// Address: 00527074
// ========================================

undefined4 FUN_00527074(undefined8 param_1,float *param_2,float *param_3)

{
  undefined4 uVar1;
  
  uVar1 = 0x3f800000;
  if (*param_2 <= *param_3) {
    uVar1 = 0;
  }
  return uVar1;
}



// ========================================
// Function: FUN_00527090
// Address: 00527090
// ========================================

long FUN_00527090(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser10comparisonEvEUlffE3_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_005270ac
// Address: 005270ac
// ========================================

undefined ** FUN_005270ac(void)

{
  return &PTR_PTR_005bfc18;
}



// ========================================
// Function: free
// Address: 005270b8
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_005270bc
// Address: 005270bc
// ========================================

void FUN_005270bc(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bfc38;
  return;
}



// ========================================
// Function: FUN_005270e0
// Address: 005270e0
// ========================================

void FUN_005270e0(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bfc38;
  return;
}



// ========================================
// Function: FUN_005270f0
// Address: 005270f0
// ========================================

void FUN_005270f0(void)

{
  return;
}



// ========================================
// Function: free
// Address: 005270f4
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_005270f8
// Address: 005270f8
// ========================================

undefined4 FUN_005270f8(undefined8 param_1,float *param_2,float *param_3)

{
  undefined4 uVar1;
  
  uVar1 = 0x3f800000;
  if (*param_3 <= *param_2) {
    uVar1 = 0;
  }
  return uVar1;
}



// ========================================
// Function: FUN_00527114
// Address: 00527114
// ========================================

long FUN_00527114(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser10comparisonEvEUlffE4_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00527130
// Address: 00527130
// ========================================

undefined ** FUN_00527130(void)

{
  return &PTR_PTR_005bfc98;
}



// ========================================
// Function: free
// Address: 0052713c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00527140
// Address: 00527140
// ========================================

void FUN_00527140(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bfcb8;
  return;
}



// ========================================
// Function: FUN_00527164
// Address: 00527164
// ========================================

void FUN_00527164(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bfcb8;
  return;
}



// ========================================
// Function: FUN_00527174
// Address: 00527174
// ========================================

void FUN_00527174(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00527178
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_0052717c
// Address: 0052717c
// ========================================

undefined4 FUN_0052717c(undefined8 param_1,float *param_2,float *param_3)

{
  bool bVar1;
  undefined4 uVar2;
  
  bVar1 = true;
  if ((*param_3 != 0.0) && (bVar1 = false, !NAN(*param_2))) {
    bVar1 = *param_2 == 0.0;
  }
  uVar2 = 0x3f800000;
  if (bVar1) {
    uVar2 = 0;
  }
  return uVar2;
}



// ========================================
// Function: FUN_0052719c
// Address: 0052719c
// ========================================

long FUN_0052719c(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser11logical_andEvEUlffE_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_005271b8
// Address: 005271b8
// ========================================

undefined ** FUN_005271b8(void)

{
  return &PTR_PTR_005bfd18;
}



// ========================================
// Function: FUN_005271c4
// Address: 005271c4
// ========================================

void FUN_005271c4(undefined8 *param_1)

{
  long *plVar1;
  long *plVar2;
  long lVar3;
  
  plVar1 = (long *)param_1[8];
  plVar2 = param_1 + 4;
  *param_1 = &PTR_FUN_005bfd38;
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) goto LAB_00527210;
    lVar3 = 5;
    plVar2 = plVar1;
  }
  (**(code **)(*plVar2 + lVar3 * 8))();
LAB_00527210:
  plVar2 = (long *)param_1[2];
  param_1[2] = 0;
  if (plVar2 != (long *)0x0) {
    (**(code **)(*plVar2 + 8))();
  }
  plVar2 = (long *)param_1[1];
  param_1[1] = 0;
  if (plVar2 != (long *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00527244. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar2 + 8))();
    return;
  }
  return;
}



// ========================================
// Function: FUN_00527254
// Address: 00527254
// ========================================

void FUN_00527254(undefined8 *param_1)

{
  long *plVar1;
  long *plVar2;
  long lVar3;
  
  plVar1 = (long *)param_1[8];
  plVar2 = param_1 + 4;
  *param_1 = &PTR_FUN_005bfd38;
  if (plVar1 == plVar2) {
    lVar3 = 4;
  }
  else {
    if (plVar1 == (long *)0x0) goto LAB_005272a0;
    lVar3 = 5;
    plVar2 = plVar1;
  }
  (**(code **)(*plVar2 + lVar3 * 8))();
LAB_005272a0:
  plVar2 = (long *)param_1[2];
  param_1[2] = 0;
  if (plVar2 != (long *)0x0) {
    (**(code **)(*plVar2 + 8))();
  }
  plVar2 = (long *)param_1[1];
  param_1[1] = 0;
  if (plVar2 != (long *)0x0) {
    (**(code **)(*plVar2 + 8))();
  }
  free(param_1);
  return;
}



// ========================================
// Function: FUN_005272e0
// Address: 005272e0
// ========================================

void FUN_005272e0(undefined8 *param_1,long param_2)

{
  uint uVar1;
  ulong uVar2;
  long lVar3;
  long *plVar4;
  ulong uVar5;
  undefined4 uVar6;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 local_80 [4];
  uint local_70;
  undefined4 local_6c [4];
  uint local_5c;
  long local_58;
  
  lVar3 = tpidr_el0;
  local_58 = *(long *)(lVar3 + 0x28);
  (**(code **)(**(long **)(param_2 + 8) + 0x10))(local_6c);
  (**(code **)(**(long **)(param_2 + 0x10) + 0x10))(local_80);
  *param_1 = 0;
  param_1[1] = 0;
  uVar1 = local_5c;
  if ((int)local_5c <= (int)local_70) {
    uVar1 = local_70;
  }
  *(uint *)(param_1 + 2) = uVar1;
  if (0 < (int)uVar1) {
    uVar5 = 0;
    do {
      plVar4 = *(long **)(param_2 + 0x40);
      uVar2 = 0;
      if (local_5c != 1) {
        uVar2 = uVar5 & 0xffffffff;
      }
      uStack_84 = local_6c[uVar2];
      uVar2 = 0;
      if (local_70 != 1) {
        uVar2 = uVar5 & 0xffffffff;
      }
      local_88 = local_80[uVar2];
      if (plVar4 == (long *)0x0) {
        if (*(long *)(lVar3 + 0x28) == local_58) {
                    /* WARNING: Subroutine does not return */
          FUN_002efc90();
        }
        goto LAB_005273f8;
      }
      uVar6 = (**(code **)(*plVar4 + 0x30))(plVar4,&uStack_84,&local_88);
      *(undefined4 *)((long)param_1 + uVar5 * 4) = uVar6;
      uVar5 = uVar5 + 1;
    } while (uVar1 != uVar5);
  }
  if (*(long *)(lVar3 + 0x28) == local_58) {
    return;
  }
LAB_005273f8:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005273fc
// Address: 005273fc
// ========================================

void FUN_005273fc(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00527400
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00527404
// Address: 00527404
// ========================================

void FUN_00527404(void)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  *puVar1 = &PTR_FUN_005bfd78;
  return;
}



// ========================================
// Function: FUN_00527428
// Address: 00527428
// ========================================

void FUN_00527428(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = &PTR_FUN_005bfd78;
  return;
}



// ========================================
// Function: FUN_00527438
// Address: 00527438
// ========================================

void FUN_00527438(void)

{
  return;
}



// ========================================
// Function: free
// Address: 0052743c
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00527440
// Address: 00527440
// ========================================

undefined4 FUN_00527440(undefined8 param_1,float *param_2,float *param_3)

{
  bool bVar1;
  undefined4 uVar2;
  
  bVar1 = false;
  if ((*param_3 == 0.0) && (bVar1 = false, !NAN(*param_2))) {
    bVar1 = *param_2 == 0.0;
  }
  uVar2 = 0x3f800000;
  if (bVar1) {
    uVar2 = 0;
  }
  return uVar2;
}



// ========================================
// Function: FUN_00527460
// Address: 00527460
// ========================================

long FUN_00527460(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) != "ZN10magic_iris12_GLOBAL__N_16Parser10logical_orEvEUlffE_") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_0052747c
// Address: 0052747c
// ========================================

undefined ** FUN_0052747c(void)

{
  return &PTR_PTR_005bfdd8;
}



// ========================================
// Function: FUN_00527488
// Address: 00527488
// ========================================

void FUN_00527488(long *param_1,char *param_2)

{
  long lVar1;
  ulong uVar2;
  size_t sVar3;
  long *plVar4;
  undefined8 *puVar5;
  void *pvVar6;
  long lVar7;
  ulong local_68;
  size_t sStack_60;
  void *local_58;
  undefined8 local_50;
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  lVar7 = *param_1;
  if (*(char *)(lVar7 + 0x30) != '\0') {
    sVar3 = strlen(param_2);
    if (0xffffffffffffffef < sVar3) {
      if (*(long *)(lVar1 + 0x28) == local_48) {
                    /* WARNING: Subroutine does not return */
        FUN_002d18a8(&local_68);
      }
      goto LAB_00527620;
    }
    if (sVar3 < 0x17) {
      pvVar6 = (void *)((ulong)&local_68 | 1);
      local_68 = CONCAT71(local_68._1_7_,(char)((int)sVar3 << 1));
      if (sVar3 != 0) goto LAB_0052750c;
    }
    else {
      pvVar6 = (void *)FUN_005a5d4c((sVar3 | 0xf) + 1);
      local_68 = (sVar3 | 0xf) + 2;
      sStack_60 = sVar3;
      local_58 = pvVar6;
LAB_0052750c:
      memcpy(pvVar6,param_2,sVar3);
    }
    *(undefined1 *)((long)pvVar6 + sVar3) = 0;
                    /* try { // try from 00527520 to 0052757f has its CatchHandler @ 005275f4 */
    plVar4 = (long *)FUN_0029b45c(lVar7 + 0x18,&local_50,&local_68);
    if (*plVar4 == 0) {
      puVar5 = (undefined8 *)FUN_005a5d4c(0x38);
      pvVar6 = local_58;
      sVar3 = sStack_60;
      uVar2 = local_68;
      sStack_60 = 0;
      local_58 = (void *)0x0;
      local_68 = 0;
      puVar5[6] = pvVar6;
      puVar5[5] = sVar3;
      puVar5[4] = uVar2;
      *puVar5 = 0;
      puVar5[1] = 0;
      puVar5[2] = local_50;
      *plVar4 = (long)puVar5;
      if (**(long **)(lVar7 + 0x18) != 0) {
        *(long *)(lVar7 + 0x18) = **(long **)(lVar7 + 0x18);
        puVar5 = (undefined8 *)*plVar4;
      }
      FUN_002c1c30(*(undefined8 *)(lVar7 + 0x20),puVar5);
      *(long *)(lVar7 + 0x28) = *(long *)(lVar7 + 0x28) + 1;
    }
    if ((local_68 & 1) != 0) {
      free(local_58);
    }
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return;
  }
LAB_00527620:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_00527624
// Address: 00527624
// ========================================

void FUN_00527624(undefined8 param_1,undefined8 *param_2)

{
  if (param_2 != (undefined8 *)0x0) {
    FUN_00527624(param_1,*param_2);
    FUN_00527624(param_1,param_2[1]);
    if ((*(byte *)(param_2 + 4) & 1) != 0) {
      free((void *)param_2[6]);
    }
    free(param_2);
    return;
  }
  return;
}



// ========================================
// Function: FUN_00527674
// Address: 00527674
// ========================================

undefined8 * FUN_00527674(long *param_1,undefined8 param_2,undefined8 param_3,undefined8 *param_4)

{
  long lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  byte *pbVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  undefined8 local_68;
  undefined8 *local_60;
  long *local_58;
  undefined1 local_50;
  long local_48;
  
  lVar1 = tpidr_el0;
  local_48 = *(long *)(lVar1 + 0x28);
  puVar2 = (undefined8 *)FUN_005277d0(param_1,&local_68,param_2);
  puVar6 = (undefined8 *)*puVar2;
  if (puVar6 == (undefined8 *)0x0) {
    puVar6 = (undefined8 *)FUN_005a5d4c(0xf8);
    pbVar5 = (byte *)*param_4;
    local_50 = 0;
    local_60 = puVar6;
    local_58 = param_1 + 1;
    if ((*pbVar5 & 1) == 0) {
      uVar7 = *(undefined8 *)(pbVar5 + 8);
      uVar3 = *(undefined8 *)pbVar5;
      puVar6[6] = *(undefined8 *)(pbVar5 + 0x10);
      puVar6[5] = uVar7;
      puVar6[4] = uVar3;
    }
    else {
                    /* try { // try from 00527700 to 00527707 has its CatchHandler @ 005277a8 */
      FUN_00251fc8(puVar6 + 4,*(undefined8 *)(pbVar5 + 0x10),*(undefined8 *)(pbVar5 + 8));
    }
    *puVar6 = 0;
    puVar6[1] = 0;
    puVar6[2] = local_68;
    puVar6[0x1e] = 0;
    puVar6[0x1d] = 0;
    puVar6[0x1c] = 0;
    puVar6[0x1b] = 0;
    puVar6[0x1a] = 0;
    puVar6[0x19] = 0;
    puVar6[0x18] = 0;
    puVar6[0x17] = 0;
    puVar6[0x16] = 0;
    puVar6[0x15] = 0;
    puVar6[0x14] = 0;
    puVar6[0x13] = 0;
    puVar6[0x12] = 0;
    puVar6[0x11] = 0;
    puVar6[0x10] = 0;
    puVar6[0xf] = 0;
    puVar6[0xe] = 0;
    puVar6[0xd] = 0;
    puVar6[0xc] = 0;
    puVar6[0xb] = 0;
    puVar6[10] = 0;
    puVar6[9] = 0;
    puVar6[8] = 0;
    puVar6[7] = 0;
    *puVar2 = puVar6;
    puVar4 = puVar6;
    if (*(long *)*param_1 != 0) {
      *param_1 = *(long *)*param_1;
      puVar4 = (undefined8 *)*puVar2;
    }
    puVar2 = (undefined8 *)FUN_002c1c30(param_1[1],puVar4);
    uVar3 = 1;
    param_1[2] = param_1[2] + 1;
  }
  else {
    uVar3 = 0;
  }
  if (*(long *)(lVar1 + 0x28) == local_48) {
    return puVar6;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(puVar2,uVar3);
}



// ========================================
// Function: FUN_005277d0
// Address: 005277d0
// ========================================

long * FUN_005277d0(long param_1,undefined8 *param_2,byte *param_3)

{
  void *__s2;
  size_t __n;
  ulong uVar1;
  byte *__s1;
  bool bVar2;
  ulong uVar3;
  int iVar4;
  long *plVar5;
  long *plVar6;
  long *plVar7;
  
  plVar6 = (long *)(param_1 + 8);
  plVar5 = (long *)*plVar6;
  plVar7 = plVar6;
  if (plVar5 != (long *)0x0) {
    uVar1 = *(ulong *)(param_3 + 8);
    __s1 = *(byte **)(param_3 + 0x10);
    if ((*param_3 & 1) == 0) {
      __s1 = param_3 + 1;
      uVar1 = (ulong)(*param_3 >> 1);
    }
    do {
      while( true ) {
        plVar7 = plVar5;
        __s2 = (void *)((long)plVar7 + 0x21);
        uVar3 = (ulong)(*(byte *)(plVar7 + 4) >> 1);
        if ((*(byte *)(plVar7 + 4) & 1) != 0) {
          __s2 = (void *)plVar7[6];
          uVar3 = plVar7[5];
        }
        __n = uVar3;
        if (uVar1 <= uVar3) {
          __n = uVar1;
        }
        iVar4 = memcmp(__s1,__s2,__n);
        bVar2 = uVar1 < uVar3;
        if (iVar4 != 0) {
          bVar2 = iVar4 < 0;
        }
        if (bVar2) break;
        iVar4 = memcmp(__s2,__s1,__n);
        bVar2 = uVar3 < uVar1;
        if (iVar4 != 0) {
          bVar2 = iVar4 < 0;
        }
        if (!bVar2) goto LAB_005278b4;
        plVar6 = plVar7 + 1;
        plVar5 = (long *)*plVar6;
        if ((long *)*plVar6 == (long *)0x0) goto LAB_005278b4;
      }
      plVar5 = (long *)*plVar7;
      plVar6 = plVar7;
    } while ((long *)*plVar7 != (long *)0x0);
  }
LAB_005278b4:
  *param_2 = plVar7;
  return plVar6;
}



// ========================================
// Function: FUN_005278d4
// Address: 005278d4
// ========================================

void FUN_005278d4(undefined8 *param_1)

{
  void *__ptr;
  
  __ptr = (void *)*param_1;
  *param_1 = 0;
  if (__ptr != (void *)0x0) {
    if ((*(char *)(param_1 + 2) != '\0') && ((*(byte *)((long)__ptr + 0x20) & 1) != 0)) {
      free(*(void **)((long)__ptr + 0x30));
    }
    free(__ptr);
    return;
  }
  return;
}



// ========================================
// Function: FUN_00527924
// Address: 00527924
// ========================================

void FUN_00527924(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00527928
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_0052792c
// Address: 0052792c
// ========================================

void FUN_0052792c(long param_1)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar2 = *(undefined8 *)(param_1 + 8);
  *puVar1 = &PTR_FUN_005bfdf8;
  puVar1[1] = uVar2;
  return;
}



// ========================================
// Function: FUN_00527960
// Address: 00527960
// ========================================

void FUN_00527960(long param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  
  uVar1 = *(undefined8 *)(param_1 + 8);
  *param_2 = &PTR_FUN_005bfdf8;
  param_2[1] = uVar1;
  return;
}



// ========================================
// Function: FUN_00527974
// Address: 00527974
// ========================================

void FUN_00527974(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00527978
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_0052797c
// Address: 0052797c
// ========================================

long FUN_0052797c(long param_1,undefined8 param_2)

{
  long lVar1;
  long lVar2;
  undefined1 uStack_31;
  undefined8 local_30;
  long local_28;
  
  lVar1 = tpidr_el0;
  local_28 = *(long *)(lVar1 + 0x28);
  local_30 = param_2;
  lVar2 = FUN_00527674(*(undefined8 *)(param_1 + 8),param_2,PTR_DAT_005c5e10,&local_30,&uStack_31);
  if (*(long *)(lVar1 + 0x28) == local_28) {
    return lVar2 + 0x38;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005279dc
// Address: 005279dc
// ========================================

long FUN_005279dc(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12IrisUniforms14set_propertiesERKNS_10PropertiesEE3$_0") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_005279f8
// Address: 005279f8
// ========================================

undefined ** FUN_005279f8(void)

{
  return &PTR_PTR_005bfe68;
}



// ========================================
// Function: FUN_00527a04
// Address: 00527a04
// ========================================

void FUN_00527a04(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00527a08
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00527a0c
// Address: 00527a0c
// ========================================

void FUN_00527a0c(long param_1)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  puVar1 = (undefined8 *)FUN_005a5d4c(0x10);
  uVar2 = *(undefined8 *)(param_1 + 8);
  *puVar1 = &PTR_FUN_005bfe88;
  puVar1[1] = uVar2;
  return;
}



// ========================================
// Function: FUN_00527a40
// Address: 00527a40
// ========================================

void FUN_00527a40(long param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  
  uVar1 = *(undefined8 *)(param_1 + 8);
  *param_2 = &PTR_FUN_005bfe88;
  param_2[1] = uVar1;
  return;
}



// ========================================
// Function: FUN_00527a54
// Address: 00527a54
// ========================================

void FUN_00527a54(void)

{
  return;
}



// ========================================
// Function: free
// Address: 00527a58
// ========================================

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// ========================================
// Function: FUN_00527a5c
// Address: 00527a5c
// ========================================

undefined4 FUN_00527a5c(long param_1)

{
  undefined4 uVar1;
  long lVar2;
  
  lVar2 = FUN_002c2fb4(*(long *)(param_1 + 8) + 0x18);
  if (*(long *)(param_1 + 8) + 0x20 == lVar2) {
    uVar1 = 1;
  }
  else {
    uVar1 = *(undefined4 *)(lVar2 + 0x38);
  }
  return uVar1;
}



// ========================================
// Function: FUN_00527aa0
// Address: 00527aa0
// ========================================

long FUN_00527aa0(long param_1,long param_2)

{
  param_1 = param_1 + 8;
  if (*(char **)(param_2 + 8) !=
      "ZN10magic_iris12IrisUniforms14set_propertiesERKNS_10PropertiesEE3$_1") {
    param_1 = 0;
  }
  return param_1;
}



// ========================================
// Function: FUN_00527abc
// Address: 00527abc
// ========================================

undefined ** FUN_00527abc(void)

{
  return &PTR_PTR_005bfef8;
}



// ========================================
// Function: FUN_00527ac8
// Address: 00527ac8
// ========================================

undefined8 * FUN_00527ac8(ulong *param_1,undefined8 *param_2)

{
  ulong uVar1;
  ulong uVar2;
  long lVar3;
  long *plVar4;
  ulong uVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  ulong uVar8;
  undefined8 *puVar9;
  long lVar10;
  undefined8 *puVar11;
  undefined8 *puVar13;
  long lVar14;
  undefined8 uVar15;
  undefined8 uVar16;
  undefined8 uVar17;
  undefined8 *puVar12;
  
  uVar2 = *param_1;
  uVar8 = param_1[1];
  lVar10 = uVar8 - uVar2;
  lVar14 = lVar10 >> 4;
  uVar1 = lVar14 + 1;
  if (uVar1 >> 0x3c != 0) {
    FUN_00527c98(param_1);
LAB_00527c94:
                    /* WARNING: Subroutine does not return */
    FUN_0029fc3c();
  }
  uVar5 = (long)(param_1[2] - uVar2) >> 3;
  if (uVar5 <= uVar1) {
    uVar5 = uVar1;
  }
  if (0x7fffffffffffffef < param_1[2] - uVar2) {
    uVar5 = 0xfffffffffffffff;
  }
  if (uVar5 >> 0x3c != 0) goto LAB_00527c94;
  lVar3 = FUN_005a5d4c(uVar5 * 0x10);
  uVar15 = param_2[1];
  puVar6 = (undefined8 *)(lVar3 + lVar10);
  param_2[1] = 0;
  puVar13 = (undefined8 *)*param_1;
  puVar12 = (undefined8 *)param_1[1];
  puVar9 = puVar6 + 2;
  *puVar6 = *param_2;
  uVar1 = lVar3 + uVar5 * 0x10;
  *(undefined8 *)(lVar3 + lVar14 * 0x10 + 8) = uVar15;
  lVar10 = (long)puVar12 - (long)puVar13;
  if (lVar10 == 0) {
    *param_1 = (ulong)puVar6;
    param_1[1] = (ulong)puVar9;
    param_1[2] = uVar1;
    goto joined_r0x00527c84;
  }
  uVar5 = lVar10 - 0x10;
  puVar11 = puVar12;
  if ((uVar5 < 0x90) ||
     (((undefined8 *)(((uVar8 - uVar2) - (uVar5 & 0xfffffffffffffff0)) + lVar3 + -0x10) < puVar12 &&
      ((undefined8 *)((long)puVar12 + (-0x10 - (uVar5 & 0xfffffffffffffff0))) < puVar6)))) {
LAB_00527bf4:
    do {
      puVar12 = puVar11 + -2;
      puVar7 = puVar6 + -2;
      *puVar7 = *puVar12;
      uVar15 = puVar11[-1];
      puVar11[-1] = 0;
      puVar6[-1] = uVar15;
      puVar6 = puVar7;
      puVar11 = puVar12;
    } while (puVar12 != puVar13);
  }
  else {
    uVar2 = (uVar5 >> 4) + 1;
    uVar5 = uVar2 & 0x1ffffffffffffffe;
    puVar7 = puVar6 + uVar5 * -2;
    puVar11 = puVar12 + uVar5 * -2;
    uVar8 = uVar5;
    do {
      uVar16 = puVar12[-3];
      uVar15 = puVar12[-2];
      uVar17 = puVar12[-1];
      uVar8 = uVar8 - 2;
      puVar12[-1] = 0;
      puVar12[-3] = 0;
      puVar6[-4] = puVar12[-4];
      puVar6[-3] = uVar16;
      puVar6[-2] = uVar15;
      puVar6[-1] = uVar17;
      puVar6 = puVar6 + -4;
      puVar12 = puVar12 + -4;
    } while (uVar8 != 0);
    puVar6 = puVar7;
    if (uVar2 != uVar5) goto LAB_00527bf4;
  }
  puVar6 = (undefined8 *)*param_1;
  puVar13 = (undefined8 *)param_1[1];
  *param_1 = (ulong)puVar7;
  param_1[1] = (ulong)puVar9;
  param_1[2] = uVar1;
  puVar12 = puVar13;
  for (; puVar13 != puVar6; puVar13 = puVar13 + -2) {
    plVar4 = (long *)puVar13[-1];
    puVar13[-1] = 0;
    if (plVar4 != (long *)0x0) {
      (**(code **)(*plVar4 + 8))();
    }
    puVar12 = puVar6;
  }
joined_r0x00527c84:
  if (puVar12 != (undefined8 *)0x0) {
    free(puVar12);
  }
  return puVar9;
}



// ========================================
// Function: FUN_00527c98
// Address: 00527c98
// ========================================

void FUN_00527c98(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0029fbbc("vector");
}



// ========================================
// Function: FUN_00527cac
// Address: 00527cac
// ========================================

uint FUN_00527cac(byte *param_1)

{
  uint *puVar1;
  byte *pbVar2;
  byte *pbVar3;
  byte *pbVar4;
  uint *puVar5;
  int iVar6;
  ulong uVar7;
  uint uVar8;
  
  if (((DAT_0098f050 & 1) == 0) && (iVar6 = FUN_0058bb00(&DAT_0098f050), iVar6 != 0)) {
    FUN_00527df4();
    FUN_0058bc30(&DAT_0098f050);
  }
  uVar7 = *(ulong *)(param_1 + 8);
  puVar5 = *(uint **)(param_1 + 0x10);
  if ((*param_1 & 1) == 0) {
    puVar5 = (uint *)(param_1 + 1);
    uVar7 = (ulong)(*param_1 >> 1);
  }
  uVar8 = 0xffffffff;
  for (; 7 < uVar7; uVar7 = uVar7 - 8) {
    puVar1 = puVar5 + 1;
    pbVar2 = (byte *)((long)puVar5 + 5);
    pbVar3 = (byte *)((long)puVar5 + 6);
    uVar8 = *puVar5 ^ uVar8;
    pbVar4 = (byte *)((long)puVar5 + 7);
    puVar5 = puVar5 + 2;
    uVar8 = (&DAT_0098e850)[uVar8 >> 8 & 0xff] ^ (&DAT_0098ec50)[uVar8 & 0xff] ^
            (&DAT_0098e450)[uVar8 >> 0x10 & 0xff] ^ (&DAT_0098e050)[uVar8 >> 0x18] ^
            (&DAT_0098dc50)[(byte)*puVar1] ^ (&DAT_0098d850)[*pbVar2] ^ (&DAT_0098d450)[*pbVar3] ^
            (&DAT_0098d050)[*pbVar4];
  }
  for (; uVar7 != 0; uVar7 = uVar7 - 1) {
    uVar8 = (&DAT_0098d050)[(ulong)((byte)*puVar5 ^ uVar8) & 0xff] ^ uVar8 >> 8;
    puVar5 = (uint *)((long)puVar5 + 1);
  }
  return ~uVar8;
}



// ========================================
// Function: FUN_00527df4
// Address: 00527df4
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00527df4(void)

{
  long lVar1;
  undefined1 auVar2 [16];
  undefined3 uVar3;
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  uint uVar11;
  int iVar12;
  int iVar13;
  uint uVar14;
  int iVar15;
  undefined1 auVar16 [16];
  undefined1 auVar17 [16];
  undefined1 auVar18 [16];
  undefined1 auVar19 [16];
  undefined1 auVar20 [16];
  undefined1 auVar21 [16];
  undefined1 auVar22 [16];
  undefined1 auVar23 [16];
  ulong uVar24;
  ulong uVar25;
  long lVar26;
  uint uVar27;
  uint uVar29;
  undefined8 uVar28;
  uint uVar31;
  ulong uVar30;
  uint5 uVar32;
  undefined1 auVar33 [16];
  undefined1 auVar34 [16];
  undefined1 auVar35 [16];
  undefined1 auVar36 [16];
  undefined1 auVar37 [16];
  undefined1 auVar38 [16];
  undefined1 auVar39 [16];
  undefined1 auVar40 [16];
  undefined1 auVar41 [16];
  byte bVar42;
  undefined1 uVar43;
  undefined1 uVar44;
  undefined1 uVar45;
  byte bVar46;
  byte bVar47;
  byte bVar48;
  byte bVar49;
  byte bVar50;
  byte bVar51;
  byte bVar52;
  byte bVar53;
  byte bVar54;
  byte bVar55;
  byte bVar56;
  byte bVar57;
  byte bVar58;
  byte bVar59;
  byte bVar60;
  
  lVar26 = 0;
  uVar28 = _DAT_001a0d20;
  uVar30 = _UNK_001a0d28;
  do {
    uVar32 = CONCAT14((char)((ulong)uVar28 >> 0x20),(uint)((byte)uVar28 & 1)) & 0x1ffffffff;
    uVar25 = uVar30 & 1;
    uVar24 = uVar30 & 0x100000000;
    uVar27 = (uint)uVar28;
    bVar42 = (byte)((ulong)uVar28 >> 0x18) >> 1;
    uVar29 = (uint)((ulong)uVar28 >> 0x20);
    uVar11 = uVar29 >> 1;
    uVar43 = (undefined1)uVar11;
    uVar44 = (undefined1)(uVar11 >> 8);
    uVar45 = (undefined1)(uVar11 >> 0x10);
    bVar46 = (byte)((ulong)uVar28 >> 0x39);
    uVar11 = (uint)uVar30 >> 1;
    bVar47 = (byte)(uVar11 >> 8);
    bVar48 = (byte)(uVar11 >> 0x10);
    bVar49 = (byte)(uVar30 >> 0x18) >> 1;
    uVar31 = (uint)(uVar30 >> 0x20);
    uVar14 = uVar31 >> 1;
    bVar50 = (byte)(uVar14 >> 8);
    bVar51 = (byte)(uVar14 >> 0x10);
    bVar52 = (byte)(uVar30 >> 0x39);
    uVar28 = CONCAT44(uVar29 + 4,uVar27 + 4);
    uVar30 = CONCAT44(uVar31 + 4,(uint)uVar30 + 4);
    auVar33._0_4_ = -(uint)((int)uVar32 == 0);
    auVar33._4_4_ = -(uint)((char)(uVar32 >> 0x20) == '\0');
    auVar33._8_4_ = -(uint)(uVar25 == 0);
    auVar33._12_4_ = -(uint)(uVar24 == 0);
    bVar53 = (byte)uVar11 ^ 0x20;
    bVar54 = bVar47 ^ 0x83;
    bVar55 = bVar48 ^ 0xb8;
    bVar56 = bVar49 ^ 0xed;
    bVar57 = (byte)uVar14 ^ 0x20;
    bVar58 = bVar50 ^ 0x83;
    bVar59 = bVar51 ^ 0xb8;
    bVar60 = bVar52 ^ 0xed;
    uVar3 = (undefined3)(uVar27 >> 1);
    auVar2[3] = bVar42;
    auVar2._0_3_ = uVar3;
    auVar2[4] = uVar43;
    auVar2[5] = uVar44;
    auVar2[6] = uVar45;
    auVar2[7] = bVar46;
    auVar2[8] = (byte)uVar11;
    auVar2[9] = bVar47;
    auVar2[10] = bVar48;
    auVar2[0xb] = bVar49;
    auVar2[0xc] = (byte)uVar14;
    auVar2[0xd] = bVar50;
    auVar2[0xe] = bVar51;
    auVar2[0xf] = bVar52;
    auVar16[8] = bVar53;
    auVar16._0_8_ =
         CONCAT17(bVar46,CONCAT16(uVar45,CONCAT15(uVar44,CONCAT14(uVar43,CONCAT13(bVar42,uVar3)))))
         ^ 0xedb88320edb88320;
    auVar16[9] = bVar54;
    auVar16[10] = bVar55;
    auVar16[0xb] = bVar56;
    auVar16[0xc] = bVar57;
    auVar16[0xd] = bVar58;
    auVar16[0xe] = bVar59;
    auVar16[0xf] = bVar60;
    auVar34[8] = bVar53;
    auVar34._0_8_ =
         CONCAT17(bVar46,CONCAT16(uVar45,CONCAT15(uVar44,CONCAT14(uVar43,CONCAT13(bVar42,uVar3)))))
         ^ 0xedb88320edb88320;
    auVar34[9] = bVar54;
    auVar34[10] = bVar55;
    auVar34[0xb] = bVar56;
    auVar34[0xc] = bVar57;
    auVar34[0xd] = bVar58;
    auVar34[0xe] = bVar59;
    auVar34[0xf] = bVar60;
    auVar34 = auVar34 ^ (auVar16 ^ auVar2) & auVar33;
    auVar35._0_4_ = auVar34._0_4_ >> 1;
    auVar35._4_4_ = auVar34._4_4_ >> 1;
    auVar35._8_4_ = auVar34._8_4_ >> 1;
    auVar35._12_4_ = auVar34._12_4_ >> 1;
    iVar12 = -(uint)((auVar34 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    iVar13 = -(uint)((auVar34 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    iVar15 = -(uint)((auVar34 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    auVar17[8] = (byte)auVar35._8_4_ ^ 0x20;
    auVar17._0_8_ =
         CONCAT17(auVar34[7] >> 1,
                  CONCAT16((char)(auVar35._4_4_ >> 0x10),
                           CONCAT15((char)(auVar35._4_4_ >> 8),
                                    CONCAT14((char)auVar35._4_4_,
                                             CONCAT13(auVar34[3] >> 1,(int3)auVar35._0_4_))))) ^
         0xedb88320edb88320;
    auVar17[9] = (byte)(auVar35._8_4_ >> 8) ^ 0x83;
    auVar17[10] = (byte)(auVar35._8_4_ >> 0x10) ^ 0xb8;
    auVar17[0xb] = auVar34[0xb] >> 1 ^ 0xed;
    auVar17[0xc] = (byte)auVar35._12_4_ ^ 0x20;
    auVar17[0xd] = (byte)(auVar35._12_4_ >> 8) ^ 0x83;
    auVar17[0xe] = (byte)(auVar35._12_4_ >> 0x10) ^ 0xb8;
    auVar17[0xf] = auVar34[0xf] >> 1 ^ 0xed;
    auVar4[4] = (char)iVar12;
    auVar4._0_4_ = -(uint)((auVar34 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    auVar4[5] = (char)((uint)iVar12 >> 8);
    auVar4[6] = (char)((uint)iVar12 >> 0x10);
    auVar4[7] = (char)((uint)iVar12 >> 0x18);
    auVar4[8] = (char)iVar13;
    auVar4[9] = (char)((uint)iVar13 >> 8);
    auVar4[10] = (char)((uint)iVar13 >> 0x10);
    auVar4[0xb] = (char)((uint)iVar13 >> 0x18);
    auVar4[0xc] = (char)iVar15;
    auVar4[0xd] = (char)((uint)iVar15 >> 8);
    auVar4[0xe] = (char)((uint)iVar15 >> 0x10);
    auVar4[0xf] = (char)((uint)iVar15 >> 0x18);
    auVar35 = auVar35 ^ (auVar35 ^ auVar17) & ~auVar4;
    auVar36._0_4_ = auVar35._0_4_ >> 1;
    auVar36._4_4_ = auVar35._4_4_ >> 1;
    auVar36._8_4_ = auVar35._8_4_ >> 1;
    auVar36._12_4_ = auVar35._12_4_ >> 1;
    iVar12 = -(uint)((auVar35 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    iVar13 = -(uint)((auVar35 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    iVar15 = -(uint)((auVar35 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    auVar18[8] = (byte)auVar36._8_4_ ^ 0x20;
    auVar18._0_8_ =
         CONCAT17(auVar35[7] >> 1,
                  CONCAT16((char)(auVar36._4_4_ >> 0x10),
                           CONCAT15((char)(auVar36._4_4_ >> 8),
                                    CONCAT14((char)auVar36._4_4_,
                                             CONCAT13(auVar35[3] >> 1,(int3)auVar36._0_4_))))) ^
         0xedb88320edb88320;
    auVar18[9] = (byte)(auVar36._8_4_ >> 8) ^ 0x83;
    auVar18[10] = (byte)(auVar36._8_4_ >> 0x10) ^ 0xb8;
    auVar18[0xb] = auVar35[0xb] >> 1 ^ 0xed;
    auVar18[0xc] = (byte)auVar36._12_4_ ^ 0x20;
    auVar18[0xd] = (byte)(auVar36._12_4_ >> 8) ^ 0x83;
    auVar18[0xe] = (byte)(auVar36._12_4_ >> 0x10) ^ 0xb8;
    auVar18[0xf] = auVar35[0xf] >> 1 ^ 0xed;
    auVar5[4] = (char)iVar12;
    auVar5._0_4_ = -(uint)((auVar35 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    auVar5[5] = (char)((uint)iVar12 >> 8);
    auVar5[6] = (char)((uint)iVar12 >> 0x10);
    auVar5[7] = (char)((uint)iVar12 >> 0x18);
    auVar5[8] = (char)iVar13;
    auVar5[9] = (char)((uint)iVar13 >> 8);
    auVar5[10] = (char)((uint)iVar13 >> 0x10);
    auVar5[0xb] = (char)((uint)iVar13 >> 0x18);
    auVar5[0xc] = (char)iVar15;
    auVar5[0xd] = (char)((uint)iVar15 >> 8);
    auVar5[0xe] = (char)((uint)iVar15 >> 0x10);
    auVar5[0xf] = (char)((uint)iVar15 >> 0x18);
    auVar36 = auVar36 ^ (auVar36 ^ auVar18) & ~auVar5;
    auVar37._0_4_ = auVar36._0_4_ >> 1;
    auVar37._4_4_ = auVar36._4_4_ >> 1;
    auVar37._8_4_ = auVar36._8_4_ >> 1;
    auVar37._12_4_ = auVar36._12_4_ >> 1;
    iVar12 = -(uint)((auVar36 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    iVar13 = -(uint)((auVar36 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    iVar15 = -(uint)((auVar36 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    auVar19[8] = (byte)auVar37._8_4_ ^ 0x20;
    auVar19._0_8_ =
         CONCAT17(auVar36[7] >> 1,
                  CONCAT16((char)(auVar37._4_4_ >> 0x10),
                           CONCAT15((char)(auVar37._4_4_ >> 8),
                                    CONCAT14((char)auVar37._4_4_,
                                             CONCAT13(auVar36[3] >> 1,(int3)auVar37._0_4_))))) ^
         0xedb88320edb88320;
    auVar19[9] = (byte)(auVar37._8_4_ >> 8) ^ 0x83;
    auVar19[10] = (byte)(auVar37._8_4_ >> 0x10) ^ 0xb8;
    auVar19[0xb] = auVar36[0xb] >> 1 ^ 0xed;
    auVar19[0xc] = (byte)auVar37._12_4_ ^ 0x20;
    auVar19[0xd] = (byte)(auVar37._12_4_ >> 8) ^ 0x83;
    auVar19[0xe] = (byte)(auVar37._12_4_ >> 0x10) ^ 0xb8;
    auVar19[0xf] = auVar36[0xf] >> 1 ^ 0xed;
    auVar6[4] = (char)iVar12;
    auVar6._0_4_ = -(uint)((auVar36 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    auVar6[5] = (char)((uint)iVar12 >> 8);
    auVar6[6] = (char)((uint)iVar12 >> 0x10);
    auVar6[7] = (char)((uint)iVar12 >> 0x18);
    auVar6[8] = (char)iVar13;
    auVar6[9] = (char)((uint)iVar13 >> 8);
    auVar6[10] = (char)((uint)iVar13 >> 0x10);
    auVar6[0xb] = (char)((uint)iVar13 >> 0x18);
    auVar6[0xc] = (char)iVar15;
    auVar6[0xd] = (char)((uint)iVar15 >> 8);
    auVar6[0xe] = (char)((uint)iVar15 >> 0x10);
    auVar6[0xf] = (char)((uint)iVar15 >> 0x18);
    auVar37 = auVar37 ^ (auVar37 ^ auVar19) & ~auVar6;
    auVar38._0_4_ = auVar37._0_4_ >> 1;
    auVar38._4_4_ = auVar37._4_4_ >> 1;
    auVar38._8_4_ = auVar37._8_4_ >> 1;
    auVar38._12_4_ = auVar37._12_4_ >> 1;
    iVar12 = -(uint)((auVar37 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    iVar13 = -(uint)((auVar37 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    iVar15 = -(uint)((auVar37 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    auVar20[8] = (byte)auVar38._8_4_ ^ 0x20;
    auVar20._0_8_ =
         CONCAT17(auVar37[7] >> 1,
                  CONCAT16((char)(auVar38._4_4_ >> 0x10),
                           CONCAT15((char)(auVar38._4_4_ >> 8),
                                    CONCAT14((char)auVar38._4_4_,
                                             CONCAT13(auVar37[3] >> 1,(int3)auVar38._0_4_))))) ^
         0xedb88320edb88320;
    auVar20[9] = (byte)(auVar38._8_4_ >> 8) ^ 0x83;
    auVar20[10] = (byte)(auVar38._8_4_ >> 0x10) ^ 0xb8;
    auVar20[0xb] = auVar37[0xb] >> 1 ^ 0xed;
    auVar20[0xc] = (byte)auVar38._12_4_ ^ 0x20;
    auVar20[0xd] = (byte)(auVar38._12_4_ >> 8) ^ 0x83;
    auVar20[0xe] = (byte)(auVar38._12_4_ >> 0x10) ^ 0xb8;
    auVar20[0xf] = auVar37[0xf] >> 1 ^ 0xed;
    auVar7[4] = (char)iVar12;
    auVar7._0_4_ = -(uint)((auVar37 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    auVar7[5] = (char)((uint)iVar12 >> 8);
    auVar7[6] = (char)((uint)iVar12 >> 0x10);
    auVar7[7] = (char)((uint)iVar12 >> 0x18);
    auVar7[8] = (char)iVar13;
    auVar7[9] = (char)((uint)iVar13 >> 8);
    auVar7[10] = (char)((uint)iVar13 >> 0x10);
    auVar7[0xb] = (char)((uint)iVar13 >> 0x18);
    auVar7[0xc] = (char)iVar15;
    auVar7[0xd] = (char)((uint)iVar15 >> 8);
    auVar7[0xe] = (char)((uint)iVar15 >> 0x10);
    auVar7[0xf] = (char)((uint)iVar15 >> 0x18);
    auVar38 = auVar38 ^ (auVar38 ^ auVar20) & ~auVar7;
    auVar39._0_4_ = auVar38._0_4_ >> 1;
    auVar39._4_4_ = auVar38._4_4_ >> 1;
    auVar39._8_4_ = auVar38._8_4_ >> 1;
    auVar39._12_4_ = auVar38._12_4_ >> 1;
    iVar12 = -(uint)((auVar38 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    iVar13 = -(uint)((auVar38 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    iVar15 = -(uint)((auVar38 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    auVar21[8] = (byte)auVar39._8_4_ ^ 0x20;
    auVar21._0_8_ =
         CONCAT17(auVar38[7] >> 1,
                  CONCAT16((char)(auVar39._4_4_ >> 0x10),
                           CONCAT15((char)(auVar39._4_4_ >> 8),
                                    CONCAT14((char)auVar39._4_4_,
                                             CONCAT13(auVar38[3] >> 1,(int3)auVar39._0_4_))))) ^
         0xedb88320edb88320;
    auVar21[9] = (byte)(auVar39._8_4_ >> 8) ^ 0x83;
    auVar21[10] = (byte)(auVar39._8_4_ >> 0x10) ^ 0xb8;
    auVar21[0xb] = auVar38[0xb] >> 1 ^ 0xed;
    auVar21[0xc] = (byte)auVar39._12_4_ ^ 0x20;
    auVar21[0xd] = (byte)(auVar39._12_4_ >> 8) ^ 0x83;
    auVar21[0xe] = (byte)(auVar39._12_4_ >> 0x10) ^ 0xb8;
    auVar21[0xf] = auVar38[0xf] >> 1 ^ 0xed;
    auVar8[4] = (char)iVar12;
    auVar8._0_4_ = -(uint)((auVar38 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    auVar8[5] = (char)((uint)iVar12 >> 8);
    auVar8[6] = (char)((uint)iVar12 >> 0x10);
    auVar8[7] = (char)((uint)iVar12 >> 0x18);
    auVar8[8] = (char)iVar13;
    auVar8[9] = (char)((uint)iVar13 >> 8);
    auVar8[10] = (char)((uint)iVar13 >> 0x10);
    auVar8[0xb] = (char)((uint)iVar13 >> 0x18);
    auVar8[0xc] = (char)iVar15;
    auVar8[0xd] = (char)((uint)iVar15 >> 8);
    auVar8[0xe] = (char)((uint)iVar15 >> 0x10);
    auVar8[0xf] = (char)((uint)iVar15 >> 0x18);
    auVar39 = auVar39 ^ (auVar39 ^ auVar21) & ~auVar8;
    auVar40._0_4_ = auVar39._0_4_ >> 1;
    auVar40._4_4_ = auVar39._4_4_ >> 1;
    auVar40._8_4_ = auVar39._8_4_ >> 1;
    auVar40._12_4_ = auVar39._12_4_ >> 1;
    iVar12 = -(uint)((auVar39 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    iVar13 = -(uint)((auVar39 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    iVar15 = -(uint)((auVar39 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    auVar22[8] = (byte)auVar40._8_4_ ^ 0x20;
    auVar22._0_8_ =
         CONCAT17(auVar39[7] >> 1,
                  CONCAT16((char)(auVar40._4_4_ >> 0x10),
                           CONCAT15((char)(auVar40._4_4_ >> 8),
                                    CONCAT14((char)auVar40._4_4_,
                                             CONCAT13(auVar39[3] >> 1,(int3)auVar40._0_4_))))) ^
         0xedb88320edb88320;
    auVar22[9] = (byte)(auVar40._8_4_ >> 8) ^ 0x83;
    auVar22[10] = (byte)(auVar40._8_4_ >> 0x10) ^ 0xb8;
    auVar22[0xb] = auVar39[0xb] >> 1 ^ 0xed;
    auVar22[0xc] = (byte)auVar40._12_4_ ^ 0x20;
    auVar22[0xd] = (byte)(auVar40._12_4_ >> 8) ^ 0x83;
    auVar22[0xe] = (byte)(auVar40._12_4_ >> 0x10) ^ 0xb8;
    auVar22[0xf] = auVar39[0xf] >> 1 ^ 0xed;
    auVar9[4] = (char)iVar12;
    auVar9._0_4_ = -(uint)((auVar39 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    auVar9[5] = (char)((uint)iVar12 >> 8);
    auVar9[6] = (char)((uint)iVar12 >> 0x10);
    auVar9[7] = (char)((uint)iVar12 >> 0x18);
    auVar9[8] = (char)iVar13;
    auVar9[9] = (char)((uint)iVar13 >> 8);
    auVar9[10] = (char)((uint)iVar13 >> 0x10);
    auVar9[0xb] = (char)((uint)iVar13 >> 0x18);
    auVar9[0xc] = (char)iVar15;
    auVar9[0xd] = (char)((uint)iVar15 >> 8);
    auVar9[0xe] = (char)((uint)iVar15 >> 0x10);
    auVar9[0xf] = (char)((uint)iVar15 >> 0x18);
    auVar40 = auVar40 ^ (auVar40 ^ auVar22) & ~auVar9;
    auVar41._0_4_ = auVar40._0_4_ >> 1;
    auVar41._4_4_ = auVar40._4_4_ >> 1;
    auVar41._8_4_ = auVar40._8_4_ >> 1;
    auVar41._12_4_ = auVar40._12_4_ >> 1;
    iVar12 = -(uint)((auVar40 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    iVar13 = -(uint)((auVar40 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    iVar15 = -(uint)((auVar40 & (undefined1  [16])0x100000000) == (undefined1  [16])0x0);
    auVar23[8] = (byte)auVar41._8_4_ ^ 0x20;
    auVar23._0_8_ =
         CONCAT17(auVar40[7] >> 1,
                  CONCAT16((char)(auVar41._4_4_ >> 0x10),
                           CONCAT15((char)(auVar41._4_4_ >> 8),
                                    CONCAT14((char)auVar41._4_4_,
                                             CONCAT13(auVar40[3] >> 1,(int3)auVar41._0_4_))))) ^
         0xedb88320edb88320;
    auVar23[9] = (byte)(auVar41._8_4_ >> 8) ^ 0x83;
    auVar23[10] = (byte)(auVar41._8_4_ >> 0x10) ^ 0xb8;
    auVar23[0xb] = auVar40[0xb] >> 1 ^ 0xed;
    auVar23[0xc] = (byte)auVar41._12_4_ ^ 0x20;
    auVar23[0xd] = (byte)(auVar41._12_4_ >> 8) ^ 0x83;
    auVar23[0xe] = (byte)(auVar41._12_4_ >> 0x10) ^ 0xb8;
    auVar23[0xf] = auVar40[0xf] >> 1 ^ 0xed;
    auVar10[4] = (char)iVar12;
    auVar10._0_4_ = -(uint)((auVar40 & (undefined1  [16])0x1) == (undefined1  [16])0x0);
    auVar10[5] = (char)((uint)iVar12 >> 8);
    auVar10[6] = (char)((uint)iVar12 >> 0x10);
    auVar10[7] = (char)((uint)iVar12 >> 0x18);
    auVar10[8] = (char)iVar13;
    auVar10[9] = (char)((uint)iVar13 >> 8);
    auVar10[10] = (char)((uint)iVar13 >> 0x10);
    auVar10[0xb] = (char)((uint)iVar13 >> 0x18);
    auVar10[0xc] = (char)iVar15;
    auVar10[0xd] = (char)((uint)iVar15 >> 8);
    auVar10[0xe] = (char)((uint)iVar15 >> 0x10);
    auVar10[0xf] = (char)((uint)iVar15 >> 0x18);
    auVar41 = auVar41 ^ (auVar41 ^ auVar23) & ~auVar10;
    *(long *)(lVar26 + 0x98d058) = auVar41._8_8_;
    *(long *)((long)&DAT_0098d050 + lVar26) = auVar41._0_8_;
    lVar26 = lVar26 + 0x10;
  } while (lVar26 != 0x400);
  lVar26 = 0;
  do {
    lVar1 = lVar26 + 4;
    *(uint *)((long)&DAT_0098d450 + lVar26) =
         (&DAT_0098d050)[(ulong)*(uint *)((long)&DAT_0098d050 + lVar26) & 0xff] ^
         *(uint *)((long)&DAT_0098d050 + lVar26) >> 8;
    lVar26 = lVar1;
  } while (lVar1 != 0x400);
  lVar26 = 0;
  do {
    lVar1 = lVar26 + 4;
    *(uint *)((long)&DAT_0098d850 + lVar26) =
         (&DAT_0098d050)[(ulong)*(uint *)((long)&DAT_0098d450 + lVar26) & 0xff] ^
         *(uint *)((long)&DAT_0098d450 + lVar26) >> 8;
    lVar26 = lVar1;
  } while (lVar1 != 0x400);
  lVar26 = 0;
  do {
    lVar1 = lVar26 + 4;
    *(uint *)((long)&DAT_0098dc50 + lVar26) =
         (&DAT_0098d050)[(ulong)*(uint *)((long)&DAT_0098d850 + lVar26) & 0xff] ^
         *(uint *)((long)&DAT_0098d850 + lVar26) >> 8;
    lVar26 = lVar1;
  } while (lVar1 != 0x400);
  lVar26 = 0;
  do {
    lVar1 = lVar26 + 4;
    *(uint *)((long)&DAT_0098e050 + lVar26) =
         (&DAT_0098d050)[(ulong)*(uint *)((long)&DAT_0098dc50 + lVar26) & 0xff] ^
         *(uint *)((long)&DAT_0098dc50 + lVar26) >> 8;
    lVar26 = lVar1;
  } while (lVar1 != 0x400);
  lVar26 = 0;
  do {
    lVar1 = lVar26 + 4;
    *(uint *)((long)&DAT_0098e450 + lVar26) =
         (&DAT_0098d050)[(ulong)*(uint *)((long)&DAT_0098e050 + lVar26) & 0xff] ^
         *(uint *)((long)&DAT_0098e050 + lVar26) >> 8;
    lVar26 = lVar1;
  } while (lVar1 != 0x400);
  lVar26 = -0x400;
  do {
    lVar1 = lVar26 + 4;
    *(uint *)((long)&DAT_0098ec50 + lVar26) =
         (&DAT_0098d050)[(ulong)*(uint *)((long)&DAT_0098e850 + lVar26) & 0xff] ^
         *(uint *)((long)&DAT_0098e850 + lVar26) >> 8;
    lVar26 = lVar1;
  } while (lVar1 != 0);
  lVar26 = -0x400;
  do {
    lVar1 = lVar26 + 4;
    *(uint *)(&DAT_0098f050 + lVar26) =
         (&DAT_0098d050)[(ulong)*(uint *)((long)&DAT_0098ec50 + lVar26) & 0xff] ^
         *(uint *)((long)&DAT_0098ec50 + lVar26) >> 8;
    lVar26 = lVar1;
  } while (lVar1 != 0);
  return;
}



// ========================================
// Function: FUN_00527fe4
// Address: 00527fe4
// ========================================

/* WARNING: Removing unreachable block (ram,0x005286ec) */

void FUN_00527fe4(long param_1,ulong param_2,byte *param_3,undefined8 param_4)

{
  bool bVar1;
  short *psVar2;
  byte bVar3;
  short sVar4;
  ulong uVar5;
  long lVar6;
  long lVar7;
  bool bVar8;
  int iVar9;
  int iVar10;
  undefined8 uVar11;
  char *pcVar12;
  ulong uVar13;
  long lVar14;
  uint uVar15;
  ulong uVar16;
  uint uVar17;
  int iVar18;
  ulong uVar19;
  ulong uVar20;
  uint uVar21;
  ushort uVar22;
  uint uVar23;
  uint uVar24;
  int iVar25;
  ulong uVar26;
  ulong uVar27;
  ulong uVar28;
  uint uVar29;
  long local_17f0;
  ulong local_17e8;
  ulong local_17e0;
  undefined5 uStack_17d8;
  uint3 local_17d3;
  uint uStack_17d0;
  char cStack_17cc;
  byte *local_17c8;
  ulong local_17c0;
  ulong local_17b8;
  short local_17ac;
  short local_17aa;
  short local_d4c [16];
  ushort auStack_d2c [288];
  ushort auStack_aec [1024];
  ushort local_2ec [256];
  short local_ec;
  long local_70;
  
  lVar6 = tpidr_el0;
  local_70 = *(long *)(lVar6 + 0x28);
  bVar3 = *param_3;
  local_17e0 = 0;
  uStack_17d8 = 0;
  local_17d3 = 0;
  uStack_17d0 = 0;
  cStack_17cc = '\0';
  local_17b8 = 0;
  local_17c0 = (ulong)(bVar3 >> 1);
  if ((bVar3 & 1) != 0) {
    local_17c0 = *(ulong *)(param_3 + 8);
  }
  local_17f0 = param_1;
  local_17e8 = param_2;
  if (local_17c0 == 0) {
    local_17c8 = (byte *)0x0;
  }
  else {
    local_17c8 = *(byte **)(param_3 + 0x10);
    if ((bVar3 & 1) == 0) {
      local_17c8 = param_3 + 1;
    }
  }
LAB_00528080:
  uVar26 = CONCAT35(local_17d3,uStack_17d8);
  if ((int)uStack_17d0 < 1) {
    uVar13 = local_17e0;
    if (local_17e0 <= local_17e8) {
      uVar13 = local_17e8;
    }
    do {
      uVar16 = (ulong)uStack_17d0;
      if (uVar13 == local_17e0) {
        if ((int)uStack_17d0 < 1) {
          uVar29 = 0;
          cStack_17cc = '\x01';
          uVar13 = uVar26;
          goto LAB_005280b4;
        }
        break;
      }
      uVar27 = local_17e0 + 1;
      uVar29 = uStack_17d0 + 8;
      uVar26 = (ulong)*(byte *)(local_17f0 + local_17e0) << (uVar16 & 0x3f) | uVar26;
      uStack_17d8 = (undefined5)uVar26;
      local_17d3 = (uint3)(uVar26 >> 0x28);
      bVar1 = (int)uStack_17d0 < 0x31;
      uStack_17d0 = uVar29;
      local_17e0 = uVar27;
    } while (bVar1);
  }
  uVar29 = (uint)uVar26 & 1;
  uVar13 = uVar26 >> 1;
  uStack_17d0 = uStack_17d0 - 1;
  uVar16 = (ulong)uStack_17d0;
  uStack_17d8 = (undefined5)uVar13;
  local_17d3 = (uint3)(uVar26 >> 0x29);
  uVar24 = uStack_17d0;
  if (uStack_17d0 < 2) {
LAB_005280b4:
    uVar26 = local_17e0;
    if (local_17e0 <= local_17e8) {
      uVar26 = local_17e8;
    }
    do {
      uVar21 = (uint)uVar16;
      if (uVar26 == local_17e0) {
        uVar24 = uVar21;
        if ((int)uVar21 < 2) {
          cStack_17cc = '\x01';
          goto LAB_00528b40;
        }
        break;
      }
      uVar27 = local_17e0 + 1;
      uVar13 = (ulong)*(byte *)(local_17f0 + local_17e0) << (uVar16 & 0x3f) | uVar13;
      uVar24 = uVar21 + 8;
      uVar16 = (ulong)uVar24;
      uStack_17d8 = (undefined5)uVar13;
      local_17d3 = (uint3)(uVar13 >> 0x28);
      local_17e0 = uVar27;
      uStack_17d0 = uVar24;
    } while ((int)uVar21 < 0x31);
  }
  uVar26 = uVar13 >> 2;
  uVar21 = uVar24 - 2;
  uStack_17d8 = (undefined5)uVar26;
  local_17d3 = (uint3)(uVar13 >> 0x2a);
  uStack_17d0 = uVar21;
  if (cStack_17cc == '\0') {
    uVar17 = (uint)uVar13 & 3;
    if (uVar17 == 2) {
      if (uVar21 < 5) {
        lVar14 = 0;
        uVar13 = local_17e0;
        if (local_17e0 <= local_17e8) {
          uVar13 = local_17e8;
        }
        do {
          if (uVar13 == local_17e0) {
            uVar16 = lVar14 + (ulong)uVar21;
            uVar21 = (uint)uVar16;
            if (4 < (int)uVar21) goto LAB_005282f8;
            bVar1 = true;
            uVar17 = 0;
            uVar24 = 0x101;
            cStack_17cc = '\x01';
            uVar27 = uVar26;
            goto LAB_00528324;
          }
          uVar16 = local_17e0 + 1;
          uVar27 = (ulong)uVar21 + lVar14;
          iVar10 = (int)lVar14;
          lVar14 = lVar14 + 8;
          uVar26 = (ulong)*(byte *)(local_17f0 + local_17e0) << (uVar27 & 0x3f) | uVar26;
          uStack_17d8 = (undefined5)uVar26;
          local_17d3 = (uint3)(uVar26 >> 0x28);
          local_17e0 = uVar16;
          uStack_17d0 = uVar24 + iVar10 + 6;
        } while ((int)((uVar24 - 10) + (int)lVar14) < 0x31);
        uVar21 = uVar21 + (int)lVar14;
      }
LAB_005282f8:
      uVar17 = (uint)uVar26 & 0x1f;
      uVar27 = uVar26 >> 5;
      uStack_17d0 = uVar21 - 5;
      uVar16 = (ulong)uStack_17d0;
      uVar24 = uVar17 + 0x101;
      uStack_17d8 = (undefined5)uVar27;
      local_17d3 = (uint3)(uVar26 >> 0x2d);
      if (uStack_17d0 < 5) {
        bVar1 = false;
        uVar13 = local_17e0;
LAB_00528324:
        uVar26 = uVar13;
        if (uVar13 <= local_17e8) {
          uVar26 = local_17e8;
        }
        uVar16 = uVar16 & 0xffffffff;
        do {
          uVar23 = (uint)uVar16;
          if (uVar26 == uVar13) {
            uVar21 = uVar23;
            if ((int)uVar23 < 5) {
              bVar1 = true;
              uVar15 = 0;
              cStack_17cc = '\x01';
              uVar26 = uVar27;
              goto joined_r0x0052838c;
            }
            break;
          }
          local_17e0 = uVar13 + 1;
          uVar21 = uVar23 + 8;
          uVar5 = uVar16 & 0x3f;
          uVar16 = (ulong)uVar21;
          uVar27 = (ulong)*(byte *)(local_17f0 + uVar13) << uVar5 | uVar27;
          uStack_17d8 = (undefined5)uVar27;
          local_17d3 = (uint3)(uVar27 >> 0x28);
          uVar13 = local_17e0;
          uStack_17d0 = uVar21;
        } while ((int)uVar23 < 0x31);
      }
      else {
        bVar1 = false;
        uVar21 = uStack_17d0;
      }
      uVar15 = (uint)uVar27 & 0x1f;
      uVar26 = uVar27 >> 5;
      uVar23 = uVar21 - 5;
      uVar16 = (ulong)uVar23;
      uStack_17d8 = (undefined5)uVar26;
      local_17d3 = (uint3)(uVar27 >> 0x2d);
      uStack_17d0 = uVar23;
joined_r0x0052838c:
      if ((int)uVar23 < 4) {
        uVar13 = local_17e0;
        if (local_17e0 <= local_17e8) {
          uVar13 = local_17e8;
        }
        do {
          uVar21 = (uint)uVar16;
          if (uVar13 == local_17e0) {
            uVar23 = uVar21;
            if ((int)uVar21 < 4) {
              bVar1 = true;
              uVar13 = 0;
              cStack_17cc = '\x01';
              goto LAB_00528434;
            }
            break;
          }
          uVar27 = local_17e0 + 1;
          uVar26 = (ulong)*(byte *)(local_17f0 + local_17e0) << (uVar16 & 0x3f) | uVar26;
          uVar23 = uVar21 + 8;
          uVar16 = (ulong)uVar23;
          uStack_17d8 = (undefined5)uVar26;
          local_17d3 = (uint3)(uVar26 >> 0x28);
          local_17e0 = uVar27;
          uStack_17d0 = uVar23;
        } while ((int)uVar21 < 0x31);
      }
      uVar13 = uVar26 & 0xf;
      uStack_17d0 = uVar23 - 4;
      uVar16 = (ulong)uStack_17d0;
      uStack_17d8 = (undefined5)(uVar26 >> 4);
      local_17d3 = (uint3)(uVar26 >> 0x2c);
      uVar26 = uVar26 >> 4;
LAB_00528434:
      if ((uVar17 < 0x1e) && (uVar15 < 0x1e)) {
        iVar10 = uVar15 + 1;
        memset(local_2ec,0,0x27c);
        uVar5 = local_17e8;
        lVar7 = local_17f0;
        lVar14 = 0;
        uVar20 = local_17e0;
        uVar27 = local_17e0;
        do {
          uVar21 = (uint)uVar16;
          if ((int)uVar21 < 3) {
            uVar19 = uVar20;
            if (uVar20 <= local_17e8) {
              uVar19 = local_17e8;
            }
            if (uVar20 < local_17e8) {
              do {
                uVar27 = uVar20 + 1;
                iVar9 = (int)uVar16;
                uVar28 = uVar16 & 0x3f;
                uVar21 = iVar9 + 8;
                uVar16 = (ulong)uVar21;
                uVar26 = (ulong)*(byte *)(local_17f0 + uVar20) << uVar28 | uVar26;
                uStack_17d8 = (undefined5)uVar26;
                local_17d3 = (uint3)(uVar26 >> 0x28);
                uVar20 = uVar27;
                local_17e0 = uVar27;
                if (0x30 < iVar9) goto LAB_00528488;
                uStack_17d0 = uVar21;
              } while (uVar19 != uVar27);
            }
            uVar21 = (uint)uVar16;
            uVar20 = uVar19;
            if (2 < (int)uVar21) goto LAB_00528488;
            bVar1 = true;
            uVar22 = 0;
            cStack_17cc = '\x01';
            uVar28 = uVar26;
          }
          else {
LAB_00528488:
            uVar19 = uVar20;
            uVar22 = (ushort)uVar26 & 7;
            uVar28 = uVar26 >> 3;
            uStack_17d0 = uVar21 - 3;
            uVar16 = (ulong)uStack_17d0;
            uStack_17d8 = (undefined5)uVar28;
            local_17d3 = (uint3)(uVar26 >> 0x2b);
          }
          psVar2 = &DAT_001c7e68 + lVar14;
          bVar8 = lVar14 != uVar13 + 3;
          lVar14 = lVar14 + 1;
          local_2ec[*psVar2] = uVar22;
          uVar20 = uVar19;
          uVar26 = uVar28;
        } while (bVar8);
        if ((uint)(uVar13 + 3) < 0x12) {
          do {
            lVar14 = uVar13 * 2;
            uVar26 = uVar13 + 4;
            uVar13 = uVar13 + 1;
            local_2ec[*(short *)(&DAT_001c7e70 + lVar14)] = 0;
          } while (uVar26 < 0x12);
        }
        memset(local_d4c,0,0xa60);
        iVar9 = FUN_0052af28(local_d4c,local_2ec,0x13);
        if (iVar9 == 0) {
          uVar26 = 0;
LAB_0052858c:
          if ((int)uVar16 < 0xf) {
            uVar20 = uVar27;
            uVar13 = uVar27;
            if (uVar27 <= uVar5) {
              uVar13 = uVar5;
            }
            do {
              uVar27 = uVar13;
              if (uVar13 == uVar20) break;
              uVar27 = uVar20 + 1;
              iVar9 = (int)uVar16;
              uVar28 = (ulong)*(byte *)(lVar7 + uVar20) << (uVar16 & 0x3f) | uVar28;
              uStack_17d0 = iVar9 + 8;
              uVar16 = (ulong)uStack_17d0;
              uStack_17d8 = (undefined5)uVar28;
              local_17d3 = (uint3)(uVar28 >> 0x28);
              uVar20 = uVar27;
              local_17e0 = uVar27;
            } while (iVar9 < 0x31);
          }
          uVar21 = auStack_aec[uVar28 & 0x3ff] & 0xf;
          if ((auStack_aec[uVar28 & 0x3ff] & 0xf) == 0 || (int)uVar16 < (int)uVar21) {
            iVar9 = 0;
            iVar25 = 0;
            uVar21 = 0;
            lVar14 = 1;
            uVar13 = uVar27;
            do {
              uVar17 = (uint)uVar16;
              if ((int)uVar17 < 1) {
                uVar20 = uVar13;
                if (uVar13 <= uVar5) {
                  uVar20 = uVar5;
                }
                if (uVar13 < uVar5) {
                  do {
                    uVar27 = uVar13 + 1;
                    iVar18 = (int)uVar16;
                    uVar19 = uVar16 & 0x3f;
                    uVar17 = iVar18 + 8;
                    uVar16 = (ulong)uVar17;
                    uVar28 = (ulong)*(byte *)(lVar7 + uVar13) << uVar19 | uVar28;
                    uStack_17d8 = (undefined5)uVar28;
                    local_17d3 = (uint3)(uVar28 >> 0x28);
                    uVar13 = uVar27;
                    local_17e0 = uVar27;
                    if (0x30 < iVar18) goto LAB_0052868c;
                    uStack_17d0 = uVar17;
                  } while (uVar20 != uVar27);
                }
                uVar17 = (uint)uVar16;
                uVar13 = uVar20;
                if (0 < (int)uVar17) goto LAB_0052868c;
                bVar1 = true;
                uVar23 = 0;
                cStack_17cc = '\x01';
              }
              else {
LAB_0052868c:
                uVar20 = uVar13;
                uVar23 = (uint)uVar28 & 1;
                uStack_17d0 = uVar17 - 1;
                uVar16 = (ulong)uStack_17d0;
                uStack_17d8 = (undefined5)(uVar28 >> 1);
                local_17d3 = (uint3)(uVar28 >> 0x29);
                uVar28 = uVar28 >> 1;
              }
              sVar4 = local_d4c[lVar14];
              uVar23 = uVar23 | uVar21;
              pcVar12 = "bad code-length code";
              if ((int)(uVar23 - (int)sVar4) < iVar25) goto LAB_005286f0;
              lVar14 = lVar14 + 1;
              uVar21 = uVar23 << 1;
              iVar25 = (iVar25 + sVar4) * 2;
              iVar9 = iVar9 + sVar4;
              uVar13 = uVar20;
              if (lVar14 == 0x10) goto LAB_00528b70;
            } while( true );
          }
          uVar28 = uVar28 >> uVar21;
          uVar22 = 0;
          uStack_17d0 = (int)uVar16 - uVar21;
          uVar16 = (ulong)uStack_17d0;
          uStack_17d8 = (undefined5)uVar28;
          local_17d3 = (uint3)(uVar28 >> 0x28);
          goto LAB_00528704;
        }
        pcVar12 = "incomplete code-length code";
      }
      else {
        pcVar12 = "bad dynamic block counts";
      }
      goto LAB_00528b70;
    }
    if (uVar17 == 1) {
      if (((DAT_00990520 & 1) == 0) && (iVar10 = FUN_0058bb00(&DAT_00990520), iVar10 != 0)) {
        FUN_0052ab34();
        DAT_00990518 = 1;
        FUN_0058bc30(&DAT_00990520);
      }
      uVar26 = FUN_0052ac10(&local_17f0,&DAT_0098f058,&DAT_0098fab8,param_4);
      goto joined_r0x00528a8c;
    }
    if ((uVar13 & 3) == 0) {
      uStack_17d0 = 0;
      uVar26 = local_17e0 - (uVar21 >> 3);
      local_17e0 = uVar26 + 4;
      uStack_17d8 = 0;
      local_17d3 = 0;
      if (local_17e8 < local_17e0) {
        pcVar12 = "truncated stored block";
        local_17e0 = uVar26;
      }
      else {
        uVar22 = *(ushort *)(local_17f0 + uVar26);
        uVar13 = (ulong)uVar22;
        if ((((ushort *)(local_17f0 + uVar26))[1] ^ uVar22) == 0xffff) {
          if ((local_17e0 + uVar13 <= local_17e8) && (local_17b8 + uVar13 <= local_17c0)) {
            memcpy(local_17c8 + local_17b8,(void *)(local_17f0 + local_17e0),uVar13);
            local_17e0 = local_17e0 + uVar13;
            local_17b8 = local_17b8 + uVar13;
            goto LAB_00528248;
          }
          pcVar12 = "stored block runs past the data";
        }
        else {
          pcVar12 = "stored block length check failed";
        }
      }
    }
    else {
      pcVar12 = "bad block type";
    }
  }
  else {
LAB_00528b40:
    pcVar12 = "compressed data ends early";
  }
  goto LAB_00528b48;
LAB_005286f0:
  uVar22 = auStack_d2c[(int)((iVar9 - iVar25) + uVar23)];
  if ((short)uVar22 < 0) goto LAB_00528b70;
LAB_00528704:
  uVar21 = (uint)uVar16;
  pcVar12 = "bad code-length code";
  if (bVar1) goto LAB_00528b70;
  iVar9 = (int)uVar26;
  if (uVar22 < 0x10) {
    bVar1 = false;
    local_2ec[iVar9] = uVar22;
    uVar26 = (ulong)(iVar9 + 1);
    goto LAB_005289d0;
  }
  if (uVar22 == 0x11) {
    uVar26 = uVar27;
    if ((int)uVar21 < 3) {
      uVar13 = uVar27;
      if (uVar27 <= uVar5) {
        uVar13 = uVar5;
      }
      do {
        uVar17 = (uint)uVar16;
        if (uVar13 == uVar27) {
          uVar26 = uVar13;
          uVar21 = uVar17;
          if ((int)uVar17 < 3) {
            bVar1 = true;
            uVar17 = 0;
            cStack_17cc = '\x01';
            uVar27 = uVar13;
            goto LAB_005288a8;
          }
          break;
        }
        uVar26 = uVar27 + 1;
        uVar28 = (ulong)*(byte *)(lVar7 + uVar27) << (uVar16 & 0x3f) | uVar28;
        uVar21 = uVar17 + 8;
        uVar16 = (ulong)uVar21;
        uStack_17d8 = (undefined5)uVar28;
        local_17d3 = (uint3)(uVar28 >> 0x28);
        uVar27 = uVar26;
        local_17e0 = uVar26;
        uStack_17d0 = uVar21;
      } while ((int)uVar17 < 0x31);
    }
    uVar17 = (uint)uVar28 & 7;
    bVar1 = false;
    uStack_17d0 = uVar21 - 3;
    uVar16 = (ulong)uStack_17d0;
    uStack_17d8 = (undefined5)(uVar28 >> 3);
    local_17d3 = (uint3)(uVar28 >> 0x2b);
    uVar27 = uVar26;
    uVar28 = uVar28 >> 3;
LAB_005288a8:
    uVar17 = uVar17 + 3;
LAB_005288e0:
    uVar22 = 0;
  }
  else {
    if (uVar22 != 0x10) {
      uVar26 = uVar27;
      if ((int)uVar21 < 7) {
        uVar13 = uVar27;
        if (uVar27 <= uVar5) {
          uVar13 = uVar5;
        }
        do {
          uVar17 = (uint)uVar16;
          if (uVar13 == uVar27) {
            uVar26 = uVar13;
            uVar21 = uVar17;
            if ((int)uVar17 < 7) {
              bVar1 = true;
              uVar17 = 0;
              cStack_17cc = '\x01';
              goto LAB_005288d8;
            }
            break;
          }
          uVar26 = uVar27 + 1;
          uVar28 = (ulong)*(byte *)(lVar7 + uVar27) << (uVar16 & 0x3f) | uVar28;
          uVar21 = uVar17 + 8;
          uVar16 = (ulong)uVar21;
          uStack_17d8 = (undefined5)uVar28;
          local_17d3 = (uint3)(uVar28 >> 0x28);
          uVar27 = uVar26;
          local_17e0 = uVar26;
          uStack_17d0 = uVar21;
        } while ((int)uVar17 < 0x31);
      }
      uVar17 = (uint)uVar28 & 0x7f;
      bVar1 = false;
      uStack_17d0 = uVar21 - 7;
      uVar16 = (ulong)uStack_17d0;
      uStack_17d8 = (undefined5)(uVar28 >> 7);
      local_17d3 = (uint3)(uVar28 >> 0x2f);
      uVar13 = uVar26;
      uVar28 = uVar28 >> 7;
LAB_005288d8:
      uVar17 = uVar17 + 0xb;
      uVar27 = uVar13;
      goto LAB_005288e0;
    }
    if (iVar9 == 0) {
      pcVar12 = "repeat with no previous length";
      goto LAB_00528b70;
    }
    uVar26 = uVar27;
    if ((int)uVar21 < 2) {
      uVar13 = uVar27;
      if (uVar27 <= uVar5) {
        uVar13 = uVar5;
      }
      do {
        uVar17 = (uint)uVar16;
        if (uVar13 == uVar27) {
          uVar26 = uVar13;
          uVar21 = uVar17;
          if ((int)uVar17 < 2) {
            bVar1 = true;
            uVar17 = 0;
            cStack_17cc = '\x01';
            uVar27 = uVar13;
            goto LAB_00528910;
          }
          break;
        }
        uVar26 = uVar27 + 1;
        uVar21 = uVar17 + 8;
        uVar20 = uVar16 & 0x3f;
        uVar16 = (ulong)uVar21;
        uVar28 = (ulong)*(byte *)(lVar7 + uVar27) << uVar20 | uVar28;
        uStack_17d8 = (undefined5)uVar28;
        local_17d3 = (uint3)(uVar28 >> 0x28);
        uVar27 = uVar26;
        local_17e0 = uVar26;
        uStack_17d0 = uVar21;
      } while ((int)uVar17 < 0x31);
    }
    uVar17 = (uint)uVar28 & 3;
    bVar1 = false;
    uStack_17d0 = uVar21 - 2;
    uVar16 = (ulong)uStack_17d0;
    uStack_17d8 = (undefined5)(uVar28 >> 2);
    local_17d3 = (uint3)(uVar28 >> 0x2a);
    uVar27 = uVar26;
    uVar28 = uVar28 >> 2;
LAB_00528910:
    uVar17 = uVar17 + 3;
    uVar22 = local_2ec[(long)iVar9 + -1];
  }
  if ((int)(iVar10 + uVar24) < (int)(uVar17 + iVar9)) {
    pcVar12 = "too many code lengths";
    goto LAB_00528b70;
  }
  uVar26 = (ulong)iVar9;
  if (0xf < uVar17) {
    uVar13 = (ulong)uVar17 & 0xf0;
    *(ulong *)(local_2ec + uVar26 + 4) = CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
    *(ulong *)(local_2ec + uVar26) = CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
    *(ulong *)(local_2ec + uVar26 + 0xc) = CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)))
    ;
    *(ulong *)(local_2ec + uVar26 + 8) = CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
    if (uVar13 != 0x10) {
      *(ulong *)(local_2ec + uVar26 + 0x14) =
           CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
      *(ulong *)(local_2ec + uVar26 + 0x10) =
           CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
      *(ulong *)(local_2ec + uVar26 + 0x1c) =
           CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
      *(ulong *)(local_2ec + uVar26 + 0x18) =
           CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
      if (uVar13 != 0x20) {
        *(ulong *)(local_2ec + uVar26 + 0x24) =
             CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
        *(ulong *)(local_2ec + uVar26 + 0x20) =
             CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
        *(ulong *)(local_2ec + uVar26 + 0x2c) =
             CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
        *(ulong *)(local_2ec + uVar26 + 0x28) =
             CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
        if (uVar13 != 0x30) {
          *(ulong *)(local_2ec + uVar26 + 0x34) =
               CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
          *(ulong *)(local_2ec + uVar26 + 0x30) =
               CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
          *(ulong *)(local_2ec + uVar26 + 0x3c) =
               CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
          *(ulong *)(local_2ec + uVar26 + 0x38) =
               CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
          if (uVar13 != 0x40) {
            *(ulong *)(local_2ec + uVar26 + 0x44) =
                 CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
            *(ulong *)(local_2ec + uVar26 + 0x40) =
                 CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
            *(ulong *)(local_2ec + uVar26 + 0x4c) =
                 CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
            *(ulong *)(local_2ec + uVar26 + 0x48) =
                 CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
            if (uVar13 != 0x50) {
              *(ulong *)(local_2ec + uVar26 + 0x54) =
                   CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
              *(ulong *)(local_2ec + uVar26 + 0x50) =
                   CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
              *(ulong *)(local_2ec + uVar26 + 0x5c) =
                   CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
              *(ulong *)(local_2ec + uVar26 + 0x58) =
                   CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
              if (uVar13 != 0x60) {
                *(ulong *)(local_2ec + uVar26 + 100) =
                     CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
                *(ulong *)(local_2ec + uVar26 + 0x60) =
                     CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
                *(ulong *)(local_2ec + uVar26 + 0x6c) =
                     CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
                *(ulong *)(local_2ec + uVar26 + 0x68) =
                     CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
                if (uVar13 != 0x70) {
                  *(ulong *)(local_2ec + uVar26 + 0x74) =
                       CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
                  *(ulong *)(local_2ec + uVar26 + 0x70) =
                       CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
                  *(ulong *)(local_2ec + uVar26 + 0x7c) =
                       CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
                  *(ulong *)(local_2ec + uVar26 + 0x78) =
                       CONCAT26(uVar22,CONCAT24(uVar22,CONCAT22(uVar22,uVar22)));
                }
              }
            }
          }
        }
      }
    }
    uVar26 = uVar13 + uVar26;
    if (uVar13 == uVar17) goto LAB_005289d0;
    uVar17 = uVar17 - (int)uVar13;
  }
  uVar17 = uVar17 + 1;
  uVar13 = uVar26;
  do {
    uVar17 = uVar17 - 1;
    uVar26 = uVar13 + 1;
    local_2ec[uVar13] = uVar22;
    uVar13 = uVar26;
  } while (1 < uVar17);
LAB_005289d0:
  if ((int)(iVar10 + uVar24) <= (int)uVar26) goto code_r0x005289e0;
  goto LAB_0052858c;
code_r0x005289e0:
  if (local_ec == 0) {
    pcVar12 = "no end-of-block code";
  }
  else {
    iVar9 = FUN_0052af28(local_d4c,local_2ec);
    pcVar12 = "bad literal/length code lengths";
    if ((-1 < iVar9) && ((iVar9 == 0 || (uVar24 == (int)local_d4c[1] + (int)local_d4c[0])))) {
      memset(&local_17ac,0,0xa60);
      iVar9 = FUN_0052af28(&local_17ac,local_2ec + uVar24,iVar10);
      if ((-1 < iVar9) && ((iVar9 == 0 || (iVar10 == (int)local_17aa + (int)local_17ac)))) {
        uVar26 = FUN_0052ac10(&local_17f0,local_d4c,&local_17ac,param_4);
joined_r0x00528a8c:
        if ((uVar26 & 1) == 0) goto LAB_00528b78;
LAB_00528248:
        if (uVar29 != 0) {
          if (local_17b8 == local_17c0) {
            uVar11 = 1;
          }
          else {
            pcVar12 = "less data than the zip says";
LAB_00528b48:
            FUN_00561ab4(param_4,pcVar12);
LAB_00528b78:
            uVar11 = 0;
          }
          if (*(long *)(lVar6 + 0x28) == local_70) {
            return;
          }
                    /* WARNING: Subroutine does not return */
          __stack_chk_fail(uVar11);
        }
        goto LAB_00528080;
      }
      pcVar12 = "bad distance code lengths";
    }
  }
LAB_00528b70:
  FUN_00561ab4(param_4,pcVar12);
  goto LAB_00528b78;
}



// ========================================
// Function: FUN_00528bc4
// Address: 00528bc4
// ========================================

uint FUN_00528bc4(undefined8 param_1,byte *param_2,undefined8 param_3)

{
  undefined *puVar1;
  undefined8 uVar2;
  long lVar3;
  undefined *puVar4;
  undefined *puVar5;
  uint uVar6;
  ulong uVar7;
  long *plVar8;
  byte *pbVar9;
  long lVar10;
  byte *pbVar11;
  byte *pbVar12;
  byte *pbVar13;
  undefined8 local_1d0;
  undefined8 uStack_1c8;
  long local_1c0;
  undefined *local_1b8 [2];
  undefined1 auStack_1a8 [120];
  undefined8 uStack_130;
  undefined4 auStack_128 [10];
  undefined *local_100 [19];
  long local_68;
  
  lVar3 = tpidr_el0;
  local_68 = *(long *)(lVar3 + 0x28);
  if ((*param_2 & 1) != 0) {
    free(*(void **)(param_2 + 0x10));
  }
  param_2[0] = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[5] = 0;
  param_2[6] = 0;
  param_2[7] = 0;
  param_2[8] = 0;
  param_2[9] = 0;
  param_2[10] = 0;
  param_2[0xb] = 0;
  param_2[0xc] = 0;
  param_2[0xd] = 0;
  param_2[0xe] = 0;
  param_2[0xf] = 0;
  pbVar11 = param_2 + 0x18;
  pbVar12 = *(byte **)pbVar11;
  param_2[0x10] = 0;
  param_2[0x11] = 0;
  param_2[0x12] = 0;
  param_2[0x13] = 0;
  param_2[0x14] = 0;
  param_2[0x15] = 0;
  param_2[0x16] = 0;
  param_2[0x17] = 0;
  if (pbVar12 != (byte *)0x0) {
    pbVar9 = *(byte **)(param_2 + 0x20);
    pbVar13 = pbVar12;
    if (pbVar9 != pbVar12) {
      do {
        pbVar13 = pbVar9 + -0x38;
        if ((*pbVar13 & 1) != 0) {
          free(*(void **)(pbVar9 + -0x28));
        }
        pbVar9 = pbVar13;
      } while (pbVar13 != pbVar12);
      pbVar13 = *(byte **)pbVar11;
    }
    *(byte **)(param_2 + 0x20) = pbVar12;
    free(pbVar13);
    pbVar11[0] = 0;
    pbVar11[1] = 0;
    pbVar11[2] = 0;
    pbVar11[3] = 0;
    pbVar11[4] = 0;
    pbVar11[5] = 0;
    pbVar11[6] = 0;
    pbVar11[7] = 0;
    param_2[0x20] = 0;
    param_2[0x21] = 0;
    param_2[0x22] = 0;
    param_2[0x23] = 0;
    param_2[0x24] = 0;
    param_2[0x25] = 0;
    param_2[0x26] = 0;
    param_2[0x27] = 0;
    param_2[0x28] = 0;
    param_2[0x29] = 0;
    param_2[0x2a] = 0;
    param_2[0x2b] = 0;
    param_2[0x2c] = 0;
    param_2[0x2d] = 0;
    param_2[0x2e] = 0;
    param_2[0x2f] = 0;
  }
  pbVar11[0] = 0;
  pbVar11[1] = 0;
  pbVar11[2] = 0;
  pbVar11[3] = 0;
  pbVar11[4] = 0;
  pbVar11[5] = 0;
  pbVar11[6] = 0;
  pbVar11[7] = 0;
  param_2[0x20] = 0;
  param_2[0x21] = 0;
  param_2[0x22] = 0;
  param_2[0x23] = 0;
  param_2[0x24] = 0;
  param_2[0x25] = 0;
  param_2[0x26] = 0;
  param_2[0x27] = 0;
  pbVar11 = param_2 + 0x30;
  param_2[0x28] = 0;
  param_2[0x29] = 0;
  param_2[0x2a] = 0;
  param_2[0x2b] = 0;
  param_2[0x2c] = 0;
  param_2[0x2d] = 0;
  param_2[0x2e] = 0;
  param_2[0x2f] = 0;
  if ((*pbVar11 & 1) != 0) {
    free(*(void **)(param_2 + 0x40));
  }
  puVar5 = PTR_DAT_005c6318;
  puVar4 = PTR_PTR_005c62e8;
  local_1b8[0] = *(undefined **)(PTR_PTR_005c62e8 + 8);
  uVar2 = *(undefined8 *)(PTR_PTR_005c62e8 + 0x10);
  puVar1 = PTR_DAT_005c6318 + 0x40;
  param_2[0x38] = 0;
  param_2[0x39] = 0;
  param_2[0x3a] = 0;
  param_2[0x3b] = 0;
  param_2[0x3c] = 0;
  param_2[0x3d] = 0;
  param_2[0x3e] = 0;
  param_2[0x3f] = 0;
  pbVar11[0] = 0;
  pbVar11[1] = 0;
  pbVar11[2] = 0;
  pbVar11[3] = 0;
  pbVar11[4] = 0;
  pbVar11[5] = 0;
  pbVar11[6] = 0;
  pbVar11[7] = 0;
  param_2[0x48] = 0;
  param_2[0x49] = 0;
  param_2[0x4a] = 0;
  param_2[0x4b] = 0;
  param_2[0x4c] = 0;
  param_2[0x4d] = 0;
  param_2[0x4e] = 0;
  param_2[0x4f] = 0;
  param_2[0x40] = 0;
  param_2[0x41] = 0;
  param_2[0x42] = 0;
  param_2[0x43] = 0;
  param_2[0x44] = 0;
  param_2[0x45] = 0;
  param_2[0x46] = 0;
  param_2[0x47] = 0;
  local_1b8[1] = (undefined *)0x0;
  local_100[0] = puVar1;
  *(undefined8 *)((long)local_1b8 + *(long *)(local_1b8[0] + -0x18)) = uVar2;
  lVar10 = *(long *)(local_1b8[0] + -0x18);
                    /* try { // try from 00528ccc to 00528cd7 has its CatchHandler @ 00528e3c */
  FUN_005646a8((long)local_1b8 + lVar10,auStack_1a8);
  local_1b8[0] = puVar5 + 0x18;
  *(undefined8 *)((long)&uStack_130 + lVar10) = 0;
  *(undefined4 *)((long)auStack_128 + lVar10) = 0xffffffff;
                    /* try { // try from 00528cf0 to 00528cf7 has its CatchHandler @ 00528e28 */
  local_100[0] = puVar1;
  FUN_005663a0(auStack_1a8);
  local_1c0 = 0;
                    /* try { // try from 00528cfc to 00528d77 has its CatchHandler @ 00528e4c */
  uVar7 = FUN_00528e74(param_1,local_1b8,&local_1c0,param_3);
  lVar10 = local_1c0;
  if ((uVar7 & 1) != 0) {
    FUN_00561fb8(param_2,local_1c0,0);
    if (lVar10 != 0) {
      pbVar11 = param_2 + 1;
      if ((*param_2 & 1) != 0) {
        pbVar11 = *(byte **)(param_2 + 0x10);
      }
      plVar8 = (long *)FUN_005651d8(local_1b8,pbVar11,lVar10);
      if ((*(byte *)((long)plVar8 + *(long *)(*plVar8 + -0x18) + 0x20) & 5) != 0) {
        FUN_00561ab4(param_3,"cannot read the zip");
        goto LAB_00528db8;
      }
    }
    local_1d0 = 0;
    uStack_1c8 = 0;
                    /* try { // try from 00528d80 to 00528daf has its CatchHandler @ 00528e24 */
    uVar7 = FUN_00529108(param_2,0,&local_1d0,param_3);
    if ((uVar7 & 1) != 0) {
      uVar6 = FUN_00529258(param_2,0,&local_1d0,param_2,param_3);
      goto LAB_00528dbc;
    }
  }
LAB_00528db8:
  uVar6 = 0;
LAB_00528dbc:
  local_1b8[0] = *(undefined **)puVar4;
  *(undefined8 *)((long)local_1b8 + *(long *)(local_1b8[0] + -0x18)) =
       *(undefined8 *)(puVar4 + 0x18);
  FUN_005664d8(auStack_1a8);
  FUN_00564acc(local_1b8,puVar4 + 8);
  thunk_FUN_00564510(local_100);
  if (*(long *)(lVar3 + 0x28) != local_68) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar6 & 1;
}



// ========================================
// Function: FUN_00528e74
// Address: 00528e74
// ========================================

void FUN_00528e74(byte *param_1,long *param_2,ulong *param_3,byte *param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  byte bVar3;
  byte bVar4;
  long lVar5;
  bool bVar6;
  ulong uVar7;
  ulong *puVar8;
  byte *pbVar9;
  undefined8 uVar10;
  char *pcVar11;
  undefined8 uVar12;
  byte local_98 [16];
  void *local_88;
  ulong local_80;
  ulong uStack_78;
  void *local_70;
  int local_68 [2];
  undefined8 local_60;
  undefined6 local_58;
  undefined2 uStack_52;
  undefined6 uStack_50;
  long local_48;
  
  lVar5 = tpidr_el0;
  local_48 = *(long *)(lVar5 + 0x28);
  local_68[0] = 0;
  local_60 = FUN_00563970();
  bVar6 = (*param_1 & 1) != 0;
  local_80 = 0;
  uStack_78 = 0;
  pbVar9 = param_1 + 4;
  if (bVar6) {
    pbVar9 = *(byte **)(param_1 + 0x10);
  }
  local_70 = (void *)0x0;
  uVar7 = (ulong)(*param_1 >> 1);
  if (bVar6) {
    uVar7 = *(ulong *)(param_1 + 8);
  }
                    /* try { // try from 00528edc to 00528ee3 has its CatchHandler @ 005290d8 */
  FUN_002e72b4(&local_80,pbVar9,pbVar9 + uVar7 * 4);
                    /* try { // try from 00528ee4 to 00528eef has its CatchHandler @ 005290d4 */
  uVar7 = FUN_0058b3ac(&local_80,local_68);
  *param_3 = uVar7;
  if ((local_80 & 1) != 0) {
    free(local_70);
  }
  if (local_68[0] == 0) {
    if (*param_3 < 0x4000001) {
      local_80 = 0;
      uStack_78 = 0;
      local_70 = (void *)0x0;
      uVar7 = (ulong)(*param_1 >> 1);
      pbVar9 = param_1 + 4;
      if ((*param_1 & 1) != 0) {
        uVar7 = *(ulong *)(param_1 + 8);
        pbVar9 = *(byte **)(param_1 + 0x10);
      }
                    /* try { // try from 00529004 to 0052900f has its CatchHandler @ 005290a4 */
      FUN_002e72b4(&local_80,pbVar9,pbVar9 + uVar7 * 4);
      pvVar1 = (void *)((ulong)&local_80 | 1);
      if ((local_80 & 1) != 0) {
        pvVar1 = local_70;
      }
                    /* try { // try from 00529024 to 0052902f has its CatchHandler @ 005290a0 */
      FUN_0056622c(param_2,pvVar1,4);
      if ((local_80 & 1) != 0) {
        free(local_70);
      }
      if ((*(byte *)((long)param_2 + *(long *)(*param_2 + -0x18) + 0x20) & 5) == 0) {
        uVar10 = 1;
        goto LAB_00529070;
      }
      pcVar11 = "cannot open the zip";
    }
    else {
      pcVar11 = "zip larger than 64 MB";
    }
    FUN_00561ab4(param_4,pcVar11);
  }
  else {
    FUN_005639d0(local_98,local_68);
                    /* try { // try from 00528f18 to 00528f2b has its CatchHandler @ 005290c0 */
    puVar8 = (ulong *)FUN_005612e0(local_98,0,"cannot read the zip (");
    local_70 = (void *)puVar8[2];
    uStack_78 = puVar8[1];
    local_80 = *puVar8;
    puVar8[1] = 0;
    puVar8[2] = 0;
    *puVar8 = 0;
                    /* try { // try from 00528f44 to 00528f53 has its CatchHandler @ 005290a8 */
    pbVar9 = (byte *)FUN_00561dc8(&local_80,&DAT_00157c5d);
    bVar3 = *pbVar9;
    uVar10 = *(undefined8 *)(pbVar9 + 8);
    uVar2 = *(undefined8 *)(pbVar9 + 0x10);
    bVar4 = pbVar9[1];
    uVar12 = *(undefined8 *)(pbVar9 + 2);
    pbVar9[8] = 0;
    pbVar9[9] = 0;
    pbVar9[10] = 0;
    pbVar9[0xb] = 0;
    pbVar9[0xc] = 0;
    pbVar9[0xd] = 0;
    pbVar9[0xe] = 0;
    pbVar9[0xf] = 0;
    pbVar9[0x10] = 0;
    pbVar9[0x11] = 0;
    pbVar9[0x12] = 0;
    pbVar9[0x13] = 0;
    pbVar9[0x14] = 0;
    pbVar9[0x15] = 0;
    pbVar9[0x16] = 0;
    pbVar9[0x17] = 0;
    pbVar9[0] = 0;
    pbVar9[1] = 0;
    pbVar9[2] = 0;
    pbVar9[3] = 0;
    pbVar9[4] = 0;
    pbVar9[5] = 0;
    pbVar9[6] = 0;
    pbVar9[7] = 0;
    local_58 = (undefined6)uVar12;
    uStack_52 = (undefined2)uVar10;
    uStack_50 = (undefined6)((ulong)uVar10 >> 0x10);
    if ((*param_4 & 1) != 0) {
      free(*(void **)(param_4 + 0x10));
    }
    *param_4 = bVar3;
    param_4[1] = bVar4;
    *(ulong *)(param_4 + 2) = CONCAT26(uStack_52,local_58);
    *(ulong *)(param_4 + 8) = CONCAT62(uStack_50,uStack_52);
    *(undefined8 *)(param_4 + 0x10) = uVar2;
    if ((local_80 & 1) != 0) {
      free(local_70);
    }
    if ((local_98[0] & 1) != 0) {
      free(local_88);
    }
  }
  uVar10 = 0;
LAB_00529070:
  if (*(long *)(lVar5 + 0x28) != local_48) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail(uVar10);
  }
  return;
}



// ========================================
// Function: FUN_00529108
// Address: 00529108
// ========================================

undefined8 FUN_00529108(byte *param_1,long param_2,long *param_3,undefined8 param_4)

{
  ulong uVar1;
  ulong uVar2;
  byte *pbVar3;
  uint uVar4;
  byte bVar5;
  ushort uVar6;
  char *pcVar7;
  ulong uVar8;
  byte *pbVar9;
  
  bVar5 = *param_1;
  uVar1 = (ulong)(bVar5 >> 1);
  if ((bVar5 & 1) != 0) {
    uVar1 = *(ulong *)(param_1 + 8);
  }
  if (uVar1 < 0x16) {
    pcVar7 = "not a zip file";
  }
  else {
    pbVar9 = *(byte **)(param_1 + 0x10);
    uVar2 = 0;
    if (0x10014 < uVar1) {
      uVar2 = uVar1 - 0x10015;
    }
    if ((bVar5 & 1) == 0) {
      pbVar9 = param_1 + 1;
    }
    do {
      uVar8 = uVar1;
      if (uVar8 - 0x15 <= uVar2) {
        pcVar7 = "not a zip file (no end record)";
        goto LAB_005291f8;
      }
      uVar1 = uVar8 - 1;
    } while (*(int *)(pbVar9 + (uVar8 - 0x16)) != 0x6054b50);
    if ((*(uint *)(pbVar9 + (uVar8 - 10)) != 0xffffffff) &&
       (uVar6 = *(ushort *)(pbVar9 + (uVar8 - 0xc)), uVar6 != 0xffff)) {
      uVar4 = *(uint *)(pbVar9 + (uVar8 - 6));
      if (uVar4 != 0xffffffff) {
        pbVar3 = param_1 + 1;
        if ((bVar5 & 1) != 0) {
          pbVar3 = *(byte **)(param_1 + 0x10);
        }
        if ((*(short *)(pbVar3 + (uVar8 - 0x10)) == 0 && pbVar3[uVar8 - 0x12] == 0) &&
            pbVar3[uVar8 - 0x11] == 0) {
          if (uVar6 < 0x1001) {
            if ((ulong)uVar4 + (ulong)*(uint *)(pbVar9 + (uVar8 - 10)) <=
                (param_2 + (uVar8 - 1)) - 0x15) {
              *(uint *)(param_3 + 1) = (uint)uVar6;
              *(uint *)((long)param_3 + 0xc) = uVar4;
              *param_3 = uVar8 - 0x16;
              return 1;
            }
            pcVar7 = "zip central directory is damaged";
          }
          else {
            pcVar7 = "zip has too many entries";
          }
        }
        else {
          pcVar7 = "split zip archives are not supported";
        }
        goto LAB_005291f8;
      }
    }
    pcVar7 = "ZIP64 archives are not supported";
  }
LAB_005291f8:
  FUN_00561ab4(param_4,pcVar7);
  return 0;
}



// ========================================
// Function: FUN_00529258
// Address: 00529258
// ========================================

/* WARNING: Type propagation algorithm not settling */

int FUN_00529258(byte *param_1,long param_2,ulong *param_3,long param_4,undefined8 param_5)

{
  byte *pbVar1;
  ulong uVar2;
  ulong uVar3;
  byte *pbVar4;
  ulong *puVar5;
  byte bVar6;
  ushort uVar7;
  ushort uVar8;
  long lVar9;
  ulong uVar10;
  bool bVar11;
  char *pcVar12;
  ulong *puVar13;
  ulong uVar14;
  ulong uVar15;
  long lVar16;
  ulong uVar17;
  char *pcVar18;
  char *pcVar19;
  ulong uVar20;
  int iVar21;
  uint uVar22;
  undefined8 uVar23;
  undefined8 uVar24;
  ulong local_d8;
  ulong uStack_d0;
  char *local_c8;
  ulong local_c0;
  ulong uStack_b8;
  char *local_b0;
  ulong uStack_a8;
  undefined4 local_a0;
  int iStack_9c;
  int iStack_98;
  int iStack_94;
  undefined1 uStack_90;
  long local_80;
  
  lVar9 = tpidr_el0;
  local_80 = *(long *)(lVar9 + 0x28);
  if ((int)param_3[1] == 0) {
    iVar21 = 1;
  }
  else {
    uVar17 = *param_3;
    param_2 = (ulong)*(uint *)((long)param_3 + 0xc) - param_2;
    pbVar1 = param_1 + 1;
    uVar22 = 0;
    while (uVar2 = param_2 + 0x2e, uVar2 <= uVar17) {
      bVar6 = *param_1;
      pbVar4 = pbVar1;
      if ((bVar6 & 1) != 0) {
        pbVar4 = *(byte **)(param_1 + 0x10);
      }
      if (*(int *)(pbVar4 + param_2) != 0x2014b50) break;
      bVar11 = (bVar6 & 1) != 0;
      uStack_90 = 0;
      pbVar4 = pbVar1;
      if (bVar11) {
        pbVar4 = *(byte **)(param_1 + 0x10);
      }
      pcVar12 = "zip central directory is damaged";
      local_b0 = (char *)0x0;
      uStack_b8 = 0;
      local_c0 = 0;
      uStack_a8 = (ulong)CONCAT24(*(undefined2 *)(pbVar4 + param_2 + 8),
                                  (uint)*(ushort *)(pbVar4 + param_2 + 10));
      local_a0 = *(undefined4 *)(pbVar4 + param_2 + 0x10);
      iStack_9c = *(int *)(pbVar4 + param_2 + 0x14);
      pbVar4 = pbVar1;
      if (bVar11) {
        pbVar4 = *(byte **)(param_1 + 0x10);
      }
      iStack_98 = *(int *)(pbVar4 + param_2 + 0x18);
      uVar20 = (ulong)*(ushort *)(pbVar4 + param_2 + 0x1c);
      uVar7 = *(ushort *)(pbVar4 + param_2 + 0x1e);
      uVar8 = *(ushort *)(pbVar4 + param_2 + 0x20);
      iStack_94 = *(int *)(pbVar4 + param_2 + 0x2a);
      if (uVar17 < uVar7 + uVar20 + uVar2 + uVar8) {
LAB_00529394:
                    /* try { // try from 00529394 to 0052939b has its CatchHandler @ 00529898 */
        FUN_00561ab4(param_5,pcVar12);
        iVar21 = 0;
      }
      else {
        if ((iStack_9c == -1) || (iStack_98 == -1)) {
          pcVar12 = "ZIP64 archives are not supported";
          goto LAB_00529394;
        }
        pcVar12 = "ZIP64 archives are not supported";
        if (iStack_94 == -1) goto LAB_00529394;
        uVar3 = (ulong)(bVar6 >> 1);
        if ((bVar6 & 1) != 0) {
          uVar3 = *(ulong *)(param_1 + 8);
        }
        if (uVar3 < uVar2) {
          if (*(long *)(lVar9 + 0x28) == local_80) {
                    /* try { // try from 0052987c to 00529883 has its CatchHandler @ 00529894 */
                    /* WARNING: Subroutine does not return */
            FUN_002d64d0(&local_d8,"ZIP64 archives are not supported");
          }
          goto LAB_005298c8;
        }
        pbVar4 = pbVar1;
        if ((bVar6 & 1) != 0) {
          pbVar4 = *(byte **)(param_1 + 0x10);
        }
        uVar14 = uVar3 - uVar2;
        if (uVar20 <= uVar3 - uVar2) {
          uVar14 = uVar20;
        }
        if (uVar14 < 0x17) {
          local_d8 = CONCAT71(local_d8._1_7_,(char)((int)uVar14 << 1));
          pcVar12 = (char *)((ulong)&local_d8 | 1);
          if (uVar14 != 0) goto LAB_00529468;
        }
        else {
          uVar3 = (uVar14 | 0xf) + 1;
                    /* try { // try from 0052944c to 00529453 has its CatchHandler @ 00529890 */
          pcVar12 = (char *)FUN_005a5d4c(uVar3);
          local_d8 = uVar3 | 1;
          uStack_d0 = uVar14;
          local_c8 = pcVar12;
LAB_00529468:
          memmove(pcVar12,pbVar4 + uVar2,uVar14);
        }
        pcVar12[uVar14] = '\0';
        if ((local_c0 & 1) != 0) {
          free(local_b0);
        }
        uStack_b8 = uStack_d0;
        local_c0 = local_d8;
        uVar10 = local_c0;
        local_c0._0_1_ = (byte)local_d8;
        local_b0 = local_c8;
        uVar14 = (ulong)((byte)local_c0 >> 1);
        uVar3 = uVar14;
        pcVar12 = (char *)((ulong)&local_c0 | 1);
        if ((local_d8 & 1) != 0) {
          uVar3 = uStack_d0;
          pcVar12 = local_c8;
        }
        if (uVar3 != 0) {
          pcVar18 = pcVar12;
          if (uVar3 < 8) {
LAB_005297f0:
            do {
              if (*pcVar18 == '\\') {
                *pcVar18 = '/';
              }
              pcVar18 = pcVar18 + 1;
            } while (pcVar18 != pcVar12 + uVar3);
          }
          else if (uVar3 < 0x10) {
            uVar15 = 0;
LAB_005294d8:
            uVar14 = uVar3 & 0xfffffffffffffff8;
            pcVar18 = pcVar12 + uVar14;
            lVar16 = uVar15 - uVar14;
            pcVar19 = pcVar12 + uVar15 + 3;
            do {
              uVar23 = *(undefined8 *)(pcVar19 + -3);
              if ((char)uVar23 == '\\') {
                pcVar19[-3] = '/';
              }
              if ((char)((ulong)uVar23 >> 8) == '\\') {
                pcVar19[-2] = '/';
              }
              if ((char)((ulong)uVar23 >> 0x10) == '\\') {
                pcVar19[-1] = '/';
              }
              if ((char)((ulong)uVar23 >> 0x18) == '\\') {
                *pcVar19 = '/';
              }
              if ((char)((ulong)uVar23 >> 0x20) == '\\') {
                pcVar19[1] = '/';
              }
              if ((char)((ulong)uVar23 >> 0x28) == '\\') {
                pcVar19[2] = '/';
              }
              if ((char)((ulong)uVar23 >> 0x30) == '\\') {
                pcVar19[3] = '/';
              }
              if ((char)((ulong)uVar23 >> 0x38) == '\\') {
                pcVar19[4] = '/';
              }
              lVar16 = lVar16 + 8;
              pcVar19 = pcVar19 + 8;
            } while (lVar16 != 0);
            if (uVar3 != uVar14) goto LAB_005297f0;
          }
          else {
            uVar15 = uVar3 & 0xfffffffffffffff0;
            pcVar18 = pcVar12 + 7;
            uVar14 = uVar15;
            do {
              uVar24 = *(undefined8 *)(pcVar18 + 1);
              uVar23 = *(undefined8 *)(pcVar18 + -7);
              if ((char)uVar23 == '\\') {
                pcVar18[-7] = '/';
              }
              if ((char)((ulong)uVar23 >> 8) == '\\') {
                pcVar18[-6] = '/';
              }
              if ((char)((ulong)uVar23 >> 0x10) == '\\') {
                pcVar18[-5] = '/';
              }
              if ((char)((ulong)uVar23 >> 0x18) == '\\') {
                pcVar18[-4] = '/';
              }
              if ((char)((ulong)uVar23 >> 0x20) == '\\') {
                pcVar18[-3] = '/';
              }
              if ((char)((ulong)uVar23 >> 0x28) == '\\') {
                pcVar18[-2] = '/';
              }
              if ((char)((ulong)uVar23 >> 0x30) == '\\') {
                pcVar18[-1] = '/';
              }
              if ((char)((ulong)uVar23 >> 0x38) == '\\') {
                *pcVar18 = '/';
              }
              if ((char)uVar24 == '\\') {
                pcVar18[1] = '/';
              }
              if ((char)((ulong)uVar24 >> 8) == '\\') {
                pcVar18[2] = '/';
              }
              if ((char)((ulong)uVar24 >> 0x10) == '\\') {
                pcVar18[3] = '/';
              }
              if ((char)((ulong)uVar24 >> 0x18) == '\\') {
                pcVar18[4] = '/';
              }
              if ((char)((ulong)uVar24 >> 0x20) == '\\') {
                pcVar18[5] = '/';
              }
              if ((char)((ulong)uVar24 >> 0x28) == '\\') {
                pcVar18[6] = '/';
              }
              if ((char)((ulong)uVar24 >> 0x30) == '\\') {
                pcVar18[7] = '/';
              }
              if ((char)((ulong)uVar24 >> 0x38) == '\\') {
                pcVar18[8] = '/';
              }
              uVar14 = uVar14 - 0x10;
              pcVar18 = pcVar18 + 0x10;
            } while (uVar14 != 0);
            if (uVar3 != uVar15) {
              if (((uint)uVar3 >> 3 & 1) == 0) {
                pcVar18 = pcVar12 + uVar15;
                goto LAB_005297f0;
              }
              goto LAB_005294d8;
            }
          }
          uVar14 = (ulong)((byte)local_c0 >> 1);
        }
        if ((local_d8 & 1) != 0) {
          uVar14 = uStack_d0;
        }
        if (uVar14 != 0) {
          pcVar12 = (char *)((ulong)&local_c0 | 1);
          if ((local_d8 & 1) != 0) {
            pcVar12 = local_c8;
          }
          uVar14 = (ulong)(pcVar12[uVar14 - 1] == '/');
        }
        puVar5 = *(ulong **)(param_4 + 0x20);
        uStack_90 = (undefined1)uVar14;
        local_c0 = uVar10;
        if (puVar5 < *(ulong **)(param_4 + 0x28)) {
          if ((local_d8 & 1) == 0) {
            puVar5[2] = (ulong)local_c8;
            puVar5[1] = uStack_d0;
            *puVar5 = local_d8;
          }
          else {
                    /* try { // try from 0052979c to 005297a3 has its CatchHandler @ 00529884 */
            FUN_00251fc8(puVar5,local_c8);
          }
          puVar13 = puVar5 + 7;
          *(ulong *)((long)puVar5 + 0x29) = CONCAT17(uStack_90,CONCAT43(iStack_94,iStack_98._1_3_));
          *(ulong *)((long)puVar5 + 0x21) =
               CONCAT17((undefined1)iStack_98,CONCAT43(iStack_9c,local_a0._1_3_));
          puVar5[4] = CONCAT44(iStack_9c,local_a0);
          puVar5[3] = uStack_a8;
          *(ulong **)(param_4 + 0x20) = puVar13;
        }
        else {
                    /* try { // try from 00529788 to 00529793 has its CatchHandler @ 00529898 */
          puVar13 = (ulong *)FUN_0052b4b8(param_4 + 0x18,&local_c0);
        }
        iVar21 = 1;
        *(ulong **)(param_4 + 0x20) = puVar13;
        param_2 = uVar2 + uVar20 + (ulong)uVar7 + (ulong)uVar8;
      }
      if ((local_c0 & 1) != 0) {
        free(local_b0);
      }
      if ((iVar21 == 0) || (uVar22 = uVar22 + 1, (uint)param_3[1] <= uVar22)) goto LAB_00529834;
    }
    FUN_00561ab4(param_5,"zip central directory is damaged");
    iVar21 = 0;
  }
LAB_00529834:
  if (*(long *)(lVar9 + 0x28) == local_80) {
    return iVar21;
  }
LAB_005298c8:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_005298cc
// Address: 005298cc
// ========================================

undefined4 FUN_005298cc(undefined8 param_1,byte *param_2,undefined8 param_3)

{
  undefined *puVar1;
  void *pvVar2;
  undefined8 uVar3;
  long lVar4;
  undefined *puVar5;
  undefined *puVar6;
  ulong uVar7;
  long *plVar8;
  ulong uVar9;
  byte *pbVar10;
  long lVar11;
  undefined4 uVar12;
  byte *pbVar13;
  byte *pbVar14;
  byte *pbVar15;
  void *pvVar16;
  ulong uVar17;
  long local_1f0;
  ulong uStack_1e8;
  ulong local_1e0;
  ulong local_1d8;
  void *local_1d0;
  ulong local_1c8;
  undefined *local_1c0 [2];
  undefined1 auStack_1b0 [120];
  undefined8 uStack_138;
  undefined4 auStack_130 [10];
  undefined *local_108 [19];
  long local_70;
  
  lVar4 = tpidr_el0;
  local_70 = *(long *)(lVar4 + 0x28);
  if ((*param_2 & 1) != 0) {
    free(*(void **)(param_2 + 0x10));
  }
  param_2[0] = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[5] = 0;
  param_2[6] = 0;
  param_2[7] = 0;
  param_2[8] = 0;
  param_2[9] = 0;
  param_2[10] = 0;
  param_2[0xb] = 0;
  param_2[0xc] = 0;
  param_2[0xd] = 0;
  param_2[0xe] = 0;
  param_2[0xf] = 0;
  pbVar13 = param_2 + 0x18;
  pbVar14 = *(byte **)pbVar13;
  param_2[0x10] = 0;
  param_2[0x11] = 0;
  param_2[0x12] = 0;
  param_2[0x13] = 0;
  param_2[0x14] = 0;
  param_2[0x15] = 0;
  param_2[0x16] = 0;
  param_2[0x17] = 0;
  if (pbVar14 != (byte *)0x0) {
    pbVar10 = *(byte **)(param_2 + 0x20);
    pbVar15 = pbVar14;
    if (pbVar10 != pbVar14) {
      do {
        pbVar15 = pbVar10 + -0x38;
        if ((*pbVar15 & 1) != 0) {
          free(*(void **)(pbVar10 + -0x28));
        }
        pbVar10 = pbVar15;
      } while (pbVar15 != pbVar14);
      pbVar15 = *(byte **)pbVar13;
    }
    *(byte **)(param_2 + 0x20) = pbVar14;
    free(pbVar15);
    pbVar13[0] = 0;
    pbVar13[1] = 0;
    pbVar13[2] = 0;
    pbVar13[3] = 0;
    pbVar13[4] = 0;
    pbVar13[5] = 0;
    pbVar13[6] = 0;
    pbVar13[7] = 0;
    param_2[0x20] = 0;
    param_2[0x21] = 0;
    param_2[0x22] = 0;
    param_2[0x23] = 0;
    param_2[0x24] = 0;
    param_2[0x25] = 0;
    param_2[0x26] = 0;
    param_2[0x27] = 0;
    param_2[0x28] = 0;
    param_2[0x29] = 0;
    param_2[0x2a] = 0;
    param_2[0x2b] = 0;
    param_2[0x2c] = 0;
    param_2[0x2d] = 0;
    param_2[0x2e] = 0;
    param_2[0x2f] = 0;
  }
  pbVar13[0] = 0;
  pbVar13[1] = 0;
  pbVar13[2] = 0;
  pbVar13[3] = 0;
  pbVar13[4] = 0;
  pbVar13[5] = 0;
  pbVar13[6] = 0;
  pbVar13[7] = 0;
  param_2[0x20] = 0;
  param_2[0x21] = 0;
  param_2[0x22] = 0;
  param_2[0x23] = 0;
  param_2[0x24] = 0;
  param_2[0x25] = 0;
  param_2[0x26] = 0;
  param_2[0x27] = 0;
  pbVar13 = param_2 + 0x30;
  param_2[0x28] = 0;
  param_2[0x29] = 0;
  param_2[0x2a] = 0;
  param_2[0x2b] = 0;
  param_2[0x2c] = 0;
  param_2[0x2d] = 0;
  param_2[0x2e] = 0;
  param_2[0x2f] = 0;
  if ((*pbVar13 & 1) != 0) {
    free(*(void **)(param_2 + 0x40));
  }
  puVar6 = PTR_DAT_005c6318;
  puVar5 = PTR_PTR_005c62e8;
  local_1c0[0] = *(undefined **)(PTR_PTR_005c62e8 + 8);
  uVar3 = *(undefined8 *)(PTR_PTR_005c62e8 + 0x10);
  puVar1 = PTR_DAT_005c6318 + 0x40;
  param_2[0x38] = 0;
  param_2[0x39] = 0;
  param_2[0x3a] = 0;
  param_2[0x3b] = 0;
  param_2[0x3c] = 0;
  param_2[0x3d] = 0;
  param_2[0x3e] = 0;
  param_2[0x3f] = 0;
  pbVar13[0] = 0;
  pbVar13[1] = 0;
  pbVar13[2] = 0;
  pbVar13[3] = 0;
  pbVar13[4] = 0;
  pbVar13[5] = 0;
  pbVar13[6] = 0;
  pbVar13[7] = 0;
  param_2[0x48] = 0;
  param_2[0x49] = 0;
  param_2[0x4a] = 0;
  param_2[0x4b] = 0;
  param_2[0x4c] = 0;
  param_2[0x4d] = 0;
  param_2[0x4e] = 0;
  param_2[0x4f] = 0;
  param_2[0x40] = 0;
  param_2[0x41] = 0;
  param_2[0x42] = 0;
  param_2[0x43] = 0;
  param_2[0x44] = 0;
  param_2[0x45] = 0;
  param_2[0x46] = 0;
  param_2[0x47] = 0;
  local_1c0[1] = (undefined *)0x0;
  local_108[0] = puVar1;
  *(undefined8 *)((long)local_1c0 + *(long *)(local_1c0[0] + -0x18)) = uVar3;
  lVar11 = *(long *)(local_1c0[0] + -0x18);
                    /* try { // try from 005299d8 to 005299e3 has its CatchHandler @ 00529cdc */
  FUN_005646a8((long)local_1c0 + lVar11,auStack_1b0);
  local_1c0[0] = puVar6 + 0x18;
  *(undefined8 *)((long)&uStack_138 + lVar11) = 0;
  *(undefined4 *)((long)auStack_130 + lVar11) = 0xffffffff;
                    /* try { // try from 005299fc to 00529a03 has its CatchHandler @ 00529cc8 */
  local_108[0] = puVar1;
  FUN_005663a0(auStack_1b0);
  local_1c8 = 0;
                    /* try { // try from 00529a08 to 00529a1b has its CatchHandler @ 00529cc0 */
  uVar7 = FUN_00528e74(param_1,local_1c0,&local_1c8,param_3);
  uVar9 = local_1c8;
  if ((uVar7 & 1) == 0) {
    uVar12 = 0;
    goto LAB_00529c48;
  }
  uVar7 = local_1c8;
  if (0x10014 < local_1c8) {
    uVar7 = 0x10015;
  }
  if (local_1c8 < 0x17) {
    pvVar16 = (void *)((ulong)&local_1e0 | 1);
    local_1e0 = CONCAT71(local_1e0._1_7_,(char)((int)uVar7 << 1));
    if (local_1c8 != 0) goto LAB_00529a80;
  }
  else {
    uVar17 = (uVar7 | 0xf) + 1;
                    /* try { // try from 00529a68 to 00529a6f has its CatchHandler @ 00529cb4 */
    pvVar16 = (void *)FUN_005a5d4c(uVar17);
    local_1e0 = uVar17 | 1;
    local_1d8 = uVar7;
    local_1d0 = pvVar16;
LAB_00529a80:
    memset(pvVar16,0,uVar7);
  }
  *(undefined1 *)((long)pvVar16 + uVar7) = 0;
  pvVar16 = (void *)((ulong)&local_1e0 | 1);
  uVar17 = local_1e0 >> 1 & 0x7f;
  if ((local_1e0 & 1) != 0) {
    pvVar16 = local_1d0;
    uVar17 = local_1d8;
  }
  pvVar2 = (void *)0x0;
  if (uVar17 != 0) {
    pvVar2 = pvVar16;
  }
                    /* try { // try from 00529ac8 to 00529b27 has its CatchHandler @ 00529cec */
  FUN_005645c8((long)local_1c0 + *(long *)(local_1c0[0] + -0x18),0);
  uVar17 = uVar9 - uVar7;
  FUN_005652d0(local_1c0,0,uVar17);
  if ((uVar9 == 0) ||
     (plVar8 = (long *)FUN_005651d8(local_1c0,pvVar2,uVar7),
     (*(byte *)((long)plVar8 + *(long *)(*plVar8 + -0x18) + 0x20) & 5) == 0)) {
    local_1f0 = 0;
    uStack_1e8 = 0;
                    /* try { // try from 00529b30 to 00529b43 has its CatchHandler @ 00529cbc */
    uVar9 = FUN_00529108(&local_1e0,uVar17,&local_1f0,param_3);
    if ((uVar9 & 1) == 0) goto LAB_00529c34;
    uVar9 = uStack_1e8 >> 0x20;
    lVar11 = uVar17 - uVar9;
    if (uVar9 <= uVar17 && lVar11 != 0) {
                    /* try { // try from 00529b58 to 00529bdf has its CatchHandler @ 00529cb8 */
      FUN_00560b80(&local_1e0,0,lVar11,0);
      pvVar16 = (void *)((ulong)&local_1e0 | 1);
      if ((local_1e0 & 1) != 0) {
        pvVar16 = local_1d0;
      }
      FUN_005645c8((long)local_1c0 + *(long *)(local_1c0[0] + -0x18),0);
      FUN_005652d0(local_1c0,0,uVar9);
      plVar8 = (long *)FUN_005651d8(local_1c0,pvVar16,lVar11);
      if ((*(byte *)((long)plVar8 + *(long *)(*plVar8 + -0x18) + 0x20) & 5) != 0) {
        FUN_00561ab4(param_3,"cannot read the zip");
        goto LAB_00529c34;
      }
      local_1f0 = local_1f0 + lVar11;
      uVar17 = uVar9;
    }
                    /* try { // try from 00529bf4 to 00529c1b has its CatchHandler @ 00529cbc */
    uVar9 = FUN_00529258(&local_1e0,uVar17,&local_1f0,param_2,param_3);
    if ((uVar9 & 1) == 0) goto LAB_00529c34;
    FUN_005625e4(pbVar13,param_1);
    *(ulong *)(param_2 + 0x48) = local_1c8;
    uVar12 = 1;
  }
  else {
    FUN_00561ab4(param_3,"cannot read the zip");
LAB_00529c34:
    uVar12 = 0;
  }
  if ((local_1e0 & 1) != 0) {
    free(local_1d0);
  }
LAB_00529c48:
  local_1c0[0] = *(undefined **)puVar5;
  *(undefined8 *)((long)local_1c0 + *(long *)(local_1c0[0] + -0x18)) =
       *(undefined8 *)(puVar5 + 0x18);
  FUN_005664d8(auStack_1b0);
  FUN_00564acc(local_1c0,puVar5 + 8);
  thunk_FUN_00564510(local_108);
  if (*(long *)(lVar4 + 0x28) != local_70) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return uVar12;
}



// ========================================
// Function: FUN_00529d28
// Address: 00529d28
// ========================================

bool FUN_00529d28(long *param_1,undefined8 param_2,undefined8 param_3,long param_4)

{
  bool bVar1;
  long *plVar2;
  
  FUN_005645c8((long)param_1 + *(long *)(*param_1 + -0x18),0);
  FUN_005652d0(param_1,0,param_2);
  if (param_4 == 0) {
    bVar1 = true;
  }
  else {
    plVar2 = (long *)FUN_005651d8(param_1,param_3,param_4);
    bVar1 = (*(byte *)((long)plVar2 + *(long *)(*plVar2 + -0x18) + 0x20) & 5) == 0;
  }
  return bVar1;
}



// ========================================
// Function: FUN_00529db4
// Address: 00529db4
// ========================================

void FUN_00529db4(ulong *param_1,byte *param_2,byte *param_3,ulong *param_4)

{
  char *pcVar1;
  long lVar2;
  size_t sVar3;
  byte *pbVar4;
  undefined8 uVar5;
  int iVar6;
  byte bVar7;
  byte bVar8;
  long lVar9;
  bool bVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  undefined *puVar15;
  ulong *__ptr;
  ulong *puVar16;
  ulong uVar17;
  byte *pbVar18;
  undefined8 uVar19;
  void *pvVar20;
  ulong uVar21;
  ulong local_218;
  ulong local_210;
  byte *local_208;
  ulong local_200;
  ulong uStack_1f8;
  void *local_1f0;
  byte local_1e8;
  undefined5 uStack_1e7;
  undefined2 uStack_1e2;
  undefined6 local_1e0;
  undefined2 uStack_1da;
  void *local_1d8;
  undefined6 local_1d0;
  undefined2 uStack_1ca;
  undefined6 uStack_1c8;
  ulong local_1c0 [2];
  void *local_1b0 [2];
  byte abStack_1a0 [152];
  undefined1 auStack_108 [152];
  long local_70;
  
  lVar9 = tpidr_el0;
  local_70 = *(long *)(lVar9 + 0x28);
  puVar16 = param_1;
  if ((*param_3 & 1) == 0) {
    param_3[0] = 0;
    param_3[1] = 0;
    if ((param_2[0x1c] & 1) != 0) goto LAB_00529e00;
LAB_00529e58:
    if (0x4000000 < *(uint *)(param_2 + 0x28)) {
      bVar7 = *param_2;
      sVar3 = (ulong)(bVar7 >> 1);
      if ((bVar7 & 1) != 0) {
        sVar3 = *(size_t *)(param_2 + 8);
      }
      uVar17 = sVar3 + 0x1d;
      if (0xffffffffffffffef < uVar17) goto LAB_0052a990;
      if (uVar17 < 0x17) {
        local_1c0[1] = 0;
        local_1b0[0] = (void *)0x0;
        pvVar20 = (void *)((ulong)local_1c0 | 1);
        local_1c0[0] = (ulong)(byte)((int)uVar17 << 1);
LAB_0052a08c:
        pbVar18 = *(byte **)(param_2 + 0x10);
        if ((bVar7 & 1) == 0) {
          pbVar18 = param_2 + 1;
        }
        memmove(pvVar20,pbVar18,sVar3);
      }
      else {
        pvVar20 = (void *)FUN_005a5d4c((uVar17 | 0xf) + 1);
        local_1c0[0] = (uVar17 | 0xf) + 2;
        local_1c0[1] = uVar17;
        local_1b0[0] = pvVar20;
        if (sVar3 != 0) goto LAB_0052a08c;
      }
      uVar12 = s___zip_entry_larger_than_64_MB_0017cd9b._21_8_;
      uVar11 = s___zip_entry_larger_than_64_MB_0017cd9b._0_8_;
      pcVar1 = (char *)((long)pvVar20 + sVar3);
      uVar5 = CONCAT35(s___zip_entry_larger_than_64_MB_0017cd9b._13_3_,
                       s___zip_entry_larger_than_64_MB_0017cd9b._8_5_);
      uVar19 = CONCAT53(s___zip_entry_larger_than_64_MB_0017cd9b._16_5_,
                        s___zip_entry_larger_than_64_MB_0017cd9b._13_3_);
      pcVar1[0x1d] = '\0';
      *(undefined8 *)(pcVar1 + 8) = uVar5;
      *(undefined8 *)pcVar1 = uVar11;
      *(undefined8 *)(pcVar1 + 0x15) = uVar12;
      *(undefined8 *)(pcVar1 + 0xd) = uVar19;
      bVar7 = (byte)*param_4;
      goto joined_r0x0052a0c8;
    }
    bVar7 = (byte)param_1[6];
    uVar21 = (ulong)*(uint *)(param_2 + 0x2c);
    local_218 = 0;
    local_210 = 0;
    local_208 = (byte *)0x0;
    uVar17 = (ulong)(bVar7 >> 1);
    if ((bVar7 & 1) != 0) {
      uVar17 = param_1[7];
    }
    if (uVar17 == 0) {
      bVar7 = (byte)*param_1;
      uVar17 = (ulong)(bVar7 >> 1);
      if ((bVar7 & 1) != 0) {
        uVar17 = param_1[1];
      }
      if (uVar21 + 0x1e <= uVar17) {
        pbVar18 = (byte *)param_1[2];
        if ((bVar7 & 1) == 0) {
          pbVar18 = (byte *)((long)param_1 + 1);
        }
        if (*(int *)(pbVar18 + uVar21) != 0x4034b50) goto LAB_0052a278;
        lVar2 = (ulong)*(ushort *)(pbVar18 + uVar21 + 0x1a) + uVar21 + 0x1e +
                (ulong)*(ushort *)(pbVar18 + uVar21 + 0x1c);
        if (uVar17 < lVar2 + (ulong)*(uint *)(param_2 + 0x24)) {
          bVar7 = *param_2;
          sVar3 = (ulong)(bVar7 >> 1);
          if ((bVar7 & 1) != 0) {
            sVar3 = *(size_t *)(param_2 + 8);
          }
          uVar17 = sVar3 + 0x1d;
          if (0xffffffffffffffef < uVar17) goto LAB_0052a9c0;
          if (uVar17 < 0x17) {
            local_1c0[1] = 0;
            local_1b0[0] = (void *)0x0;
            pvVar20 = (void *)((ulong)local_1c0 | 1);
            local_1c0[0] = (ulong)(byte)((int)uVar17 << 1);
LAB_0052a93c:
            pbVar18 = *(byte **)(param_2 + 0x10);
            if ((bVar7 & 1) == 0) {
              pbVar18 = param_2 + 1;
            }
            memmove(pvVar20,pbVar18,sVar3);
          }
          else {
            uVar21 = (uVar17 | 0xf) + 1;
                    /* try { // try from 0052a920 to 0052a927 has its CatchHandler @ 0052aaec */
            pvVar20 = (void *)FUN_005a5d4c(uVar21);
            local_1c0[0] = uVar21 | 1;
            local_1c0[1] = uVar17;
            local_1b0[0] = pvVar20;
            if (sVar3 != 0) goto LAB_0052a93c;
          }
          uVar12 = s___zip_entry_runs_past_the_end_0016f277._21_8_;
          uVar11 = s___zip_entry_runs_past_the_end_0016f277._0_8_;
          pcVar1 = (char *)((long)pvVar20 + sVar3);
          uVar5 = CONCAT35(s___zip_entry_runs_past_the_end_0016f277._13_3_,
                           s___zip_entry_runs_past_the_end_0016f277._8_5_);
          uVar19 = CONCAT53(s___zip_entry_runs_past_the_end_0016f277._16_5_,
                            s___zip_entry_runs_past_the_end_0016f277._13_3_);
          pcVar1[0x1d] = '\0';
          *(undefined8 *)(pcVar1 + 8) = uVar5;
          *(undefined8 *)pcVar1 = uVar11;
          *(undefined8 *)(pcVar1 + 0x15) = uVar12;
          *(undefined8 *)(pcVar1 + 0xd) = uVar19;
          goto LAB_0052a31c;
        }
        pbVar18 = pbVar18 + lVar2;
        goto LAB_0052a244;
      }
LAB_0052a278:
      bVar7 = *param_2;
      sVar3 = (ulong)(bVar7 >> 1);
      if ((bVar7 & 1) != 0) {
        sVar3 = *(size_t *)(param_2 + 8);
      }
      uVar17 = sVar3 + 0x13;
      if (0xffffffffffffffef < uVar17) {
LAB_0052a9c0:
        puVar16 = local_1c0;
        if (*(long *)(lVar9 + 0x28) == local_70) {
                    /* WARNING: Subroutine does not return */
                    /* try { // try from 0052a9d4 to 0052a9d7 has its CatchHandler @ 0052aaec */
          FUN_002d18a8(puVar16);
        }
        goto LAB_0052ab30;
      }
      if (uVar17 < 0x17) {
        local_1c0[1] = 0;
        pvVar20 = (void *)((ulong)local_1c0 | 1);
        local_1b0[0] = (void *)0x0;
        local_1c0[0] = (ulong)(byte)((int)uVar17 << 1);
        if (sVar3 != 0) goto LAB_0052a2e0;
      }
      else {
        uVar21 = (uVar17 | 0xf) + 1;
        pvVar20 = (void *)FUN_005a5d4c(uVar21);
        local_1c0[0] = uVar21 | 1;
        local_1c0[1] = uVar17;
        local_1b0[0] = pvVar20;
LAB_0052a2e0:
        pbVar18 = *(byte **)(param_2 + 0x10);
        if ((bVar7 & 1) == 0) {
          pbVar18 = param_2 + 1;
        }
        memmove(pvVar20,pbVar18,sVar3);
      }
      uVar19 = s___damaged_zip_entry_0019363a._8_8_;
      uVar5 = s___damaged_zip_entry_0019363a._0_8_;
      pcVar1 = (char *)((long)pvVar20 + sVar3);
      pcVar1[0x13] = '\0';
      *(undefined8 *)(pcVar1 + 8) = uVar19;
      *(undefined8 *)pcVar1 = uVar5;
      pcVar1[0xf] = 'n';
      pcVar1[0x10] = 't';
      pcVar1[0x11] = 'r';
      pcVar1[0x12] = 'y';
LAB_0052a31c:
      if ((*param_4 & 1) != 0) {
        free((void *)param_4[2]);
      }
      puVar16 = (ulong *)0x0;
      param_4[1] = local_1c0[1];
      *param_4 = local_1c0[0];
      param_4[2] = (ulong)local_1b0[0];
    }
    else {
      local_200 = 0;
      uStack_1f8 = 0;
      pbVar18 = (byte *)((long)param_1 + 0x34);
      if ((bVar7 & 1) != 0) {
        pbVar18 = (byte *)param_1[8];
      }
      local_1f0 = (void *)0x0;
                    /* try { // try from 00529ef4 to 00529eff has its CatchHandler @ 0052aad4 */
      FUN_002e72b4(&local_200,pbVar18,pbVar18 + uVar17 * 4);
      pvVar20 = (void *)((ulong)&local_200 | 1);
      if ((local_200 & 1) != 0) {
        pvVar20 = local_1f0;
      }
                    /* try { // try from 00529f14 to 00529f1f has its CatchHandler @ 0052aad0 */
      FUN_002e31b4(local_1c0,pvVar20,4);
      if ((local_200 & 1) != 0) {
        free(local_1f0);
      }
                    /* try { // try from 00529f30 to 00529f37 has its CatchHandler @ 0052aac8 */
      __ptr = (ulong *)FUN_005a5d4c(0x20);
      uVar17 = param_1[9];
      *__ptr = 0;
      __ptr[1] = 0;
      pbVar18 = (byte *)((long)__ptr + 0x17);
      pbVar18[0] = 0;
      pbVar18[1] = 0;
      pbVar18[2] = 0;
      pbVar18[3] = 0;
      pbVar18[4] = 0;
      pbVar18[5] = 0;
      pbVar18[6] = 0;
      pbVar18[7] = 0;
      __ptr[2] = 0;
      puVar16 = __ptr;
      if ((uVar17 < uVar21 + 0x1e) ||
         (puVar16 = (ulong *)((long)local_1c0 + *(long *)(local_1c0[0] - 0x18)),
         (abStack_1a0[*(long *)(local_1c0[0] - 0x18)] & 5) != 0)) {
LAB_00529f78:
        bVar7 = *param_2;
        sVar3 = (ulong)(bVar7 >> 1);
        if ((bVar7 & 1) != 0) {
          sVar3 = *(size_t *)(param_2 + 8);
        }
        uVar17 = sVar3 + 0x13;
        if (0xffffffffffffffef < uVar17) {
          if (*(long *)(lVar9 + 0x28) == local_70) {
                    /* try { // try from 0052a9b8 to 0052a9bf has its CatchHandler @ 0052aaf4 */
                    /* WARNING: Subroutine does not return */
            FUN_002d18a8(&local_200);
          }
          goto LAB_0052ab30;
        }
        if (uVar17 < 0x17) {
          uStack_1f8 = 0;
          pvVar20 = (void *)((ulong)&local_200 | 1);
          local_1f0 = (void *)0x0;
          local_200 = (ulong)(byte)((int)uVar17 << 1);
          if (sVar3 != 0) goto LAB_0052a198;
        }
        else {
          uVar21 = (uVar17 | 0xf) + 1;
                    /* try { // try from 0052a180 to 0052a187 has its CatchHandler @ 0052aaf4 */
          pvVar20 = (void *)FUN_005a5d4c(uVar21);
          local_200 = uVar21 | 1;
          uStack_1f8 = uVar17;
          local_1f0 = pvVar20;
LAB_0052a198:
          pbVar18 = *(byte **)(param_2 + 0x10);
          if ((bVar7 & 1) == 0) {
            pbVar18 = param_2 + 1;
          }
          memmove(pvVar20,pbVar18,sVar3);
        }
        uVar19 = s___damaged_zip_entry_0019363a._8_8_;
        uVar5 = s___damaged_zip_entry_0019363a._0_8_;
        pcVar1 = (char *)((long)pvVar20 + sVar3);
        pcVar1[0x13] = '\0';
        *(undefined8 *)(pcVar1 + 8) = uVar19;
        *(undefined8 *)pcVar1 = uVar5;
        pcVar1[0xf] = 'n';
        pcVar1[0x10] = 't';
        pcVar1[0x11] = 'r';
        pcVar1[0x12] = 'y';
LAB_0052a1d4:
        if ((*param_4 & 1) != 0) {
          free((void *)param_4[2]);
        }
        bVar10 = false;
        param_4[1] = uStack_1f8;
        *param_4 = local_200;
        param_4[2] = (ulong)local_1f0;
        pbVar18 = (byte *)0x0;
      }
      else {
                    /* try { // try from 0052a3f4 to 0052a41b has its CatchHandler @ 0052aac4 */
        FUN_005645c8(puVar16,0);
        FUN_005652d0(local_1c0,0,uVar21);
        puVar16 = (ulong *)FUN_005651d8(local_1c0,__ptr,0x1e);
        if (((*(byte *)((long)puVar16 + *(long *)(*puVar16 - 0x18) + 0x20) & 5) != 0) ||
           ((int)*__ptr != 0x4034b50)) goto LAB_00529f78;
        lVar2 = (ulong)*(ushort *)((long)__ptr + 0x1a) + uVar21 + 0x1e +
                (ulong)*(ushort *)((long)__ptr + 0x1c);
        if (param_1[9] < lVar2 + (ulong)*(uint *)(param_2 + 0x24)) {
                    /* try { // try from 0052a470 to 0052a483 has its CatchHandler @ 0052aa3c */
          FUN_004a3088(&local_200,param_2,": zip entry runs past the end");
          goto LAB_0052a1d4;
        }
                    /* try { // try from 0052a8b8 to 0052a8fb has its CatchHandler @ 0052aa40 */
        FUN_00561fb8(&local_218,(ulong)*(uint *)(param_2 + 0x24),0);
        pbVar18 = (byte *)((ulong)&local_218 | 1);
        uVar17 = local_218 >> 1 & 0x7f;
        if ((local_218 & 1) != 0) {
          pbVar18 = local_208;
          uVar17 = local_210;
        }
        pbVar4 = (byte *)0x0;
        if (uVar17 != 0) {
          pbVar4 = pbVar18;
        }
        uVar17 = FUN_00529d28(local_1c0,lVar2,pbVar4,*(undefined4 *)(param_2 + 0x24));
        if ((uVar17 & 1) == 0) {
                    /* try { // try from 0052a978 to 0052a98b has its CatchHandler @ 0052aa38 */
          FUN_004a3088(&local_200,param_2,": zip entry runs past the end");
          goto LAB_0052a1d4;
        }
        bVar10 = true;
        pbVar18 = (byte *)((ulong)&local_218 | 1);
        if ((local_218 & 1) != 0) {
          pbVar18 = local_208;
        }
      }
      free(__ptr);
      puVar15 = PTR_PTR_005c62e8;
      local_1c0[0] = *(ulong *)PTR_PTR_005c62e8;
      *(undefined8 *)((long)local_1c0 + *(long *)(local_1c0[0] - 0x18)) =
           *(undefined8 *)(PTR_PTR_005c62e8 + 0x18);
      FUN_005664d8(local_1b0);
      FUN_00564acc(local_1c0,puVar15 + 8);
      puVar16 = (ulong *)thunk_FUN_00564510(auStack_108);
      if (bVar10) {
LAB_0052a244:
        iVar6 = *(int *)(param_2 + 0x18);
        if (iVar6 == 8) {
                    /* try { // try from 0052a348 to 0052a357 has its CatchHandler @ 0052aaec */
          FUN_0056175c(param_3,*(undefined4 *)(param_2 + 0x28),0);
          local_1c0[0] = 0;
          local_1c0[1] = 0;
          local_1b0[0] = (void *)0x0;
                    /* try { // try from 0052a364 to 0052a377 has its CatchHandler @ 0052aaa8 */
          puVar16 = (ulong *)FUN_00527fe4(pbVar18,*(undefined4 *)(param_2 + 0x24),param_3,local_1c0)
          ;
          if (((ulong)puVar16 & 1) != 0) {
            if ((local_1c0[0] & 1) != 0) {
              free(local_1b0[0]);
            }
LAB_0052a390:
            puVar16 = (ulong *)FUN_00527cac();
            if ((int)puVar16 == *(int *)(param_2 + 0x20)) {
              puVar16 = (ulong *)0x1;
            }
            else {
              bVar7 = *param_2;
              sVar3 = (ulong)(bVar7 >> 1);
              if ((bVar7 & 1) != 0) {
                sVar3 = *(size_t *)(param_2 + 8);
              }
              uVar17 = sVar3 + 0x20;
              if (0xffffffffffffffef < uVar17) {
                if (*(long *)(lVar9 + 0x28) == local_70) {
                    /* try { // try from 0052aa18 to 0052aa1f has its CatchHandler @ 0052aa60 */
                    /* WARNING: Subroutine does not return */
                  FUN_002d18a8(local_1c0);
                }
                goto LAB_0052ab30;
              }
              if (uVar17 < 0x17) {
                local_1c0[1] = 0;
                local_1b0[0] = (void *)0x0;
                pvVar20 = (void *)((ulong)local_1c0 | 1);
                local_1c0[0] = (ulong)(byte)((int)uVar17 << 1);
LAB_0052a728:
                pbVar18 = *(byte **)(param_2 + 0x10);
                if ((bVar7 & 1) == 0) {
                  pbVar18 = param_2 + 1;
                }
                memmove(pvVar20,pbVar18,sVar3);
              }
              else {
                uVar21 = (uVar17 | 0xf) + 1;
                    /* try { // try from 0052a70c to 0052a713 has its CatchHandler @ 0052aa60 */
                pvVar20 = (void *)FUN_005a5d4c(uVar21);
                local_1c0[0] = uVar21 | 1;
                local_1c0[1] = uVar17;
                local_1b0[0] = pvVar20;
                if (sVar3 != 0) goto LAB_0052a728;
              }
              uVar12 = s___CRC_check_failed__damaged_zip__00147a5d._24_8_;
              uVar11 = s___CRC_check_failed__damaged_zip__00147a5d._16_8_;
              uVar19 = s___CRC_check_failed__damaged_zip__00147a5d._8_8_;
              uVar5 = s___CRC_check_failed__damaged_zip__00147a5d._0_8_;
              pcVar1 = (char *)((long)pvVar20 + sVar3);
              pcVar1[0x20] = '\0';
              *(undefined8 *)(pcVar1 + 8) = uVar19;
              *(undefined8 *)pcVar1 = uVar5;
              *(undefined8 *)(pcVar1 + 0x18) = uVar12;
              *(undefined8 *)(pcVar1 + 0x10) = uVar11;
              if ((*param_4 & 1) != 0) {
                free((void *)param_4[2]);
              }
              param_4[1] = local_1c0[1];
              *param_4 = local_1c0[0];
              param_4[2] = (ulong)local_1b0[0];
              if ((*param_3 & 1) == 0) {
                puVar16 = (ulong *)0x0;
                param_3[0] = 0;
                param_3[1] = 0;
              }
              else {
                puVar16 = (ulong *)0x0;
                **(undefined1 **)(param_3 + 0x10) = 0;
                param_3[8] = 0;
                param_3[9] = 0;
                param_3[10] = 0;
                param_3[0xb] = 0;
                param_3[0xc] = 0;
                param_3[0xd] = 0;
                param_3[0xe] = 0;
                param_3[0xf] = 0;
              }
            }
            goto LAB_0052a898;
          }
          bVar7 = *param_2;
          sVar3 = (ulong)(bVar7 >> 1);
          if ((bVar7 & 1) != 0) {
            sVar3 = *(size_t *)(param_2 + 8);
          }
          uVar17 = sVar3 + 2;
          if (0xffffffffffffffef < uVar17) {
            if (*(long *)(lVar9 + 0x28) == local_70) {
                    /* try { // try from 0052aa30 to 0052aa37 has its CatchHandler @ 0052aa5c */
                    /* WARNING: Subroutine does not return */
              FUN_002d18a8(&local_200);
            }
            goto LAB_0052ab30;
          }
          if (uVar17 < 0x17) {
            uStack_1f8 = 0;
            pvVar20 = (void *)((ulong)&local_200 | 1);
            local_1f0 = (void *)0x0;
            local_200 = (ulong)(byte)((int)uVar17 << 1);
            if (sVar3 != 0) goto LAB_0052a7c0;
          }
          else {
            uVar21 = (uVar17 | 0xf) + 1;
                    /* try { // try from 0052a7a8 to 0052a7af has its CatchHandler @ 0052aa5c */
            pvVar20 = (void *)FUN_005a5d4c(uVar21);
            local_200 = uVar21 | 1;
            uStack_1f8 = uVar17;
            local_1f0 = pvVar20;
LAB_0052a7c0:
            pbVar18 = *(byte **)(param_2 + 0x10);
            if ((bVar7 & 1) == 0) {
              pbVar18 = param_2 + 1;
            }
            memmove(pvVar20,pbVar18,sVar3);
          }
          *(undefined2 *)((long)pvVar20 + sVar3) = 0x203a;
          *(undefined1 *)((undefined2 *)((long)pvVar20 + sVar3) + 1) = 0;
          uVar17 = local_1c0[0] >> 1 & 0x7f;
          pvVar20 = (void *)((ulong)local_1c0 | 1);
          if ((local_1c0[0] & 1) != 0) {
            uVar17 = local_1c0[1];
            pvVar20 = local_1b0[0];
          }
                    /* try { // try from 0052a808 to 0052a80f has its CatchHandler @ 0052aa44 */
          pbVar18 = (byte *)FUN_00561098(&local_200,pvVar20,uVar17);
          bVar7 = *pbVar18;
          bVar8 = pbVar18[1];
          local_1e8 = (byte)*(undefined8 *)(pbVar18 + 2);
          uStack_1e7 = (undefined5)((ulong)*(undefined8 *)(pbVar18 + 2) >> 8);
          uVar17 = *(ulong *)(pbVar18 + 0x10);
          uStack_1e2 = (undefined2)*(undefined8 *)(pbVar18 + 8);
          local_1e0 = (undefined6)((ulong)*(undefined8 *)(pbVar18 + 8) >> 0x10);
          pbVar18[8] = 0;
          pbVar18[9] = 0;
          pbVar18[10] = 0;
          pbVar18[0xb] = 0;
          pbVar18[0xc] = 0;
          pbVar18[0xd] = 0;
          pbVar18[0xe] = 0;
          pbVar18[0xf] = 0;
          pbVar18[0x10] = 0;
          pbVar18[0x11] = 0;
          pbVar18[0x12] = 0;
          pbVar18[0x13] = 0;
          pbVar18[0x14] = 0;
          pbVar18[0x15] = 0;
          pbVar18[0x16] = 0;
          pbVar18[0x17] = 0;
          pbVar18[0] = 0;
          pbVar18[1] = 0;
          pbVar18[2] = 0;
          pbVar18[3] = 0;
          pbVar18[4] = 0;
          pbVar18[5] = 0;
          pbVar18[6] = 0;
          pbVar18[7] = 0;
          if ((*param_4 & 1) != 0) {
            free((void *)param_4[2]);
          }
          *(byte *)param_4 = bVar7;
          *(byte *)((long)param_4 + 1) = bVar8;
          *(ulong *)((long)param_4 + 2) = CONCAT26(uStack_1e2,CONCAT51(uStack_1e7,local_1e8));
          param_4[1] = CONCAT62(local_1e0,uStack_1e2);
          param_4[2] = uVar17;
          if ((local_200 & 1) != 0) {
            free(local_1f0);
          }
          if ((*param_3 & 1) == 0) {
            param_3[0] = 0;
            param_3[1] = 0;
            pvVar20 = local_1b0[0];
            uVar17 = local_1c0[0];
          }
          else {
            **(undefined1 **)(param_3 + 0x10) = 0;
            param_3[8] = 0;
            param_3[9] = 0;
            param_3[10] = 0;
            param_3[0xb] = 0;
            param_3[0xc] = 0;
            param_3[0xd] = 0;
            param_3[0xe] = 0;
            param_3[0xf] = 0;
            pvVar20 = local_1b0[0];
            uVar17 = local_1c0[0];
          }
        }
        else {
          if (iVar6 == 0) {
            if (*(int *)(param_2 + 0x24) == *(int *)(param_2 + 0x28)) {
                    /* try { // try from 0052a260 to 0052a2cf has its CatchHandler @ 0052aaec */
              thunk_FUN_0055eab8(param_3,pbVar18);
              goto LAB_0052a390;
            }
            bVar7 = *param_2;
            sVar3 = (ulong)(bVar7 >> 1);
            if ((bVar7 & 1) != 0) {
              sVar3 = *(size_t *)(param_2 + 8);
            }
            uVar17 = sVar3 + 0x16;
            if (0xffffffffffffffef < uVar17) {
              if (*(long *)(lVar9 + 0x28) == local_70) {
                    /* try { // try from 0052aa00 to 0052aa07 has its CatchHandler @ 0052aa64 */
                    /* WARNING: Subroutine does not return */
                FUN_002d18a8(local_1c0);
              }
              goto LAB_0052ab30;
            }
            if (uVar17 < 0x17) {
              local_1c0[1] = 0;
              pvVar20 = (void *)((ulong)local_1c0 | 1);
              local_1b0[0] = (void *)0x0;
              local_1c0[0] = (ulong)(byte)((int)uVar17 << 1);
              if (sVar3 != 0) goto LAB_0052a6c8;
            }
            else {
              uVar21 = (uVar17 | 0xf) + 1;
                    /* try { // try from 0052a6b0 to 0052a6b7 has its CatchHandler @ 0052aa64 */
              pvVar20 = (void *)FUN_005a5d4c(uVar21);
              local_1c0[0] = uVar21 | 1;
              local_1c0[1] = uVar17;
              local_1b0[0] = pvVar20;
LAB_0052a6c8:
              pbVar18 = *(byte **)(param_2 + 0x10);
              if ((bVar7 & 1) == 0) {
                pbVar18 = param_2 + 1;
              }
              memmove(pvVar20,pbVar18,sVar3);
            }
            uVar11 = s___damaged_stored_entry_0016aa8f._0_8_;
            pcVar1 = (char *)((long)pvVar20 + sVar3);
            uVar5 = CONCAT26(s___damaged_stored_entry_0016aa8f._14_2_,
                             s___damaged_stored_entry_0016aa8f._8_6_);
            uVar19 = CONCAT62(s___damaged_stored_entry_0016aa8f._16_6_,
                              s___damaged_stored_entry_0016aa8f._14_2_);
            pcVar1[0x16] = '\0';
            *(undefined8 *)(pcVar1 + 8) = uVar5;
            *(undefined8 *)pcVar1 = uVar11;
            *(undefined8 *)(pcVar1 + 0xe) = uVar19;
            goto LAB_0052a31c;
          }
          bVar7 = *param_2;
          sVar3 = (ulong)(bVar7 >> 1);
          if ((bVar7 & 1) != 0) {
            sVar3 = *(size_t *)(param_2 + 8);
          }
          uVar17 = sVar3 + 0x15;
          if (0xffffffffffffffef < uVar17) {
            if (*(long *)(lVar9 + 0x28) == local_70) {
                    /* try { // try from 0052a9e8 to 0052a9ef has its CatchHandler @ 0052aac0 */
                    /* WARNING: Subroutine does not return */
              FUN_002d18a8(&local_200);
            }
            goto LAB_0052ab30;
          }
          if (uVar17 < 0x17) {
            uStack_1f8 = 0;
            pvVar20 = (void *)((ulong)&local_200 | 1);
            local_1f0 = (void *)0x0;
            local_200 = (ulong)(byte)((int)uVar17 << 1);
            if (sVar3 != 0) goto LAB_0052a4f0;
          }
          else {
            uVar21 = (uVar17 | 0xf) + 1;
                    /* try { // try from 0052a4d8 to 0052a4df has its CatchHandler @ 0052aac0 */
            pvVar20 = (void *)FUN_005a5d4c(uVar21);
            local_200 = uVar21 | 1;
            uStack_1f8 = uVar17;
            local_1f0 = pvVar20;
LAB_0052a4f0:
            pbVar18 = *(byte **)(param_2 + 0x10);
            if ((bVar7 & 1) == 0) {
              pbVar18 = param_2 + 1;
            }
            memmove(pvVar20,pbVar18,sVar3);
          }
          uVar11 = s___compression_method_001892ff._0_8_;
          pcVar1 = (char *)((long)pvVar20 + sVar3);
          uVar5 = CONCAT35(s___compression_method_001892ff._13_3_,
                           s___compression_method_001892ff._8_5_);
          uVar19 = CONCAT53(s___compression_method_001892ff._16_5_,
                            s___compression_method_001892ff._13_3_);
          pcVar1[0x15] = '\0';
          *(undefined8 *)(pcVar1 + 8) = uVar5;
          *(undefined8 *)pcVar1 = uVar11;
          *(undefined8 *)(pcVar1 + 0xd) = uVar19;
                    /* try { // try from 0052a528 to 0052a537 has its CatchHandler @ 0052aa98 */
          FUN_00562e2c(&local_1e8,iVar6);
          uVar17 = (ulong)(local_1e8 >> 1);
          pvVar20 = (void *)((ulong)&local_1e8 | 1);
          if ((local_1e8 & 1) != 0) {
            uVar17 = CONCAT26(uStack_1da,local_1e0);
            pvVar20 = local_1d8;
          }
                    /* try { // try from 0052a554 to 0052a55b has its CatchHandler @ 0052aa80 */
          puVar16 = (ulong *)FUN_00561098(&local_200,pvVar20,uVar17);
          local_1b0[0] = (void *)puVar16[2];
          local_1c0[1] = puVar16[1];
          local_1c0[0] = *puVar16;
          puVar16[1] = 0;
          puVar16[2] = 0;
          *puVar16 = 0;
                    /* try { // try from 0052a574 to 0052a583 has its CatchHandler @ 0052aa68 */
          pbVar18 = (byte *)FUN_00561dc8(local_1c0,
                                         " is not supported (use a normal zip: stored or deflate)");
          bVar7 = *pbVar18;
          uVar5 = *(undefined8 *)(pbVar18 + 8);
          uVar17 = *(ulong *)(pbVar18 + 0x10);
          bVar8 = pbVar18[1];
          uVar19 = *(undefined8 *)(pbVar18 + 2);
          pbVar18[8] = 0;
          pbVar18[9] = 0;
          pbVar18[10] = 0;
          pbVar18[0xb] = 0;
          pbVar18[0xc] = 0;
          pbVar18[0xd] = 0;
          pbVar18[0xe] = 0;
          pbVar18[0xf] = 0;
          pbVar18[0x10] = 0;
          pbVar18[0x11] = 0;
          pbVar18[0x12] = 0;
          pbVar18[0x13] = 0;
          pbVar18[0x14] = 0;
          pbVar18[0x15] = 0;
          pbVar18[0x16] = 0;
          pbVar18[0x17] = 0;
          pbVar18[0] = 0;
          pbVar18[1] = 0;
          pbVar18[2] = 0;
          pbVar18[3] = 0;
          pbVar18[4] = 0;
          pbVar18[5] = 0;
          pbVar18[6] = 0;
          pbVar18[7] = 0;
          local_1d0 = (undefined6)uVar19;
          uStack_1ca = (undefined2)uVar5;
          uStack_1c8 = (undefined6)((ulong)uVar5 >> 0x10);
          if ((*param_4 & 1) != 0) {
            free((void *)param_4[2]);
          }
          *(byte *)param_4 = bVar7;
          *(byte *)((long)param_4 + 1) = bVar8;
          *(ulong *)((long)param_4 + 2) = CONCAT26(uStack_1ca,local_1d0);
          param_4[1] = CONCAT62(uStack_1c8,uStack_1ca);
          param_4[2] = uVar17;
          if ((local_1c0[0] & 1) != 0) {
            free(local_1b0[0]);
          }
          pvVar20 = local_1f0;
          uVar17 = local_200;
          if ((local_1e8 & 1) != 0) {
            free(local_1d8);
            pvVar20 = local_1f0;
            uVar17 = local_200;
          }
        }
        if ((uVar17 & 1) != 0) {
          free(pvVar20);
        }
      }
      puVar16 = (ulong *)0x0;
    }
LAB_0052a898:
    if ((local_218 & 1) != 0) {
      free(local_208);
    }
  }
  else {
    **(undefined1 **)(param_3 + 0x10) = 0;
    param_3[8] = 0;
    param_3[9] = 0;
    param_3[10] = 0;
    param_3[0xb] = 0;
    param_3[0xc] = 0;
    param_3[0xd] = 0;
    param_3[0xe] = 0;
    param_3[0xf] = 0;
    if ((param_2[0x1c] & 1) == 0) goto LAB_00529e58;
LAB_00529e00:
    bVar7 = *param_2;
    sVar3 = (ulong)(bVar7 >> 1);
    if ((bVar7 & 1) != 0) {
      sVar3 = *(size_t *)(param_2 + 8);
    }
    uVar17 = sVar3 + 0x29;
    if (0xffffffffffffffef < uVar17) {
LAB_0052a990:
      if (*(long *)(lVar9 + 0x28) == local_70) {
                    /* WARNING: Subroutine does not return */
        FUN_002d18a8(local_1c0);
      }
      goto LAB_0052ab30;
    }
    if (uVar17 < 0x17) {
      local_1c0[1] = 0;
      local_1b0[0] = (void *)0x0;
      pvVar20 = (void *)((ulong)local_1c0 | 1);
      local_1c0[0] = (ulong)(byte)((int)uVar17 << 1);
LAB_00529fe0:
      pbVar18 = *(byte **)(param_2 + 0x10);
      if ((bVar7 & 1) == 0) {
        pbVar18 = param_2 + 1;
      }
      memmove(pvVar20,pbVar18,sVar3);
    }
    else {
      pvVar20 = (void *)FUN_005a5d4c((uVar17 | 0xf) + 1);
      local_1c0[0] = (uVar17 | 0xf) + 2;
      local_1c0[1] = uVar17;
      local_1b0[0] = pvVar20;
      if (sVar3 != 0) goto LAB_00529fe0;
    }
    uVar14 = s___encrypted_zip_entries_are_not_s_0017edd8._33_8_;
    uVar13 = s___encrypted_zip_entries_are_not_s_0017edd8._16_8_;
    uVar12 = s___encrypted_zip_entries_are_not_s_0017edd8._8_8_;
    uVar11 = s___encrypted_zip_entries_are_not_s_0017edd8._0_8_;
    pcVar1 = (char *)((long)pvVar20 + sVar3);
    uVar5 = CONCAT71(s___encrypted_zip_entries_are_not_s_0017edd8._25_7_,
                     s___encrypted_zip_entries_are_not_s_0017edd8[0x18]);
    uVar19 = CONCAT17(s___encrypted_zip_entries_are_not_s_0017edd8[0x20],
                      s___encrypted_zip_entries_are_not_s_0017edd8._25_7_);
    pcVar1[0x29] = '\0';
    *(undefined8 *)(pcVar1 + 8) = uVar12;
    *(undefined8 *)pcVar1 = uVar11;
    *(undefined8 *)(pcVar1 + 0x18) = uVar5;
    *(undefined8 *)(pcVar1 + 0x10) = uVar13;
    *(undefined8 *)(pcVar1 + 0x21) = uVar14;
    *(undefined8 *)(pcVar1 + 0x19) = uVar19;
    bVar7 = (byte)*param_4;
joined_r0x0052a0c8:
    if ((bVar7 & 1) != 0) {
      free((void *)param_4[2]);
    }
    puVar16 = (ulong *)0x0;
    param_4[1] = local_1c0[1];
    *param_4 = local_1c0[0];
    param_4[2] = (ulong)local_1b0[0];
  }
  if (*(long *)(lVar9 + 0x28) == local_70) {
    return;
  }
LAB_0052ab30:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(puVar16);
}



// ========================================
// Function: FUN_0052ab34
// Address: 0052ab34
// ========================================

void FUN_0052ab34(void)

{
  long lVar1;
  undefined8 local_270;
  undefined8 uStack_268;
  undefined8 uStack_260;
  undefined8 uStack_258;
  undefined8 local_250;
  undefined8 uStack_248;
  undefined8 local_240;
  undefined8 local_238;
  undefined8 local_230;
  undefined8 uStack_228;
  undefined8 uStack_220;
  undefined8 uStack_218;
  undefined8 local_210;
  undefined8 uStack_208;
  undefined8 uStack_200;
  undefined8 uStack_1f8;
  undefined8 local_1f0;
  undefined8 uStack_1e8;
  undefined8 uStack_1e0;
  undefined8 uStack_1d8;
  undefined8 local_1d0;
  undefined8 uStack_1c8;
  undefined8 uStack_1c0;
  undefined8 uStack_1b8;
  undefined8 local_1b0;
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  undefined8 uStack_198;
  undefined8 local_190;
  undefined8 uStack_188;
  undefined8 uStack_180;
  undefined8 uStack_178;
  undefined8 local_170;
  undefined8 uStack_168;
  undefined8 uStack_160;
  undefined8 uStack_158;
  undefined8 local_150;
  undefined8 uStack_148;
  undefined8 uStack_140;
  undefined8 uStack_138;
  undefined8 local_130;
  undefined8 uStack_128;
  undefined8 uStack_120;
  undefined8 uStack_118;
  undefined8 local_110;
  undefined8 uStack_108;
  undefined8 uStack_100;
  undefined8 uStack_f8;
  undefined8 local_f0;
  undefined8 uStack_e8;
  undefined8 uStack_e0;
  undefined8 uStack_d8;
  undefined8 local_d0;
  undefined8 uStack_c8;
  undefined8 uStack_c0;
  undefined8 uStack_b8;
  undefined8 local_b0;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined8 uStack_98;
  undefined8 local_90;
  undefined8 uStack_88;
  undefined8 uStack_80;
  undefined8 uStack_78;
  undefined8 local_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 local_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  undefined8 uStack_38;
  long local_28;
  
  lVar1 = tpidr_el0;
  local_28 = *(long *)(lVar1 + 0x28);
  uStack_268 = 0x8000800080008;
  local_270 = 0x8000800080008;
  uStack_258 = 0x8000800080008;
  uStack_260 = 0x8000800080008;
  uStack_248 = 0x8000800080008;
  local_250 = 0x8000800080008;
  local_238 = 0x8000800080008;
  local_240 = 0x8000800080008;
  uStack_228 = 0x8000800080008;
  local_230 = 0x8000800080008;
  uStack_218 = 0x8000800080008;
  uStack_220 = 0x8000800080008;
  uStack_208 = 0x8000800080008;
  local_210 = 0x8000800080008;
  uStack_1f8 = 0x8000800080008;
  uStack_200 = 0x8000800080008;
  uStack_1e8 = 0x8000800080008;
  local_1f0 = 0x8000800080008;
  uStack_1d8 = 0x8000800080008;
  uStack_1e0 = 0x8000800080008;
  uStack_1c8 = 0x8000800080008;
  local_1d0 = 0x8000800080008;
  uStack_1b8 = 0x8000800080008;
  uStack_1c0 = 0x8000800080008;
  uStack_1a8 = 0x8000800080008;
  local_1b0 = 0x8000800080008;
  uStack_198 = 0x8000800080008;
  uStack_1a0 = 0x8000800080008;
  uStack_188 = 0x8000800080008;
  local_190 = 0x8000800080008;
  uStack_178 = 0x8000800080008;
  uStack_180 = 0x8000800080008;
  uStack_168 = 0x8000800080008;
  local_170 = 0x8000800080008;
  uStack_158 = 0x8000800080008;
  uStack_160 = 0x8000800080008;
  uStack_148 = 0x9000900090009;
  local_150 = 0x9000900090009;
  uStack_138 = 0x9000900090009;
  uStack_140 = 0x9000900090009;
  uStack_128 = 0x9000900090009;
  local_130 = 0x9000900090009;
  uStack_118 = 0x9000900090009;
  uStack_120 = 0x9000900090009;
  uStack_108 = 0x9000900090009;
  local_110 = 0x9000900090009;
  uStack_f8 = 0x9000900090009;
  uStack_100 = 0x9000900090009;
  uStack_e8 = 0x9000900090009;
  local_f0 = 0x9000900090009;
  uStack_d8 = 0x9000900090009;
  uStack_e0 = 0x9000900090009;
  uStack_c8 = 0x9000900090009;
  local_d0 = 0x9000900090009;
  uStack_b8 = 0x9000900090009;
  uStack_c0 = 0x9000900090009;
  uStack_a8 = 0x9000900090009;
  local_b0 = 0x9000900090009;
  uStack_98 = 0x9000900090009;
  uStack_a0 = 0x9000900090009;
  uStack_88 = 0x9000900090009;
  local_90 = 0x9000900090009;
  uStack_78 = 0x9000900090009;
  uStack_80 = 0x9000900090009;
  uStack_68 = 0x7000700070007;
  local_70 = 0x7000700070007;
  uStack_58 = 0x7000700070007;
  uStack_60 = 0x7000700070007;
  uStack_48 = 0x7000700070007;
  local_50 = 0x7000700070007;
  uStack_38 = 0x8000800080008;
  uStack_40 = 0x8000800080008;
  FUN_0052af28(&DAT_0098f058,&local_270,0x120);
  local_238 = CONCAT44(local_238._4_4_,0x50005);
  uStack_268 = 0x5000500050005;
  local_270 = 0x5000500050005;
  uStack_258 = 0x5000500050005;
  uStack_260 = 0x5000500050005;
  uStack_248 = 0x5000500050005;
  local_250 = 0x5000500050005;
  local_240 = 0x5000500050005;
  FUN_0052af28(&DAT_0098fab8,&local_270,0x1e);
  if (*(long *)(lVar1 + 0x28) == local_28) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0052ac10
// Address: 0052ac10
// ========================================

undefined8 FUN_0052ac10(long *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  bool bVar1;
  byte bVar2;
  short sVar3;
  short sVar4;
  short sVar5;
  long lVar6;
  uint uVar7;
  uint uVar8;
  ulong uVar9;
  ulong uVar10;
  ulong uVar11;
  uint uVar12;
  char *pcVar13;
  uint uVar14;
  
  uVar8 = FUN_0052b330();
  if (*(char *)((long)param_1 + 0x24) == '\0') {
    pcVar13 = "bad literal/length code";
    do {
      if ((int)uVar8 < 0) goto LAB_0052ac50;
      if (uVar8 < 0x100) {
        uVar11 = param_1[7];
        if ((ulong)param_1[6] <= uVar11) {
LAB_0052aee4:
          pcVar13 = "more data than the zip says";
          goto LAB_0052ac50;
        }
        param_1[7] = uVar11 + 1;
        *(char *)(param_1[5] + uVar11) = (char)uVar8;
      }
      else {
        if (uVar8 == 0x100) {
          return 1;
        }
        if (0x11d < uVar8) {
          pcVar13 = "bad length code";
          goto LAB_0052ac50;
        }
        uVar12 = *(uint *)(param_1 + 4);
        lVar6 = (ulong)(uVar8 - 0x101) * 2;
        sVar3 = *(short *)(&DAT_001c7db6 + lVar6);
        sVar4 = *(short *)(&DAT_001c7d7c + lVar6);
        uVar8 = (uint)sVar3;
        if ((int)uVar12 < (int)sVar3) {
          if ((int)uVar12 < 0x39) {
            uVar9 = param_1[2];
            uVar10 = param_1[3];
            uVar14 = uVar12;
            uVar11 = uVar9;
            if (uVar9 <= (ulong)param_1[1]) {
              uVar11 = param_1[1];
            }
            do {
              uVar12 = uVar14;
              if (uVar11 == uVar9) break;
              uVar12 = uVar14 + 8;
              param_1[2] = uVar9 + 1;
              bVar2 = *(byte *)(*param_1 + uVar9);
              *(uint *)(param_1 + 4) = uVar12;
              uVar10 = (ulong)bVar2 << ((ulong)uVar14 & 0x3f) | uVar10;
              param_1[3] = uVar10;
              bVar1 = (int)uVar14 < 0x31;
              uVar9 = uVar9 + 1;
              uVar14 = uVar12;
            } while (bVar1);
          }
          if ((int)uVar8 <= (int)uVar12) goto LAB_0052ada0;
          uVar14 = 0;
          *(undefined1 *)((long)param_1 + 0x24) = 1;
        }
        else {
LAB_0052ada0:
          uVar14 = (uint)param_1[3] & (-1 << (ulong)(uVar8 & 0x1f) ^ 0xffffffffU);
          *(uint *)(param_1 + 4) = uVar12 - uVar8;
          param_1[3] = (ulong)param_1[3] >> ((long)sVar3 & 0x3fU);
        }
        uVar8 = FUN_0052b330(param_1,param_3);
        if (0x1d < uVar8) {
          pcVar13 = "bad distance code";
          goto LAB_0052ac50;
        }
        uVar12 = *(uint *)(param_1 + 4);
        sVar3 = *(short *)(&DAT_001c7e2c + (ulong)uVar8 * 2);
        sVar5 = *(short *)(&DAT_001c7df0 + (ulong)uVar8 * 2);
        uVar8 = (uint)sVar3;
        if ((int)uVar12 < (int)sVar3) {
          if ((int)uVar12 < 0x39) {
            uVar9 = param_1[2];
            uVar10 = param_1[3];
            uVar7 = uVar12;
            uVar11 = uVar9;
            if (uVar9 <= (ulong)param_1[1]) {
              uVar11 = param_1[1];
            }
            do {
              uVar12 = uVar7;
              if (uVar11 == uVar9) break;
              uVar12 = uVar7 + 8;
              param_1[2] = uVar9 + 1;
              bVar2 = *(byte *)(*param_1 + uVar9);
              *(uint *)(param_1 + 4) = uVar12;
              uVar10 = (ulong)bVar2 << ((ulong)uVar7 & 0x3f) | uVar10;
              param_1[3] = uVar10;
              bVar1 = (int)uVar7 < 0x31;
              uVar9 = uVar9 + 1;
              uVar7 = uVar12;
            } while (bVar1);
          }
          if ((int)uVar12 < (int)uVar8) {
            *(undefined1 *)((long)param_1 + 0x24) = 1;
            break;
          }
        }
        uVar11 = param_1[3];
        *(uint *)(param_1 + 4) = uVar12 - uVar8;
        param_1[3] = uVar11 >> ((long)sVar3 & 0x3fU);
        if (*(char *)((long)param_1 + 0x24) != '\0') break;
        uVar9 = param_1[7];
        uVar11 = (ulong)((uint)uVar11 & (-1 << (ulong)(uVar8 & 0x1f) ^ 0xffffffffU)) + (long)sVar5;
        if (uVar9 < uVar11) {
          pcVar13 = "distance before the start of the data";
          goto LAB_0052ac50;
        }
        uVar10 = (ulong)(int)(uVar14 + (int)sVar4);
        if ((ulong)param_1[6] < uVar9 + uVar10) goto LAB_0052aee4;
        if ((uint)uVar11 < uVar14 + (int)sVar4) {
          if (uVar10 < 2) {
            uVar10 = 1;
          }
          do {
            uVar10 = uVar10 - 1;
            *(undefined1 *)(param_1[5] + uVar9) = *(undefined1 *)(param_1[5] + (uVar9 - uVar11));
            uVar9 = param_1[7] + 1;
            param_1[7] = uVar9;
          } while (uVar10 != 0);
        }
        else {
          memcpy((void *)(param_1[5] + uVar9),(void *)((long)(param_1[5] + uVar9) - uVar11),uVar10);
          param_1[7] = param_1[7] + uVar10;
        }
      }
      uVar8 = FUN_0052b330(param_1,param_2);
    } while (*(char *)((long)param_1 + 0x24) == '\0');
  }
  pcVar13 = "compressed data ends early";
LAB_0052ac50:
  FUN_00561ab4(param_4,pcVar13);
  return 0;
}



// ========================================
// Function: FUN_0052af28
// Address: 0052af28
// ========================================

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052af28(short *param_1,short *param_2,uint param_3)

{
  long lVar1;
  undefined1 auVar2 [16];
  undefined1 auVar3 [16];
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  undefined1 auVar8 [16];
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  undefined1 auVar13 [16];
  uint uVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  undefined8 uVar20;
  undefined8 uVar21;
  undefined1 auVar22 [16];
  undefined8 uVar23;
  undefined8 uVar24;
  int iVar25;
  long lVar26;
  uint uVar27;
  ulong uVar28;
  int iVar29;
  short *psVar30;
  long lVar31;
  uint uVar32;
  int iVar33;
  long lVar34;
  short sVar35;
  uint uVar36;
  undefined1 auVar37 [16];
  undefined1 auVar38 [16];
  undefined1 auVar39 [16];
  undefined1 auVar40 [16];
  undefined1 auVar41 [16];
  undefined1 auVar45 [16];
  undefined1 auVar46 [16];
  undefined1 auVar47 [16];
  byte bVar48;
  byte bVar49;
  byte bVar50;
  byte bVar51;
  byte bVar52;
  byte bVar53;
  byte bVar54;
  byte bVar55;
  byte bVar56;
  byte bVar57;
  byte bVar58;
  byte bVar59;
  byte bVar60;
  byte bVar61;
  byte bVar62;
  byte bVar63;
  short local_58 [4];
  short local_50;
  short local_4e;
  short local_4c;
  short local_4a;
  short local_48;
  short local_46;
  short local_44;
  short local_42;
  short local_40;
  short local_3e;
  short local_3c;
  short local_3a;
  long local_38;
  uint uVar42;
  uint uVar43;
  uint uVar44;
  
  lVar1 = tpidr_el0;
  local_38 = *(long *)(lVar1 + 0x28);
  memset(param_1 + 0x130,0,0x800);
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[0] = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  if ((int)param_3 < 1) {
    if (param_3 != 0) goto LAB_0052afb8;
  }
  else {
    uVar28 = (ulong)param_3;
    psVar30 = param_2;
    do {
      uVar28 = uVar28 - 1;
      param_1[*psVar30] = param_1[*psVar30] + 1;
      psVar30 = psVar30 + 1;
    } while (uVar28 != 0);
    if ((int)*param_1 != param_3) {
LAB_0052afb8:
      sVar35 = param_1[1];
      iVar25 = 2 - sVar35;
      if (sVar35 < 3) {
        iVar25 = iVar25 * 2 - (int)param_1[2];
        if (-1 < iVar25) {
          iVar25 = iVar25 * 2 - (int)param_1[3];
          if (-1 < iVar25) {
            iVar25 = iVar25 * 2 - (int)param_1[4];
            if (-1 < iVar25) {
              iVar25 = iVar25 * 2 - (int)param_1[5];
              if (-1 < iVar25) {
                iVar25 = iVar25 * 2 - (int)param_1[6];
                if (-1 < iVar25) {
                  iVar25 = iVar25 * 2 - (int)param_1[7];
                  if (-1 < iVar25) {
                    iVar25 = iVar25 * 2 - (int)param_1[8];
                    if (-1 < iVar25) {
                      iVar25 = iVar25 * 2 - (int)param_1[9];
                      if (-1 < iVar25) {
                        iVar25 = iVar25 * 2 - (int)param_1[10];
                        if (-1 < iVar25) {
                          iVar25 = iVar25 * 2 - (int)param_1[0xb];
                          if (-1 < iVar25) {
                            iVar25 = iVar25 * 2 - (int)param_1[0xc];
                            if (-1 < iVar25) {
                              iVar25 = iVar25 * 2 - (int)param_1[0xd];
                              if (-1 < iVar25) {
                                iVar25 = iVar25 * 2 - (int)param_1[0xe];
                                if ((-1 < iVar25) &&
                                   (iVar25 = iVar25 * 2 - (int)param_1[0xf], -1 < iVar25)) {
                                  local_58[2] = sVar35;
                                  local_58[3] = param_1[2] + sVar35;
                                  local_50 = param_1[3] + local_58[3];
                                  local_4e = param_1[4] + local_50;
                                  local_4c = param_1[5] + local_4e;
                                  local_4a = param_1[6] + local_4c;
                                  local_48 = param_1[7] + local_4a;
                                  local_46 = param_1[8] + local_48;
                                  local_44 = param_1[9] + local_46;
                                  local_42 = param_1[10] + local_44;
                                  local_40 = param_1[0xb] + local_42;
                                  local_3e = param_1[0xc] + local_40;
                                  local_3c = param_1[0xd] + local_3e;
                                  local_58[0] = 0;
                                  local_58[1] = 0;
                                  local_3a = param_1[0xe] + local_3c;
                                  if (0 < (int)param_3) {
                                    uVar28 = 0;
                                    do {
                                      lVar31 = (long)param_2[uVar28];
                                      if (lVar31 != 0) {
                                        sVar35 = local_58[lVar31];
                                        local_58[lVar31] = sVar35 + 1;
                                        param_1[(long)sVar35 + 0x10] = (short)uVar28;
                                      }
                                      uVar28 = uVar28 + 1;
                                    } while (param_3 != uVar28);
                                  }
                                  uVar24 = _UNK_001a12e8;
                                  uVar23 = _DAT_001a12e0;
                                  auVar22 = _DAT_001a1110;
                                  uVar21 = _UNK_001a1088;
                                  uVar20 = _DAT_001a1080;
                                  uVar19 = _UNK_001a0d58;
                                  uVar18 = _DAT_001a0d50;
                                  uVar17 = _UNK_001a0d34;
                                  uVar16 = _DAT_001a0d30;
                                  uVar15 = _UNK_001a0d24;
                                  uVar14 = _DAT_001a0d20;
                                  auVar13 = _DAT_001a0cc0;
                                  uVar12 = _UNK_001a0c54;
                                  uVar11 = _DAT_001a0c50;
                                  uVar10 = _UNK_001a0c44;
                                  uVar9 = _DAT_001a0c40;
                                  auVar8 = _DAT_001a0c30;
                                  uVar7 = _UNK_001a0be4;
                                  uVar6 = _DAT_001a0be0;
                                  uVar5 = _UNK_001a0bd4;
                                  uVar4 = _DAT_001a0bd0;
                                  uVar27 = 0;
                                  lVar34 = 0;
                                  iVar29 = 0;
                                  lVar31 = 1;
                                  do {
                                    sVar35 = param_1[lVar31];
                                    if (0 < sVar35) {
                                      uVar32 = (uint)lVar31;
                                      lVar34 = (long)(int)lVar34;
                                      iVar33 = 0;
                                      do {
                                        auVar40._4_4_ = iVar29;
                                        auVar40._0_4_ = iVar29;
                                        auVar40._8_4_ = iVar29;
                                        auVar40._12_4_ = iVar29;
                                        auVar37 = NEON_ushl(auVar40,auVar13,4);
                                        auVar45._0_5_ =
                                             CONCAT14(auVar37[4],(uint)(auVar37[0] & 1)) &
                                             0x1ffffffff;
                                        auVar45._5_3_ = 0;
                                        auVar45[8] = auVar37[8] & 1;
                                        auVar45._9_3_ = 0;
                                        auVar45[0xc] = auVar37[0xc] & 1;
                                        auVar45._13_3_ = 0;
                                        auVar37._4_4_ = uVar32 + (int)((ulong)uVar20 >> 0x20);
                                        auVar37._0_4_ = uVar32 + (int)uVar20;
                                        auVar37._8_4_ = uVar32 + (int)uVar21;
                                        auVar37._12_4_ = uVar32 + (int)((ulong)uVar21 >> 0x20);
                                        auVar37 = NEON_ushl(auVar45,auVar37,4);
                                        if ((uVar27 & 0xfffffffc) == 0) {
                                          auVar47 = ZEXT816(0);
                                          auVar39 = auVar37;
                                          uVar36 = uVar14;
                                          uVar42 = uVar15;
                                          uVar43 = uVar16;
                                          uVar44 = uVar17;
                                        }
                                        else {
                                          auVar45 = NEON_ushl(auVar40,auVar8,4);
                                          auVar46._0_5_ =
                                               CONCAT14(auVar45[4],(uint)(auVar45[0] & 1)) &
                                               0x1ffffffff;
                                          auVar46._5_3_ = 0;
                                          auVar46[8] = auVar45[8] & 1;
                                          auVar46._9_3_ = 0;
                                          auVar46[0xc] = auVar45[0xc] & 1;
                                          auVar46._13_3_ = 0;
                                          auVar2._4_4_ = uVar32 + (int)((ulong)uVar18 >> 0x20);
                                          auVar2._0_4_ = uVar32 + (int)uVar18;
                                          auVar2._8_4_ = uVar32 + (int)uVar19;
                                          auVar2._12_4_ = uVar32 + (int)((ulong)uVar19 >> 0x20);
                                          auVar45 = NEON_ushl(auVar46,auVar2,4);
                                          bVar48 = auVar45[0] | auVar37[0];
                                          bVar49 = auVar45[1] | auVar37[1];
                                          bVar50 = auVar45[2] | auVar37[2];
                                          bVar51 = auVar45[3] | auVar37[3];
                                          bVar52 = auVar45[4] | auVar37[4];
                                          bVar53 = auVar45[5] | auVar37[5];
                                          bVar54 = auVar45[6] | auVar37[6];
                                          bVar55 = auVar45[7] | auVar37[7];
                                          bVar56 = auVar45[8] | auVar37[8];
                                          bVar57 = auVar45[9] | auVar37[9];
                                          bVar58 = auVar45[10] | auVar37[10];
                                          bVar59 = auVar45[0xb] | auVar37[0xb];
                                          bVar60 = auVar45[0xc] | auVar37[0xc];
                                          bVar61 = auVar45[0xd] | auVar37[0xd];
                                          bVar62 = auVar45[0xe] | auVar37[0xe];
                                          bVar63 = auVar45[0xf] | auVar37[0xf];
                                          if ((uVar27 & 0xfffffffc) == 4) {
                                            auVar39[9] = bVar57;
                                            auVar39[8] = bVar56;
                                            auVar39[10] = bVar58;
                                            auVar39[0xb] = bVar59;
                                            auVar39[0xc] = bVar60;
                                            auVar39[0xd] = bVar61;
                                            auVar39[0xe] = bVar62;
                                            auVar39[0xf] = bVar63;
                                            auVar39[1] = bVar49;
                                            auVar39[0] = bVar48;
                                            auVar39[2] = bVar50;
                                            auVar39[3] = bVar51;
                                            auVar39[4] = bVar52;
                                            auVar39[5] = bVar53;
                                            auVar39[6] = bVar54;
                                            auVar39[7] = bVar55;
                                            auVar47 = auVar37;
                                            uVar36 = uVar9;
                                            uVar42 = uVar10;
                                            uVar43 = uVar11;
                                            uVar44 = uVar12;
                                          }
                                          else {
                                            auVar37 = NEON_ushl(auVar40,auVar22,4);
                                            auVar47[9] = bVar57;
                                            auVar47[8] = bVar56;
                                            auVar47[10] = bVar58;
                                            auVar47[0xb] = bVar59;
                                            auVar47[0xc] = bVar60;
                                            auVar47[0xd] = bVar61;
                                            auVar47[0xe] = bVar62;
                                            auVar47[0xf] = bVar63;
                                            auVar47[1] = bVar49;
                                            auVar47[0] = bVar48;
                                            auVar47[2] = bVar50;
                                            auVar47[3] = bVar51;
                                            auVar47[4] = bVar52;
                                            auVar47[5] = bVar53;
                                            auVar47[6] = bVar54;
                                            auVar47[7] = bVar55;
                                            auVar38._0_5_ =
                                                 CONCAT14(auVar37[4],(uint)(auVar37[0] & 1)) &
                                                 0x1ffffffff;
                                            auVar38._5_3_ = 0;
                                            auVar38[8] = auVar37[8] & 1;
                                            auVar38._9_3_ = 0;
                                            auVar38[0xc] = auVar37[0xc] & 1;
                                            auVar38._13_3_ = 0;
                                            auVar3._4_4_ = uVar32 + (int)((ulong)uVar23 >> 0x20);
                                            auVar3._0_4_ = uVar32 + (int)uVar23;
                                            auVar3._8_4_ = uVar32 + (int)uVar24;
                                            auVar3._12_4_ = uVar32 + (int)((ulong)uVar24 >> 0x20);
                                            auVar37 = NEON_ushl(auVar38,auVar3,4);
                                            auVar39[0] = auVar37[0] | bVar48;
                                            auVar39[1] = auVar37[1] | bVar49;
                                            auVar39[2] = auVar37[2] | bVar50;
                                            auVar39[3] = auVar37[3] | bVar51;
                                            auVar39[4] = auVar37[4] | bVar52;
                                            auVar39[5] = auVar37[5] | bVar53;
                                            auVar39[6] = auVar37[6] | bVar54;
                                            auVar39[7] = auVar37[7] | bVar55;
                                            auVar39[8] = auVar37[8] | bVar56;
                                            auVar39[9] = auVar37[9] | bVar57;
                                            auVar39[10] = auVar37[10] | bVar58;
                                            auVar39[0xb] = auVar37[0xb] | bVar59;
                                            auVar39[0xc] = auVar37[0xc] | bVar60;
                                            auVar39[0xd] = auVar37[0xd] | bVar61;
                                            auVar39[0xe] = auVar37[0xe] | bVar62;
                                            auVar39[0xf] = auVar37[0xf] | bVar63;
                                            uVar36 = uVar4;
                                            uVar42 = uVar5;
                                            uVar43 = uVar6;
                                            uVar44 = uVar7;
                                          }
                                        }
                                        auVar41._0_4_ = -(uint)(uVar27 < uVar36);
                                        auVar41._4_4_ = -(uint)(uVar27 < uVar42);
                                        auVar41._8_4_ = -(uint)(uVar27 < uVar43);
                                        auVar41._12_4_ = -(uint)(uVar27 < uVar44);
                                        auVar39 = auVar39 ^ (auVar39 ^ auVar47) & auVar41;
                                        auVar37 = NEON_ext(auVar39,auVar39,8,1);
                                        uVar36 = CONCAT13(auVar39[3] | auVar37[3],
                                                          CONCAT12(auVar39[2] | auVar37[2],
                                                                   CONCAT11(auVar39[1] | auVar37[1],
                                                                            auVar39[0] | auVar37[0])
                                                                  ));
                                        uVar36 = uVar36 | (uint)(CONCAT17(auVar39[7] | auVar37[7],
                                                                          CONCAT16(auVar39[6] |
                                                                                   auVar37[6],
                                                                                   CONCAT15(auVar39[
                                                  5] | auVar37[5],
                                                  CONCAT14(auVar39[4] | auVar37[4],uVar36)))) >>
                                                  0x20);
                                        if ((int)uVar36 < 0x400) {
                                          lVar26 = (long)(int)uVar36;
                                          sVar35 = param_1[lVar34 + 0x10];
                                          do {
                                            param_1[lVar26 + 0x130] = (short)lVar31 + sVar35 * 0x10;
                                            lVar26 = lVar26 + (ulong)(uint)(1 << (ulong)(uVar32 & 
                                                  0x1f));
                                          } while (lVar26 < 0x400);
                                          sVar35 = param_1[lVar31];
                                        }
                                        iVar33 = iVar33 + 1;
                                        iVar29 = iVar29 + 1;
                                        lVar34 = lVar34 + 1;
                                      } while (iVar33 < sVar35);
                                    }
                                    lVar31 = lVar31 + 1;
                                    iVar29 = iVar29 << 1;
                                    uVar27 = uVar27 + 1;
                                  } while (lVar31 != 0xb);
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      goto LAB_0052b308;
    }
  }
  iVar25 = 0;
LAB_0052b308:
  if (*(long *)(lVar1 + 0x28) == local_38) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(iVar25);
}



// ========================================
// Function: FUN_0052b330
// Address: 0052b330
// ========================================

ulong FUN_0052b330(long *param_1,long param_2)

{
  bool bVar1;
  ulong uVar2;
  byte bVar3;
  ushort uVar4;
  short sVar5;
  ulong uVar6;
  ulong uVar7;
  uint uVar8;
  ulong uVar9;
  int iVar10;
  int iVar11;
  ulong uVar12;
  long lVar13;
  uint uVar14;
  uint uVar15;
  
  uVar9 = (ulong)*(uint *)(param_1 + 4);
  if ((int)*(uint *)(param_1 + 4) < 0xf) {
    uVar12 = param_1[2];
    uVar7 = param_1[3];
    uVar2 = uVar12;
    if (uVar12 <= (ulong)param_1[1]) {
      uVar2 = param_1[1];
    }
    do {
      iVar10 = (int)uVar9;
      if (uVar2 == uVar12) break;
      param_1[2] = uVar12 + 1;
      uVar7 = (ulong)*(byte *)(*param_1 + uVar12) << (uVar9 & 0x3f) | uVar7;
      uVar14 = iVar10 + 8;
      uVar9 = (ulong)uVar14;
      param_1[3] = uVar7;
      *(uint *)(param_1 + 4) = uVar14;
      uVar12 = uVar12 + 1;
    } while (iVar10 < 0x31);
  }
  else {
    uVar7 = param_1[3];
  }
  uVar4 = *(ushort *)(param_2 + (uVar7 & 0x3ff) * 2 + 0x260);
  uVar14 = uVar4 & 0xf;
  if ((uVar4 & 0xf) != 0 && (int)uVar14 <= (int)uVar9) {
    *(uint *)(param_1 + 4) = (int)uVar9 - uVar14;
    param_1[3] = uVar7 >> uVar14;
    return (ulong)(uVar4 >> 4);
  }
  iVar10 = 0;
  iVar11 = 0;
  uVar14 = 0;
  lVar13 = 1;
  do {
    uVar8 = (uint)uVar9;
    if ((int)uVar8 < 1) {
      uVar12 = param_1[2];
      uVar2 = uVar12;
      if (uVar12 <= (ulong)param_1[1]) {
        uVar2 = param_1[1];
      }
      do {
        uVar8 = (uint)uVar9;
        if (uVar2 == uVar12) {
          if ((int)uVar8 < 1) {
            uVar15 = 0;
            *(undefined1 *)((long)param_1 + 0x24) = 1;
            goto LAB_0052b3ec;
          }
          break;
        }
        uVar15 = uVar8 + 8;
        param_1[2] = uVar12 + 1;
        bVar3 = *(byte *)(*param_1 + uVar12);
        *(uint *)(param_1 + 4) = uVar15;
        uVar6 = uVar9 & 0x3f;
        uVar9 = (ulong)uVar15;
        uVar7 = (ulong)bVar3 << uVar6 | uVar7;
        param_1[3] = uVar7;
        bVar1 = (int)uVar8 < 0x31;
        uVar12 = uVar12 + 1;
        uVar8 = uVar15;
      } while (bVar1);
    }
    uVar15 = (uint)uVar7 & 1;
    uVar7 = uVar7 >> 1;
    uVar9 = (ulong)(uVar8 - 1);
    *(uint *)(param_1 + 4) = uVar8 - 1;
    param_1[3] = uVar7;
LAB_0052b3ec:
    sVar5 = *(short *)(param_2 + lVar13 * 2);
    uVar15 = uVar15 | uVar14;
    if ((int)(uVar15 - (int)sVar5) < iVar11) {
      return (long)*(short *)(param_2 + (long)(int)((iVar10 - iVar11) + uVar15) * 2 + 0x20);
    }
    lVar13 = lVar13 + 1;
    uVar14 = uVar15 << 1;
    iVar11 = (iVar11 + sVar5) * 2;
    iVar10 = iVar10 + sVar5;
    if (lVar13 == 0x10) {
      return 0xffffffff;
    }
  } while( true );
}



// ========================================
// Function: FUN_0052b4b8
// Address: 0052b4b8
// ========================================

undefined8 * FUN_0052b4b8(long *param_1,byte *param_2)

{
  ulong uVar1;
  undefined8 *puVar2;
  long lVar3;
  byte *pbVar4;
  undefined8 *puVar5;
  long lVar6;
  long lVar7;
  undefined8 uVar8;
  long lVar9;
  ulong uVar10;
  byte *pbVar11;
  byte *pbVar12;
  byte *pbVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  
  lVar3 = tpidr_el0;
  lVar6 = *(long *)(lVar3 + 0x28);
  pbVar11 = (byte *)*param_1;
  pbVar13 = (byte *)param_1[1];
  lVar7 = (long)pbVar13 - (long)pbVar11 >> 3;
  uVar1 = lVar7 * 0x6db6db6db6db6db7 + 1;
  if (uVar1 < 0x492492492492493) {
    lVar9 = param_1[2] - (long)pbVar11 >> 3;
    uVar10 = lVar9 * -0x2492492492492492;
    if (uVar10 < uVar1 || uVar10 - uVar1 == 0) {
      uVar10 = uVar1;
    }
    if (0x249249249249248 < (ulong)(lVar9 * 0x6db6db6db6db6db7)) {
      uVar10 = 0x492492492492492;
    }
    if (uVar10 == 0) {
      lVar9 = 0;
    }
    else {
      if (0x492492492492492 < uVar10) goto LAB_0052b6dc;
      lVar9 = FUN_005a5d4c(uVar10 * 0x38);
    }
    puVar5 = (undefined8 *)(lVar9 + lVar7 * 8);
    if ((*param_2 & 1) == 0) {
      uVar14 = *(undefined8 *)param_2;
      uVar8 = *(undefined8 *)(param_2 + 0x10);
      puVar5[1] = *(undefined8 *)(param_2 + 8);
      *puVar5 = uVar14;
      puVar5[2] = uVar8;
    }
    else {
                    /* try { // try from 0052b5c0 to 0052b5c3 has its CatchHandler @ 0052b6f0 */
      FUN_00251fc8(puVar5,*(undefined8 *)(param_2 + 0x10),*(undefined8 *)(param_2 + 8));
      pbVar11 = (byte *)*param_1;
      pbVar13 = (byte *)param_1[1];
    }
    uVar8 = *(undefined8 *)(param_2 + 0x18);
    uVar15 = *(undefined8 *)(param_2 + 0x29);
    uVar14 = *(undefined8 *)(param_2 + 0x21);
    lVar7 = lVar9 + lVar7 * 8;
    puVar2 = puVar5 + 7;
    *(undefined8 *)(lVar7 + 0x20) = *(undefined8 *)(param_2 + 0x20);
    *(undefined8 *)(lVar7 + 0x18) = uVar8;
    *(undefined8 *)(lVar7 + 0x29) = uVar15;
    *(undefined8 *)(lVar7 + 0x21) = uVar14;
    pbVar12 = pbVar11;
    if (pbVar13 != pbVar11) {
      do {
        uVar14 = *(undefined8 *)(pbVar13 + -0x30);
        uVar8 = *(undefined8 *)(pbVar13 + -0x38);
        puVar5[-5] = *(undefined8 *)(pbVar13 + -0x28);
        puVar5[-6] = uVar14;
        puVar5[-7] = uVar8;
        pbVar12 = pbVar13 + -0xf;
        uVar8 = *(undefined8 *)(pbVar13 + -0x17);
        uVar15 = *(undefined8 *)(pbVar13 + -0x18);
        uVar14 = *(undefined8 *)(pbVar13 + -0x20);
        pbVar13[-0x30] = 0;
        pbVar13[-0x2f] = 0;
        pbVar13[-0x2e] = 0;
        pbVar13[-0x2d] = 0;
        pbVar13[-0x2c] = 0;
        pbVar13[-0x2b] = 0;
        pbVar13[-0x2a] = 0;
        pbVar13[-0x29] = 0;
        pbVar13[-0x28] = 0;
        pbVar13[-0x27] = 0;
        pbVar13[-0x26] = 0;
        pbVar13[-0x25] = 0;
        pbVar13[-0x24] = 0;
        pbVar13[-0x23] = 0;
        pbVar13[-0x22] = 0;
        pbVar13[-0x21] = 0;
        pbVar13[-0x38] = 0;
        pbVar13[-0x37] = 0;
        pbVar13[-0x36] = 0;
        pbVar13[-0x35] = 0;
        pbVar13[-0x34] = 0;
        pbVar13[-0x33] = 0;
        pbVar13[-0x32] = 0;
        pbVar13[-0x31] = 0;
        pbVar13 = pbVar13 + -0x38;
        *(undefined8 *)((long)puVar5 + -0xf) = *(undefined8 *)pbVar12;
        *(undefined8 *)((long)puVar5 + -0x17) = uVar8;
        puVar5[-3] = uVar15;
        puVar5[-4] = uVar14;
        puVar5 = puVar5 + -7;
      } while (pbVar13 != pbVar11);
      pbVar11 = (byte *)param_1[1];
      pbVar12 = (byte *)*param_1;
    }
    *param_1 = (long)puVar5;
    param_1[1] = (long)puVar2;
    param_1[2] = lVar9 + uVar10 * 0x38;
    pbVar13 = pbVar11;
    while (pbVar4 = pbVar11, pbVar4 != pbVar12) {
      pbVar11 = pbVar4 + -0x38;
      pbVar13 = pbVar12;
      if ((*pbVar11 & 1) != 0) {
        free(*(void **)(pbVar4 + -0x28));
      }
    }
    if (pbVar13 != (byte *)0x0) {
      free(pbVar13);
    }
    if (*(long *)(lVar3 + 0x28) == lVar6) {
      return puVar2;
    }
  }
  else {
    if (*(long *)(lVar3 + 0x28) != lVar6) goto LAB_0052b714;
    FUN_0052b780(param_1);
LAB_0052b6dc:
    if (*(long *)(lVar3 + 0x28) == lVar6) {
                    /* WARNING: Subroutine does not return */
      FUN_0029fc3c();
    }
  }
LAB_0052b714:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0052b718
// Address: 0052b718
// ========================================

void FUN_0052b718(undefined8 *param_1)

{
  long lVar1;
  long lVar2;
  long lVar3;
  
  lVar1 = param_1[1];
  lVar3 = param_1[2];
  while (lVar2 = lVar3, lVar2 != lVar1) {
    param_1[2] = lVar2 + -0x38;
    lVar3 = lVar2 + -0x38;
    if ((*(byte *)(lVar2 + -0x38) & 1) != 0) {
      free(*(void **)(lVar2 + -0x28));
      lVar3 = param_1[2];
    }
  }
  if ((void *)*param_1 != (void *)0x0) {
    free((void *)*param_1);
    return;
  }
  return;
}



// ========================================
// Function: FUN_0052b780
// Address: 0052b780
// ========================================

void FUN_0052b780(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0029fbbc("vector");
}



// ========================================
// Function: FUN_0052b794
// Address: 0052b794
// ========================================

void FUN_0052b794(long *param_1)

{
  long lVar1;
  int iVar2;
  uint uVar3;
  long *__arg;
  long lVar4;
  ulong uVar5;
  long *plVar6;
  pthread_t pStack_78;
  pthread_attr_t pStack_70;
  long local_38;
  
  lVar1 = tpidr_el0;
  local_38 = *(long *)(lVar1 + 0x28);
  __arg = (long *)FUN_005a5d4c(0x10);
  lVar4 = param_1[1];
  *__arg = *param_1;
  __arg[1] = lVar4;
  if (lVar4 != 0) {
    FUN_005a7d60(1,lVar4 + 8);
  }
  pthread_attr_init(&pStack_70);
  pthread_attr_setstacksize(&pStack_70,0x400000);
  pthread_attr_setdetachstate(&pStack_70,1);
  iVar2 = pthread_create(&pStack_78,&pStack_70,FUN_0052b8a8,__arg);
  uVar3 = pthread_attr_destroy(&pStack_70);
  uVar5 = (ulong)uVar3;
  if (iVar2 != 0) {
    plVar6 = (long *)__arg[1];
    if ((plVar6 != (long *)0x0) && (lVar4 = FUN_005a7d90(0xffffffffffffffff,plVar6 + 1), lVar4 == 0)
       ) {
      (**(code **)(*plVar6 + 0x10))(plVar6);
      FUN_005605e0(plVar6);
    }
    free(__arg);
    uVar5 = FUN_00561ab4(*param_1 + 0x90,"atlas blocks: no thread could be started");
    *(undefined4 *)(*param_1 + 0x6a) = 1;
  }
  if (*(long *)(lVar1 + 0x28) == local_38) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(uVar5);
}



// ========================================
// Function: FUN_0052b8a8
// Address: 0052b8a8
// ========================================

undefined8 FUN_0052b8a8(long *param_1)

{
  long *plVar1;
  byte bVar2;
  long lVar3;
  int iVar4;
  id_t __who;
  long lVar5;
  pthread_t __target_thread;
  undefined ***pppuVar6;
  void *pvVar7;
  long lVar8;
  long lVar9;
  long *plVar10;
  undefined4 local_134;
  long local_130;
  long *local_128;
  undefined **local_120;
  long lStack_118;
  undefined8 local_110;
  undefined ***local_100;
  undefined1 auStack_e8 [160];
  long local_48;
  
  lVar3 = tpidr_el0;
  local_48 = *(long *)(lVar3 + 0x28);
  lVar8 = *param_1;
  plVar1 = (long *)param_1[1];
  if (plVar1 != (long *)0x0) {
    FUN_005a7d60(1,plVar1 + 1);
    plVar10 = (long *)param_1[1];
    if ((plVar10 != (long *)0x0) &&
       (lVar5 = FUN_005a7d90(0xffffffffffffffff,plVar10 + 1), lVar5 == 0)) {
      (**(code **)(*plVar10 + 0x10))(plVar10);
      FUN_005605e0(plVar10);
    }
  }
  free(param_1);
  __target_thread = pthread_self();
                    /* try { // try from 0052b924 to 0052b943 has its CatchHandler @ 0052bca0 */
  iVar4 = pthread_setname_np(__target_thread,"magic-atlas");
  __who = gettid(iVar4);
  iVar4 = setpriority(PRIO_PROCESS,__who,5);
  lVar5 = FUN_0055e594(iVar4);
  if ((*(byte *)(lVar8 + 0x69) & 1) != 0) goto LAB_0052bac8;
  local_120 = &PTR_FUN_005bff18;
  lVar9 = lVar8 + 0x19;
  if ((*(byte *)(lVar8 + 0x18) & 1) != 0) {
    lVar9 = *(long *)(lVar8 + 0x28);
  }
                    /* try { // try from 0052b98c to 0052b997 has its CatchHandler @ 0052bb68 */
  lStack_118 = lVar8;
  local_100 = &local_120;
  FUN_00533d90(&local_130,&local_120,lVar9,*(int *)(lVar8 + 0x30),*(undefined4 *)(lVar8 + 0x34),
               *(int *)(lVar8 + 0x30) << 2);
  if (local_100 == &local_120) {
    lVar9 = 4;
    pppuVar6 = &local_120;
LAB_0052b9b8:
    (*(code *)(*pppuVar6)[lVar9])();
  }
  else if (local_100 != (undefined ***)0x0) {
    lVar9 = 5;
    pppuVar6 = local_100;
    goto LAB_0052b9b8;
  }
  if (local_130 == 0) {
                    /* try { // try from 0052ba00 to 0052ba0f has its CatchHandler @ 0052bb54 */
    FUN_00561ab4(lVar8 + 0x90,"atlas blocks: the game\'s block textures were not found");
  }
  else if ((*(byte *)(lVar8 + 0x69) & 1) == 0) {
    local_134 = 0;
    if (*(char *)(lVar8 + 0x68) == '\0') {
                    /* try { // try from 0052ba14 to 0052ba2b has its CatchHandler @ 0052bb50 */
      FUN_00534174(&local_120,local_130,local_130 + 0x30,lVar8 + 0x38,&local_134);
    }
    else {
                    /* try { // try from 0052b9e8 to 0052b9fb has its CatchHandler @ 0052bb50 */
      FUN_00538a64(&local_120,local_130,local_130 + 0x30,&local_134);
    }
    pvVar7 = *(void **)(lVar8 + 0x70);
    if (pvVar7 != (void *)0x0) {
      *(void **)(lVar8 + 0x78) = pvVar7;
      free(pvVar7);
      *(undefined8 *)(lVar8 + 0x70) = 0;
      *(undefined8 *)(lVar8 + 0x78) = 0;
      *(undefined8 *)(lVar8 + 0x80) = 0;
    }
    *(long *)(lVar8 + 0x78) = lStack_118;
    *(undefined ***)(lVar8 + 0x70) = local_120;
    *(undefined8 *)(lVar8 + 0x80) = local_110;
    *(undefined8 *)(lVar8 + 0x88) = *(undefined8 *)(local_130 + 0x30);
    lVar9 = FUN_0055e594();
    FUN_0052bd18((double)(lVar9 - lVar5) / 1000000.0,auStack_e8);
                    /* try { // try from 0052ba8c to 0052ba97 has its CatchHandler @ 0052bb4c */
    FUN_00561ab4(lVar8 + 0x90,auStack_e8);
  }
  if ((local_128 != (long *)0x0) &&
     (lVar5 = FUN_005a7d90(0xffffffffffffffff,local_128 + 1), lVar5 == 0)) {
    (**(code **)(*local_128 + 0x10))(local_128);
    FUN_005605e0(local_128);
  }
LAB_0052bac8:
  bVar2 = *(byte *)(lVar8 + 0x18);
  pvVar7 = *(void **)(lVar8 + 0x28);
  *(undefined8 *)(lVar8 + 0x18) = 0;
  *(undefined8 *)(lVar8 + 0x20) = 0;
  *(undefined8 *)(lVar8 + 0x28) = 0;
  if ((bVar2 & 1) != 0) {
    free(pvVar7);
  }
  *(undefined4 *)(lVar8 + 0x6a) = 1;
  if ((plVar1 != (long *)0x0) && (lVar8 = FUN_005a7d90(0xffffffffffffffff,plVar1 + 1), lVar8 == 0))
  {
    (**(code **)(*plVar1 + 0x10))(plVar1);
    FUN_005605e0(plVar1);
  }
  if (*(long *)(lVar3 + 0x28) == local_48) {
    return 0;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}



// ========================================
// Function: FUN_0052bcc8
// Address: 0052bcc8
// ========================================

void FUN_0052bcc8(long param_1)

{
  long lVar1;
  long *plVar2;
  
  plVar2 = *(long **)(param_1 + 8);
  if ((plVar2 != (long *)0x0) && (lVar1 = FUN_005a7d90(0xffffffffffffffff,plVar2 + 1), lVar1 == 0))
  {
    (**(code **)(*plVar2 + 0x10))(plVar2);
    FUN_005605e0(plVar2);
    return;
  }
  return;
}



// ========================================
// Function: FUN_0052bd18
// Address: 0052bd18
// ========================================

void FUN_0052bd18(char *param_1)

{
  long lVar1;
  int iVar2;
  undefined8 in_x4;
  undefined8 in_x5;
  undefined8 in_x6;
  undefined8 in_x7;
  long lVar3;
  undefined8 local_90;
  undefined8 uStack_88;
  undefined8 local_80;
  undefined8 uStack_78;
  undefined1 *local_70;
  undefined1 **ppuStack_68;
  undefined8 *puStack_60;
  undefined8 uStack_58;
  
  lVar1 = tpidr_el0;
  lVar3 = *(long *)(lVar1 + 0x28);
  ppuStack_68 = &local_70;
  puStack_60 = &local_90;
  uStack_58 = 0xffffff80ffffffe0;
  local_90 = in_x4;
  uStack_88 = in_x5;
  local_80 = in_x6;
  uStack_78 = in_x7;
  local_70 = (undefined1 *)register0x00000008;
  iVar2 = vsnprintf(param_1,0xa0,
                    "atlas blocks: %d of %d cells recognised, %d with an id from this pack, in %.0f ms"
                    ,&local_70);
  if (*(long *)(lVar1 + 0x28) == lVar3) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(iVar2);
}

