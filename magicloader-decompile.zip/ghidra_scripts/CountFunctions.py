# @runtime PyGhidra

fm = currentProgram.getFunctionManager()

defined = 0
external = 0

for f in fm.getFunctions(True):
    if f.isExternal():
        external += 1
    else:
        defined += 1

print(f"DEFINED_FUNCTIONS={defined}")
print(f"EXTERNAL_FUNCTIONS={external}")
print(f"TOTAL_FUNCTIONS={defined + external}")
