// @category Analysis

import java.io.*;
import ghidra.app.decompiler.*;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;

public class DecompileAllFunctions extends GhidraScript {

    @Override
    protected void run() throws Exception {
        File output = new File(getScriptArgs().length > 0
            ? getScriptArgs()[0]
            : "/workspaces/Native/magicloader_decompiled.c");

        DecompInterface decomp = new DecompInterface();
        decomp.openProgram(currentProgram);

        FunctionManager fm = currentProgram.getFunctionManager();
        int total = 0, external = 0, success = 0, failed = 0;

        for (Function f : fm.getFunctions(true)) {
            if (f.isExternal()) {
                external++;
            } else {
                total++;
            }
        }

        println("Defined functions: " + total);
        println("External functions: " + external);

        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(output)))) {
            for (Function f : fm.getFunctions(true)) {
                monitor.checkCancelled();
                if (f.isExternal()) continue;

                DecompileResults result =
                    decomp.decompileFunction(f, 60, monitor);

                out.println("\n\n// ========================================");
                out.println("// Function: " + f.getName());
                out.println("// Address: " + f.getEntryPoint());
                out.println("// ========================================");

                if (result != null && result.decompileCompleted()
                        && result.getDecompiledFunction() != null) {
                    out.println(result.getDecompiledFunction().getC());
                    success++;
                } else {
                    out.println("// DECOMPILATION FAILED");
                    failed++;
                }

                if ((success + failed) % 50 == 0) {
                    out.flush();
                    println("Progress: " + (success + failed) + "/" + total);
                }
            }
        } finally {
            decomp.dispose();
        }

        println("Finished. Success: " + success + ", Failed: " + failed);
        println("Output: " + output.getAbsolutePath());
    }
}
