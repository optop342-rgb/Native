# @runtime PyGhidra

from pathlib import Path
from ghidra.app.decompiler import DecompInterface

OUTPUT_DIR = Path("/workspaces/Native/decompile_batches")
BATCH_SIZE = 700
TIMEOUT_SECONDS = 60

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

fm = currentProgram.getFunctionManager()
functions = [
    f for f in fm.getFunctions(True)
    if not f.isExternal()
]

functions.sort(key=lambda f: f.getEntryPoint().getOffset())

total = len(functions)
total_batches = (total + BATCH_SIZE - 1) // BATCH_SIZE

print("Total functions:", total)
print("Batch size:", BATCH_SIZE)
print("Total batches:", total_batches)

decomp = DecompInterface()

if not decomp.openProgram(currentProgram):
    raise RuntimeError("Decompiler could not open the program")

grand_success = 0
grand_failed = 0

try:
    for batch_index, start in enumerate(
        range(0, total, BATCH_SIZE), start=1
    ):
        batch = functions[start:start + BATCH_SIZE]

        output_file = OUTPUT_DIR / f"batch_{batch_index:03d}.c"
        summary_file = OUTPUT_DIR / f"batch_{batch_index:03d}_summary.txt"

        success = 0
        failed = 0

        print(f"Starting batch {batch_index}/{total_batches}: "
              f"{len(batch)} functions")

        with output_file.open("w", encoding="utf-8") as out:

            out.write(f"// Batch {batch_index}/{total_batches}\n")
            out.write(f"// Functions: {len(batch)}\n")

            for local_index, function in enumerate(batch, start=1):
                monitor.checkCancelled()

                name = function.getName()
                address = str(function.getEntryPoint())

                out.write("\n\n")
                out.write("// ========================================\n")
                out.write(f"// Function: {name}\n")
                out.write(f"// Address: {address}\n")
                out.write("// ========================================\n")

                try:
                    result = decomp.decompileFunction(
                        function, TIMEOUT_SECONDS, monitor
                    )

                    if (result is not None
                            and result.decompileCompleted()
                            and result.getDecompiledFunction() is not None):

                        out.write(
                            result.getDecompiledFunction().getC()
                        )
                        success += 1

                    else:
                        error = (
                            result.getErrorMessage()
                            if result is not None
                            else "No decompiler result"
                        )
                        out.write(f"\n// DECOMPILATION FAILED: {error}\n")
                        failed += 1

                except Exception as exc:
                    out.write(f"\n// ERROR: {str(exc)}\n")
                    failed += 1

                if local_index % 25 == 0:
                    out.flush()
                    print(
                        f"Batch {batch_index}: "
                        f"{local_index}/{len(batch)} processed"
                    )

        grand_success += success
        grand_failed += failed

        with summary_file.open("w", encoding="utf-8") as summary:
            summary.write(f"Batch: {batch_index}/{total_batches}\n")
            summary.write(f"Functions: {len(batch)}\n")
            summary.write(f"Successful: {success}\n")
            summary.write(f"Failed: {failed}\n")

        print(
            f"Batch {batch_index} complete | "
            f"Success: {success} | Failed: {failed}"
        )

finally:
    decomp.dispose()

print("ALL BATCHES FINISHED")
print("Total successful:", grand_success)
print("Total failed:", grand_failed)
print("Output directory:", str(OUTPUT_DIR))
