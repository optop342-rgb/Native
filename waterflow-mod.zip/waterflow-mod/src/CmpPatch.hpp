#pragma once
// Pure logic (no Android deps) so it can be unit-tested on a PC.
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>

namespace wf {

struct CmpInfo {
  uint32_t rn;   // register number
  uint32_t imm;  // 12-bit immediate
};

// "cmp wN, #imm12" (no shift) == SUBS wzr, wN, #imm12 -> 0x7100001F | imm<<10 | rn<<5
inline std::optional<CmpInfo> decodeCmpW(uint32_t w) {
  if ((w & 0xFFC0001Fu) != 0x7100001Fu) return std::nullopt;
  return CmpInfo{(w >> 5) & 0x1Fu, (w >> 10) & 0xFFFu};
}

inline uint32_t withImm(uint32_t w, uint32_t imm) {
  return (w & ~(0xFFFu << 10)) | ((imm & 0xFFFu) << 10);
}

inline uint32_t wordFromBytes(const uint8_t *b) {
  return uint32_t(b[0]) | (uint32_t(b[1]) << 8) | (uint32_t(b[2]) << 16) |
         (uint32_t(b[3]) << 24);
}

inline void wordToBytes(uint32_t w, uint8_t *b) {
  b[0] = uint8_t(w);
  b[1] = uint8_t(w >> 8);
  b[2] = uint8_t(w >> 16);
  b[3] = uint8_t(w >> 24);
}

// digits only, 1..4095. Anything else -> nullopt.
inline std::optional<uint32_t> parseLimit(std::string_view s) {
  while (!s.empty() && (s.front() == ' ' || s.front() == '\t')) s.remove_prefix(1);
  while (!s.empty() && (s.back() == ' ' || s.back() == '\t' || s.back() == '\r' ||
                        s.back() == '\n'))
    s.remove_suffix(1);
  if (s.empty() || s.size() > 4) return std::nullopt;
  uint32_t v = 0;
  for (char c : s) {
    if (c < '0' || c > '9') return std::nullopt;
    v = v * 10 + uint32_t(c - '0');
  }
  if (v < 1 || v > 4095) return std::nullopt;
  return v;
}

struct SiteSpec {
  enum class Kind { Off, Probe, Sig } kind{Kind::Off};
  uint64_t off{};          // Off/Probe: virtual address offset inside libminecraftpe.so
  std::string sig;         // Sig: byte pattern
  int64_t delta{};         // Sig: bytes from match to the cmp instruction
  uint32_t expectImm{7};   // value the cmp must currently have
  int line{};
};

inline std::string_view trim(std::string_view s) {
  while (!s.empty() && (s.front() == ' ' || s.front() == '\t')) s.remove_prefix(1);
  while (!s.empty() && (s.back() == ' ' || s.back() == '\t' || s.back() == '\r' ||
                        s.back() == '\n'))
    s.remove_suffix(1);
  return s;
}

inline bool parseNum(std::string_view s, uint64_t &out) {
  s = trim(s);
  if (s.empty()) return false;
  int base = 10;
  if (s.size() > 2 && s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) {
    base = 16;
    s.remove_prefix(2);
  }
  uint64_t v = 0;
  for (char c : s) {
    int d;
    if (c >= '0' && c <= '9') d = c - '0';
    else if (base == 16 && c >= 'a' && c <= 'f') d = c - 'a' + 10;
    else if (base == 16 && c >= 'A' && c <= 'F') d = c - 'A' + 10;
    else return false;
    if (v > (UINT64_MAX - uint64_t(d)) / uint64_t(base)) return false;
    v = v * uint64_t(base) + uint64_t(d);
  }
  out = v;
  return true;
}

// Line formats:
//   off   0xADDR [expectImm]
//   probe 0xADDR
//   sig   PATTERN | delta | expectImm
// Returns false for bad lines; comments/blank lines return true with nullopt.
inline bool parseSiteLine(std::string_view line, int lineNo,
                          std::optional<SiteSpec> &out, std::string &err) {
  out.reset();
  line = trim(line);
  if (line.empty() || line[0] == '#') return true;

  SiteSpec s;
  s.line = lineNo;
  auto sp = line.find_first_of(" \t");
  std::string_view kw = sp == std::string_view::npos ? line : line.substr(0, sp);
  std::string_view rest =
      sp == std::string_view::npos ? std::string_view{} : trim(line.substr(sp));

  if (kw == "off" || kw == "probe") {
    s.kind = kw == "off" ? SiteSpec::Kind::Off : SiteSpec::Kind::Probe;
    auto sp2 = rest.find_first_of(" \t");
    std::string_view a = sp2 == std::string_view::npos ? rest : rest.substr(0, sp2);
    if (!parseNum(a, s.off)) {
      err = "bad address";
      return false;
    }
    if (sp2 != std::string_view::npos) {
      uint64_t imm;
      if (!parseNum(rest.substr(sp2), imm) || imm > 4095) {
        err = "bad expected value";
        return false;
      }
      s.expectImm = uint32_t(imm);
    }
  } else if (kw == "sig") {
    auto p1 = rest.find('|');
    auto p2 = p1 == std::string_view::npos ? p1 : rest.find('|', p1 + 1);
    if (p1 == std::string_view::npos || p2 == std::string_view::npos) {
      err = "sig needs: PATTERN | delta | expectImm";
      return false;
    }
    s.kind = SiteSpec::Kind::Sig;
    s.sig = std::string(trim(rest.substr(0, p1)));
    uint64_t d, imm;
    std::string_view ds = trim(rest.substr(p1 + 1, p2 - p1 - 1));
    bool neg = !ds.empty() && ds[0] == '-';
    if (neg) ds.remove_prefix(1);
    if (s.sig.empty() || !parseNum(ds, d) || d > 0xFFFF) {
      err = "bad sig/delta";
      return false;
    }
    s.delta = neg ? -int64_t(d) : int64_t(d);
    if (!parseNum(rest.substr(p2 + 1), imm) || imm > 4095) {
      err = "bad expected value";
      return false;
    }
    s.expectImm = uint32_t(imm);
  } else {
    err = "unknown keyword (use off / probe / sig)";
    return false;
  }
  out = s;
  return true;
}

} // namespace wf
