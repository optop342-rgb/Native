// WaterFlow Limit - LeviLaunchroid native mod
// Patches "cmp wN, #imm" sites that decide the water flow limit (default 7).
// Every site is verified (instruction type + current value) BEFORE writing.
#include <dlfcn.h>
#include <link.h>

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <span>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>
#include <pl/memory/Patch.hpp>
#include <pl/memory/Signature.hpp>

#include "CmpPatch.hpp"

namespace {

constexpr const char *kLib = "libminecraftpe.so";
constexpr const char *kModuleId = "waterflow.limit";

bool endsWith(const char *s, const char *suffix) {
  if (!s || !suffix) return false;
  size_t a = std::strlen(s), b = std::strlen(suffix);
  return a >= b && std::strcmp(s + a - b, suffix) == 0;
}

uintptr_t findBaseIter() {
  struct Ctx {
    uintptr_t base;
  } ctx{0};
  dl_iterate_phdr(
      [](dl_phdr_info *info, size_t, void *data) -> int {
        auto *c = static_cast<Ctx *>(data);
        if (info->dlpi_name && endsWith(info->dlpi_name, kLib)) {
          c->base = static_cast<uintptr_t>(info->dlpi_addr);
          return 1;
        }
        return 0;
      },
      &ctx);
  return ctx.base;
}

uintptr_t findBaseMaps() {
  FILE *f = std::fopen("/proc/self/maps", "r");
  if (!f) return 0;
  char line[1024];
  uintptr_t found = 0;
  while (std::fgets(line, sizeof(line), f)) {
    unsigned long start = 0, end = 0, off = 0;
    char perms[8] = {};
    char path[512] = {};
    int n = std::sscanf(line, "%lx-%lx %7s %lx %*s %*s %511s", &start, &end, perms,
                        &off, path);
    if (n >= 5 && off == 0 && endsWith(path, kLib)) {
      found = static_cast<uintptr_t>(start);
      break;
    }
  }
  std::fclose(f);
  return found;
}

std::string hex(uint64_t v) {
  char b[32];
  std::snprintf(b, sizeof(b), "0x%llX", static_cast<unsigned long long>(v));
  return b;
}

std::string hexWord(uint32_t w) {
  char b[16];
  std::snprintf(b, sizeof(b), "%08X", w);
  return b;
}

class WaterFlowMod {
public:
  static WaterFlowMod &instance() {
    static WaterFlowMod inst;
    return inst;
  }

  WaterFlowMod() : mSelf(ll::mod::NativeMod::current()) {}
  ~WaterFlowMod() { stopWorker(); }

  bool load() {
    if (!mSelf) return false; // current() must be valid during registration
    std::error_code ec;
    std::filesystem::create_directories(mSelf->getConfigDir(), ec);
    std::filesystem::create_directories(mSelf->getDataDir(), ec);
    loadSites();
    std::lock_guard<std::mutex> lock(mMutex);
    writeStatusLocked();
    mSelf->getLogger().info("WaterFlow loaded ({} sites)", mSites.size());
    return true;
  }

  bool enable() {
    if (!mSelf) return false;
    bool ok =
        pl::modmenu::ModuleBuilder(kModuleId, "Water Flow Limit")
            .modId(mSelf->getId())
            .description("Pani kitne block tak behe (vanilla = 7). "
                         "Toggle ON karo, phir limit set karo.")
            .defaultEnabled(false)
            .onToggle([this](std::string_view, bool on) { onToggle(on); })
            .onConfigChanged([this](std::string_view, std::string_view key,
                                    std::string_view value) { onConfig(key, value); })
            .config("limit_slider", "Limit (slider)",
                    pl::modmenu::ConfigType::SliderInt, "7", "1", "100")
            .config("limit_text", "Limit (number likho)",
                    pl::modmenu::ConfigType::Text, "7")
            .registerModule();
    if (!ok) {
      mSelf->getLogger().error("Mod Menu registration failed");
      return false;
    }
    startWorker();
    return true;
  }

  bool disable() {
    stopWorker();
    if (mSelf) pl::modmenu::unregisterModule(kModuleId);
    std::lock_guard<std::mutex> lock(mMutex);
    mEnabled = false;
    restoreLocked();
    writeStatusLocked();
    return true;
  }

  bool unload() {
    stopWorker();
    return true;
  }

private:
  struct Site {
    wf::SiteSpec spec;
    uintptr_t addr{};
    uint32_t origWord{};
    uint32_t appliedImm{};
    bool valid{};
    bool patched{};
    std::string note;
    std::string name;
  };

  // ---- config / sites -------------------------------------------------------
  void loadSites() {
    std::lock_guard<std::mutex> lock(mMutex);
    mSites.clear();
    mParseErrors.clear();
    auto path = mSelf->getConfigDir() / "sites.txt";
    std::ifstream in(path);
    if (!in) {
      mParseErrors.push_back("sites.txt not found: " + path.string());
      return;
    }
    std::string line;
    int n = 0;
    while (std::getline(in, line)) {
      ++n;
      std::optional<wf::SiteSpec> spec;
      std::string err;
      if (!wf::parseSiteLine(line, n, spec, err)) {
        mParseErrors.push_back("line " + std::to_string(n) + ": " + err);
        continue;
      }
      if (!spec) continue;
      Site s;
      s.spec = *spec;
      s.name = "waterflow.site" + std::to_string(mSites.size());
      mSites.push_back(std::move(s));
    }
  }

  // ---- worker: wait for libminecraftpe.so ----------------------------------
  void startWorker() {
    stopWorker();
    mStop = false;
    mWorker = std::thread([this] {
      using namespace std::chrono_literals;
      for (int i = 0; i < 1200 && !mStop; ++i) {
        bool viaMaps = false;
        uintptr_t b = findBaseIter();
        if (!b) {
          b = findBaseMaps();
          viaMaps = b != 0;
        }
        if (b) {
          onLibReady(b, viaMaps);
          return;
        }
        std::this_thread::sleep_for(500ms);
      }
      std::lock_guard<std::mutex> lock(mMutex);
      mStatusExtra = "libminecraftpe.so NOT found (gave up)";
      writeStatusLocked();
    });
  }

  void stopWorker() {
    mStop = true;
    if (mWorker.joinable() && mWorker.get_id() != std::this_thread::get_id())
      mWorker.join();
  }

  void onLibReady(uintptr_t base, bool viaMaps) {
    std::lock_guard<std::mutex> lock(mMutex);
    mBase = base;
    mStatusExtra = std::string("base=") + hex(base) + (viaMaps ? " (via /proc/maps)" : "");
    resolveLocked();
    mReady = true;
    if (mEnabled) applyLocked();
    writeStatusLocked();
  }

  // ---- core logic (all *Locked need mMutex) ---------------------------------
  static bool readWord(uintptr_t addr, uint32_t &w) {
    auto b = pl::memory::readBytes(addr, 4);
    if (b.size() != 4) return false;
    w = wf::wordFromBytes(b.data());
    return true;
  }

  static bool writeWord(uintptr_t addr, uint32_t w, const std::string &name) {
    uint8_t b[4];
    wf::wordToBytes(w, b);
    if (!pl::memory::writeBytes(addr, std::span<const uint8_t>(b, 4), name)) return false;
    uint32_t rb = 0;
    return readWord(addr, rb) && rb == w;
  }

  void resolveLocked() {
    for (auto &s : mSites) {
      s.valid = false;
      s.addr = 0;
      using K = wf::SiteSpec::Kind;
      if (s.spec.kind == K::Sig) {
        uintptr_t m = pl::memory::resolveSignature(s.spec.sig, kLib);
        if (!m) {
          s.note = "SKIP: signature not found";
          continue;
        }
        s.addr = static_cast<uintptr_t>(static_cast<int64_t>(m) + s.spec.delta);
      } else {
        s.addr = mBase + static_cast<uintptr_t>(s.spec.off);
      }
      uint32_t w = 0;
      if (!readWord(s.addr, w)) {
        s.note = "SKIP: address not readable";
        continue;
      }
      auto cmp = wf::decodeCmpW(w);
      if (!cmp) {
        s.note = "SKIP: bytes " + hexWord(w) + " are not 'cmp wN,#imm'";
        continue;
      }
      std::string info = "cmp w" + std::to_string(cmp->rn) + ", #" +
                         std::to_string(cmp->imm) + " (word " + hexWord(w) + ")";
      if (s.spec.kind == K::Probe) {
        s.note = "PROBE ok: " + info + " [read-only]";
        continue;
      }
      if (cmp->imm != s.spec.expectImm) {
        s.note = "SKIP: " + info + " but expected #" + std::to_string(s.spec.expectImm);
        continue;
      }
      s.origWord = w;
      s.valid = true;
      s.note = "READY: " + info;
    }
  }

  void applyLocked() {
    if (!mReady) return;
    const uint32_t want = mLimit.load();
    for (auto &s : mSites) {
      if (!s.valid) continue;
      if (s.patched && s.appliedImm == want) continue;
      uint32_t cur = 0;
      if (!readWord(s.addr, cur)) {
        s.note = "ERROR: cannot read";
        continue;
      }
      uint32_t ours = s.patched ? wf::withImm(s.origWord, s.appliedImm) : s.origWord;
      if (cur != ours && cur != s.origWord) {
        s.note = "SKIP: bytes changed by someone else (" + hexWord(cur) + ")";
        continue;
      }
      uint32_t nw = wf::withImm(s.origWord, want);
      if (writeWord(s.addr, nw, s.name)) {
        s.patched = true;
        s.appliedImm = want;
        s.note = "PATCHED: #" + std::to_string(s.spec.expectImm) + " -> #" +
                 std::to_string(want) + " (word " + hexWord(nw) + ")";
      } else {
        s.note = "ERROR: write failed";
      }
    }
  }

  void restoreLocked() {
    for (auto &s : mSites) {
      if (!s.patched) continue;
      if (writeWord(s.addr, s.origWord, s.name)) {
        s.patched = false;
        s.note = "RESTORED: #" + std::to_string(s.spec.expectImm);
      } else {
        s.note = "ERROR: restore failed";
      }
    }
  }

  void writeStatusLocked() {
    if (!mSelf) return;
    std::ostringstream o;
    o << "WaterFlow status\n";
    o << "enabled=" << (mEnabled ? "yes" : "no") << " limit=" << mLimit.load() << "\n";
    o << (mStatusExtra.empty() ? "waiting for libminecraftpe.so" : mStatusExtra) << "\n";
    o << "ready=" << (mReady ? "yes" : "no") << "\n";
    for (auto &e : mParseErrors) o << "CONFIG ERROR " << e << "\n";
    if (mSites.empty()) o << "No sites in config/sites.txt (add 'off 0xADDR 7' lines)\n";
    int i = 0;
    for (auto &s : mSites) {
      using K = wf::SiteSpec::Kind;
      o << "[" << i++ << "] "
        << (s.spec.kind == K::Sig ? "sig" : s.spec.kind == K::Probe ? "probe" : "off")
        << " ";
      if (s.spec.kind == K::Sig) o << "'" << s.spec.sig << "' ";
      else o << hex(s.spec.off) << " ";
      if (s.addr) o << "@" << hex(s.addr) << " ";
      o << ": " << (s.note.empty() ? "pending" : s.note) << "\n";
    }
    std::ofstream f(mSelf->getDataDir() / "status.txt", std::ios::trunc);
    if (f) f << o.str();
    mSelf->getLogger().info("{}", o.str());
  }

  // ---- menu callbacks -------------------------------------------------------
  void onToggle(bool on) {
    try {
      std::lock_guard<std::mutex> lock(mMutex);
      mEnabled = on;
      if (on) applyLocked();
      else restoreLocked();
      writeStatusLocked();
    } catch (...) {
    }
  }

  void onConfig(std::string_view key, std::string_view value) {
    try {
      if (key != "limit_slider" && key != "limit_text") return;
      auto dot = value.find('.');
      if (dot != std::string_view::npos) value = value.substr(0, dot);
      auto v = wf::parseLimit(value);
      if (!v) return; // ignore partial / invalid typing
      std::lock_guard<std::mutex> lock(mMutex);
      mLimit = *v;
      if (mEnabled) applyLocked();
      writeStatusLocked();
    } catch (...) {
    }
  }

  ll::mod::NativeMod *mSelf{};
  std::mutex mMutex;
  std::vector<Site> mSites;
  std::vector<std::string> mParseErrors;
  std::string mStatusExtra;
  uintptr_t mBase{};
  bool mReady{};
  bool mEnabled{};
  std::atomic<uint32_t> mLimit{7};
  std::atomic<bool> mStop{false};
  std::thread mWorker;
};

} // namespace

PL_REGISTER_MOD(WaterFlowMod, WaterFlowMod::instance())
