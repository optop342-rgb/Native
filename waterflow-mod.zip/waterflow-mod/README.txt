WATER FLOW LIMIT  (LeviLaunchroid native mod)

KAISE CHALAYE
1. waterflow-mod.zip repo me daalo -> GitHub Actions -> waterflow.levipack banega.
2. Launcher me import karo. Mod Menu -> "Water Flow Limit" -> toggle ON.
3. Limit: slider (1-100) ya "number likho" box (1-4095).

PEHLI BAAR (zaroori)
Mod abhi sirf PROBE karta hai (kuch badalta nahi). Game kholo, mod ON/OFF karo, phir:
  <mod folder>/data/status.txt  kholo.
Wahan har site ka result likha hota hai:
  PROBE ok: cmp w0, #7   -> address sahi, instruction asli hai
  SKIP: ...              -> address/version galat, kuch nahi chhua gaya
Jab sahi function pakka ho jaye, config/sites.txt me 'probe' ko 'off' karo.

SAFETY
- Patch se pehle: instruction 'cmp wN,#imm' hona chahiye aur imm == expected (7).
  Nahi to SKIP (crash nahi).
- Write ke baad dobara read karke verify.
- Toggle OFF / mod disable -> original bytes wapas.
- Koi aur bytes badal de to mod chhuta nahi.

NOTE
- Ye 'hook' nahi, instruction patch hai: cmp function ke beech me hota hai, usko hook nahi
  kar sakte. Signature se dhoondhna ho to: sig PATTERN | delta | 7
- liquid_depth 4-bit hai (0-15). 15 se bada limit ka asar game-logic par depend karta hai.
- Pehle naye test world me try karo.
