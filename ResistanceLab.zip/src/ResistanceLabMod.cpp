#include <pl/Mod.hpp>
#include <pl/memory/Hook.hpp>
#include <pl/ModMenu.hpp>
#include <pl/Logger.hpp>

#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>

// =====================================================================
// Zaphkiel RE offsets (game build scanned 2026-11-02)
// text segment fo == va, isliye ye direct lib-base offsets hain.
// Game update par Zaphkiel entt<> round dobara chalo aur badlo.
// =====================================================================
static constexpr uintptr_t OFF_SPEED_GET_AT    = 0xc057f48; // MovementSpeedComponent storage vtable slot0
static constexpr uintptr_t OFF_FRICTION_GET_AT = 0xc022688; // FrictionModifierOverrideComponent storage vtable slot0
static constexpr float ICE_FRICTION = 0.98f;                // ice-level slipperiness

static std::atomic<bool>  g_speedOn{false};
static std::atomic<bool>  g_iceOn{false};
static std::atomic<float> g_mult{2.0f};

using GetAtFn = float* (*)(void*, uint32_t);
static GetAtFn origSpeedGetAt    = nullptr;
static GetAtFn origFrictionGetAt = nullptr;

static thread_local float s_speedShadow;
static thread_local float s_frictionShadow;

// Speed hook: base component ko kabhi mutate nahi karte (no compounding).
// Har read par fresh shadow = original * multiplier return hota hai.
static float* hookSpeedGetAt(void* storage, uint32_t entity) {
    float* p = origSpeedGetAt(storage, entity);
    if (p && g_speedOn.load(std::memory_order_relaxed)) {
        s_speedShadow = (*p) * g_mult.load(std::memory_order_relaxed);
        return &s_speedShadow;
    }
    return p; // toggle OFF = 100% vanilla
}

// Friction hook: jab game friction override value puchhe, ice value do.
static float* hookFrictionGetAt(void* storage, uint32_t entity) {
    float* p = origFrictionGetAt(storage, entity);
    if (g_iceOn.load(std::memory_order_relaxed)) {
        s_frictionShadow = ICE_FRICTION;
        return &s_frictionShadow;
    }
    return p;
}

// =====================================================================
// libminecraftpe.so load base — /proc/self/maps se (SDK-independent)
// =====================================================================
static uintptr_t findLibBase(const char* libName) {
    FILE* f = std::fopen("/proc/self/maps", "r");
    if (!f) return 0;
    char line[512];
    uintptr_t base = 0;
    while (std::fgets(line, sizeof(line), f)) {
        if (!std::strstr(line, libName)) continue;
        uintptr_t start = 0;
        if (std::sscanf(line, "%lx-", &start) == 1) {
            if (base == 0 || start < base) base = start;
        }
    }
    std::fclose(f);
    return base;
}

class ResistanceLabMod : public pl::mod::NativeMod {
private:
    ll::mod::NativeMod &mSelf;
public:
    ResistanceLabMod() : mSelf(*ll::mod::NativeMod::current()) {}
public:
    bool enable() override {
        uintptr_t base = findLibBase("libminecraftpe.so");
        if (!base) {
            mSelf.getLogger().error("ResistanceLab: libminecraftpe.so base not found");
            return false;
        }

        mSpeedHook = pl::memory::HookHandle(
            reinterpret_cast<void*>(base + OFF_SPEED_GET_AT),
            reinterpret_cast<void*>(&hookSpeedGetAt),
            reinterpret_cast<void**>(&origSpeedGetAt));

        mIceHook = pl::memory::HookHandle(
            reinterpret_cast<void*>(base + OFF_FRICTION_GET_AT),
            reinterpret_cast<void*>(&hookFrictionGetAt),
            reinterpret_cast<void**>(&origFrictionGetAt));

        if (!mSpeedHook.installed()) {
            mSelf.getLogger().error("ResistanceLab: speed hook install failed");
            return false;
        }

        setupMenu();
        mSelf.getLogger().info("ResistanceLab enabled (speed={} , ice={})",
                                   g_speedOn.load(), g_iceOn.load());
        return true;
    }

    void disable() override {
        g_speedOn = false;
        g_iceOn   = false;
        g_mult    = 1.0f;
        mSpeedHook = {}; // RAII uninstall
        mIceHook   = {};
    }

private:
    pl::memory::HookHandle mSpeedHook;
    pl::memory::HookHandle mIceHook;

    void setupMenu() {
        pl::modmenu::ModuleBuilder("resistance.lab", "Resistance Lab")
            .modId(mSelf.getId())
            .description("Speed multiplier + ice-slide friction (singleplayer)")
            .registerModule();

        // TOGGLE 1: Speed/Resistance mod
        pl::modmenu::ButtonBuilder("resistance.speed_toggle", "Speed/Resistance Mod")
            .moduleId("resistance.lab")
            .modId(mSelf.getId())
            .label("Speed Mod: OFF")
            .behavior(pl::modmenu::ButtonBehavior::Toggle)
            .onEvent([](std::string_view, pl::modmenu::ButtonEvent ev, float state) {
                if (ev == pl::modmenu::ButtonEvent::StateChanged)
                    g_speedOn.store(state > 0.5f);
            })
            .registerButton();

        // Multiplier cycle: 0.5 -> 1 -> 1.5 -> 2 -> 3 -> 5
        pl::modmenu::ButtonBuilder("resistance.mult_cycle", "Multiplier")
            .moduleId("resistance.lab")
            .modId(mSelf.getId())
            .label("Cycle Multiplier")
            .behavior(pl::modmenu::ButtonBehavior::Click)
            .onEvent([](std::string_view, pl::modmenu::ButtonEvent ev, float) {
                if (ev != pl::modmenu::ButtonEvent::Click) return;
                static const float presets[] = {0.5f, 1.0f, 1.5f, 2.0f, 3.0f, 5.0f};
                static int idx = 3;
                idx = (idx + 1) % 6;
                g_mult.store(presets[idx]);
            })
            .registerButton();

        // TOGGLE 2: Ice slide
        pl::modmenu::ButtonBuilder("resistance.ice_toggle", "Ice Slide (Friction)")
            .moduleId("resistance.lab")
            .modId(mSelf.getId())
            .label("Ice Slide: OFF")
            .behavior(pl::modmenu::ButtonBehavior::Toggle)
            .onEvent([](std::string_view, pl::modmenu::ButtonEvent ev, float state) {
                if (ev == pl::modmenu::ButtonEvent::StateChanged)
                    g_iceOn.store(state > 0.5f);
            })
            .registerButton();
    }
};

// SDK ke registration macro se match karo (agar naam alag ho toh wahi use karo)
PL_REGISTER_MOD(ResistanceLabMod, ResistanceLabMod::instance())
