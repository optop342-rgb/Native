# Resistance Lab (LeviLauncher Native Mod)
Speed multiplier + ice-slide friction for MCPE singleplayer.
Build: GitHub Actions -> Artifacts -> ResistanceLab.levipack
Install: .levipack ko LeviLauncher mods folder mein drop karo.
