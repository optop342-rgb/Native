// Headless test: runs the real ImGui + Editor + TouchRouter code on the host (no GPU, no Android)
// and drives it with simulated touches. Build/run:  make -C tests run
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>

#include "Core.hpp"
#include "Editor.hpp"
#include "TouchRouter.hpp"
#include "imgui.h"

using namespace cm;

static int g_fail = 0;
#define CHECK(cond, msg)                                           \
  do {                                                             \
    if (!(cond)) {                                                 \
      std::printf("  FAIL: %s   (%s:%d)\n", msg, __FILE__, __LINE__); \
      ++g_fail;                                                    \
    } else {                                                       \
      std::printf("  ok:   %s\n", msg);                            \
    }                                                              \
  } while (0)

static const ImVec2 kDisp(2400, 1080);
static Library lib;
static TouchRouter router;
static Editor* ed;
static EditorHost host;
static int saves = 0, closes = 0;
static Pose lastCam;

static void frame(float dt = 1.f / 60.f) {
  ImGuiIO& io = ImGui::GetIO();
  io.DisplaySize = kDisp;
  io.DeltaTime = dt;
  router.beginFrame(io);
  ImGui::NewFrame();
  ed->draw(kDisp, dt, host);
  ImGui::Render();
}
static void frames(int n, float dt = 1.f / 60.f) {
  for (int i = 0; i < n; ++i) frame(dt);
}
static void touch(int action, int id, float x, float y) { router.push({action, id, x, y}); }
static void tapAt(float x, float y) {
  touch(0, 9, x, y);
  frames(3);
  touch(1, 9, x, y);
  frames(3);
}
static ImVec2 centerOf(const ButtonRec& b) { return ImVec2((b.mn.x + b.mx.x) * 0.5f, (b.mn.y + b.mx.y) * 0.5f); }
static bool tapButton(const char* label) {
  const ButtonRec* b = ed->findButton(label);
  if (!b) {
    std::printf("  (button '%s' not found)\n", label);
    return false;
  }
  const ImVec2 c = centerOf(*b);
  tapAt(c.x, c.y);
  return true;
}
static ImVec2 zoneCenter(ZoneId z) {
  ImVec2 a, b;
  router.zoneRect(z, a, b);
  return ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f);
}
static bool near(float a, float b, float eps) { return std::fabs(a - b) <= eps; }

int main() {
  // ------------------------------------------------------------- Core
  std::printf("[Core]\n");
  {
    Preset p;
    p.smooth = false;
    Pose a, b;
    a.x = 0; a.yaw = 350; b.x = 10; b.yaw = 10;
    p.addOrReplaceKey(10, b);
    p.addOrReplaceKey(0, a);
    CHECK(p.keys.size() == 2 && p.keys[0].t == 0 && p.keys[1].t == 10, "keys stay sorted");
    CHECK(p.addOrReplaceKey(0.02f, b) == 0 && p.keys.size() == 2, "key within 0.05s is replaced");
    p.keys[0].p = a;
    Pose m = samplePreset(p, 5);
    CHECK(near(m.x, 5, 1e-4f), "linear midpoint x");
    CHECK(near(std::fabs(m.yaw), 0.f, 1e-3f), "yaw 350 -> 10 goes through 0 (short way)");
    CHECK(samplePreset(p, -3).x == 0 && samplePreset(p, 99).x == 10, "clamps before first / after last key");
    p.smooth = true;
    CHECK(near(samplePreset(p, 5).x, 5, 1e-3f), "catmull-rom midpoint (2 keys)");
    Preset p3 = p;
    Pose c; c.x = 5; p3.addOrReplaceKey(5, c);
    CHECK(near(samplePreset(p3, 5).x, 5, 1e-4f) && near(samplePreset(p3, 10).x, 10, 1e-4f), "smooth path passes through keys");
    Library l;
    l.slots[1] = p3;
    l.slots[1]->name = "Tab\tName";
    CHECK(saveLibrary("/tmp/cinemod_test.txt", l), "save library");
    Library l2;
    CHECK(loadLibrary("/tmp/cinemod_test.txt", l2) && !l2.slots[0] && l2.slots[1] && l2.slots[1]->keys.size() == 3, "load library round-trip");
    CHECK(l2.slots[1]->name == "Tab Name" && near(l2.slots[1]->keys[1].p.x, 5, 1e-4f), "name sanitised, values kept");
  }

  // ------------------------------------------------------------- ImGui setup
  ImGui::CreateContext();
  ImGuiIO& io = ImGui::GetIO();
  io.IniFilename = nullptr;
  ImFontConfig fc;
  fc.SizePixels = kFontBasePx;
  io.Fonts->AddFontDefault(&fc);
  unsigned char* px; int fw, fh;
  io.Fonts->GetTexDataAsRGBA32(&px, &fw, &fh);
  CHECK(fw > 0 && fh > 0, "font atlas builds (rectpack fallback works)");
  io.Fonts->SetTexID((ImTextureID)1);

  static Editor editor(lib, router);
  ed = &editor;
  host.gameTex = (ImTextureID)7;
  host.gameW = 2400;
  host.gameH = 1080;
  host.onSave = [] { ++saves; };
  host.onClose = [] { ++closes; };
  host.onCamera = [](const Pose& p) { lastCam = p; };
  frames(3);

  // ------------------------------------------------------------- navigation
  std::printf("[Navigation]\n");
  CHECK(ed->screen() == Screen::Main, "starts on Main screen");
  CHECK(ed->findButton("Presets") && !ed->findButton("+ Create New"), "Main shows only [Presets]");
  tapButton("Presets");
  CHECK(ed->screen() == Screen::Presets, "tap Presets -> Presets menu");
  CHECK(ed->findButton("Slot 1") && ed->findButton("Slot 2") && ed->findButton("Slot 3"), "3 slots listed");
  CHECK(ed->findButton("+ Create New") && ed->findButton("- Delete Slot") && ed->findButton("< Back"), "Create / Delete / Back present");

  tapButton("+ Create New");
  frames(2);
  CHECK(ed->createOpen(), "Create popup opens");
  CHECK(ed->findButton("input:name") != nullptr, "popup has Name field");
  const ButtonRec* nb = ed->findButton("Create");
  CHECK(nb != nullptr, "popup has Create button");
  tapButton("input:name");
  io.AddInputCharactersUTF8("Intro");
  frames(3);
  tapButton("Create");
  CHECK(ed->screen() == Screen::Editor && lib.slots[0] && lib.slots[0]->name == "Intro", "Create -> Editor with new preset in Slot 1");
  CHECK(saves >= 1, "creating a preset saves");
  frames(2);
  CHECK(ed->findButton("+ Add Key") && ed->findButton("- Delete Key") && ed->findButton("Save") && ed->findButton("Camera 1"), "Editor buttons present");

  // ------------------------------------------------------------- free camera + multitouch
  std::printf("[Free camera / multi-touch]\n");
  Pose start = ed->camera();
  ImVec2 jc = zoneCenter(ZJoystick), lc = zoneCenter(ZLook);
  ImVec2 ja, jb;
  router.zoneRect(ZJoystick, ja, jb);
  const float R = (jb.x - ja.x) * 0.5f;
  touch(0, 1, jc.x, jc.y - R * 0.9f);  // joystick: forward
  frames(30);
  CHECK(ed->camMode() == CamMode::Free && ed->camera().z > start.z + 1.f, "joystick forward moves camera (+z at yaw 0)");
  // second finger drags the look zone while the joystick is still held
  Pose beforeLook = ed->camera();
  touch(0, 2, lc.x, lc.y);
  frames(2);
  touch(2, 2, lc.x + 100, lc.y);
  frames(2);
  CHECK(near(ed->camera().yaw - beforeLook.yaw, 20.f, 1.5f) || near(std::fabs(ed->camera().yaw - beforeLook.yaw), 20.f, 1.5f), "second finger rotates view ~20 deg (100px * 2.0x)");
  Pose mid = ed->camera();
  frames(20);
  CHECK(ed->camera().z != mid.z || ed->camera().x != mid.x, "joystick still moving while look finger is down (true multi-touch)");
  touch(1, 2, lc.x + 100, lc.y);
  touch(1, 1, jc.x, jc.y - R * 0.9f);
  frames(3);
  Pose stopped = ed->camera();
  frames(10);
  CHECK(near(ed->camera().z, stopped.z, 1e-4f), "camera stops when fingers lift");

  ImVec2 uc = zoneCenter(ZUp);
  float y0 = ed->camera().y;
  touch(0, 3, uc.x, uc.y);
  frames(30);
  touch(1, 3, uc.x, uc.y);
  frames(3);
  CHECK(ed->camera().y > y0 + 1.f, "hold Up raises camera");
  ImVec2 dcn = zoneCenter(ZDown);
  y0 = ed->camera().y;
  touch(0, 3, dcn.x, dcn.y);
  frames(30);
  touch(1, 3, dcn.x, dcn.y);
  frames(3);
  CHECK(ed->camera().y < y0 - 1.f, "hold Down lowers camera");
  CHECK(near(lastCam.y, ed->camera().y, 1e-4f), "pose is pushed to host.onCamera every frame");

  // ------------------------------------------------------------- preview buttons
  std::printf("[Preview buttons]\n");
  ImVec2 c = zoneCenter(ZNight);
  tapAt(c.x, c.y);
  CHECK(ed->nightVision(), "moon button toggles night vision");
  c = zoneCenter(ZBright);
  tapAt(c.x, c.y);
  CHECK(ed->fullBright(), "sun button toggles full brightness");
  c = zoneCenter(ZNight);
  tapAt(c.x, c.y);
  CHECK(!ed->nightVision(), "moon toggles back off");
  c = zoneCenter(ZTools);
  tapAt(c.x, c.y);
  CHECK(ed->toolsOpen(), "[TLS] opens tools panel");
  frames(2);
  c = zoneCenter(ZExpand);
  tapAt(c.x, c.y);
  CHECK(ed->expanded(), "[+] expands preview");
  tapAt(zoneCenter(ZExpand).x, zoneCenter(ZExpand).y);
  CHECK(!ed->expanded(), "[+] again restores");

  // ------------------------------------------------------------- keys + timeline
  std::printf("[Keys / timeline]\n");
  ed->setPlayhead(0.f);
  frames(2);
  tapButton("+ Add Key");
  CHECK(lib.slots[0]->keys.size() == 1 && near(lib.slots[0]->keys[0].t, 0.f, 1e-4f), "Add Key at 0s");
  Pose far = ed->camera();
  far.x += 20; far.z += 20; far.yaw = wrapAngle(far.yaw + 90);
  ed->setCamera(far);
  ed->setPlayhead(8.f);
  frames(2);
  tapButton("+ Add Key");
  CHECK(lib.slots[0]->keys.size() == 2 && near(lib.slots[0]->keys[1].t, 8.f, 1e-4f), "Add Key at 8s");
  tapButton("- Delete Key");
  CHECK(lib.slots[0]->keys.size() == 1, "Delete Key removes the selected key");
  ed->setCamera(far);
  ed->setPlayhead(8.f);
  frames(2);
  tapButton("+ Add Key");
  CHECK(lib.slots[0]->keys.size() == 2, "key re-added");

  const ButtonRec* ruler = ed->findButton("timeline:ruler");
  CHECK(ruler != nullptr, "timeline ruler exists");
  if (ruler) {
    const float w = ruler->mx.x - ruler->mn.x;
    const float y = (ruler->mn.y + ruler->mx.y) * 0.5f;
    touch(0, 4, ruler->mn.x + w * 0.25f, y);
    frames(3);
    touch(2, 4, ruler->mn.x + w * 0.5f, y);
    frames(3);
    touch(1, 4, ruler->mn.x + w * 0.5f, y);
    frames(3);
    CHECK(near(ed->playhead(), 10.f, 0.3f), "dragging the ruler scrubs the playhead (20s timeline)");
    CHECK(ed->camMode() == CamMode::Follow, "scrubbing switches camera to Follow");
  }
  const ButtonRec* k1 = ed->findButton("timeline:key1");
  CHECK(k1 != nullptr, "second key diamond is on the timeline");
  if (k1) {
    const ImVec2 kc = centerOf(*k1);
    tapAt(kc.x, kc.y);
    CHECK(ed->selectedKey() == 1 && near(ed->playhead(), 8.f, 0.05f), "tapping a diamond selects it and jumps there");
  }

  // ------------------------------------------------------------- playback
  std::printf("[Playback]\n");
  ed->setPlayhead(0.f);
  frames(2);
  tapButton("Play");
  CHECK(ed->playing(), "Play starts playback");
  frames(60);
  CHECK(near(ed->playhead(), 1.0f, 0.12f), "playhead advances in real time (1s after 60 frames)");
  Preset& pr = *lib.slots[0];
  Pose expect = samplePreset(pr, ed->playhead());
  CHECK(near(lastCam.x, expect.x, 0.05f) && near(lastCam.z, expect.z, 0.05f), "playback pose == interpolated pose");
  tapButton("Pause");
  CHECK(!ed->playing(), "Pause stops playback");
  tapButton(">>");
  CHECK(near(ed->playhead(), 8.f, 0.05f), ">> jumps to next key");
  tapButton("<<");
  CHECK(near(ed->playhead(), 0.f, 0.05f), "<< jumps to previous key");
  ed->setPlayhead(7.9f);
  frames(1);
  tapButton("Play");
  frames(60 * 13);
  CHECK(!ed->playing() && near(ed->playhead(), 20.f, 0.01f), "playback stops by itself at the end (20s)");

  // ------------------------------------------------------------- save / back / delete / close
  std::printf("[Save / Back / Delete / Close]\n");
  int s0 = saves;
  tapButton("Save");
  CHECK(saves == s0 + 1, "Save calls host.onSave");
  tapButton("< Back");
  CHECK(ed->screen() == Screen::Presets, "Back -> Presets");
  CHECK(ed->findButton("Camera 1") != nullptr, "selected slot shows [Camera 1]");
  tapButton("- Delete Slot");
  CHECK(lib.slots[0].has_value(), "first tap on Delete only arms it");
  tapButton("Tap again to delete");
  CHECK(!lib.slots[0].has_value(), "second tap deletes the slot");
  tapButton("< Back");
  CHECK(ed->screen() == Screen::Main, "Back -> Main");
  tapButton("X");
  CHECK(closes == 1, "[X] calls host.onClose");

  // ------------------------------------------------------------- no stray ImGui state
  CHECK(ImGui::GetCurrentContext() != nullptr, "context alive, no ImGui assertion fired in whole run");
  ImGui::DestroyContext();
  std::printf("\n%s (%d failure%s)\n", g_fail ? "TESTS FAILED" : "ALL TESTS PASSED", g_fail, g_fail == 1 ? "" : "s");
  return g_fail ? 1 : 0;
}
