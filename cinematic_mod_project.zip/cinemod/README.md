# Cinematic Studio - LeviLauncher native mod (Android, arm64-v8a)

Mod Menu me **Cinematic Rec Mode** toggle -> ImGui editor khulta hai, game uske **preview box ke andar** dikhta hai
(frame capture + `ImGui::Image`), baaki UI: Presets (3 slots), Create popup, Editor (Add/Delete Key, Save),
joystick, up/down, night-vision (moon), full-bright (sun), [+] expand, [TLS] tools, playback bar, 0-20s timeline.

## Build
1. Android NDK (r25+) install karo, `ANDROID_NDK_HOME` set karo.
2. `./build.sh`  -> `dist/cinematic_mod/` aur `dist/cinematic_mod.levipack`
   - Internet chahiye (Preloader SDK GitHub se fetch hota hai). Offline: `PRELOADER_SDK_DIR=/path/to/preloader-android ./build.sh`
   - PC/NDK nahi hai? Project ko GitHub repo me daalo, `.github/workflows/build.yml` khud build karke artifact de dega.
3. Install: `.levipack` LeviLauncher me import karo, ya `dist/cinematic_mod/` folder native-mod folder me copy karo.
   Folder ka naam (`cinematic_mod`) hi mod id hai - baad me mat badalna.

## PC par UI test (bina phone ke)
`make -C tests run`  - asli ImGui + Editor + TouchRouter ko simulated touches se chalata hai
(navigation, create preset, joystick + look ek saath, keys, timeline scrub, playback, save/delete). ASan/UBSan clean.

## Abhi kya kaam KARTA hai aur kya NAHI
Verified (PC test): data model, interpolation, save/load, poora UI logic, multi-touch routing.
Verified (syntax-check, asli SDK headers ke saath): MyMod.cpp, GlHost.cpp, GameBridge.cpp.
**Phone par test nahi hua** - NDK yahan nahi tha. Pehli baar build karke ye cheezein dekhna:
- Editor khulta hai? Game preview box me dikhta hai ya black? (eglSwapBuffers hook + frame capture)
- Touch sahi jagah lag raha hai? (maine maana hai ki touch coords == screen pixels, action = Android MotionEvent codes)
- Naam type karte waqt keyboard aata hai, characters double to nahi?

**Game se judne wale hisse STUB hain** (`src/GameBridge.cpp`):
1. Spectator mode / free fly
2. Game HUD + touch buttons chhupana (abhi wo bhi preview me capture ho jaate hain)
3. **Game camera override** - isko bina hook ke game ka asli view editor camera ke saath nahi chalega.
   Abhi joystick/look sirf editor ke andar ka camera pose badalte hain (preview ke upar X/Y/Z dikhta hai).
   Keys, interpolation, playback pose sab sahi bante hain; bas game tak pahunchane wala hook baaki hai
   (`libminecraftpe.so` me camera update function ka signature chahiye, version-specific).

Night vision / full bright abhi **sirf preview ka post-process** hai (additive blend), game ka asli lighting nahi.

## ImGui zip me jo fix kiya
- `imconfig.h` missing tha -> add kiya.
- `imstb_rectpack.h` missing tha -> khaali placeholder (stb_truetype ka apna fallback packer use hota hai). Official file se badal sakte ho.
- Backend files `"../imgui.h"` include karti thi -> `"imgui.h"` kiya.
- `imgui_impl_android.cpp` build me nahi liya (single-touch hai); uski jagah `TouchRouter`. `imgui_demo.cpp` bhi nahi.

## Files
- `src/Core.*` data + interpolation + save/load | `src/Editor.*` poora ImGui UI | `src/TouchRouter.*` multi-touch
- `src/GlHost.*` EGL/GLES + ImGui frame loop | `src/GameBridge.*` game hooks (TODO) | `src/MyMod.cpp` mod entry
- Presets file: `<mod data dir>/presets.txt`

## Design se jo maine guess kiya
- `[TLS]` = Tools panel (look sensitivity, speed, FOV, smooth path, duration), `[+]` = preview expand (left panel chhupao).
- Create dabane par seedha Editor khulta hai.
- Playback row ka extra `[X]` ignore kiya (top-right ka [X] hi Close hai).
