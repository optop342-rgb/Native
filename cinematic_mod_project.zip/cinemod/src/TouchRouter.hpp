// TouchRouter.hpp - multi-touch routing.
//
// The stock ImGui Android backend is single-touch. We need a joystick, a look-drag
// and normal UI taps at the same time, so every finger is routed on its own:
//   * finger starts on a registered "zone"  -> owned by that zone (joystick, button, look)
//   * finger starts anywhere else           -> becomes the (single) ImGui mouse pointer
#pragma once
#include <array>
#include <mutex>
#include <vector>

#include "imgui.h"

namespace cm {

enum ZoneId { ZJoystick, ZUp, ZDown, ZNight, ZBright, ZExpand, ZTools, ZLook, ZCount };

struct TouchEv {
  int action = 0;  // Android MotionEvent action (low byte is used)
  int id = 0;      // pointer id
  float x = 0, y = 0;
};

class TouchRouter {
 public:
  // any thread
  void push(const TouchEv& e);

  // render thread -------------------------------------------------------
  void beginFrame(ImGuiIO& io);   // call BEFORE ImGui::NewFrame()
  void releaseAll(ImGuiIO& io);   // call when the editor closes

  // Editor registers zones while drawing; they take effect next frame.
  void beginZones();
  void setZone(ZoneId z, ImVec2 mn, ImVec2 mx);

  ImVec2 joystick() const { return joy_; }          // x right, y forward, both in [-1,1]
  bool held(ZoneId z) const { return held_[z]; }
  bool takeClick(ZoneId z);                          // true once per tap on a button zone
  ImVec2 takeLookDelta();                            // pixels since last call
  bool zoneRect(ZoneId z, ImVec2& mn, ImVec2& mx) const {  // for tests / debugging
    mn = cur_[z].mn;
    mx = cur_[z].mx;
    return cur_[z].active;
  }

 private:
  struct Zone {
    ImVec2 mn{0, 0}, mx{0, 0};
    bool active = false;
  };
  struct Ptr {
    int id = -1;
    int owner = -1;  // ZoneId, kOwnUI, or -1 (ignored)
    ImVec2 pos{0, 0};
  };
  static constexpr int kOwnUI = 100;

  int hitZone(ImVec2 p) const;
  Ptr* find(int id);
  void updateJoystick(ImVec2 p);

  std::mutex mu_;
  std::vector<TouchEv> queue_;

  std::array<Zone, ZCount> cur_{}, next_{};
  std::vector<Ptr> ptrs_;
  std::array<bool, ZCount> owned_{};
  std::array<bool, ZCount> held_{};
  std::array<bool, ZCount> click_{};
  ImVec2 joy_{0, 0};
  ImVec2 look_{0, 0};
  int uiPtr_ = -1;
};

}  // namespace cm
