// GameBridge.hpp - the ONLY place that talks to Minecraft's own code.
//
// STATUS: these are stubs. The preview/editor/timeline all work without them, but the
// real game camera will not move until applyCamera() is implemented.
#pragma once
#include "Core.hpp"

namespace cm::game {

void onEnter();                    // cinematic mode switched ON  (go spectator, hide HUD ...)
void onExit();                     // cinematic mode switched OFF (restore everything)
void applyCamera(const Pose& p);   // called every frame with the pose the editor wants

}  // namespace cm::game
