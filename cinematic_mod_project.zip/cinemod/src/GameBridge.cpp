#include "GameBridge.hpp"

#include <android/log.h>

#include <atomic>

// ---------------------------------------------------------------------------
// TODO (needs reverse engineering of libminecraftpe.so for your game version):
//
//  1. Spectator / free fly:   find the function that sets the local player's game mode
//                             (or send the "/gamemode spectator" command) and call it in onEnter();
//                             restore the old mode in onExit().
//  2. Hide HUD + touch UI:    hook the HUD render call (or the GUI-visible flag) in onEnter().
//  3. Camera override:        hook the per-frame camera / view-matrix update and, while
//                             `g_overrideCamera` is true, replace position / pitch / yaw / fov
//                             with the Pose given to applyCamera().
//
// How to wire a hook with this SDK (see MyMod.cpp for a working example with eglSwapBuffers):
//
//   uintptr_t addr = pl::memory::resolveSignature("AA BB ?? CC ...", "libminecraftpe.so");
//   pl::memory::hook((void*)addr, (void*)&myDetour, (void**)&g_origCameraFn);
//
// Signatures change with every Minecraft version, so keep them in one table here.
// ---------------------------------------------------------------------------

namespace cm::game {

namespace {
std::atomic<bool> g_overrideCamera{false};
std::atomic<bool> g_warned{false};
}  // namespace

void onEnter() {
  g_overrideCamera.store(true);
  __android_log_print(ANDROID_LOG_INFO, "CinematicMod", "cinematic mode ON (GameBridge is a stub: no spectator / HUD hide yet)");
}

void onExit() {
  g_overrideCamera.store(false);
  __android_log_print(ANDROID_LOG_INFO, "CinematicMod", "cinematic mode OFF");
}

void applyCamera(const Pose& /*p*/) {
  if (!g_overrideCamera.load()) return;
  if (!g_warned.exchange(true))
    __android_log_print(ANDROID_LOG_WARN, "CinematicMod",
                        "applyCamera(): no camera hook installed yet - the game view will not follow the editor camera");
  // TODO: store `p` in a mutex/atomic-protected slot that your camera detour reads.
}

}  // namespace cm::game
