// Editor.hpp - the whole cinematic editor UI (ImGui only, no GL / Android calls).
//
// Screens (matching the mock-ups):
//   Main    : left panel has only [Presets]
//   Presets : Slot 1..3, [+ Create New] [- Delete Slot] [< Back]; selected slot shows [Camera 1]
//   Editor  : [Camera 1] [+ Add Key] [- Delete Key] [< Back] [Save]
// Always visible: game preview window (joystick, up/down, night-vision, full-bright,
// [+] expand, [TLS] tools), playback bar and a 0..20s timeline with a Camera track.
#pragma once
#include <functional>
#include <string>
#include <vector>

#include "Core.hpp"
#include "TouchRouter.hpp"
#include "imgui.h"

namespace cm {

// The host rasterises the font at this size; the editor scales it by screenHeight/540.
inline constexpr float kFontBasePx = 26.f;

enum class Screen { Main, Presets, Editor };
enum class CamMode { Free, Follow };

struct EditorHost {
  ImTextureID gameTex = nullptr;       // captured game frame (nullptr = none yet)
  int gameW = 0, gameH = 0;
  ImDrawCallback additiveCb = nullptr; // sets additive blending (GL only), may be null
  std::function<void()> onClose;       // [X]
  std::function<void()> onSave;        // persist the library
  std::function<void(const Pose&)> onCamera;  // push the camera pose to the game
};

struct ButtonRec {
  std::string label;
  ImVec2 mn, mx;
};

class Editor {
 public:
  Editor(Library& lib, TouchRouter& touch) : lib_(lib), touch_(touch) {}

  void draw(const ImVec2& display, float dt, EditorHost& host);

  // ---- state access (used by the host-side tests) --------------------
  Screen screen() const { return screen_; }
  bool createOpen() const { return createOpen_; }
  int selectedSlot() const { return selSlot_; }
  int selectedKey() const { return selKey_; }
  float playhead() const { return playhead_; }
  void setPlayhead(float t) { playhead_ = t; }
  bool playing() const { return playing_; }
  CamMode camMode() const { return mode_; }
  const Pose& camera() const { return cam_; }
  void setCamera(const Pose& p) { cam_ = p; }
  bool nightVision() const { return nightVision_; }
  bool fullBright() const { return fullBright_; }
  bool expanded() const { return expanded_; }
  bool toolsOpen() const { return toolsOpen_; }
  const std::vector<ButtonRec>& buttons() const { return buttons_; }
  const ButtonRec* findButton(const std::string& label) const;

 private:
  enum class Icon { Up, Down, Moon, Sun, Text };

  Preset* cur();
  void applyStyle(float ui);
  void tick(float dt, EditorHost& host);
  void toast(const char* msg);

  bool button(const char* label, bool enabled = true, bool accent = false);
  bool zoneBtn(ZoneId z, ImVec2 c, float hw, float hh, Icon ic, const char* label, bool on);

  void drawTop(const ImVec2& disp, float ui, EditorHost& host);
  void drawLeft(float x, float y, float w, float h, float ui, EditorHost& host);
  void drawPreview(float x, float y, float w, float h, float ui, EditorHost& host);
  void drawTools(float x, float y, float w, float h, float ui);
  void drawBottom(float x, float y, float w, float h, float ui);
  void drawTimeline(float ui);
  void drawCreatePopup(const ImVec2& disp, float ui);

  void enterEditor();
  void addKey();
  void deleteKey();
  void follow();                 // camera := sample(playhead)

  Library& lib_;
  TouchRouter& touch_;
  EditorHost* host_ = nullptr;

  Screen screen_ = Screen::Main;
  CamMode mode_ = CamMode::Free;
  Pose cam_;
  int selSlot_ = 0;
  int selKey_ = -1;
  bool playing_ = false;
  float playhead_ = 0.f;
  float zoom_ = 1.f, scroll_ = 0.f;
  bool expanded_ = false, toolsOpen_ = false;
  bool nightVision_ = false, fullBright_ = false;
  float lookSens_ = 2.0f, moveSpeed_ = 6.0f;
  bool invertLook_ = false;

  bool createOpen_ = false, createPending_ = false;
  char nameBuf_[48] = "";
  int catIdx_ = 0;
  float deleteArm_ = 0.f;

  std::string toast_;
  float toastT_ = 0.f;
  float styleUi_ = -1.f;
  std::vector<ButtonRec> buttons_;
};

}  // namespace cm
