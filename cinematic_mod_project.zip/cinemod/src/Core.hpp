// Core.hpp - pure C++ data model + camera interpolation (no ImGui, no Android).
#pragma once
#include <filesystem>
#include <optional>
#include <string>
#include <vector>

namespace cm {

struct Pose {
  float x = 0, y = 64, z = 0;   // world position
  float pitch = 0, yaw = 0;     // degrees (Minecraft convention: pitch + = look down)
  float fov = 70;
};

struct Key {
  float t = 0;  // seconds
  Pose p;
};

struct Preset {
  std::string name = "Preset";
  std::string category = "Cinematic";
  float duration = 20.f;
  bool smooth = true;      // Catmull-Rom path instead of straight lines
  std::vector<Key> keys;   // always sorted by t

  // Adds a key at t (clamped to [0,duration]); if a key already exists within
  // 0.05s it is replaced. Returns the index of the key.
  int addOrReplaceKey(float t, const Pose& p);
  void removeKey(int index);
};

inline constexpr int kSlotCount = 3;

struct Library {
  std::optional<Preset> slots[kSlotCount];
};

extern const char* const kCategories[];
extern const int kCategoryCount;

float wrapAngle(float deg);                      // -> (-180, 180]
Pose samplePreset(const Preset& pr, float t);    // camera pose at time t

// Plain text format, one file for all slots.
bool saveLibrary(const std::filesystem::path& file, const Library& lib);
bool loadLibrary(const std::filesystem::path& file, Library& lib);

}  // namespace cm
