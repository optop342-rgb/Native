#include "Core.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <sstream>

namespace cm {

const char* const kCategories[] = {"Cinematic", "Action", "Dialogue", "Establishing", "Chase", "Custom"};
const int kCategoryCount = (int)(sizeof(kCategories) / sizeof(kCategories[0]));

float wrapAngle(float d) {
  d = std::fmod(d, 360.f);
  if (d > 180.f) d -= 360.f;
  if (d <= -180.f) d += 360.f;
  return d;
}

int Preset::addOrReplaceKey(float t, const Pose& p) {
  t = std::clamp(t, 0.f, duration);
  for (size_t i = 0; i < keys.size(); ++i) {
    if (std::fabs(keys[i].t - t) < 0.05f) {
      keys[i].p = p;
      return (int)i;
    }
  }
  Key k;
  k.t = t;
  k.p = p;
  auto it = std::upper_bound(keys.begin(), keys.end(), k,
                             [](const Key& a, const Key& b) { return a.t < b.t; });
  const auto pos = keys.insert(it, k);  // (separate statement: operand evaluation order of "a - b" is unspecified)
  return (int)(pos - keys.begin());
}

void Preset::removeKey(int i) {
  if (i >= 0 && i < (int)keys.size()) keys.erase(keys.begin() + i);
}

static float catmull(float p0, float p1, float p2, float p3, float u) {
  const float u2 = u * u, u3 = u2 * u;
  return 0.5f * ((2.f * p1) + (-p0 + p2) * u + (2.f * p0 - 5.f * p1 + 4.f * p2 - p3) * u2 +
                 (-p0 + 3.f * p1 - 3.f * p2 + p3) * u3);
}

Pose samplePreset(const Preset& pr, float t) {
  const auto& k = pr.keys;
  if (k.empty()) return Pose{};
  if (k.size() == 1 || t <= k.front().t) return k.front().p;
  if (t >= k.back().t) return k.back().p;

  size_t b = 1;
  while (b < k.size() && k[b].t < t) ++b;
  const size_t a = b - 1;
  const float span = k[b].t - k[a].t;
  const float u = span > 1e-6f ? (t - k[a].t) / span : 0.f;

  const Pose& P1 = k[a].p;
  const Pose& P2 = k[b].p;
  const Pose& P0 = (a > 0) ? k[a - 1].p : P1;
  const Pose& P3 = (b + 1 < k.size()) ? k[b + 1].p : P2;

  // yaw: always take the short way round
  auto unwrap = [](float ref, float v) { return ref + wrapAngle(v - ref); };
  const float y1 = P1.yaw;
  const float y2 = unwrap(y1, P2.yaw);
  const float y0 = unwrap(y1, P0.yaw);
  const float y3 = unwrap(y2, P3.yaw);

  Pose o;
  if (pr.smooth) {
    o.x = catmull(P0.x, P1.x, P2.x, P3.x, u);
    o.y = catmull(P0.y, P1.y, P2.y, P3.y, u);
    o.z = catmull(P0.z, P1.z, P2.z, P3.z, u);
    o.pitch = catmull(P0.pitch, P1.pitch, P2.pitch, P3.pitch, u);
    o.yaw = catmull(y0, y1, y2, y3, u);
    o.fov = catmull(P0.fov, P1.fov, P2.fov, P3.fov, u);
  } else {
    auto lerp = [u](float p, float q) { return p + (q - p) * u; };
    o.x = lerp(P1.x, P2.x);
    o.y = lerp(P1.y, P2.y);
    o.z = lerp(P1.z, P2.z);
    o.pitch = lerp(P1.pitch, P2.pitch);
    o.yaw = lerp(y1, y2);
    o.fov = lerp(P1.fov, P2.fov);
  }
  o.pitch = std::clamp(o.pitch, -90.f, 90.f);
  o.yaw = wrapAngle(o.yaw);
  o.fov = std::clamp(o.fov, 10.f, 120.f);
  return o;
}

// ---------------------------------------------------------------- save / load

static std::string clean(std::string s) {
  for (char& c : s)
    if (c == '\n' || c == '\r' || c == '\t') c = ' ';
  return s;
}

bool saveLibrary(const std::filesystem::path& file, const Library& lib) {
  std::error_code ec;
  if (file.has_parent_path()) std::filesystem::create_directories(file.parent_path(), ec);
  const std::filesystem::path tmp = file.string() + ".tmp";
  {
    std::ofstream f(tmp, std::ios::trunc);
    if (!f) return false;
    f << "CINEMOD 1\n";
    for (int i = 0; i < kSlotCount; ++i) {
      if (!lib.slots[i]) continue;
      const Preset& p = *lib.slots[i];
      char buf[256];
      f << "S " << i << "\n";
      f << "N " << clean(p.name) << "\n";
      f << "C " << clean(p.category) << "\n";
      std::snprintf(buf, sizeof buf, "D %.6g\nM %d\n", p.duration, p.smooth ? 1 : 0);
      f << buf;
      for (const Key& k : p.keys) {
        std::snprintf(buf, sizeof buf, "K %.6g %.6g %.6g %.6g %.6g %.6g %.6g\n", k.t, k.p.x, k.p.y,
                      k.p.z, k.p.pitch, k.p.yaw, k.p.fov);
        f << buf;
      }
      f << "E\n";
    }
    if (!f.good()) return false;
  }
  std::filesystem::rename(tmp, file, ec);
  return !ec;
}

bool loadLibrary(const std::filesystem::path& file, Library& lib) {
  std::ifstream f(file);
  if (!f) return false;
  std::string line;
  if (!std::getline(f, line) || line.rfind("CINEMOD", 0) != 0) return false;

  Library out;
  int slot = -1;
  Preset cur;
  bool open = false;
  while (std::getline(f, line)) {
    if (!line.empty() && line.back() == '\r') line.pop_back();
    if (line.size() < 1) continue;
    const char tag = line[0];
    const char* rest = line.size() > 2 ? line.c_str() + 2 : "";
    if (tag == 'S') {
      slot = std::atoi(rest);
      cur = Preset{};
      cur.keys.clear();
      open = slot >= 0 && slot < kSlotCount;
    } else if (!open) {
      continue;
    } else if (tag == 'N') {
      cur.name = rest;
    } else if (tag == 'C') {
      cur.category = rest;
    } else if (tag == 'D') {
      cur.duration = std::clamp((float)std::atof(rest), 1.f, 3600.f);
    } else if (tag == 'M') {
      cur.smooth = std::atoi(rest) != 0;
    } else if (tag == 'K') {
      Key k;
      if (std::sscanf(rest, "%f %f %f %f %f %f %f", &k.t, &k.p.x, &k.p.y, &k.p.z, &k.p.pitch,
                      &k.p.yaw, &k.p.fov) == 7)
        cur.keys.push_back(k);
    } else if (tag == 'E') {
      std::sort(cur.keys.begin(), cur.keys.end(),
                [](const Key& a, const Key& b) { return a.t < b.t; });
      if (!cur.keys.empty()) cur.duration = std::max(cur.duration, cur.keys.back().t);
      out.slots[slot] = cur;
      open = false;
    }
  }
  lib = std::move(out);
  return true;
}

}  // namespace cm
