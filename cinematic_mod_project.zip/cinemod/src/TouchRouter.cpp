#include "TouchRouter.hpp"

#include <algorithm>
#include <cfloat>
#include <cmath>

namespace cm {

void TouchRouter::push(const TouchEv& e) {
  std::lock_guard<std::mutex> l(mu_);
  if (queue_.size() < 1024) queue_.push_back(e);
}

void TouchRouter::beginZones() { next_.fill(Zone{}); }

void TouchRouter::setZone(ZoneId z, ImVec2 mn, ImVec2 mx) {
  next_[z].mn = mn;
  next_[z].mx = mx;
  next_[z].active = true;
}

bool TouchRouter::takeClick(ZoneId z) {
  const bool c = click_[z];
  click_[z] = false;
  return c;
}

ImVec2 TouchRouter::takeLookDelta() {
  ImVec2 d = look_;
  look_ = ImVec2(0, 0);
  return d;
}

int TouchRouter::hitZone(ImVec2 p) const {
  for (int z = 0; z < ZCount; ++z) {
    const Zone& zn = cur_[z];
    if (zn.active && p.x >= zn.mn.x && p.x <= zn.mx.x && p.y >= zn.mn.y && p.y <= zn.mx.y) return z;
  }
  return -1;
}

TouchRouter::Ptr* TouchRouter::find(int id) {
  for (Ptr& p : ptrs_)
    if (p.id == id) return &p;
  return nullptr;
}

void TouchRouter::updateJoystick(ImVec2 p) {
  const Zone& z = cur_[ZJoystick];
  const float cx = (z.mn.x + z.mx.x) * 0.5f, cy = (z.mn.y + z.mx.y) * 0.5f;
  const float r = std::max(1.f, (z.mx.x - z.mn.x) * 0.5f);
  float vx = (p.x - cx) / r, vy = (p.y - cy) / r;
  const float len = std::sqrt(vx * vx + vy * vy);
  if (len > 1.f) {
    vx /= len;
    vy /= len;
  }
  if (len < 0.10f) {
    vx = vy = 0.f;
  }
  joy_ = ImVec2(vx, -vy);  // screen up == forward
}

void TouchRouter::beginFrame(ImGuiIO& io) {
  cur_ = next_;  // zones registered during the previous frame

  std::vector<TouchEv> events;
  {
    std::lock_guard<std::mutex> l(mu_);
    events.swap(queue_);
  }

  for (const TouchEv& e : events) {
    const int a = e.action & 0xFF;
    const ImVec2 pos(e.x, e.y);

    const bool isDown = (a == 0 || a == 5);
    const bool isUp = (a == 1 || a == 6);
    const bool isCancel = (a == 3);
    const bool isMove = (a == 2);

    if (isDown) {
      Ptr* p = find(e.id);
      if (!p) {
        ptrs_.push_back(Ptr{});
        p = &ptrs_.back();
        p->id = e.id;
      }
      p->pos = pos;
      p->owner = -1;
      const int z = hitZone(pos);
      if (z >= 0) {
        if (!owned_[z]) {
          p->owner = z;
          owned_[z] = true;
          if (z == ZJoystick) updateJoystick(pos);
          else if (z != ZLook) held_[z] = true;
        }
      } else if (uiPtr_ < 0) {
        p->owner = kOwnUI;
        uiPtr_ = e.id;
        io.AddMousePosEvent(pos.x, pos.y);
        io.AddMouseButtonEvent(0, true);
      }
    } else if (isMove) {
      Ptr* p = find(e.id);
      if (!p) continue;
      const ImVec2 d(pos.x - p->pos.x, pos.y - p->pos.y);
      p->pos = pos;
      if (p->owner == ZLook) {
        look_.x += d.x;
        look_.y += d.y;
      } else if (p->owner == ZJoystick) {
        updateJoystick(pos);
      } else if (p->owner == kOwnUI) {
        io.AddMousePosEvent(pos.x, pos.y);
      }
    } else if (isUp || isCancel) {
      Ptr* p = find(e.id);
      if (!p) continue;
      const int owner = p->owner;
      if (owner == kOwnUI) {
        io.AddMousePosEvent(pos.x, pos.y);
        io.AddMouseButtonEvent(0, false);
        io.AddMousePosEvent(-FLT_MAX, -FLT_MAX);
        uiPtr_ = -1;
      } else if (owner == ZJoystick) {
        joy_ = ImVec2(0, 0);
        owned_[ZJoystick] = false;
      } else if (owner >= 0 && owner < ZCount) {
        if (owner != ZLook) {
          const Zone& zn = cur_[owner];
          const bool inside = pos.x >= zn.mn.x && pos.x <= zn.mx.x && pos.y >= zn.mn.y && pos.y <= zn.mx.y;
          if (isUp && inside) click_[owner] = true;
          held_[owner] = false;
        }
        owned_[owner] = false;
      }
      ptrs_.erase(ptrs_.begin() + (p - ptrs_.data()));
    }
  }
}

void TouchRouter::releaseAll(ImGuiIO& io) {
  {
    std::lock_guard<std::mutex> l(mu_);
    queue_.clear();
  }
  if (uiPtr_ >= 0) {
    io.AddMouseButtonEvent(0, false);
    io.AddMousePosEvent(-FLT_MAX, -FLT_MAX);
  }
  ptrs_.clear();
  owned_.fill(false);
  held_.fill(false);
  click_.fill(false);
  joy_ = ImVec2(0, 0);
  look_ = ImVec2(0, 0);
  uiPtr_ = -1;
}

}  // namespace cm
