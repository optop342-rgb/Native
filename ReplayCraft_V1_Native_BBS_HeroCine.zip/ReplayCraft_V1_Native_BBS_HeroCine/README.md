# ReplayCraft — HeroCine Studio V1 (LeviLauncher native mod)

A native C++ Preloader mod for LeviLauncher Android. V1 uses Dear ImGui for
the editor UI and the Preloader input API for touch/text input.

## V1 features implemented in source

- Native C++ mod lifecycle (`PL_REGISTER_MOD`).
- Mod Menu module **ReplayCraft Editor** opens the editor.
- Top-right **X** closes the editor and turns its module toggle off; it does not
  unload the native mod. The Mod Menu toggle opens it again.
- Dear ImGui overlay rendered from an EGL `eglSwapBuffers` hook.
- Android touch and committed text are bridged through the Preloader Input API.
- Preset slots 1–3, create/delete, category, save/load JSON.
- Camera keyframes with position, yaw, pitch and FOV.
- First key forced to 0 seconds; following keys use timeline playhead or
  HeroCine's distance/speed auto-time rule.
- Timeline ruler, zoom, playback, seek, select and drag keyframes.
- Smoothstep position interpolation and shortest-angle yaw interpolation.
- BBS FS-inspired editor layout: central viewport aperture, inspector panel,
  camera track timeline and compact controls. No BBS FS source/assets copied.

## Rendering/camera boundary

The supplied Preloader SDK exposes a generic native hook API, Android input
callbacks, native mod lifecycle and Mod Menu toggle. This project uses the
generic hook API on `eglSwapBuffers` to render Dear ImGui in the active EGL
context. The uploaded ImGui archive is incomplete for compilation, so CMake
fetches the complete upstream Dear ImGui v1.88 source. The center viewport is a transparent aperture, so the current live
Minecraft render appears behind it. It is not an independent offscreen camera
render texture and does not resize/reparent Minecraft's native EGL surface.

The supplied HeroCine addon calls Bedrock Script API
`player.camera.setCamera("minecraft:free", ...)` and uses Script API easing.
Those are JavaScript APIs, not C++ native exports. V1 ports HeroCine's camera
path data model, ordered frames, distance/speed timing, stop/playback state and
interpolation into C++. Applying sampled camera poses to the actual Minecraft
camera still requires a build-matched internal Bedrock camera adapter; no
unknown `libminecraftpe.so` signature has been guessed. As delivered, playback
runs the native path model and updates the editor pose readout; it does not yet
move the in-game camera.

## Build

Requirements:
- Android NDK (arm64-v8a),
- CMake 3.22+,
- Git and internet access for first configure (FetchContent dependencies).

Windows PowerShell:

```powershell
$env:ANDROID_NDK_HOME = "C:\Path\To\Android\Sdk\ndk\<version>"
.\scripts\build.ps1 -Clean
```

Linux/macOS:

```bash
export ANDROID_NDK_HOME="$HOME/Android/Sdk/ndk/<version>"
chmod +x scripts/build.sh
./scripts/build.sh
```

Output: `dist/ReplayCraft_V1.levipack`

The build downloads Preloader Android SDK 0.2.3, Dear ImGui v1.88 and
nlohmann/json v3.11.3. The output ABI defaults to `arm64-v8a`.
