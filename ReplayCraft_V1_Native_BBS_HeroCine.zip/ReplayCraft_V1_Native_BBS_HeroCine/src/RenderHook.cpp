#include "RenderHook.hpp"
#include "EditorUI.hpp"

#include <pl/Input.hpp>
#include <pl/memory/Hook.hpp>

#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <dlfcn.h>
#include <imgui.h>
#include <backends/imgui_impl_opengl3.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cfloat>
#include <mutex>
#include <string>

namespace replaycraft {
namespace {
using EglSwapBuffersFn = EGLBoolean (*)(EGLDisplay, EGLSurface);
EglSwapBuffersFn gOriginalSwapBuffers{};
pl::memory::HookHandle gSwapHook;
void* gEglLibrary{};
std::atomic_bool gImGuiReady{false};
EGLContext gInitializedContext{EGL_NO_CONTEXT};
std::mutex gInputMutex;
float gTouchX{-FLT_MAX};
float gTouchY{-FLT_MAX};
bool gTouchDown{false};
bool gTouchCaptured{false};
std::string gTextQueue;
std::chrono::steady_clock::time_point gPreviousFrame{};

EGLBoolean EglSwapBuffersDetour(EGLDisplay display, EGLSurface surface) {
    if (gOriginalSwapBuffers && IsEditorOpen()) {
        const EGLContext currentContext = eglGetCurrentContext();
        EGLint width = 0, height = 0;
        if (currentContext != EGL_NO_CONTEXT &&
            eglQuerySurface(display, surface, EGL_WIDTH, &width) == EGL_TRUE &&
            eglQuerySurface(display, surface, EGL_HEIGHT, &height) == EGL_TRUE &&
            width > 0 && height > 0) {

            if (!gImGuiReady.load()) {
                IMGUI_CHECKVERSION();
                ImGui::CreateContext();
                ImGui::StyleColorsDark();
                ImGui::GetIO().IniFilename = nullptr;
                ImGui::GetIO().LogFilename = nullptr;
                if (ImGui_ImplOpenGL3_Init("#version 300 es")) {
                    gInitializedContext = currentContext;
                    gImGuiReady.store(true);
                    gPreviousFrame = std::chrono::steady_clock::now();
                } else {
                    ImGui::DestroyContext();
                }
            }

            if (gImGuiReady.load() && currentContext == gInitializedContext) {
                const auto now = std::chrono::steady_clock::now();
                float dt = std::chrono::duration<float>(now - gPreviousFrame).count();
                gPreviousFrame = now;
                dt = std::clamp(dt, 1.0f / 240.0f, 0.1f);

                ImGui_ImplOpenGL3_NewFrame();
                ImGuiIO& io = ImGui::GetIO();
                io.DisplaySize = ImVec2(static_cast<float>(width), static_cast<float>(height));
                io.DisplayFramebufferScale = ImVec2(1.0f, 1.0f);
                io.DeltaTime = dt;

                {
                    std::lock_guard<std::mutex> lock(gInputMutex);
                    io.MousePos = ImVec2(gTouchX, gTouchY);
                    io.MouseDown[0] = gTouchDown;
                    if (!gTextQueue.empty()) {
                        io.AddInputCharactersUTF8(gTextQueue.c_str());
                        gTextQueue.clear();
                    }
                }

                ImGui::NewFrame();
                DrawEditorFrame(static_cast<float>(width), static_cast<float>(height), dt);
                ImGui::Render();
                ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
            }
        }
    }

    return gOriginalSwapBuffers ? gOriginalSwapBuffers(display, surface) : EGL_FALSE;
}

bool touchCallback(const pl::input::TouchEvent& event) {
    if (!IsEditorOpen()) {
        if (event.action == 1) {
            std::lock_guard<std::mutex> lock(gInputMutex);
            gTouchDown = false;
            gTouchCaptured = false;
        }
        return false;
    }

    bool captured = false;
    {
        std::lock_guard<std::mutex> lock(gInputMutex);
        gTouchX = event.x;
        gTouchY = event.y;

        if (event.action == 0) { // ACTION_DOWN
            gTouchDown = true;
            gTouchCaptured = IsPointOnEditorUI(event.x, event.y);
        } else if (event.action == 1) { // ACTION_UP
            gTouchDown = false;
            captured = gTouchCaptured;
            gTouchCaptured = false;
            return captured;
        } else if (event.action == 2) { // ACTION_MOVE
            captured = gTouchCaptured;
            return captured;
        }
        captured = gTouchCaptured;
    }

    // Captured panel gestures stay captured even when the finger moves outside
    // the panel; touches that begin in the transparent world aperture pass through.
    return captured;
}

bool textCallback(const pl::input::TextInputEvent& event) {
    if (!IsEditorOpen()) return false;
    std::lock_guard<std::mutex> lock(gInputMutex);
    if (gTextQueue.size() < 512) gTextQueue += event.text;
    return true;
}
}

bool InstallRenderHook() {
    if (gSwapHook.installed()) return true;
    gEglLibrary = dlopen("libEGL.so", RTLD_NOW);
    void* target = gEglLibrary ? dlsym(gEglLibrary, "eglSwapBuffers")
                               : dlsym(RTLD_DEFAULT, "eglSwapBuffers");
    if (!target) return false;

    gSwapHook = pl::memory::HookHandle(
        target,
        reinterpret_cast<void*>(&EglSwapBuffersDetour),
        reinterpret_cast<void**>(&gOriginalSwapBuffers),
        pl::memory::HookPriority::Low
    );
    return gSwapHook.installed();
}

void RemoveRenderHook() {
    gSwapHook.reset();
    gOriginalSwapBuffers = nullptr;
    if (gEglLibrary) {
        dlclose(gEglLibrary);
        gEglLibrary = nullptr;
    }
    // GL backend shutdown is intentionally not called here: unload() may run
    // away from the EGL render thread. The process tears down the context.
}

void InstallInputBridge() {
    static std::atomic_bool installed{false};
    if (installed.exchange(true)) return;
    pl::input::registerTouchCallback(touchCallback);
    pl::input::registerTextInputCallback(textCallback);
}
}
