#include "EditorUI.hpp"
#include "CameraEngine.hpp"

#include <pl/Input.hpp>
#include <pl/ModMenu.hpp>
#include <imgui.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <mutex>
#include <string>

namespace replaycraft {
namespace {
constexpr char kModuleId[] = "replaycraft_v1.editor";
CameraEngine gCamera;
std::filesystem::path gDataFile;
std::atomic_bool gEditorOpen{false};
std::atomic_bool gCloseRequested{false};
std::atomic_bool gResetUiRequested{false};
std::atomic_bool gPausePlaybackRequested{false};
std::mutex gBoundsMutex;

struct UiBounds {
    float width{0}, height{0};
    float leftX{0}, leftY{0}, leftW{0}, leftH{0};
    float rightX{0}, rightY{0}, rightW{0}, rightH{0};
    float timelineX{0}, timelineY{0}, timelineW{0}, timelineH{0};
    float closeX{0}, closeY{0};
    bool createModal{false};
    float modalX{0}, modalY{0}, modalW{0}, modalH{0};
} gBounds;

enum class Page { Main, Presets, Editor };
Page gPage{Page::Main};
bool gToolsVisible{true};
bool gAutoTiming{false};
float gZoom{1.0f};
float gVisibleSeconds{20.0f};
char gPresetName[64] = "Camera 1";
int gCategoryIndex{0};
const char* kCategories[] = {"Camera", "Scene", "Other"};
bool gNameKeyboardRequested{false};
int gTimelineDragKey{-1};
bool gStyleApplied{false};
bool gOpenCreatePopup{false};

struct Layout {
    float width{}, height{};
    float leftX{}, leftY{}, leftW{}, leftH{};
    float centerX{}, centerY{}, centerW{}, centerH{};
    float rightX{}, rightY{}, rightW{}, rightH{};
    float timelineX{}, timelineY{}, timelineW{}, timelineH{};
    float closeX{}, closeY{};
    float trackX{}, trackW{}, trackY{};
};

Layout layoutFor(float width, float height) {
    Layout l{};
    l.width = width; l.height = height;
    const float margin = std::clamp(width * 0.014f, 10.0f, 22.0f);
    const float top = 54.0f;
    const float bottom = std::clamp(height * 0.19f, 112.0f, 158.0f);
    l.leftX = margin; l.leftY = top;
    l.leftW = std::clamp(width * 0.18f, 154.0f, 228.0f);
    l.timelineX = margin; l.timelineW = width - 2.0f * margin;
    l.timelineH = bottom; l.timelineY = height - bottom - margin;
    l.leftH = l.timelineY - top - 12.0f;
    l.rightW = gToolsVisible ? std::clamp(width * 0.20f, 178.0f, 250.0f) : 38.0f;
    l.rightX = width - margin - l.rightW; l.rightY = top; l.rightH = l.leftH;
    l.centerX = l.leftX + l.leftW + 12.0f;
    l.centerY = top;
    l.centerW = std::max(160.0f, l.rightX - l.centerX - 12.0f);
    l.centerH = l.leftH;
    l.closeX = width - margin - 40.0f; l.closeY = 10.0f;
    l.trackX = l.timelineX + 88.0f;
    l.trackW = l.timelineW - 112.0f;
    l.trackY = l.timelineY + 78.0f;
    return l;
}

void saveData() {
    if (!gDataFile.empty()) gCamera.save(gDataFile);
}

void setBounds(const Layout& l, bool modal = false) {
    std::lock_guard<std::mutex> lock(gBoundsMutex);
    gBounds.width = l.width; gBounds.height = l.height;
    gBounds.leftX = l.leftX; gBounds.leftY = l.leftY; gBounds.leftW = l.leftW; gBounds.leftH = l.leftH;
    gBounds.rightX = l.rightX; gBounds.rightY = l.rightY; gBounds.rightW = l.rightW; gBounds.rightH = l.rightH;
    gBounds.timelineX = l.timelineX; gBounds.timelineY = l.timelineY;
    gBounds.timelineW = l.timelineW; gBounds.timelineH = l.timelineH;
    gBounds.closeX = l.closeX; gBounds.closeY = l.closeY;
    gBounds.createModal = modal;
    if (modal) {
        gBounds.modalX = l.centerX + l.centerW * 0.14f;
        gBounds.modalY = l.centerY + l.centerH * 0.22f;
        gBounds.modalW = l.centerW * 0.72f;
        gBounds.modalH = l.centerH * 0.56f;
    }
}

void styleEditor() {
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding = 8.0f;
    s.ChildRounding = 7.0f;
    s.FrameRounding = 5.0f;
    s.PopupRounding = 7.0f;
    s.ScrollbarRounding = 7.0f;
    s.WindowBorderSize = 1.0f;
    s.FrameBorderSize = 1.0f;
    s.ItemSpacing = ImVec2(8, 7);
    s.FramePadding = ImVec2(9, 7);
    s.Colors[ImGuiCol_WindowBg] = ImVec4(0.055f, 0.068f, 0.090f, 0.96f);
    s.Colors[ImGuiCol_ChildBg] = ImVec4(0.070f, 0.084f, 0.112f, 0.94f);
    s.Colors[ImGuiCol_PopupBg] = ImVec4(0.055f, 0.068f, 0.090f, 0.98f);
    s.Colors[ImGuiCol_Border] = ImVec4(0.26f, 0.32f, 0.42f, 0.72f);
    s.Colors[ImGuiCol_FrameBg] = ImVec4(0.13f, 0.16f, 0.21f, 1.0f);
    s.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.20f, 0.27f, 0.37f, 1.0f);
    s.Colors[ImGuiCol_Button] = ImVec4(0.15f, 0.19f, 0.26f, 1.0f);
    s.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.24f, 0.34f, 0.48f, 1.0f);
    s.Colors[ImGuiCol_ButtonActive] = ImVec4(0.27f, 0.40f, 0.58f, 1.0f);
    s.Colors[ImGuiCol_Header] = ImVec4(0.15f, 0.20f, 0.28f, 1.0f);
    s.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.22f, 0.31f, 0.44f, 1.0f);
    s.Colors[ImGuiCol_SliderGrab] = ImVec4(0.55f, 0.68f, 0.87f, 1.0f);
    s.Colors[ImGuiCol_CheckMark] = ImVec4(0.66f, 0.79f, 1.0f, 1.0f);
}

bool drawPresetsPanel(float panelW, float panelH) {
    bool enteredEditor = false;
    ImGui::BeginChild("##left-panel", ImVec2(panelW, panelH), true);
    if (gPage == Page::Main || gPage == Page::Presets) {
        if (ImGui::Button(gPage == Page::Presets ? "Presets  v" : "Presets", ImVec2(-1, 40))) {
            gPage = (gPage == Page::Presets) ? Page::Main : Page::Presets;
        }
        if (gPage == Page::Presets) {
            ImGui::Spacing();
            ImGui::TextDisabled("PROJECT SLOTS");
            for (int slot = 0; slot < 3; ++slot) {
                const auto* preset = gCamera.preset(slot);
                std::string label = "Slot " + std::to_string(slot + 1) + "  ";
                label += preset ? preset->name : "(Empty)";
                if (ImGui::Selectable(label.c_str(), false, 0, ImVec2(0, 36))) {
                    if (gCamera.selectPreset(slot)) {
                        gPage = Page::Editor;
                        enteredEditor = true;
                    }
                }
            }
            ImGui::Spacing();
            int used = 0;
            for (int i = 0; i < 3; ++i) used += gCamera.preset(i) ? 1 : 0;
            ImGui::BeginDisabled(used >= 3);
            if (ImGui::Button("+ Create New", ImVec2(-1, 34))) {
                gPresetName[0] = '\0';
                gCategoryIndex = 0;
                gOpenCreatePopup = true;
            }
            ImGui::EndDisabled();
            if (ImGui::Button("- Delete Slot", ImVec2(-1, 34))) {
                for (int slot = 2; slot >= 0; --slot) {
                    if (gCamera.preset(slot)) {
                        gCamera.deletePreset(slot);
                        saveData();
                        break;
                    }
                }
            }
            if (ImGui::Button("< Back", ImVec2(-1, 32))) gPage = Page::Main;
        }
    } else {
        ImGui::TextColored(ImVec4(0.63f, 0.75f, 0.93f, 1), "EDITOR");
        ImGui::Separator();
        const auto* preset = gCamera.activePreset();
        ImGui::TextWrapped("%s", preset ? preset->name.c_str() : "No preset");
        ImGui::Spacing();
        if (ImGui::Button("+ Add Key", ImVec2(-1, 36))) {
            gCamera.addKey();
            saveData();
        }
        if (ImGui::Button("- Delete Key", ImVec2(-1, 36))) {
            gCamera.deleteSelectedKey();
            saveData();
        }
        if (ImGui::Button("< Back", ImVec2(-1, 32))) {
            gCamera.pausePlayback();
            gPage = Page::Presets;
        }
        if (ImGui::Button("Save", ImVec2(-1, 32))) saveData();
        ImGui::Spacing();
        ImGui::TextDisabled("KEYFRAMES");
        if (preset) {
            ImGui::BeginChild("##key-list", ImVec2(0, 0), false);
            for (const auto& key : preset->keys) {
                const bool selected = key.id == gCamera.selectedKeyId();
                const std::string label = "K" + std::to_string(key.id) + "   " +
                                          std::to_string(key.time).substr(0, 4) + "s";
                if (ImGui::Selectable(label.c_str(), selected)) gCamera.selectKey(key.id);
            }
            ImGui::EndChild();
        }
    }
    ImGui::EndChild();
    return enteredEditor;
}

void drawTools(float panelW, float panelH) {
    if (!gToolsVisible) return;
    ImGui::BeginChild("##tools-panel", ImVec2(panelW, panelH), true);
    ImGui::TextColored(ImVec4(0.63f, 0.75f, 0.93f, 1), "TOOLS");
    ImGui::Separator();
    ImGui::TextDisabled("CAMERA TRANSFORM");
    CameraPose pose = gCamera.currentPose();
    bool changed = false;
    changed |= ImGui::DragFloat("X", &pose.position.x, 0.05f);
    changed |= ImGui::DragFloat("Y", &pose.position.y, 0.05f);
    changed |= ImGui::DragFloat("Z", &pose.position.z, 0.05f);
    changed |= ImGui::DragFloat("Yaw", &pose.yaw, 0.5f, -360.0f, 360.0f);
    changed |= ImGui::DragFloat("Pitch", &pose.pitch, 0.5f, -89.9f, 89.9f);
    changed |= ImGui::SliderFloat("FOV", &pose.fov, 30.0f, 110.0f);
    if (changed) {
        const auto before = gCamera.currentPose();
        gCamera.setCurrentPose(pose);
    }
    ImGui::Separator();
    ImGui::Checkbox("HeroCine auto timing", &gAutoTiming);
    gCamera.setAutoTiming(gAutoTiming);
    float speed = gCamera.cameraSpeed();
    if (ImGui::SliderFloat("Camera speed", &speed, 0.1f, 12.0f, "%.1f")) {
        gCamera.setCameraSpeed(speed);
    }
    if (ImGui::Button("TLS  Hide", ImVec2(-1, 30))) gToolsVisible = false;
    ImGui::EndChild();
}

void drawTimeline(float width, float height, float x, float y) {
    ImGui::SetCursorPos(ImVec2(x, y));
    ImGui::BeginChild("##timeline", ImVec2(width, height), true);
    ImGui::BeginGroup();
    ImGui::TextColored(ImVec4(0.63f, 0.75f, 0.93f, 1), "TIMELINE");
    ImGui::SameLine(100);
    if (ImGui::SmallButton("<<")) gCamera.setPlayhead(0.0f);
    ImGui::SameLine();
    if (ImGui::SmallButton(gCamera.isPlaying() ? "Pause" : "Play")) {
        if (gCamera.isPlaying()) gCamera.pausePlayback();
        else gCamera.startPlayback();
    }
    ImGui::SameLine();
    if (ImGui::SmallButton(">>")) gCamera.setPlayhead(gCamera.duration());
    ImGui::SameLine(width - 150);
    if (ImGui::SmallButton("-")) {
        gZoom = std::clamp(gZoom - 0.25f, 0.5f, 4.0f);
        gVisibleSeconds = 20.0f / gZoom;
    }
    ImGui::SameLine();
    ImGui::Text("%.2fx", gZoom);
    ImGui::SameLine();
    if (ImGui::SmallButton("+")) {
        gZoom = std::clamp(gZoom + 0.25f, 0.5f, 4.0f);
        gVisibleSeconds = 20.0f / gZoom;
    }
    ImGui::EndGroup();

    const float labelW = 72.0f;
    const float rowH = 34.0f;
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);
    ImGui::Text("Camera");
    ImGui::SameLine(labelW);
    const float trackW = std::max(120.0f, ImGui::GetContentRegionAvail().x);
    const ImVec2 trackStart = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("##camera-track", ImVec2(trackW, rowH));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float centerY = trackStart.y + rowH * 0.5f;
    dl->AddLine(ImVec2(trackStart.x, centerY), ImVec2(trackStart.x + trackW, centerY),
                IM_COL32(110, 130, 160, 220), 2.0f);
    for (int tick = 0; tick <= 4; ++tick) {
        const float tx = trackStart.x + trackW * (static_cast<float>(tick) / 4.0f);
        dl->AddLine(ImVec2(tx, trackStart.y + 1), ImVec2(tx, trackStart.y + rowH - 1),
                    IM_COL32(65, 78, 100, 220), 1.0f);
        char label[16];
        std::snprintf(label, sizeof(label), "%.0fs", gVisibleSeconds * tick / 4.0f);
        dl->AddText(ImVec2(tx - 7, trackStart.y - 13), IM_COL32(150, 165, 188, 255), label);
    }

    const auto* preset = gCamera.activePreset();
    if (preset) {
        for (const auto& key : preset->keys) {
            const float alpha = std::clamp(key.time / std::max(0.1f, gVisibleSeconds), 0.0f, 1.0f);
            const ImVec2 c(trackStart.x + alpha * trackW, centerY);
            const ImU32 color = key.id == gCamera.selectedKeyId()
                                ? IM_COL32(255, 204, 104, 255)
                                : IM_COL32(185, 207, 240, 255);
            dl->AddQuadFilled(ImVec2(c.x, c.y - 7), ImVec2(c.x + 7, c.y),
                              ImVec2(c.x, c.y + 7), ImVec2(c.x - 7, c.y), color);
        }
    }

    const float playAlpha = std::clamp(gCamera.playhead() / std::max(0.1f, gVisibleSeconds), 0.0f, 1.0f);
    const float playX = trackStart.x + playAlpha * trackW;
    dl->AddLine(ImVec2(playX, trackStart.y - 10), ImVec2(playX, trackStart.y + rowH + 6),
                IM_COL32(255, 177, 89, 255), 2.0f);

    if (ImGui::IsItemActivated()) {
        gTimelineDragKey = -1;
        if (preset) {
            float nearestDist = 14.0f;
            for (const auto& key : preset->keys) {
                const float keyPx = trackStart.x + std::clamp(key.time / gVisibleSeconds, 0.0f, 1.0f) * trackW;
                const float d = std::abs(keyPx - ImGui::GetIO().MousePos.x);
                if (d < nearestDist) {
                    nearestDist = d;
                    gTimelineDragKey = key.id;
                    gCamera.selectKey(key.id);
                }
            }
        }
        if (gTimelineDragKey < 0) {
            const float alpha = std::clamp((ImGui::GetIO().MousePos.x - trackStart.x) / trackW, 0.0f, 1.0f);
            gCamera.setPlayhead(alpha * gVisibleSeconds);
        }
    }
    if (ImGui::IsItemActive() && ImGui::IsMouseDragging(ImGuiMouseButton_Left)) {
        const float alpha = std::clamp((ImGui::GetIO().MousePos.x - trackStart.x) / trackW, 0.0f, 1.0f);
        const float t = alpha * gVisibleSeconds;
        if (gTimelineDragKey >= 0) gCamera.moveKeyTime(gTimelineDragKey, t);
        else gCamera.setPlayhead(t);
    }
    if (ImGui::IsItemDeactivated()) gTimelineDragKey = -1;

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 3.0f);
    ImGui::Text("TIME  %.2fs     POS  %.2f / %.2f / %.2f",
                gCamera.playhead(), gCamera.currentPose().position.x,
                gCamera.currentPose().position.y, gCamera.currentPose().position.z);
    ImGui::EndChild();
}
}

void ConfigureEditor(const std::filesystem::path& dataFile) {
    gDataFile = dataFile;
    gCamera.load(gDataFile);
    gAutoTiming = gCamera.autoTiming();
}

void SetEditorOpen(bool open) {
    gEditorOpen.store(open);
    if (open) {
        gResetUiRequested.store(true);
        gCloseRequested.store(false);
    } else {
        gPausePlaybackRequested.store(true);
    }
}
bool IsEditorOpen() { return gEditorOpen.load(); }
void RequestEditorClose() { gCloseRequested.store(true); }
bool IsPointOnEditorUI(float x, float y) {
    std::lock_guard<std::mutex> lock(gBoundsMutex);
    const auto& b = gBounds;
    if (!gEditorOpen.load()) return false;
    if (x >= b.closeX && y <= 48.0f) return true;
    if (x >= b.leftX && x <= b.leftX + b.leftW && y >= b.leftY && y <= b.leftY + b.leftH) return true;
    if (x >= b.rightX && x <= b.rightX + b.rightW && y >= b.rightY && y <= b.rightY + b.rightH) return true;
    if (x >= b.timelineX && x <= b.timelineX + b.timelineW && y >= b.timelineY && y <= b.timelineY + b.timelineH) return true;
    if (b.createModal && x >= b.modalX && x <= b.modalX + b.modalW && y >= b.modalY && y <= b.modalY + b.modalH) return true;
    return false;
}

void DrawEditorFrame(float displayWidth, float displayHeight, float deltaSeconds) {
    if (!gEditorOpen.load()) return;
    if (gResetUiRequested.exchange(false)) gPage = Page::Main;
    if (gPausePlaybackRequested.exchange(false)) gCamera.pausePlayback();

    gCamera.advance(deltaSeconds);
    if (!gStyleApplied) { styleEditor(); gStyleApplied = true; }
    const Layout l = layoutFor(displayWidth, displayHeight);
    setBounds(l, ImGui::IsPopupOpen("CREATE PRESET") || gOpenCreatePopup);

    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2(displayWidth, displayHeight));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    constexpr ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
        ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoBackground |
        ImGuiWindowFlags_NoNavFocus;
    ImGui::Begin("##ReplayCraftOverlayRoot", nullptr, flags);
    ImDrawList* draw = ImGui::GetWindowDrawList();

    // Header bar and close button.
    draw->AddRectFilled(ImVec2(0, 0), ImVec2(displayWidth, 48), IM_COL32(13, 17, 26, 242));
    draw->AddText(ImVec2(18, 15), IM_COL32(241, 243, 248, 255), "REPLAYCRAFT  /  HERO CINE STUDIO");
    draw->AddText(ImVec2(displayWidth * 0.5f - 56, 16), IM_COL32(157, 180, 216, 255), "LIVE WORLD");
    ImGui::SetCursorScreenPos(ImVec2(l.closeX, l.closeY));
    if (ImGui::Button("X", ImVec2(40, 28))) RequestEditorClose();

    // Left panel.
    ImGui::SetCursorScreenPos(ImVec2(l.leftX, l.leftY));
    const bool changedPage = drawPresetsPanel(l.leftW, l.leftH);
    (void)changedPage;

    // Center world aperture: transparent, so the game's current live render stays visible.
    draw->AddRect(ImVec2(l.centerX, l.centerY),
                  ImVec2(l.centerX + l.centerW, l.centerY + l.centerH),
                  IM_COL32(116, 146, 189, 220), 3.0f, 0, 1.0f);
    draw->AddText(ImVec2(l.centerX + 10, l.centerY + 8),
                  IM_COL32(215, 226, 242, 230), "WORLD PREVIEW  /  LIVE");
    if (gPage == Page::Editor) {
        const auto& pose = gCamera.currentPose();
        char text[160];
        std::snprintf(text, sizeof(text), "Camera path pose  X %.2f  Y %.2f  Z %.2f",
                      pose.position.x, pose.position.y, pose.position.z);
        draw->AddText(ImVec2(l.centerX + 10, l.centerY + 28),
                      IM_COL32(190, 204, 225, 220), text);
    }

    // Right inspector.
    ImGui::SetCursorScreenPos(ImVec2(l.rightX, l.rightY));
    if (gToolsVisible) {
        drawTools(l.rightW, l.rightH);
    } else {
        ImGui::SetCursorScreenPos(ImVec2(l.rightX, l.rightY + 6));
        if (ImGui::Button("TLS", ImVec2(38, 34))) gToolsVisible = true;
    }

    // Timeline stays visible on every editor page.
    drawTimeline(l.timelineW, l.timelineH, l.timelineX, l.timelineY);

    // Open and draw popup from the root window scope so the popup ID matches.
    if (gOpenCreatePopup) {
        ImGui::OpenPopup("CREATE PRESET");
        gOpenCreatePopup = false;
    }
    if (gPage == Page::Presets) {
        if (ImGui::BeginPopupModal("CREATE PRESET", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
            ImGui::Text("CREATE PRESET");
            ImGui::Separator();
            ImGui::InputText("Name", gPresetName, sizeof(gPresetName));
            if (ImGui::IsItemActive() && !gNameKeyboardRequested) {
                pl::input::showKeyboard();
                gNameKeyboardRequested = true;
            }
            if (!ImGui::IsItemActive()) gNameKeyboardRequested = false;
            ImGui::Combo("Category", &gCategoryIndex, kCategories, IM_ARRAYSIZE(kCategories));
            if (ImGui::Button("Back")) {
                ImGui::CloseCurrentPopup();
                pl::input::hideKeyboard();
            }
            ImGui::SameLine();
            if (ImGui::Button("Create")) {
                if (gCamera.createPreset(gPresetName, kCategories[gCategoryIndex]) >= 0) {
                    gPage = Page::Editor;
                    saveData();
                }
                ImGui::CloseCurrentPopup();
                pl::input::hideKeyboard();
            }
            ImGui::EndPopup();
        }
    }
    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar(2);

    if (gCloseRequested.exchange(false)) {
        gEditorOpen.store(false);
        gCamera.pausePlayback();
        pl::modmenu::setModuleEnabled(kModuleId, false);
    }
}
}
