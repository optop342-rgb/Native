#include "CameraEngine.hpp"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <nlohmann/json.hpp>

namespace replaycraft {
namespace {
using nlohmann::json;

json poseToJson(const CameraPose& p) {
    return {
        {"position", {{"x", p.position.x}, {"y", p.position.y}, {"z", p.position.z}}},
        {"rotation", {{"yaw", p.yaw}, {"pitch", p.pitch}}},
        {"fov", p.fov}
    };
}

CameraPose poseFromJson(const json& j) {
    CameraPose p;
    if (j.contains("position")) {
        const auto& v = j["position"];
        p.position.x = v.value("x", 0.0f);
        p.position.y = v.value("y", 64.0f);
        p.position.z = v.value("z", 0.0f);
    }
    if (j.contains("rotation")) {
        const auto& r = j["rotation"];
        p.yaw = r.value("yaw", 0.0f);
        p.pitch = r.value("pitch", 0.0f);
    }
    p.fov = j.value("fov", 70.0f);
    return p;
}
}

bool CameraEngine::load(const std::filesystem::path& file) {
    try {
        if (!std::filesystem::exists(file)) return true;
        std::ifstream in(file);
        if (!in) return false;
        json data;
        in >> data;

        mPresetUsed.fill(false);
        mActiveSlot = -1;
        mSelectedKeyId = -1;
        mNextPresetId = 1;
        mNextKeyId = 1;

        mCameraSpeed = data.value("cameraSpeed", 2.0f);
        mAutoTiming = data.value("autoTiming", false);

        if (data.contains("slots") && data["slots"].is_array()) {
            for (const auto& item : data["slots"]) {
                const int slot = item.value("slot", 0);
                if (slot < 0 || slot >= 3) continue;
                CameraPreset p;
                p.id = item.value("id", mNextPresetId++);
                p.name = item.value("name", std::string("Camera"));
                p.category = item.value("category", std::string("Camera"));
                mNextPresetId = std::max(mNextPresetId, p.id + 1);
                if (item.contains("keys") && item["keys"].is_array()) {
                    for (const auto& key : item["keys"]) {
                        CameraKeyframe k;
                        k.id = key.value("id", mNextKeyId++);
                        k.time = std::max(0.0f, key.value("time", 0.0f));
                        k.pose = poseFromJson(key.value("pose", json::object()));
                        mNextKeyId = std::max(mNextKeyId, k.id + 1);
                        p.keys.push_back(k);
                    }
                }
                std::sort(p.keys.begin(), p.keys.end(),
                          [](const auto& a, const auto& b) { return a.time < b.time; });
                mPresets[static_cast<size_t>(slot)] = std::move(p);
                mPresetUsed[static_cast<size_t>(slot)] = true;
            }
        }
        return true;
    } catch (...) {
        return false;
    }
}

bool CameraEngine::save(const std::filesystem::path& file) const {
    try {
        std::filesystem::create_directories(file.parent_path());
        json data;
        data["schemaVersion"] = 1;
        data["cameraSpeed"] = mCameraSpeed;
        data["autoTiming"] = mAutoTiming;
        data["slots"] = json::array();

        for (int slot = 0; slot < 3; ++slot) {
            if (!mPresetUsed[static_cast<size_t>(slot)]) continue;
            const auto& p = mPresets[static_cast<size_t>(slot)];
            json entry = {
                {"slot", slot}, {"id", p.id}, {"name", p.name},
                {"category", p.category}, {"keys", json::array()}
            };
            for (const auto& k : p.keys) {
                entry["keys"].push_back({
                    {"id", k.id}, {"time", k.time}, {"pose", poseToJson(k.pose)}
                });
            }
            data["slots"].push_back(std::move(entry));
        }

        const auto temp = file.string() + ".tmp";
        {
            std::ofstream out(temp, std::ios::trunc);
            if (!out) return false;
            out << data.dump(2) << '\n';
            if (!out.good()) return false;
        }
        std::error_code ec;
        std::filesystem::rename(temp, file, ec);
        if (ec) {
            std::filesystem::remove(file, ec);
            ec.clear();
            std::filesystem::rename(temp, file, ec);
        }
        return !ec;
    } catch (...) {
        return false;
    }
}

int CameraEngine::createPreset(const std::string& name, const std::string& category) {
    for (int slot = 0; slot < 3; ++slot) {
        const auto index = static_cast<size_t>(slot);
        if (mPresetUsed[index]) continue;
        CameraPreset p;
        p.id = mNextPresetId++;
        p.name = name.empty() ? "Camera " + std::to_string(slot + 1) : name;
        p.category = category.empty() ? "Camera" : category;
        mPresets[index] = std::move(p);
        mPresetUsed[index] = true;
        mActiveSlot = slot;
        mSelectedKeyId = -1;
        mPlayhead = 0.0f;
        mPlaying = false;
        return slot;
    }
    return -1;
}

void CameraEngine::deletePreset(int slot) {
    if (slot < 0 || slot >= 3) return;
    mPresets[static_cast<size_t>(slot)] = CameraPreset{};
    mPresetUsed[static_cast<size_t>(slot)] = false;
    if (mActiveSlot == slot) {
        mActiveSlot = -1;
        mSelectedKeyId = -1;
        mPlayhead = 0.0f;
        mPlaying = false;
    }
}

bool CameraEngine::selectPreset(int slot) {
    if (slot < 0 || slot >= 3 || !mPresetUsed[static_cast<size_t>(slot)]) return false;
    mActiveSlot = slot;
    mSelectedKeyId = -1;
    mPlayhead = 0.0f;
    mPlaying = false;
    const auto& p = mPresets[static_cast<size_t>(slot)];
    if (!p.keys.empty()) mCurrentPose = p.keys.front().pose;
    return true;
}

const CameraPreset* CameraEngine::preset(int slot) const {
    if (slot < 0 || slot >= 3 || !mPresetUsed[static_cast<size_t>(slot)]) return nullptr;
    return &mPresets[static_cast<size_t>(slot)];
}

CameraPreset* CameraEngine::activePreset() {
    if (mActiveSlot < 0 || mActiveSlot >= 3) return nullptr;
    if (!mPresetUsed[static_cast<size_t>(mActiveSlot)]) return nullptr;
    return &mPresets[static_cast<size_t>(mActiveSlot)];
}
const CameraPreset* CameraEngine::activePreset() const {
    if (mActiveSlot < 0 || mActiveSlot >= 3) return nullptr;
    if (!mPresetUsed[static_cast<size_t>(mActiveSlot)]) return nullptr;
    return &mPresets[static_cast<size_t>(mActiveSlot)];
}

int CameraEngine::addKey() {
    auto* p = activePreset();
    if (!p) return -1;

    float t = 0.0f;
    if (!p->keys.empty()) {
        t = mPlayhead;
        if (mAutoTiming) {
            const auto& last = p->keys.back();
            const float d = distance(last.pose.position, mCurrentPose.position);
            // Port of HeroCine's calculateEaseTime(): segment time = distance / camera speed.
            t = last.time + std::max(0.1f, d / std::max(0.1f, mCameraSpeed));
        } else {
            const bool collision = std::any_of(p->keys.begin(), p->keys.end(),
                [t](const auto& existing) { return std::abs(existing.time - t) < 0.05f; });
            if (collision) t += 0.05f;
        }
    }

    CameraKeyframe key;
    key.id = mNextKeyId++;
    key.time = std::clamp(t, 0.0f, 120.0f);
    key.pose = mCurrentPose;
    p->keys.push_back(key);
    std::sort(p->keys.begin(), p->keys.end(),
              [](const auto& a, const auto& b) { return a.time < b.time; });
    mSelectedKeyId = key.id;
    mPlayhead = key.time;
    return key.id;
}

bool CameraEngine::deleteSelectedKey() {
    auto* p = activePreset();
    if (!p || mSelectedKeyId < 0) return false;
    const auto oldSize = p->keys.size();
    std::erase_if(p->keys, [this](const auto& k) { return k.id == mSelectedKeyId; });
    const bool removed = p->keys.size() != oldSize;
    if (removed) mSelectedKeyId = -1;
    return removed;
}

bool CameraEngine::selectKey(int keyId) {
    auto* p = activePreset();
    if (!p) return false;
    for (const auto& key : p->keys) {
        if (key.id == keyId) {
            mSelectedKeyId = key.id;
            mPlayhead = key.time;
            mCurrentPose = key.pose;
            return true;
        }
    }
    return false;
}

bool CameraEngine::moveKeyTime(int keyId, float time) {
    auto* p = activePreset();
    if (!p) return false;
    for (auto& key : p->keys) {
        if (key.id == keyId) {
            key.time = std::clamp(time, 0.0f, 120.0f);
            std::sort(p->keys.begin(), p->keys.end(),
                      [](const auto& a, const auto& b) { return a.time < b.time; });
            return true;
        }
    }
    return false;
}

void CameraEngine::setPlayhead(float seconds) {
    mPlayhead = std::max(0.0f, seconds);
    mCurrentPose = evaluate(mPlayhead);
}

float CameraEngine::duration() const {
    const auto* p = activePreset();
    return (!p || p->keys.empty()) ? 20.0f : std::max(20.0f, p->keys.back().time);
}

void CameraEngine::setCameraSpeed(float value) {
    mCameraSpeed = std::clamp(value, 0.1f, 20.0f);
}

void CameraEngine::startPlayback() {
    const auto* p = activePreset();
    if (p && p->keys.size() >= 2) {
        mPlayhead = p->keys.front().time;
        mCurrentPose = p->keys.front().pose;
        mPlaying = true;
    }
}
void CameraEngine::pausePlayback() { mPlaying = false; }

void CameraEngine::advance(float deltaSeconds) {
    if (!mPlaying) return;
    const auto* p = activePreset();
    if (!p || p->keys.size() < 2) {
        mPlaying = false;
        return;
    }
    mPlayhead += std::max(0.0f, deltaSeconds);
    const float end = p->keys.back().time;
    if (mPlayhead >= end) {
        mPlayhead = end;
        mPlaying = false;
    }
    mCurrentPose = evaluate(mPlayhead);
}

void CameraEngine::nudgePose(float dx, float dy, float dz, float yawDelta, float pitchDelta) {
    mCurrentPose.position.x += dx;
    mCurrentPose.position.y += dy;
    mCurrentPose.position.z += dz;
    mCurrentPose.yaw = std::remainder(mCurrentPose.yaw + yawDelta, 360.0f);
    mCurrentPose.pitch = std::clamp(mCurrentPose.pitch + pitchDelta, -89.9f, 89.9f);
}

float CameraEngine::distance(const Vec3& a, const Vec3& b) {
    const float dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
    return std::sqrt(dx * dx + dy * dy + dz * dz);
}

float CameraEngine::lerpAngle(float a, float b, float t) {
    const float delta = std::remainder(b - a, 360.0f);
    return a + delta * t;
}

CameraPose CameraEngine::interpolate(const CameraPose& a, const CameraPose& b, float t) {
    // Smoothstep mirrors the smooth easing feel used by HeroCine while avoiding angle-wrap jumps.
    t = std::clamp(t, 0.0f, 1.0f);
    const float eased = t * t * (3.0f - 2.0f * t);
    CameraPose out;
    out.position = {
        a.position.x + (b.position.x - a.position.x) * eased,
        a.position.y + (b.position.y - a.position.y) * eased,
        a.position.z + (b.position.z - a.position.z) * eased
    };
    out.yaw = lerpAngle(a.yaw, b.yaw, eased);
    out.pitch = a.pitch + (b.pitch - a.pitch) * eased;
    out.fov = a.fov + (b.fov - a.fov) * eased;
    return out;
}

CameraPose CameraEngine::evaluate(float seconds) const {
    const auto* p = activePreset();
    if (!p || p->keys.empty()) return mCurrentPose;
    if (seconds <= p->keys.front().time) return p->keys.front().pose;
    if (seconds >= p->keys.back().time) return p->keys.back().pose;

    for (size_t i = 1; i < p->keys.size(); ++i) {
        const auto& a = p->keys[i - 1];
        const auto& b = p->keys[i];
        if (seconds <= b.time) {
            const float segment = std::max(0.0001f, b.time - a.time);
            const float alpha = (seconds - a.time) / segment;
            return interpolate(a.pose, b.pose, alpha);
        }
    }
    return p->keys.back().pose;
}

} // namespace replaycraft
