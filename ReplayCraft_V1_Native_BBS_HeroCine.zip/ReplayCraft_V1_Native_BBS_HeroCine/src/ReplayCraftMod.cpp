#include "ReplayCraftMod.hpp"
#include "EditorUI.hpp"
#include "RenderHook.hpp"

#include <pl/ModMenu.hpp>
#include <filesystem>
#include <string_view>

namespace {
constexpr char kModuleId[] = "replaycraft_v1.editor";

void onEditorToggle(std::string_view, bool enabled) {
    replaycraft::SetEditorOpen(enabled);
}
}

ReplayCraftMod& ReplayCraftMod::instance() {
    static ReplayCraftMod mod;
    return mod;
}

ReplayCraftMod::ReplayCraftMod()
    : mSelf(*ll::mod::NativeMod::current()) {}

bool ReplayCraftMod::load() {
    try {
        std::filesystem::create_directories(getSelf().getDataDir());
        replaycraft::ConfigureEditor(getSelf().getDataDir() / "presets.json");
        replaycraft::InstallInputBridge();
        if (!replaycraft::InstallRenderHook()) {
            getSelf().getLogger().error("Could not hook eglSwapBuffers; ImGui editor will not render.");
            return false;
        }
        getSelf().getLogger().info("ReplayCraft V1 loaded with native ImGui renderer.");
        return true;
    } catch (...) {
        getSelf().getLogger().error("ReplayCraft V1 failed to initialize.");
        return false;
    }
}

bool ReplayCraftMod::enable() {
    const bool ok = pl::modmenu::ModuleBuilder(kModuleId, "ReplayCraft Editor")
        .description("Opens the ReplayCraft native ImGui camera editor.")
        .modId(getSelf().getId())
        .defaultEnabled(false)
        .hideInHudEditor(true)
        .onToggle(onEditorToggle)
        .registerModule();

    if (!ok) getSelf().getLogger().error("Could not register ReplayCraft Editor in Mod Menu.");
    return ok;
}

bool ReplayCraftMod::disable() {
    replaycraft::SetEditorOpen(false);
    pl::modmenu::unregisterModule(kModuleId);
    return true;
}

bool ReplayCraftMod::unload() {
    replaycraft::SetEditorOpen(false);
    replaycraft::RemoveRenderHook();
    getSelf().getLogger().info("ReplayCraft V1 unloaded.");
    return true;
}

PL_REGISTER_MOD(ReplayCraftMod, ReplayCraftMod::instance())
