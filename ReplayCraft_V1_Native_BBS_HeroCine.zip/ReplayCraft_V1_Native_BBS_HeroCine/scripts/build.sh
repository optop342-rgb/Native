#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/build"
NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
ABI="${ANDROID_ABI:-arm64-v8a}"
PLATFORM="${ANDROID_PLATFORM:-android-26}"

if [[ -z "$NDK" || ! -f "$NDK/build/cmake/android.toolchain.cmake" ]]; then
  echo "Set ANDROID_NDK_HOME to an installed Android NDK folder." >&2
  exit 1
fi

cmake -S "$ROOT" -B "$BUILD" \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI="$ABI" \
  -DANDROID_PLATFORM="$PLATFORM" \
  -DCMAKE_BUILD_TYPE=Release
cmake --build "$BUILD" --config Release

PACKAGE="$BUILD/package/ReplayCraft_V1"
SO="$PACKAGE/libreplaycraft_v1.so"
[[ -f "$SO" ]] || { echo "Native library not found: $SO" >&2; exit 1; }

mkdir -p "$ROOT/dist"
cd "$PACKAGE"
zip -qr "$ROOT/dist/ReplayCraft_V1.levipack" .
echo "Created $ROOT/dist/ReplayCraft_V1.levipack"
