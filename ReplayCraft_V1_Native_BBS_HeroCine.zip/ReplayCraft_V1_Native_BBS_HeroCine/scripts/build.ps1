param(
    [string]$Ndk = $env:ANDROID_NDK_HOME,
    [string]$Abi = "arm64-v8a",
    [string]$Platform = "android-26",
    [switch]$Clean
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Build = Join-Path $Root "build"
$Package = Join-Path $Build "package/ReplayCraft_V1"

if (-not $Ndk) {
    $Ndk = $env:ANDROID_NDK_ROOT
}
if (-not $Ndk -or -not (Test-Path (Join-Path $Ndk "build/cmake/android.toolchain.cmake"))) {
    throw "Set ANDROID_NDK_HOME to an installed Android NDK folder."
}
if ($Clean -and (Test-Path $Build)) { Remove-Item $Build -Recurse -Force }

$Toolchain = Join-Path $Ndk "build/cmake/android.toolchain.cmake"
cmake -S $Root -B $Build `
    -DCMAKE_TOOLCHAIN_FILE="$Toolchain" `
    -DANDROID_ABI="$Abi" `
    -DANDROID_PLATFORM="$Platform" `
    -DCMAKE_BUILD_TYPE=Release
cmake --build $Build --config Release

$So = Join-Path $Package "libreplaycraft_v1.so"
if (-not (Test-Path $So)) { throw "Build finished but native library was not found: $So" }

$Out = Join-Path $Root "dist"
New-Item -ItemType Directory -Force -Path $Out | Out-Null
$Pack = Join-Path $Out "ReplayCraft_V1.levipack"
if (Test-Path $Pack) { Remove-Item $Pack -Force }
Compress-Archive -Path (Join-Path $Package "*") -DestinationPath $Pack -Force
Write-Host "Created $Pack"
