#pragma once
#include <pl/Mod.hpp>

class ReplayCraftMod {
public:
    static ReplayCraftMod& instance();
    ReplayCraftMod();
    [[nodiscard]] ll::mod::NativeMod& getSelf() const { return mSelf; }

    bool load();
    bool enable();
    bool disable();
    bool unload();

private:
    ll::mod::NativeMod& mSelf;
};
