#pragma once

#include <array>
#include <filesystem>
#include <string>
#include <vector>

namespace replaycraft {

struct Vec3 {
    float x{0.0f}, y{64.0f}, z{0.0f};
};

struct CameraPose {
    Vec3 position{};
    float yaw{0.0f};
    float pitch{0.0f};
    float fov{70.0f};
};

struct CameraKeyframe {
    int id{0};
    float time{0.0f};
    CameraPose pose{};
};

struct CameraPreset {
    int id{0};
    std::string name;
    std::string category{"Camera"};
    std::vector<CameraKeyframe> keys;
};

class CameraEngine {
public:
    bool load(const std::filesystem::path& file);
    bool save(const std::filesystem::path& file) const;

    int createPreset(const std::string& name, const std::string& category);
    void deletePreset(int slot);
    bool selectPreset(int slot);
    int activeSlot() const { return mActiveSlot; }
    const CameraPreset* preset(int slot) const;
    CameraPreset* activePreset();
    const CameraPreset* activePreset() const;

    int addKey();
    bool deleteSelectedKey();
    bool selectKey(int keyId);
    bool moveKeyTime(int keyId, float time);
    int selectedKeyId() const { return mSelectedKeyId; }

    void setPlayhead(float seconds);
    float playhead() const { return mPlayhead; }
    float duration() const;
    void setAutoTiming(bool value) { mAutoTiming = value; }
    bool autoTiming() const { return mAutoTiming; }
    void setCameraSpeed(float value);
    float cameraSpeed() const { return mCameraSpeed; }

    void startPlayback();
    void pausePlayback();
    bool isPlaying() const { return mPlaying; }
    void advance(float deltaSeconds);

    void nudgePose(float dx, float dy, float dz, float yawDelta, float pitchDelta);
    void setCurrentPose(const CameraPose& pose) { mCurrentPose = pose; }
    const CameraPose& currentPose() const { return mCurrentPose; }
    CameraPose evaluate(float seconds) const;

private:
    static float distance(const Vec3& a, const Vec3& b);
    static float lerpAngle(float a, float b, float t);
    static CameraPose interpolate(const CameraPose& a, const CameraPose& b, float t);

    std::array<CameraPreset, 3> mPresets{};
    std::array<bool, 3> mPresetUsed{false, false, false};
    int mActiveSlot{-1};
    int mSelectedKeyId{-1};
    int mNextPresetId{1};
    int mNextKeyId{1};
    float mPlayhead{0.0f};
    float mCameraSpeed{2.0f};
    bool mAutoTiming{false};
    bool mPlaying{false};
    CameraPose mCurrentPose{};
};

} // namespace replaycraft
