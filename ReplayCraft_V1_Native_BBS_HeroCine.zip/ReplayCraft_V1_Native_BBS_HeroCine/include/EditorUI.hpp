#pragma once
#include <filesystem>

namespace replaycraft {
void ConfigureEditor(const std::filesystem::path& dataFile);
void SetEditorOpen(bool open);
bool IsEditorOpen();
void DrawEditorFrame(float displayWidth, float displayHeight, float deltaSeconds);
bool IsPointOnEditorUI(float x, float y);
void RequestEditorClose();
}
