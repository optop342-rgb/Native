#pragma once
namespace replaycraft {
bool InstallRenderHook();
void RemoveRenderHook();
void InstallInputBridge();
}
