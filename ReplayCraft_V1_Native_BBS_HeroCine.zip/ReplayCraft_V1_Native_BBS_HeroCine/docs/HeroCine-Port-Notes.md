# HeroCine → Native V1 port notes

Original addon files inspected:
- `scripts/cinematic/functions/add-frame.js`
- `scripts/cinematic/functions/camera/start-camera.js`
- `scripts/cinematic/functions/camera/camera-utils.js`
- `scripts/cinematic/functions/camera/stop-camera.js`
- `scripts/cinematic/functions/camera/start-prev-camera.js`

The native C++ camera-path model carries across:
1. A frame stores position and rotation.
2. Frames are ordered by their key time.
3. HeroCine's dynamic segment time is `distance / cameraSpeed`.
4. Playback, pause/stop and end-of-path cleanup state.
5. Shortest angular yaw interpolation avoids 359°→0° spins.

Bedrock Script API calls such as
`player.camera.setCamera("minecraft:free", ...)` cannot be called directly
from C++; the native game-camera adapter remains a separate engine-specific
integration. The current project does not pretend those script calls are
native C++ symbols.
