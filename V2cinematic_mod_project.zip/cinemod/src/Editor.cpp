#include "Editor.hpp"

#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <cstring>

namespace cm {

namespace {
constexpr float kPi = 3.14159265358979f;
inline ImVec2 V(float x, float y) { return ImVec2(x, y); }
inline ImVec2 Add(ImVec2 a, ImVec2 b) { return ImVec2(a.x + b.x, a.y + b.y); }

const ImU32 kAccent = IM_COL32(112, 82, 250, 235);
const ImU32 kDisc = IM_COL32(18, 22, 38, 205);
const ImU32 kText = IM_COL32(225, 228, 240, 255);
const ImU32 kDim = IM_COL32(140, 146, 170, 255);
// Space (in base units) kept free at the right screen edge for the launcher's floating button.
constexpr float kRightInset = 80.f;

void fmtTime(float t, char* out, size_t n) {
  if (t < 0) t = 0;
  const int m = (int)(t / 60.f);
  std::snprintf(out, n, "%02d:%05.2f", m, t - m * 60.f);
}
}  // namespace

const ButtonRec* Editor::findButton(const std::string& label) const {
  for (const ButtonRec& b : buttons_)
    if (b.label == label) return &b;
  return nullptr;
}

Preset* Editor::cur() {
  if (selSlot_ < 0 || selSlot_ >= kSlotCount || !lib_.slots[selSlot_]) return nullptr;
  return &*lib_.slots[selSlot_];
}

void Editor::toast(const char* msg) {
  toast_ = msg;
  toastT_ = 2.2f;
}

void Editor::applyStyle(float ui) {
  ImGuiStyle& s = ImGui::GetStyle();
  s = ImGuiStyle();
  ImGui::StyleColorsDark(&s);
  s.WindowRounding = 6.f;
  s.FrameRounding = 6.f;
  s.GrabRounding = 6.f;
  s.PopupRounding = 6.f;
  s.WindowBorderSize = 1.f;
  s.FrameBorderSize = 0.f;
  s.ItemSpacing = V(8.f, 7.f);
  s.WindowPadding = V(8.f, 8.f);
  s.FramePadding = V(8.f, 6.f);
  s.GrabMinSize = 16.f;
  ImVec4* c = s.Colors;
  c[ImGuiCol_WindowBg] = ImVec4(0.035f, 0.045f, 0.085f, 0.97f);
  c[ImGuiCol_PopupBg] = ImVec4(0.05f, 0.06f, 0.11f, 0.99f);
  c[ImGuiCol_Border] = ImVec4(0.16f, 0.18f, 0.30f, 1.f);
  c[ImGuiCol_Button] = ImVec4(0.09f, 0.11f, 0.19f, 1.f);
  c[ImGuiCol_ButtonHovered] = ImVec4(0.16f, 0.16f, 0.34f, 1.f);
  c[ImGuiCol_ButtonActive] = ImVec4(0.38f, 0.28f, 0.90f, 1.f);
  c[ImGuiCol_FrameBg] = ImVec4(0.08f, 0.10f, 0.17f, 1.f);
  c[ImGuiCol_Header] = ImVec4(0.22f, 0.17f, 0.52f, 0.85f);
  c[ImGuiCol_HeaderHovered] = ImVec4(0.30f, 0.22f, 0.68f, 0.90f);
  c[ImGuiCol_SliderGrab] = ImVec4(0.44f, 0.32f, 0.98f, 1.f);
  c[ImGuiCol_SliderGrabActive] = ImVec4(0.58f, 0.46f, 1.f, 1.f);
  c[ImGuiCol_CheckMark] = ImVec4(0.58f, 0.46f, 1.f, 1.f);
  s.ScaleAllSizes(ui);
}

bool Editor::button(const char* label, bool enabled, bool accent) {
  if (!enabled) ImGui::BeginDisabled();
  if (accent) ImGui::PushStyleColor(ImGuiCol_Button, ImGui::ColorConvertU32ToFloat4(kAccent));
  const float h = 34.f * ImGui::GetIO().FontGlobalScale * (kFontBasePx / 13.f);
  const bool r = ImGui::Button(label, V(-FLT_MIN, h));
  if (accent) ImGui::PopStyleColor();
  buttons_.push_back({label, ImGui::GetItemRectMin(), ImGui::GetItemRectMax()});
  if (!enabled) ImGui::EndDisabled();
  return r && enabled;
}

// ------------------------------------------------------------------ state

void Editor::enterEditor() {
  screen_ = Screen::Editor;
  playhead_ = 0.f;
  playing_ = false;
  selKey_ = -1;
  zoom_ = 1.f;
  scroll_ = 0.f;
  Preset* p = cur();
  if (p && !p->keys.empty()) {
    mode_ = CamMode::Follow;
    cam_ = samplePreset(*p, 0.f);
  }
}

void Editor::follow() {
  Preset* p = cur();
  if (p && !p->keys.empty()) {
    mode_ = CamMode::Follow;
    cam_ = samplePreset(*p, playhead_);
  }
}

void Editor::addKey() {
  Preset* p = cur();
  if (!p) return toast("Create a preset first");
  selKey_ = p->addOrReplaceKey(playhead_, cam_);
  toast("Key added");
}

void Editor::deleteKey() {
  Preset* p = cur();
  if (!p || selKey_ < 0 || selKey_ >= (int)p->keys.size()) return toast("Select a key first");
  p->removeKey(selKey_);
  selKey_ = -1;
  toast("Key deleted");
}

void Editor::tick(float dt, EditorHost& host) {
  if (toastT_ > 0.f) toastT_ -= dt;
  if (deleteArm_ > 0.f) deleteArm_ -= dt;

  Preset* p = cur();
  const ImVec2 joy = touch_.joystick();
  const bool up = touch_.held(ZUp), down = touch_.held(ZDown);
  const ImVec2 look = touch_.takeLookDelta();
  const bool moved = joy.x != 0.f || joy.y != 0.f || up || down || look.x != 0.f || look.y != 0.f;

  if (moved) {
    mode_ = CamMode::Free;
    playing_ = false;
    const float sgn = invertLook_ ? -1.f : 1.f;
    cam_.yaw = wrapAngle(cam_.yaw + sgn * look.x * 0.10f * lookSens_);
    cam_.pitch = std::clamp(cam_.pitch + sgn * look.y * 0.10f * lookSens_, -90.f, 90.f);

    const float yaw = cam_.yaw * kPi / 180.f, pit = cam_.pitch * kPi / 180.f;
    const float fx = -std::sin(yaw) * std::cos(pit), fy = -std::sin(pit), fz = std::cos(yaw) * std::cos(pit);
    const float rx = -std::cos(yaw), rz = -std::sin(yaw);
    const float s = moveSpeed_ * dt;
    cam_.x += (fx * joy.y + rx * joy.x) * s;
    cam_.y += fy * joy.y * s;
    cam_.z += (fz * joy.y + rz * joy.x) * s;
    if (up) cam_.y += s;
    if (down) cam_.y -= s;
  }

  if (playing_ && p) {
    playhead_ += dt;
    if (playhead_ >= p->duration) {
      playhead_ = p->duration;
      playing_ = false;
    }
    follow();
  }
  if (host.onCamera) host.onCamera(cam_);
}

// ------------------------------------------------------------------- draw

void Editor::draw(const ImVec2& disp, float dt, EditorHost& host) {
  ImGuiIO& io = ImGui::GetIO();
  const float ui = std::max(0.6f, disp.y / 540.f);
  if (std::fabs(ui - styleUi_) > 0.01f) {
    applyStyle(ui);
    styleUi_ = ui;
  }
  io.FontGlobalScale = ui * 13.f / kFontBasePx;

  host_ = &host;
  buttons_.clear();
  touch_.beginZones();
  tick(dt, host);

  const float topH = 36.f * ui;
  const float bottomH = 168.f * ui;
  const float leftW = expanded_ ? 0.f : std::max(190.f * ui, disp.x * 0.22f);
  const float toolsW = toolsOpen_ ? std::max(200.f * ui, disp.x * 0.20f) : 0.f;
  const float midH = disp.y - topH - bottomH;

  drawTop(disp, ui, host);
  if (leftW > 0.f) drawLeft(0.f, topH, leftW, midH, ui, host);
  drawPreview(leftW, topH, disp.x - leftW - toolsW, midH, ui, host);
  if (toolsW > 0.f) drawTools(disp.x - toolsW, topH, toolsW, midH, ui);
  drawBottom(0.f, disp.y - bottomH, disp.x, bottomH, ui);
  drawCreatePopup(disp, ui);
}

static const ImGuiWindowFlags kPanel = ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
                                       ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                                       ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus;

void Editor::drawTop(const ImVec2& disp, float ui, EditorHost& host) {
  ImGui::SetNextWindowPos(V(0, 0), ImGuiCond_Always);
  ImGui::SetNextWindowSize(V(disp.x, 36.f * ui), ImGuiCond_Always);
  ImGui::Begin("##top", nullptr, kPanel | ImGuiWindowFlags_NoScrollbar);
  const char* name = screen_ == Screen::Main ? "Main" : (screen_ == Screen::Presets ? "Presets" : "Editor");
  ImGui::AlignTextToFramePadding();
  ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(kAccent), "CINEMATIC");
  ImGui::SameLine();
  ImGui::TextDisabled("/ %s", name);
  const float bw = 54.f * ui;
  // The launcher draws its own floating menu button in the top-right corner; stay clear of it.
  ImGui::SameLine(ImGui::GetWindowWidth() - bw - ImGui::GetStyle().WindowPadding.x - kRightInset * ui);
  if (ImGui::Button("X", V(bw, 0))) {
    if (host.onSave) host.onSave();
    if (host.onClose) host.onClose();
  }
  buttons_.push_back({"X", ImGui::GetItemRectMin(), ImGui::GetItemRectMax()});
  ImGui::End();
}

void Editor::drawLeft(float x, float y, float w, float h, float ui, EditorHost& host) {
  ImGui::SetNextWindowPos(V(x, y), ImGuiCond_Always);
  ImGui::SetNextWindowSize(V(w, h), ImGuiCond_Always);
  ImGui::Begin("##left", nullptr, kPanel);

  if (screen_ == Screen::Main) {
    if (button("Presets", true, true)) {
      screen_ = Screen::Presets;
    }
  } else if (screen_ == Screen::Presets) {
    ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(kAccent), "Presets  v");
    for (int i = 0; i < kSlotCount; ++i) {
      ImGui::PushID(i);
      const bool sel = (i == selSlot_);
      char label[32];
      std::snprintf(label, sizeof label, "%s Slot %d", sel ? "v" : ">", i + 1);
      if (ImGui::Selectable(label, sel, 0, V(0, 32.f * ui))) selSlot_ = i;
      char rec[16];
      std::snprintf(rec, sizeof rec, "Slot %d", i + 1);
      buttons_.push_back({rec, ImGui::GetItemRectMin(), ImGui::GetItemRectMax()});
      if (lib_.slots[i]) {
        ImGui::TextDisabled("  %s  [%s]", lib_.slots[i]->name.c_str(), lib_.slots[i]->category.c_str());
        if (sel) {
          ImGui::Indent(14.f * ui);
          if (button("Camera 1", true, true)) enterEditor();
          ImGui::Unindent(14.f * ui);
        }
      } else {
        ImGui::TextDisabled("  (empty)");
      }
      ImGui::PopID();
    }
    ImGui::Spacing();
    if (button("+ Create New")) {
      createPending_ = true;
      createOpen_ = true;
      nameBuf_[0] = 0;
      catIdx_ = 0;
    }
    const bool occupied = lib_.slots[selSlot_].has_value();
    if (button(deleteArm_ > 0.f ? "Tap again to delete" : "- Delete Slot", occupied)) {
      if (deleteArm_ > 0.f) {
        lib_.slots[selSlot_].reset();
        deleteArm_ = 0.f;
        if (host.onSave) host.onSave();
        toast("Slot deleted");
      } else {
        deleteArm_ = 3.f;
      }
    }
    if (button("< Back")) screen_ = Screen::Main;
  } else {  // Editor
    ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(kAccent), "EDITOR");
    if (Preset* p = cur()) ImGui::TextDisabled("%s", p->name.c_str());
    button("Camera 1", true, true);
    if (button("+ Add Key")) addKey();
    if (button("- Delete Key")) deleteKey();
    ImGui::Spacing();
    if (button("< Back")) {
      if (host.onSave) host.onSave();
      playing_ = false;
      screen_ = Screen::Presets;
    }
    if (button("Save")) {
      if (host.onSave) host.onSave();
      toast("Saved");
    }
  }
  ImGui::End();
}

void Editor::drawCreatePopup(const ImVec2& disp, float ui) {
  if (createPending_) {
    ImGui::OpenPopup("Create Preset");
    createPending_ = false;
  }
  ImGui::SetNextWindowPos(V(disp.x * 0.5f, disp.y * 0.42f), ImGuiCond_Always, V(0.5f, 0.5f));
  ImGui::SetNextWindowSize(V(std::min(disp.x * 0.6f, 520.f * ui), 0.f), ImGuiCond_Always);
  if (ImGui::BeginPopupModal("Create Preset", nullptr,
                             ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings)) {
    ImGui::Text("Name:");
    ImGui::SetNextItemWidth(-FLT_MIN);
    ImGui::InputText("##name", nameBuf_, sizeof nameBuf_);
    buttons_.push_back({"input:name", ImGui::GetItemRectMin(), ImGui::GetItemRectMax()});
    ImGui::Text("Category type:");
    ImGui::SetNextItemWidth(-FLT_MIN);
    ImGui::Combo("##cat", &catIdx_, kCategories, kCategoryCount);
    ImGui::Spacing();
    const float half = (ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x) * 0.5f;
    const float bh = 34.f * ui;
    if (ImGui::Button("Back", V(half, bh))) {
      createOpen_ = false;
      ImGui::CloseCurrentPopup();
    }
    buttons_.push_back({"Back", ImGui::GetItemRectMin(), ImGui::GetItemRectMax()});
    ImGui::SameLine();
    const bool ok = nameBuf_[0] != 0;
    if (!ok) ImGui::BeginDisabled();
    const bool create = ImGui::Button("Create", V(half, bh));
    buttons_.push_back({"Create", ImGui::GetItemRectMin(), ImGui::GetItemRectMax()});
    if (!ok) ImGui::EndDisabled();
    if (create && ok) {
      int target = -1;
      if (!lib_.slots[selSlot_]) target = selSlot_;
      else
        for (int i = 0; i < kSlotCount; ++i)
          if (!lib_.slots[i]) {
            target = i;
            break;
          }
      if (target < 0) {
        toast("All slots are full - delete one first");
      } else {
        Preset p;
        p.name = nameBuf_;
        p.category = kCategories[std::clamp(catIdx_, 0, kCategoryCount - 1)];
        lib_.slots[target] = p;
        selSlot_ = target;
        if (host_ && host_->onSave) host_->onSave();
        createOpen_ = false;
        ImGui::CloseCurrentPopup();
        enterEditor();
      }
    }
    ImGui::EndPopup();
  } else if (createOpen_ && !createPending_) {
    createOpen_ = false;  // popup was dismissed
  }
}

// ---------------------------------------------------------------- preview

bool Editor::zoneBtn(ZoneId z, ImVec2 c, float hw, float hh, Icon ic, const char* label, bool on) {
  ImDrawList* dl = ImGui::GetWindowDrawList();
  if (!createOpen_) touch_.setZone(z, V(c.x - hw, c.y - hh), V(c.x + hw, c.y + hh));
  const bool pressed = touch_.held(z);
  const ImU32 bg = (on || pressed) ? kAccent : kDisc;

  if (ic == Icon::Text) {
    dl->AddRectFilled(V(c.x - hw, c.y - hh), V(c.x + hw, c.y + hh), bg, hh * 0.35f);
    const ImVec2 ts = ImGui::CalcTextSize(label);
    dl->AddText(V(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f), kText, label);
  } else {
    const float r = hw;
    dl->AddCircleFilled(c, r, bg, 28);
    dl->AddCircle(c, r, IM_COL32(255, 255, 255, 60), 28, 1.5f);
    switch (ic) {
      case Icon::Up:
        dl->AddTriangleFilled(V(c.x, c.y - 0.42f * r), V(c.x - 0.5f * r, c.y + 0.3f * r),
                              V(c.x + 0.5f * r, c.y + 0.3f * r), kText);
        break;
      case Icon::Down:
        dl->AddTriangleFilled(V(c.x, c.y + 0.42f * r), V(c.x + 0.5f * r, c.y - 0.3f * r),
                              V(c.x - 0.5f * r, c.y - 0.3f * r), kText);
        break;
      case Icon::Moon:
        dl->AddCircleFilled(c, 0.42f * r, kText, 20);
        dl->AddCircleFilled(V(c.x + 0.22f * r, c.y - 0.12f * r), 0.38f * r, bg, 20);
        break;
      case Icon::Sun:
        dl->AddCircleFilled(c, 0.24f * r, kText, 16);
        for (int i = 0; i < 8; ++i) {
          const float a = i * kPi / 4.f;
          dl->AddLine(V(c.x + std::cos(a) * 0.40f * r, c.y + std::sin(a) * 0.40f * r),
                      V(c.x + std::cos(a) * 0.62f * r, c.y + std::sin(a) * 0.62f * r), kText, 2.f);
        }
        break;
      default:
        break;
    }
  }
  return !createOpen_ && touch_.takeClick(z);
}

void Editor::drawPreview(float x, float y, float w, float h, float ui, EditorHost& host) {
  ImGui::SetNextWindowPos(V(x, y), ImGuiCond_Always);
  ImGui::SetNextWindowSize(V(w, h), ImGuiCond_Always);
  ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, V(0, 0));
  ImGui::Begin("##preview", nullptr,
               kPanel | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoScrollbar);
  ImGui::PopStyleVar();
  ImDrawList* dl = ImGui::GetWindowDrawList();
  const ImVec2 p0 = ImGui::GetWindowPos();
  const ImVec2 p1 = V(p0.x + w, p0.y + h);
  dl->AddRectFilled(p0, p1, IM_COL32(6, 8, 14, 255));

  // --- the game frame, aspect-fitted inside the box ---
  if (host.gameTex && host.gameW > 0 && host.gameH > 0) {
    const float ar = (float)host.gameW / (float)host.gameH;
    float iw = w, ih = w / ar;
    if (ih > h) {
      ih = h;
      iw = h * ar;
    }
    const ImVec2 i0 = V(p0.x + (w - iw) * 0.5f, p0.y + (h - ih) * 0.5f);
    const ImVec2 i1 = V(i0.x + iw, i0.y + ih);
    const ImVec2 uv0 = V(0.f, 1.f), uv1 = V(1.f, 0.f);  // GL framebuffer is bottom-up
    dl->AddImage(host.gameTex, i0, i1, uv0, uv1);
    if ((fullBright_ || nightVision_) && host.additiveCb) {
      dl->AddCallback(host.additiveCb, nullptr);
      if (fullBright_) {
        dl->AddImage(host.gameTex, i0, i1, uv0, uv1, IM_COL32(255, 255, 255, 255));
        dl->AddRectFilled(i0, i1, IM_COL32(38, 38, 38, 255));
      }
      if (nightVision_) {
        dl->AddImage(host.gameTex, i0, i1, uv0, uv1, IM_COL32(0, 255, 70, 255));
        dl->AddImage(host.gameTex, i0, i1, uv0, uv1, IM_COL32(0, 190, 60, 255));
        dl->AddRectFilled(i0, i1, IM_COL32(0, 26, 6, 255));
      }
      dl->AddCallback(ImDrawCallback_ResetRenderState, nullptr);
    }
  } else {
    const char* t = "(waiting for game frame)";
    const ImVec2 ts = ImGui::CalcTextSize(t);
    dl->AddText(V(p0.x + (w - ts.x) * 0.5f, p0.y + (h - ts.y) * 0.5f), kDim, t);
  }
  dl->AddRect(p0, p1, IM_COL32(60, 66, 110, 255), 0.f, 0, 1.5f);

  // --- header chip + pose readout ---
  {
    char chip[48];
    std::snprintf(chip, sizeof chip, "WORLD PREVIEW  %s", mode_ == CamMode::Free ? "Free camera" : "Playback");
    const ImVec2 ts = ImGui::CalcTextSize(chip);
    const ImVec2 c0 = V(p0.x + 8.f * ui, p0.y + 8.f * ui);
    dl->AddRectFilled(c0, V(c0.x + ts.x + 14.f * ui, c0.y + ts.y + 8.f * ui), kDisc, 6.f * ui);
    dl->AddText(V(c0.x + 7.f * ui, c0.y + 4.f * ui), kText, chip);
    char pose[96];
    std::snprintf(pose, sizeof pose, "X %.1f  Y %.1f  Z %.1f   P %.0f  Yaw %.0f   FOV %.0f", cam_.x, cam_.y, cam_.z,
                  cam_.pitch, cam_.yaw, cam_.fov);
    const ImVec2 ps = ImGui::CalcTextSize(pose);
    const ImVec2 q0 = V(c0.x, c0.y + ts.y + 12.f * ui);
    dl->AddRectFilled(q0, V(q0.x + ps.x + 14.f * ui, q0.y + ps.y + 8.f * ui), kDisc, 6.f * ui);
    dl->AddText(V(q0.x + 7.f * ui, q0.y + 4.f * ui), kText, pose);
  }

  // --- look zone (whole preview), registered first = lowest priority ---
  if (!createOpen_) touch_.setZone(ZLook, p0, p1);

  // --- top-right: [+] expand, [TLS] tools ---
  const float bh = 15.f * ui;
  const float inset = (x + w >= ImGui::GetIO().DisplaySize.x - 1.f) ? kRightInset * ui : 0.f;
  const float rx = p1.x - inset;
  if (zoneBtn(ZTools, V(rx - 34.f * ui, p0.y + 24.f * ui), 28.f * ui, bh, Icon::Text, "TLS", toolsOpen_))
    toolsOpen_ = !toolsOpen_;
  if (zoneBtn(ZExpand, V(rx - 34.f * ui - 70.f * ui, p0.y + 24.f * ui), 22.f * ui, bh, Icon::Text, "+", expanded_))
    expanded_ = !expanded_;

  // --- joystick (bottom-left) ---
  {
    const float R = 58.f * ui;
    const ImVec2 c = V(p0.x + R + 22.f * ui, p1.y - R - 22.f * ui);
    if (!createOpen_) touch_.setZone(ZJoystick, V(c.x - R, c.y - R), V(c.x + R, c.y + R));
    const ImVec2 j = touch_.joystick();
    dl->AddCircleFilled(c, R, IM_COL32(18, 22, 38, 150), 40);
    dl->AddCircle(c, R, IM_COL32(255, 255, 255, 70), 40, 2.f);
    dl->AddCircleFilled(V(c.x + j.x * R * 0.55f, c.y - j.y * R * 0.55f), R * 0.38f, IM_COL32(210, 214, 235, 210), 28);
  }

  // --- up / down (right side) ---
  zoneBtn(ZUp, V(p1.x - 40.f * ui, p1.y - 112.f * ui), 28.f * ui, 28.f * ui, Icon::Up, "", false);
  zoneBtn(ZDown, V(p1.x - 40.f * ui, p1.y - 46.f * ui), 28.f * ui, 28.f * ui, Icon::Down, "", false);

  // --- night vision (moon) + full brightness (sun), bottom centre ---
  const float cx = p0.x + w * 0.5f;
  if (zoneBtn(ZNight, V(cx - 36.f * ui, p1.y - 34.f * ui), 24.f * ui, 24.f * ui, Icon::Moon, "", nightVision_))
    nightVision_ = !nightVision_;
  if (zoneBtn(ZBright, V(cx + 36.f * ui, p1.y - 34.f * ui), 24.f * ui, 24.f * ui, Icon::Sun, "", fullBright_))
    fullBright_ = !fullBright_;

  // --- toast ---
  if (toastT_ > 0.f && !toast_.empty()) {
    const ImVec2 ts = ImGui::CalcTextSize(toast_.c_str());
    const float a = std::min(1.f, toastT_ * 2.f);
    const ImVec2 t0 = V(cx - ts.x * 0.5f - 10.f * ui, p0.y + h * 0.5f - ts.y * 0.5f - 6.f * ui);
    dl->AddRectFilled(t0, V(t0.x + ts.x + 20.f * ui, t0.y + ts.y + 12.f * ui), IM_COL32(18, 22, 38, (int)(220 * a)), 8.f * ui);
    dl->AddText(V(t0.x + 10.f * ui, t0.y + 6.f * ui), IM_COL32(235, 235, 250, (int)(255 * a)), toast_.c_str());
  }
  ImGui::End();
}

// ------------------------------------------------------------------ tools

void Editor::drawTools(float x, float y, float w, float h, float ui) {
  ImGui::SetNextWindowPos(V(x, y), ImGuiCond_Always);
  ImGui::SetNextWindowSize(V(w, h), ImGuiCond_Always);
  ImGui::Begin("##tools", nullptr, kPanel);
  ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(kAccent), "TOOLS");
  ImGui::Separator();
  ImGui::TextDisabled("CAMERA CONTROLS");
  ImGui::Text("Look sensitivity");
  ImGui::SetNextItemWidth(-FLT_MIN);
  ImGui::SliderFloat("##sens", &lookSens_, 0.2f, 6.f, "%.2fx");
  ImGui::Text("Move speed");
  ImGui::SetNextItemWidth(-FLT_MIN);
  ImGui::SliderFloat("##spd", &moveSpeed_, 1.f, 30.f, "%.0f b/s");
  ImGui::Checkbox("Invert look", &invertLook_);
  float fov = cam_.fov;
  ImGui::Text("FOV");
  ImGui::SetNextItemWidth(-FLT_MIN);
  if (ImGui::SliderFloat("##fov", &fov, 30.f, 110.f, "%.0f")) cam_.fov = fov, mode_ = CamMode::Free;
  if (Preset* p = cur()) {
    ImGui::Separator();
    ImGui::TextDisabled("PRESET");
    ImGui::Checkbox("Smooth path", &p->smooth);
    ImGui::Text("Duration");
    float d = p->duration;
    ImGui::SetNextItemWidth(-FLT_MIN);
    if (ImGui::SliderFloat("##dur", &d, 2.f, 120.f, "%.0f s")) {
      const float minD = p->keys.empty() ? 2.f : std::max(2.f, p->keys.back().t);
      p->duration = std::max(d, minD);
      playhead_ = std::min(playhead_, p->duration);
    }
    ImGui::TextDisabled("Keys: %d", (int)p->keys.size());
  }
  (void)ui;
  ImGui::End();
}

// ----------------------------------------------------- playback + timeline

void Editor::drawBottom(float x, float y, float w, float h, float ui) {
  ImGui::SetNextWindowPos(V(x, y), ImGuiCond_Always);
  ImGui::SetNextWindowSize(V(w, h), ImGuiCond_Always);
  ImGui::Begin("##bottom", nullptr, kPanel | ImGuiWindowFlags_NoScrollbar);
  Preset* p = cur();
  const float dur = p ? p->duration : 20.f;
  const float bh = 32.f * ui, bw = 62.f * ui;

  auto small = [&](const char* label, float width) {
    const bool r = ImGui::Button(label, V(width, bh));
    buttons_.push_back({label, ImGui::GetItemRectMin(), ImGui::GetItemRectMax()});
    return r;
  };

  if (small("<<", bw)) {
    float t = 0.f;
    if (p)
      for (const Key& k : p->keys)
        if (k.t < playhead_ - 0.05f) t = k.t;
    playhead_ = t;
    playing_ = false;
    follow();
  }
  ImGui::SameLine();
  if (small("Play", bw + 10.f * ui)) {
    if (p && !p->keys.empty()) {
      if (playhead_ >= dur - 0.01f) playhead_ = 0.f;
      playing_ = true;
      follow();
    } else {
      toast("Add at least one key first");
    }
  }
  ImGui::SameLine();
  if (small("Pause", bw + 10.f * ui)) playing_ = false;
  ImGui::SameLine();
  if (small(">>", bw)) {
    float t = dur;
    if (p)
      for (const Key& k : p->keys)
        if (k.t > playhead_ + 0.05f) {
          t = k.t;
          break;
        }
    playhead_ = t;
    playing_ = false;
    follow();
  }
  ImGui::SameLine();
  char a[24], b[24], tb[64];
  fmtTime(playhead_, a, sizeof a);
  fmtTime(dur, b, sizeof b);
  std::snprintf(tb, sizeof tb, "%s / %s", a, b);
  ImGui::AlignTextToFramePadding();
  ImGui::TextUnformatted(tb);

  // zoom: [-] ----o---- [+]   (right aligned)
  const float zw = 240.f * ui;
  ImGui::SameLine(w - zw - ImGui::GetStyle().WindowPadding.x);
  if (small("-", 36.f * ui)) zoom_ = std::max(1.f, zoom_ - 0.5f);
  ImGui::SameLine();
  ImGui::SetNextItemWidth(zw - 90.f * ui);
  ImGui::SliderFloat("##zoom", &zoom_, 1.f, 8.f, "");
  ImGui::SameLine();
  if (small("+", 36.f * ui)) zoom_ = std::min(8.f, zoom_ + 0.5f);

  drawTimeline(ui);
  ImGui::End();
}

void Editor::drawTimeline(float ui) {
  ImGuiIO& io = ImGui::GetIO();
  Preset* p = cur();
  const float dur = p ? p->duration : 20.f;
  ImDrawList* dl = ImGui::GetWindowDrawList();

  const ImVec2 origin = ImGui::GetCursorScreenPos();
  const float availW = ImGui::GetContentRegionAvail().x;
  const float gutter = 86.f * ui;
  const float x0 = origin.x + gutter, x1 = origin.x + availW - 4.f * ui;
  const float areaW = std::max(10.f, x1 - x0);
  const float visSec = dur / std::max(1.f, zoom_);
  const float pps = areaW / visSec;
  scroll_ = std::clamp(scroll_, 0.f, std::max(0.f, dur - visSec));
  auto xOf = [&](float t) { return x0 + (t - scroll_) * pps; };
  auto tOf = [&](float x) { return std::clamp((x - x0) / pps + scroll_, 0.f, dur); };

  const float rulerH = 24.f * ui, laneH = 42.f * ui;
  const ImVec2 rMin = V(x0, origin.y), rMax = V(x1, origin.y + rulerH);
  const ImVec2 lMin = V(x0, rMax.y + 4.f * ui), lMax = V(x1, lMin.y + laneH);

  dl->AddText(V(origin.x + 4.f * ui, origin.y + 4.f * ui), IM_COL32(120, 110, 250, 255), "TIMELINE");
  dl->AddText(V(origin.x + 4.f * ui, lMin.y + laneH * 0.5f - 8.f * ui), IM_COL32(120, 150, 255, 255), "Camera");
  dl->AddRectFilled(rMin, rMax, IM_COL32(14, 17, 30, 255), 4.f * ui);
  dl->AddRectFilled(lMin, lMax, IM_COL32(10, 13, 24, 255), 4.f * ui);

  dl->PushClipRect(V(x0 - 1.f, origin.y), V(x1 + 1.f, lMax.y), true);
  // ruler ticks
  static const float steps[] = {0.25f, 0.5f, 1.f, 2.f, 5.f, 10.f, 15.f, 30.f, 60.f};
  float step = 60.f;
  for (float s : steps)
    if (s * pps >= 70.f * ui) {
      step = s;
      break;
    }
  for (float t = std::ceil(scroll_ / step) * step; t <= scroll_ + visSec + 1e-3f; t += step) {
    const float x = xOf(t);
    dl->AddLine(V(x, rMax.y - 8.f * ui), V(x, lMax.y), IM_COL32(60, 66, 100, 150), 1.f);
    char lb[16];
    if (step < 1.f) std::snprintf(lb, sizeof lb, "%.2fs", t);
    else std::snprintf(lb, sizeof lb, "%02ds", (int)(t + 0.5f));
    dl->AddText(V(x + 3.f * ui, rMin.y + 4.f * ui), kDim, lb);
  }

  // camera track bar between first and last key
  if (p && p->keys.size() >= 2) {
    dl->AddRectFilled(V(xOf(p->keys.front().t), lMin.y + laneH * 0.5f - 2.f * ui),
                      V(xOf(p->keys.back().t), lMin.y + laneH * 0.5f + 2.f * ui), IM_COL32(110, 90, 240, 200));
  }
  dl->PopClipRect();

  // ruler scrub
  ImGui::SetCursorScreenPos(rMin);
  ImGui::InvisibleButton("##ruler", V(areaW, rulerH));
  buttons_.push_back({"timeline:ruler", ImGui::GetItemRectMin(), ImGui::GetItemRectMax()});
  if (ImGui::IsItemActive()) {
    playhead_ = tOf(io.MousePos.x);
    playing_ = false;
    follow();
  }
  // lane scrub (keys are submitted afterwards so they win the overlap)
  ImGui::SetCursorScreenPos(lMin);
  ImGui::InvisibleButton("##lane", V(areaW, laneH));
  buttons_.push_back({"timeline:lane", ImGui::GetItemRectMin(), ImGui::GetItemRectMax()});
  ImGui::SetItemAllowOverlap();
  if (ImGui::IsItemActive()) {
    playhead_ = tOf(io.MousePos.x);
    playing_ = false;
    follow();
  }

  // keys
  if (p) {
    for (int i = 0; i < (int)p->keys.size(); ++i) {
      Key& k = p->keys[i];
      const float x = xOf(k.t);
      if (x < x0 - 14.f * ui || x > x1 + 14.f * ui) continue;
      const float s = 26.f * ui;
      ImGui::SetCursorScreenPos(V(x - s * 0.5f, lMin.y + (laneH - s) * 0.5f));
      char id[16];
      std::snprintf(id, sizeof id, "##k%d", i);
      ImGui::InvisibleButton(id, V(s, s));
      buttons_.push_back({std::string("timeline:key") + std::to_string(i), ImGui::GetItemRectMin(), ImGui::GetItemRectMax()});
      if (ImGui::IsItemActivated()) {
        selKey_ = i;
        playhead_ = k.t;
        playing_ = false;
        follow();
      }
      if (ImGui::IsItemActive() && ImGui::IsMouseDragging(0, 4.f * ui)) {
        const float lo = (i > 0) ? p->keys[i - 1].t + 0.05f : 0.f;
        const float hi = (i + 1 < (int)p->keys.size()) ? p->keys[i + 1].t - 0.05f : dur;
        k.t = std::clamp(tOf(io.MousePos.x), lo, std::max(lo, hi));
        playhead_ = k.t;
      }
    }
    // draw diamonds on top
    dl->PushClipRect(V(x0 - 14.f * ui, lMin.y), V(x1 + 14.f * ui, lMax.y), true);
    for (int i = 0; i < (int)p->keys.size(); ++i) {
      const float x = xOf(p->keys[i].t), y = lMin.y + laneH * 0.5f, r = 9.f * ui;
      const bool sel = (i == selKey_);
      const ImU32 col = sel ? IM_COL32(255, 214, 90, 255) : IM_COL32(150, 130, 255, 255);
      dl->AddQuadFilled(V(x, y - r), V(x + r, y), V(x, y + r), V(x - r, y), col);
      dl->AddQuad(V(x, y - r), V(x + r, y), V(x, y + r), V(x - r, y), IM_COL32(0, 0, 0, 160), 1.5f);
    }
    dl->PopClipRect();
  }

  // playhead
  {
    const float x = xOf(playhead_);
    if (x >= x0 - 1.f && x <= x1 + 1.f) {
      dl->AddLine(V(x, rMin.y), V(x, lMax.y), IM_COL32(255, 255, 255, 230), 2.f);
      dl->AddTriangleFilled(V(x - 6.f * ui, rMin.y), V(x + 6.f * ui, rMin.y), V(x, rMin.y + 9.f * ui),
                            IM_COL32(255, 255, 255, 240));
    }
  }

  // pan slider (only when zoomed in)
  if (zoom_ > 1.001f) {
    ImGui::SetCursorScreenPos(V(x0, lMax.y + 4.f * ui));
    ImGui::SetNextItemWidth(areaW);
    ImGui::SliderFloat("##pan", &scroll_, 0.f, std::max(0.01f, dur - visSec), "");
  }
}

}  // namespace cm
